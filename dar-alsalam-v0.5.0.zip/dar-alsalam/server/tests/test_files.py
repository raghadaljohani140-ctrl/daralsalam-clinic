import json
import re
import unittest
import urllib.error
import urllib.request

from helpers import Env

PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n" + b"x" * 300 + b"\n%%EOF\n"
PDF2 = b"%PDF-1.4\n% second version\n" + b"y" * 400 + b"\n%%EOF\n"
PROFILE = {"name": "مراجع اختبار", "gender": "male", "birthDate": "1990-01-01", "nationalId": ""}


def raw_req(e, method, path, data=None, headers=None):
    r = urllib.request.Request(e.base + path, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(r, timeout=10) as resp:
            return resp.status, resp.read(), dict(resp.headers)
    except urllib.error.HTTPError as ex:
        return ex.code, ex.read(), dict(ex.headers)


def login(e, phone):
    e.app.rl.h.clear()
    e.req("POST", "/api/v1/auth/otp", {"phone": phone})
    ph = re.sub(r"^0", "966", phone)
    lines = [json.loads(x) for x in (e.tmp / "sms-test.log").read_text(encoding="utf-8").strip().splitlines()]
    code = re.search(r"(\d{6})", [m for m in lines if m["phone"] == ph][-1]["text"]).group(1)
    s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": phone, "code": code, "profile": PROFILE})
    assert s == 200, d
    return {"Authorization": "Bearer " + d["token"]}


class TestPatientFiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e = Env({"DS_SMS_PROVIDER": "test"})
        cls.A = login(cls.e, "0565551111")
        cls.B = login(cls.e, "0566662222")

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def up(self, phone="0565551111", kind="lab", title="تحليل دم", by="سارة", data=PDF, token=True):
        from urllib.parse import urlencode
        h = {"Content-Type": "application/pdf"}
        if token:
            h["Authorization"] = "Bearer " + self.e.admin_token()
        s, b, _ = raw_req(self.e, "POST", "/api/admin/files?" + urlencode({"phone": phone, "kind": kind, "title": title, "by": by}), data, h)
        return s, json.loads(b or b"{}")

    def adm(self, method, path, body=None):
        return self.e.adm(method, path, body)

    def test_upload_requires_admin_and_valid_pdf(self):
        self.assertEqual(self.up(token=False)[0], 401)
        self.assertEqual(self.up(data=b"<html>x</html>" * 20)[0], 415)
        self.assertEqual(self.up(data=b"%PDF-1.4 no eof " + b"x" * 200)[0], 415)  # PDF مقطوع
        self.assertEqual(self.up(kind="nope")[0], 422)
        self.assertEqual(self.up(by="")[0], 422)
        self.assertEqual(self.up(phone="123")[0], 422)
        import http.client
        c = http.client.HTTPConnection("127.0.0.1", self.e.port, timeout=10)
        c.putrequest("POST", "/api/admin/files?phone=0565551111&kind=lab&title=xx&by=yy")
        c.putheader("Authorization", "Bearer " + self.e.admin_token())
        c.putheader("Content-Length", str(13 * 1024 * 1024))
        c.endheaders()
        self.assertEqual(c.getresponse().status, 413)
        c.close()
        # توكن مريض لا يرفع
        s, _, _ = raw_req(self.e, "POST", "/api/admin/files?phone=0565551111&kind=lab&title=xx&by=yy", PDF, {"Authorization": self.A["Authorization"]})
        self.assertEqual(s, 401)

    def test_isolation_between_patients(self):
        s, d = self.up(phone="0565551111", title="نتيجة خاصة بأ")
        self.assertEqual(s, 201, d)
        fid = d["file"]["id"]
        # صاحب الملف يراه ويحمّله
        s, d, _ = self.e.req("GET", "/api/v1/files", headers=self.A)
        self.assertIn(fid, [x["id"] for x in d["files"]])
        s, body, h = raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.A)
        self.assertEqual((s, body), (200, PDF))
        self.assertEqual(h["Content-Type"], "application/pdf")
        self.assertIn("no-store", h["Cache-Control"])
        self.assertIn("inline", h["Content-Disposition"])
        s, body, h = raw_req(self.e, "GET", "/api/v1/files/" + fid + "?dl=1", headers=self.A)
        self.assertIn("attachment", h["Content-Disposition"])
        # مراجع آخر: لا يرى القائمة ولا يفتح الملف (404 كأنه غير موجود)
        s, d, _ = self.e.req("GET", "/api/v1/files", headers=self.B)
        self.assertNotIn(fid, [x["id"] for x in d["files"]])
        s, _, _ = raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.B)
        self.assertEqual(s, 404)
        s, _, _ = raw_req(self.e, "GET", "/api/v1/files/f-" + "0" * 32, headers=self.B)
        self.assertEqual(s, 404)
        # بلا توكن
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid)[0], 401)
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files")[0], 401)
        # لا مسار عام للملفات
        for path in ("/files/" + fid + ".pdf", "/uploads/" + fid + ".pdf", "/data/files/" + fid + ".pdf", "/app/../data/files/" + fid + ".pdf", "/admin/" + fid + ".pdf"):
            self.assertEqual(raw_req(self.e, "GET", path)[0], 404, path)
        # توكن الإدارة ليس توكن مريض
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid, headers={"Authorization": "Bearer " + self.e.admin_token()})[0], 401)

    def test_phone_binding_before_registration(self):
        # ملف يُرفع لرقم لم يسجّل بعد ثم يظهر له عند تسجيله
        s, d = self.up(phone="0577773333", title="سجل مسبق", kind="records")
        self.assertEqual(s, 201)
        C = login(self.e, "0577773333")
        s, d2, _ = self.e.req("GET", "/api/v1/files?kind=records", headers=C)
        self.assertIn(d["file"]["id"], [x["id"] for x in d2["files"]])
        s, d2, _ = self.e.req("GET", "/api/v1/files?kind=lab", headers=C)
        self.assertEqual(d2["files"], [])

    def test_replace_update_delete_with_audit(self):
        s, d = self.up(phone="0565551111", title="للاستبدال", by="موظف أول")
        fid = d["file"]["id"]
        self.assertEqual(d["file"]["uploadedBy"], "موظف أول")
        tok = {"Authorization": "Bearer " + self.e.admin_token(), "Content-Type": "application/pdf"}
        s, b, _ = raw_req(self.e, "POST", "/api/admin/files/%s/replace?by=%s" % (fid, urllib.request.quote("موظف ثان")), PDF2, tok)
        self.assertEqual(s, 200, b)
        self.assertEqual(json.loads(b)["file"]["updatedBy"], "موظف ثان")
        s, body, _ = raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.A)
        self.assertEqual(body, PDF2)
        s, d, _ = self.adm("POST", "/files/%s/update?by=%s" % (fid, urllib.request.quote("موظف ثالث")), {"kind": "radiology", "title": "أشعة جديدة"})
        self.assertEqual((s, d["file"]["kind"], d["file"]["kindLabel"]), (200, "radiology", "نتائج الأشعة"))
        s, _, _ = self.adm("DELETE", "/files/%s?by=" % fid)
        self.assertEqual(s, 422)  # الحذف يتطلب اسم الموظف
        s, _, _ = self.adm("DELETE", "/files/%s?by=%s" % (fid, urllib.request.quote("موظف رابع")))
        self.assertEqual(s, 200)
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.A)[0], 404)  # اختفى من المريض
        s, d, _ = self.adm("GET", "/files?phone=0565551111&deleted=1")
        rec = next(x for x in d["files"] if x["id"] == fid)
        self.assertEqual((rec["deletedBy"], rec["updatedBy"]), ("موظف رابع", "موظف ثالث"))
        acts = [r["action"] for r in self.e.app.db.conn().execute("SELECT action FROM audit WHERE ref=?", (fid,))]
        for a in ("file_upload", "file_replace", "file_update", "file_delete", "file_view"):
            self.assertIn(a, acts)

    def test_admin_search_and_meta(self):
        s, d, _ = self.adm("GET", "/patients?q=0565551111")
        self.assertEqual(s, 200)
        self.assertTrue(any(x["phone"] == "966565551111" for x in d["patients"]))
        s, d, _ = self.adm("GET", "/patients?q=" + urllib.request.quote("مراجع"))
        self.assertGreaterEqual(len(d["patients"]), 2)
        _, ds, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertTrue(ds["meta"]["files"]["enabled"])
        self.assertEqual(len(ds["meta"]["files"]["kinds"]), 10)

    def test_disabled_when_no_sms(self):
        e = Env()
        try:
            self.assertEqual(e.req("GET", "/api/v1/files")[0], 503)
            _, ds, _ = e.req("GET", "/api/v1/clinic")
            self.assertFalse(ds["meta"]["files"]["enabled"])
        finally:
            e.close()


if __name__ == "__main__":
    unittest.main()
