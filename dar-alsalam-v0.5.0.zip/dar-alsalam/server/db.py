"""طبقة SQLite: جداول عامة للكيانات (فروع، أطباء...) + حجوزات + أجهزة + إشعارات + سجلات. بدون اعتماديات."""
import hashlib
import json
import secrets
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path

KINDS = ("branches", "specialties", "services", "doctors", "faqs", "banners")

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS entities(
  kind TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL,
  sort INTEGER NOT NULL DEFAULT 100, active INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL,
  PRIMARY KEY(kind,id));
CREATE INDEX IF NOT EXISTS ix_entities_kind ON entities(kind, active, sort);
CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS bookings(
  id TEXT PRIMARY KEY, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'new',
  name TEXT NOT NULL, phone TEXT NOT NULL, device_id TEXT NOT NULL,
  specialty_id TEXT, doctor_id TEXT, branch_id TEXT, service_id TEXT,
  date TEXT, period TEXT, note TEXT, source TEXT, admin_note TEXT, appointment_text TEXT);
CREATE INDEX IF NOT EXISTS ix_bookings_device ON bookings(device_id, created_at);
CREATE INDEX IF NOT EXISTS ix_bookings_status ON bookings(status, created_at);
CREATE TABLE IF NOT EXISTS devices(
  id TEXT PRIMARY KEY, created_at TEXT NOT NULL, last_seen TEXT NOT NULL, platform TEXT, push_token TEXT);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT NOT NULL DEFAULT 'all', title TEXT NOT NULL, body TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'info', ref TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_notif_target ON notifications(target, id);
CREATE TABLE IF NOT EXISTS qamar_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, device_hash TEXT, question TEXT, intent TEXT,
  confident INTEGER, used_llm INTEGER, source TEXT);
CREATE TABLE IF NOT EXISTS usage(day TEXT NOT NULL, key TEXT NOT NULL, n INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day,key));
CREATE TABLE IF NOT EXISTS patients(
  id TEXT PRIMARY KEY, phone TEXT NOT NULL UNIQUE, name TEXT NOT NULL, gender TEXT, birth_date TEXT, national_id TEXT,
  created_at TEXT NOT NULL, last_login TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS otps(
  phone TEXT PRIMARY KEY, code_hash TEXT NOT NULL, expires INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS patient_files(
  id TEXT PRIMARY KEY, phone TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, note TEXT, size INTEGER NOT NULL, sha256 TEXT NOT NULL,
  uploaded_by TEXT NOT NULL, uploaded_at TEXT NOT NULL, updated_by TEXT, updated_at TEXT, deleted_by TEXT, deleted_at TEXT);
CREATE INDEX IF NOT EXISTS ix_pfiles_phone ON patient_files(phone, deleted_at);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, who TEXT, action TEXT, kind TEXT, ref TEXT, detail TEXT);
"""

BOOKING_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def today():
    return time.strftime("%Y-%m-%d", time.gmtime())


def canon(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class DB:
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self.conn().executescript(SCHEMA_SQL)

    def conn(self):
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=15, isolation_level=None)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("PRAGMA busy_timeout=15000")
            self._local.c = c
        return c

    @contextmanager
    def tx(self):
        c = self.conn()
        c.execute("BEGIN IMMEDIATE")
        try:
            yield c
            c.execute("COMMIT")
        except BaseException:
            c.execute("ROLLBACK")
            raise

    # ------------------------------------------------------------------ kv
    def get_kv(self, key, default=None):
        r = self.conn().execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(r["value"]) if r else default

    def set_kv(self, key, value):
        with self.tx() as c:
            c.execute("INSERT INTO kv(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                      (key, json.dumps(value, ensure_ascii=False), now()))

    def is_seeded(self):
        return self.get_kv("settings") is not None

    # ------------------------------------------------------------------ كيانات
    @staticmethod
    def _row_entity(r):
        d = json.loads(r["data"])
        d["id"] = r["id"]
        d["sort"] = r["sort"]
        d["active"] = bool(r["active"])
        return d

    def list_entities(self, kind, include_inactive=False):
        q = "SELECT * FROM entities WHERE kind=?" + ("" if include_inactive else " AND active=1") + " ORDER BY sort, id"
        return [self._row_entity(r) for r in self.conn().execute(q, (kind,))]

    def get_entity(self, kind, eid):
        r = self.conn().execute("SELECT * FROM entities WHERE kind=? AND id=?", (kind, eid)).fetchone()
        return self._row_entity(r) if r else None

    def ids(self, kind):
        return {r["id"] for r in self.conn().execute("SELECT id FROM entities WHERE kind=?", (kind,))}

    def upsert_entity(self, kind, data, who="system"):
        eid = data["id"]
        sort = int(data.get("sort") if data.get("sort") is not None else 100)
        active = 1 if data.get("active", True) else 0
        payload = {k: v for k, v in data.items() if k not in ("id", "sort", "active")}
        existed = self.get_entity(kind, eid) is not None
        with self.tx() as c:
            c.execute("INSERT INTO entities(kind,id,data,sort,active,updated_at) VALUES(?,?,?,?,?,?) "
                      "ON CONFLICT(kind,id) DO UPDATE SET data=excluded.data, sort=excluded.sort, active=excluded.active, updated_at=excluded.updated_at",
                      (kind, eid, json.dumps(payload, ensure_ascii=False), sort, active, now()))
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)",
                      (now(), who, "update" if existed else "create", kind, eid, ""))
        self._bump()
        return self.get_entity(kind, eid)

    def delete_entity(self, kind, eid, hard=False, who="system"):
        e = self.get_entity(kind, eid)
        if not e:
            return False
        with self.tx() as c:
            if hard:
                c.execute("DELETE FROM entities WHERE kind=? AND id=?", (kind, eid))
            else:
                c.execute("UPDATE entities SET active=0, updated_at=? WHERE kind=? AND id=?", (now(), kind, eid))
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)",
                      (now(), who, "delete" if hard else "hide", kind, eid, json.dumps(e, ensure_ascii=False)[:2000] if hard else ""))
        self._bump()
        return True

    def _bump(self):
        v = int(self.get_kv("dataVersion", 0) or 0) + 1
        self.set_kv("dataVersion", v)

    # ------------------------------------------------------------------ تهيئة من ملف seed
    def seed(self, seed, who="seed"):
        with self.tx() as c:
            for kind in KINDS:
                for e in seed.get(kind, []):
                    e = dict(e)
                    eid = e["id"]
                    sort = int(e.get("sort", 100))
                    active = 1 if e.get("active", True) else 0
                    payload = {k: v for k, v in e.items() if k not in ("id", "sort", "active")}
                    c.execute("INSERT OR IGNORE INTO entities(kind,id,data,sort,active,updated_at) VALUES(?,?,?,?,?,?)",
                              (kind, eid, json.dumps(payload, ensure_ascii=False), sort, active, now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('settings',?,?)", (json.dumps(seed.get("settings", {}), ensure_ascii=False), now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('qamar',?,?)", (json.dumps(seed.get("qamar", {}), ensure_ascii=False), now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('meta',?,?)", (json.dumps(seed.get("meta", {}), ensure_ascii=False), now()))
            c.execute("INSERT OR IGNORE INTO kv(key,value,updated_at) VALUES('dataVersion','1',?)", (now(),))
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)", (now(), who, "seed", "", "", ""))

    # ------------------------------------------------------------------ مجموعة البيانات
    def dataset(self, public=True):
        ds = {"meta": {"version": int(self.get_kv("dataVersion", 1) or 1)},
              "settings": dict(self.get_kv("settings", {}) or {}),
              "qamar": dict(self.get_kv("qamar", {}) or {})}
        for kind in KINDS:
            items = self.list_entities(kind, include_inactive=not public)
            if public:
                items = [{k: v for k, v in e.items() if k not in ("needsReview", "active")} for e in items]
            ds[kind] = items
        if public:
            ds["settings"].pop("reviewNotes", None)
            if not ds["settings"].get("email"):
                ds["settings"]["email"] = ""
            ds["qamar"].pop("extraInstructions", None)
        return ds

    def etag(self, ds):
        return '"' + hashlib.sha256(canon(ds).encode("utf-8")).hexdigest()[:24] + '"'

    # ------------------------------------------------------------------ حجوزات
    def new_booking_id(self):
        for _ in range(20):
            bid = "DS-" + "".join(secrets.choice(BOOKING_ALPHABET) for _ in range(6))
            if not self.conn().execute("SELECT 1 FROM bookings WHERE id=?", (bid,)).fetchone():
                return bid
        raise RuntimeError("could not allocate booking id")

    def create_booking(self, rec):
        bid = self.new_booking_id()
        t = now()
        with self.tx() as c:
            c.execute("INSERT INTO bookings(id,created_at,updated_at,status,name,phone,device_id,specialty_id,doctor_id,branch_id,service_id,date,period,note,source) "
                      "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (bid, t, t, "new", rec["name"], rec["phone"], rec["device_id"], rec.get("specialty_id"), rec.get("doctor_id"),
                       rec.get("branch_id"), rec.get("service_id"), rec.get("date"), rec.get("period"), rec.get("note", ""), rec.get("source", "app")))
        return self.get_booking(bid)

    def get_booking(self, bid):
        r = self.conn().execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
        return dict(r) if r else None

    def list_bookings(self, device_id=None, status=None, q=None, limit=300):
        sql, args = "SELECT * FROM bookings WHERE 1=1", []
        if device_id:
            sql += " AND device_id=?"
            args.append(device_id)
        if status:
            sql += " AND status=?"
            args.append(status)
        if q:
            sql += " AND (id LIKE ? OR name LIKE ? OR phone LIKE ?)"
            args += ["%" + q + "%"] * 3
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(int(limit))
        return [dict(r) for r in self.conn().execute(sql, args)]

    def update_booking(self, bid, **fields):
        allowed = {"status", "admin_note", "appointment_text"}
        sets = {k: v for k, v in fields.items() if k in allowed}
        if not sets:
            return self.get_booking(bid)
        cols = ", ".join(f"{k}=?" for k in sets)
        with self.tx() as c:
            c.execute(f"UPDATE bookings SET {cols}, updated_at=? WHERE id=?", (*sets.values(), now(), bid))
        return self.get_booking(bid)

    def count_recent_bookings(self, device_id, hours=24):
        since = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - hours * 3600))
        r = self.conn().execute("SELECT COUNT(*) n FROM bookings WHERE device_id=? AND created_at>=?", (device_id, since)).fetchone()
        return r["n"]

    def booking_stats(self):
        out = {s: 0 for s in ("new", "contacted", "confirmed", "cancelled")}
        for r in self.conn().execute("SELECT status, COUNT(*) n FROM bookings GROUP BY status"):
            out[r["status"]] = r["n"]
        return out

    # ------------------------------------------------------------------ أجهزة وإشعارات
    def upsert_device(self, device_id, platform="", push_token=""):
        t = now()
        with self.tx() as c:
            c.execute("INSERT INTO devices(id,created_at,last_seen,platform,push_token) VALUES(?,?,?,?,?) "
                      "ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen, platform=CASE WHEN excluded.platform!='' THEN excluded.platform ELSE platform END, "
                      "push_token=CASE WHEN excluded.push_token!='' THEN excluded.push_token ELSE push_token END",
                      (device_id, t, t, platform or "", push_token or ""))

    def push_tokens(self, target="all", limit=500):
        if target == "all":
            rows = self.conn().execute("SELECT push_token FROM devices WHERE push_token!='' ORDER BY last_seen DESC LIMIT ?", (limit,))
        else:
            rows = self.conn().execute("SELECT push_token FROM devices WHERE id=? AND push_token!=''", (target,))
        return [r["push_token"] for r in rows]

    def delete_device_data(self, device_id):
        with self.tx() as c:
            c.execute("UPDATE bookings SET name='(محذوف)', phone='', note='', device_id=? WHERE device_id=?", ("deleted-" + secrets.token_hex(4), device_id))
            c.execute("DELETE FROM notifications WHERE target=?", (device_id,))
            c.execute("DELETE FROM devices WHERE id=?", (device_id,))

    # ------------------------------------------------------------------ مرضى مسجّلون (حساب بالجوال + رمز تحقق)
    def otp_put(self, phone, code_hash, ttl):
        t = int(time.time())
        with self.tx() as c:
            c.execute("INSERT OR REPLACE INTO otps(phone,code_hash,expires,attempts,created) VALUES(?,?,?,0,?)", (phone, code_hash, t + ttl, t))

    def otp_get(self, phone):
        r = self.conn().execute("SELECT * FROM otps WHERE phone=?", (phone,)).fetchone()
        return dict(r) if r else None

    def otp_fail(self, phone):
        with self.tx() as c:
            c.execute("UPDATE otps SET attempts=attempts+1 WHERE phone=?", (phone,))

    def otp_clear(self, phone):
        with self.tx() as c:
            c.execute("DELETE FROM otps WHERE phone=?", (phone,))

    def patient_by_phone(self, phone):
        r = self.conn().execute("SELECT * FROM patients WHERE phone=?", (phone,)).fetchone()
        return dict(r) if r else None

    def patient_by_id(self, pid):
        r = self.conn().execute("SELECT * FROM patients WHERE id=?", (pid,)).fetchone()
        return dict(r) if r else None

    def patient_create(self, phone, name, gender, birth_date, national_id):
        pid = "pt-" + secrets.token_hex(6)
        t = now()
        with self.tx() as c:
            c.execute("INSERT INTO patients(id,phone,name,gender,birth_date,national_id,created_at,last_login) VALUES(?,?,?,?,?,?,?,?)",
                      (pid, phone, name, gender, birth_date, national_id, t, t))
        return self.patient_by_id(pid)

    def patient_touch(self, pid):
        with self.tx() as c:
            c.execute("UPDATE patients SET last_login=? WHERE id=?", (now(), pid))

    def patient_update(self, pid, name, gender, birth_date, national_id):
        with self.tx() as c:
            c.execute("UPDATE patients SET name=?, gender=?, birth_date=?, national_id=? WHERE id=?", (name, gender, birth_date, national_id, pid))
        return self.patient_by_id(pid)

    def patient_delete(self, pid):
        """حذف الحساب: يمحو بيانات المريض، وتُجهَّل طلبات الحجز المرتبطة برقمه (مثل «حذف بياناتي»)."""
        p = self.patient_by_id(pid)
        if not p:
            return
        with self.tx() as c:
            c.execute("UPDATE bookings SET name='(محذوف)', phone='', note='', device_id=? WHERE phone=?", ("deleted-" + secrets.token_hex(4), p["phone"]))
            c.execute("DELETE FROM patients WHERE id=?", (pid,))
            c.execute("DELETE FROM otps WHERE phone=?", (p["phone"],))

    # ------------------------------------------------------------------ ملفات المرضى (PDF يرفعها الموظفون يدوياً)
    def audit(self, who, action, kind="", ref="", detail=""):
        with self.tx() as c:
            c.execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)", (now(), who, action, kind, ref, detail))

    def patients_search(self, q, limit=30):
        q = (q or "").strip()
        sql, args = "SELECT * FROM patients", []
        if q:
            digits = "".join(ch for ch in q if ch.isdigit())
            conds, args = ["name LIKE ?"], ["%" + q + "%"]
            if len(digits) >= 3:
                conds += ["phone LIKE ?", "national_id LIKE ?"]
                args += ["%" + digits.lstrip("0") + "%", "%" + digits + "%"]
            sql += " WHERE " + " OR ".join(conds)
        rows = self.conn().execute(sql + " ORDER BY last_login DESC LIMIT ?", args + [int(limit)])
        return [dict(r) for r in rows]

    def file_create(self, rec):
        fid = "f-" + secrets.token_hex(16)
        with self.tx() as c:
            c.execute("INSERT INTO patient_files(id,phone,kind,title,note,size,sha256,uploaded_by,uploaded_at) VALUES(?,?,?,?,?,?,?,?,?)",
                      (fid, rec["phone"], rec["kind"], rec["title"], rec.get("note", ""), rec["size"], rec["sha256"], rec["by"], now()))
        return self.file_get(fid)

    def file_get(self, fid):
        r = self.conn().execute("SELECT * FROM patient_files WHERE id=?", (fid,)).fetchone()
        return dict(r) if r else None

    def file_list(self, phone, include_deleted=False):
        sql = "SELECT * FROM patient_files WHERE phone=?" + ("" if include_deleted else " AND deleted_at IS NULL") + " ORDER BY uploaded_at DESC"
        return [dict(r) for r in self.conn().execute(sql, (phone,))]

    def file_counts(self):
        return {r["phone"]: r["n"] for r in self.conn().execute("SELECT phone, COUNT(*) n FROM patient_files WHERE deleted_at IS NULL GROUP BY phone")}

    def file_update(self, fid, by, **fields):
        allowed = {k: v for k, v in fields.items() if k in ("kind", "title", "note", "size", "sha256")}
        sets = ", ".join("%s=?" % k for k in allowed) + (", " if allowed else "") + "updated_by=?, updated_at=?"
        with self.tx() as c:
            c.execute("UPDATE patient_files SET " + sets + " WHERE id=?", list(allowed.values()) + [by, now(), fid])
        return self.file_get(fid)

    def file_soft_delete(self, fid, by):
        with self.tx() as c:
            c.execute("UPDATE patient_files SET deleted_by=?, deleted_at=? WHERE id=?", (by, now(), fid))

    def add_notification(self, title, body, target="all", kind="info", ref=""):
        with self.tx() as c:
            cur = c.execute("INSERT INTO notifications(target,title,body,kind,ref,created_at) VALUES(?,?,?,?,?,?)", (target, title, body, kind, ref, now()))
            return cur.lastrowid

    def list_notifications(self, device_id, since=0, limit=50):
        rows = self.conn().execute("SELECT * FROM notifications WHERE (target='all' OR target=?) AND id>? ORDER BY id DESC LIMIT ?",
                                   (device_id, int(since), int(limit)))
        return [dict(r) for r in rows]

    def list_all_notifications(self, limit=100):
        return [dict(r) for r in self.conn().execute("SELECT * FROM notifications ORDER BY id DESC LIMIT ?", (int(limit),))]

    # ------------------------------------------------------------------ سجلات وعدّادات
    def usage_incr(self, key, n=1):
        d = today()
        with self.tx() as c:
            c.execute("INSERT INTO usage(day,key,n) VALUES(?,?,?) ON CONFLICT(day,key) DO UPDATE SET n=n+excluded.n", (d, key, n))
            return c.execute("SELECT n FROM usage WHERE day=? AND key=?", (d, key)).fetchone()["n"]

    def usage_get(self, key):
        r = self.conn().execute("SELECT n FROM usage WHERE day=? AND key=?", (today(), key)).fetchone()
        return r["n"] if r else 0

    def log_qamar(self, device_id, question, intent, confident, used_llm, source):
        dh = hashlib.sha256(("ds|" + (device_id or "")).encode()).hexdigest()[:10]
        with self.tx() as c:
            c.execute("INSERT INTO qamar_log(ts,device_hash,question,intent,confident,used_llm,source) VALUES(?,?,?,?,?,?,?)",
                      (now(), dh, question[:240], intent, 1 if confident else 0, 1 if used_llm else 0, source))
            c.execute("DELETE FROM qamar_log WHERE id < (SELECT MAX(id) FROM qamar_log) - 2000")

    def recent_qamar_log(self, limit=100, only_unconfident=False):
        sql = "SELECT * FROM qamar_log" + (" WHERE confident=0" if only_unconfident else "") + " ORDER BY id DESC LIMIT ?"
        return [dict(r) for r in self.conn().execute(sql, (int(limit),))]

    def recent_audit(self, limit=100):
        return [dict(r) for r in self.conn().execute("SELECT id,ts,who,action,kind,ref FROM audit ORDER BY id DESC LIMIT ?", (int(limit),))]

    # ------------------------------------------------------------------ نسخ احتياطي
    def backup_to(self, dest):
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        out = sqlite3.connect(str(dest))
        try:
            self.conn().backup(out)
        finally:
            out.close()
        return str(dest)

    def export_all(self):
        ds = self.dataset(public=False)
        ds["meta"]["exportedAt"] = now()
        ds["bookings"] = self.list_bookings(limit=100000)
        return ds
