/* التسجيل برمز التحقق: خادم منفصل على :8091 بمزوّد test (يكتب الرمز في ملف بدل إرساله) */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const ROOT = require('path').resolve(__dirname, '..');
const DIR = '/tmp/ds-auth', BASE = 'http://127.0.0.1:8091';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  execSync('rm -rf ' + DIR + ' && mkdir -p ' + DIR);
  const env = Object.assign({}, process.env, { DS_DB: DIR + '/clinic.db', DS_PORT: '8091', DS_QUIET: '1', DS_SMS_PROVIDER: 'test' });
  execSync('python3 ' + ROOT + '/server/manage.py init --password devpass-12345', { env, stdio: 'ignore' });
  const srv = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  for (let i = 0; i < 30; i++) { try { const r = await fetch(BASE + '/api/v1/health'); if (r.ok) break; } catch (e) { /* انتظر */ } await sleep(300); }
  const code = () => { const l = fs.readFileSync(DIR + '/sms-test.log', 'utf8').trim().split('\n').pop(); return JSON.parse(l).text.match(/(\d{6})/)[1]; };
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar-SA' });
  const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  try {
    await page.goto(BASE + '/app/#/'); await page.waitForSelector('#view .qcard', { timeout: 8000 });
    await page.goto(BASE + '/app/#/doctors'); await sleep(500);
    ok(await page.locator('#view a[href^="#/doctor/"]').count() > 0, 'التصفح حر: صفحة الأطباء تعمل بلا تسجيل');
    await page.goto(BASE + '/app/#/book'); await page.waitForSelector('#a-phone', { timeout: 6000 });
    ok(page.url().includes('#/login') && page.url().includes('next='), 'فتح «احجز» بلا تسجيل يحوّل لصفحة الدخول مع العودة');
    await page.fill('#a-phone', '123'); await page.click('#au-phone button[type=submit]'); await sleep(300);
    ok(await page.locator('[data-err="a-phone"]:not([hidden])').count() === 1, 'رقم غير صحيح يُرفض برسالة');
    await page.fill('#a-phone', '0565551234'); await page.click('#au-phone button[type=submit]');
    await page.waitForSelector('#a-code', { timeout: 6000 });
    ok(await page.locator('#a-name').count() === 1, 'مستخدم جديد: تظهر حقول الاسم والجنس والميلاد');
    await page.fill('#a-code', code()); await page.click('#au-code button[type=submit]'); await sleep(600);
    ok(await page.locator('[data-err="a-name"]:not([hidden])').count() === 1, 'إكمال الحساب بلا بيانات يُرفض');
    await page.fill('#a-name', 'أحمد الجهني'); await page.selectOption('#a-gender', 'male'); await page.fill('#a-birthDate', '1989-07-25');
    await page.click('#au-code button[type=submit]');
    await page.waitForSelector('#f-name', { timeout: 8000 });
    ok(page.url().includes('#/book') && await page.inputValue('#f-name') === 'أحمد الجهني' && await page.inputValue('#f-phone') === '0565551234', 'بعد التسجيل يعود لصفحة الحجز والاسم والجوال معبّآن');
    ok(await page.evaluate(() => document.querySelector('#f-name').readOnly && document.querySelector('#f-phone').readOnly), 'الاسم والجوال للقراءة فقط (من الحساب)');
    await page.selectOption('#f-sel', { index: 1 });
    await page.locator('#f-consent').check().catch(() => {});
    await page.click('#f-submit'); await page.waitForSelector('.bk-id', { timeout: 8000 });
    ok(/^DS-[A-Z0-9]{6}$/.test((await page.locator('.bk-id').innerText()).trim()), 'إرسال الطلب بعد التسجيل ينجح ويظهر رقم الطلب');
    await page.goto(BASE + '/app/#/profile'); await sleep(600);
    ok(await page.locator('[data-act="au-logout"]').count() === 1, 'صفحة طلباتي فيها بطاقة الحساب مع تسجيل الخروج');
    await page.evaluate(() => document.querySelector('[data-act="au-logout"]').click()); await sleep(500);
    await page.goto(BASE + '/app/#/book'); await page.waitForSelector('#a-phone', { timeout: 6000 });
    ok(true, 'بعد الخروج يطلب الحجز التسجيل من جديد');

    /* ---------- الملفات الطبية: الموظف يرفع، المريض يرى ملفاته فقط ---------- */
    const pdf = Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n' + 'x'.repeat(300) + '\n%%EOF\n');
    const adm = await ctx.newPage();
    await adm.goto(BASE + '/admin/'); await adm.fill('input[type=password]', 'devpass-12345'); await adm.keyboard.press('Enter'); await sleep(1500);
    await adm.goto(BASE + '/admin/#/files'); await adm.waitForSelector('#pt-q');
    await adm.fill('#pt-q', '0565551234'); await sleep(900);
    ok(await adm.locator('tr[data-a="pt-open"]').count() === 1, 'الإدارة: البحث عن المراجع بالجوال يجد حسابه');
    await adm.click('tr[data-a="pt-open"]'); await adm.waitForSelector('#pf-form');
    await adm.selectOption('#pf-kind', 'lab'); await adm.fill('#pf-title', 'تحليل دم شامل'); await adm.fill('#pf-by', 'الموظفة سارة');
    await adm.setInputFiles('#pf-file', { name: 'x.pdf', mimeType: 'application/pdf', buffer: pdf });
    await adm.click('#pf-form button[type=submit]'); await adm.waitForSelector('[data-a="pf-view"]', { timeout: 8000 });
    ok(/نتائج المختبر/.test(await adm.locator('#pf-list').innerText()) && /الموظفة سارة/.test(await adm.locator('#pf-list').innerText()), 'الإدارة: الملف ظهر بنوعه واسم من رفعه');
    await adm.fill('#pf-title', 'ملف غير PDF'); await adm.fill('#pf-by', 'سارة');
    await adm.setInputFiles('#pf-file', { name: 'x.pdf', mimeType: 'application/pdf', buffer: Buffer.from('<html>' + 'x'.repeat(200)) });
    await adm.click('#pf-form button[type=submit]'); await sleep(700);
    ok(await adm.locator('#pf-err:not([hidden])').count() === 1, 'الإدارة: رفع ملف ليس PDF يُرفض برسالة');
    // المريض (يسجّل الدخول من جديد لأننا خرجنا)
    await page.goto(BASE + '/app/#/book'); await page.waitForSelector('#a-phone');
    await page.fill('#a-phone', '0565551234'); await page.click('#au-phone button[type=submit]'); await page.waitForSelector('#a-code');
    ok(await page.locator('#a-name').count() === 0, 'مستخدم موجود: لا يُطلب منه إكمال البيانات');
    await page.fill('#a-code', code()); await page.click('#au-code button[type=submit]'); await page.waitForSelector('#f-name', { timeout: 8000 });
    await page.goto(BASE + '/app/#/'); await sleep(900);
    ok(await page.locator('.qcard a[href="#/files/lab"]').count() === 1 && await page.locator('.qcard .qt.soon').count() === 0, 'الرئيسية: بطاقات الخدمات صارت حيّة (لا «قريباً») وتفتح ملفات المراجع');
    await page.goto(BASE + '/app/#/files/lab'); await page.waitForSelector('.card.fl', { timeout: 8000 });
    ok(/تحليل دم شامل/.test(await page.locator('#fl-box').innerText()), 'التطبيق: المريض يرى الملف في «نتائج المختبر» باسمه وتاريخه');
    await page.goto(BASE + '/app/#/files/radiology'); await sleep(900);
    ok(await page.locator('.card.fl').count() === 0, 'التطبيق: لا ملفات في نوع آخر');
    await page.goto(BASE + '/app/#/files/lab'); await page.waitForSelector('.card.fl');
    const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 8000 }), page.evaluate(() => document.querySelector('[data-act="fl-dl"]').click())]);
    const path = await dl.path();
    ok(fs.readFileSync(path).slice(0, 5).toString() === '%PDF-', 'التطبيق: تحميل الملف يعطي PDF صالحاً');
    // مراجع آخر لا يرى ملفات الأول
    const ctx2 = await b.newContext({ viewport: { width: 390, height: 844 } }); const p2 = await ctx2.newPage();
    await p2.goto(BASE + '/app/#/book'); await p2.waitForSelector('#a-phone');
    await p2.fill('#a-phone', '0557778888'); await p2.click('#au-phone button[type=submit]'); await p2.waitForSelector('#a-code');
    await p2.fill('#a-code', code()); await p2.fill('#a-name', 'مراجع آخر'); await p2.selectOption('#a-gender', 'female'); await p2.fill('#a-birthDate', '1995-05-05');
    await p2.click('#au-code button[type=submit]'); await p2.waitForSelector('#f-name', { timeout: 8000 });
    await p2.goto(BASE + '/app/#/files/lab'); await sleep(1200);
    ok(await p2.locator('.card.fl').count() === 0, 'مراجع آخر: لا يرى ملفات المراجع الأول');
    const fid = (await (await fetch(BASE + '/api/admin/files?phone=0565551234', { headers: { Authorization: 'Bearer ' + (await (await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: 'devpass-12345' }) })).json()).token } })).json()).files[0].id;
    const tok2 = await p2.evaluate(() => JSON.parse(localStorage.getItem('ds.ptoken')));
    const direct = await fetch(BASE + '/api/v1/files/' + fid, { headers: { Authorization: 'Bearer ' + tok2 } });
    ok(direct.status === 404, 'مراجع آخر: فتح رابط الملف مباشرة بتوكنه يعطي 404');
    ok((await fetch(BASE + '/api/v1/files/' + fid)).status === 401, 'بلا تسجيل: الملف 401');
    await ctx2.close();
    ok(errs.length === 0, 'لا أخطاء جافاسكربت: ' + errs.join('|'));
  } catch (e) { fail++; console.log('CRASH', e.message); }
  await b.close(); srv.kill();
  console.log('النتيجة: ' + pass + ' ناجح، ' + fail + ' فاشل');
  process.exit(fail ? 1 : 0);
})();
