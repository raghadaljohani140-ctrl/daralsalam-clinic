/* شاشات الطبيب في بوابة الموظفين: طابور «عيادتي»، استدعاء المراجع، تسجيل الزيارة (تشخيص ووصفة وطلبات)، حفظ تلقائي، إنهاء الزيارة.
   واجهة فقط: الخادم هو من يتحقق أن الزيارة زيارتك، وأنها لم تُقفل، وأن المراجع واحد في العيادة. يعتمد على window.DSX من staff.js. */
(function () {
  'use strict';
  var X = window.DSX;
  if (!X) return;
  var F = X.F, api = X.api, $ = X.$, esc = X.esc, toast = X.toast, hm = X.hm, mins = X.mins;
  var C = { q: null, cur: null, form: null, dirty: false, saving: null, again: false, timer: null };
  var LIM = { rx: 20, od: 20 };
  var GENDER = { male: 'ذكر', female: 'أنثى' };
  var FREQ = ['مرة يومياً', 'مرتين يومياً', '3 مرات يومياً', '4 مرات يومياً', 'كل 8 ساعات', 'كل 12 ساعة', 'عند اللزوم'];
  var DUR = ['3 أيام', '5 أيام', '7 أيام', '10 أيام', '14 يوماً', 'شهر', 'مستمر'];
  var LAB = ['صورة دم كاملة (CBC)', 'سكر صائم', 'سكر تراكمي (HbA1c)', 'وظائف كلى', 'وظائف كبد', 'دهون الدم', 'فيتامين د', 'فحص بول', 'مزرعة'];
  var RAD = ['أشعة صدر', 'أشعة عمود فقري', 'أشعة ركبة', 'أشعة أسنان بانوراما', 'سونار بطن', 'سونار حوض'];

  function chip(st, label) { return '<span class="chip ' + esc(st) + '">' + esc(label) + '</span>'; }
  function dl(id, a) { return '<datalist id="' + id + '">' + a.map(function (x) { return '<option value="' + esc(x) + '">'; }).join('') + '</datalist>'; }
  function genderOf(g) { return GENDER[g] || ''; }
  function err(e) { return '<div class="alert danger">' + esc(e.status === 403 && e.code === 'forbidden' ? 'حسابك غير مرتبط بطبيب. اطلب من الإدارة ربطه بسجل الطبيب.' : e.message) + '</div>'; }

  /* ---------- الطابور ---------- */
  function queueView() {
    leave(); C.cur = null; C.form = null;
    $('#view').innerHTML = '<div class="tools"><h1 style="font-size:1.2rem;flex:1">عيادتي <span class="muted sm" id="cl-doc"></span></h1><button class="btn ghost sm" data-a="cl-refresh">تحديث</button></div><div id="cl-sum"></div><div id="cl-box"><p class="muted">جارٍ التحميل…</p></div>';
    loadQueue();
  }
  function loadQueue() {
    return api('GET', '/clinic/queue').then(function (r) { C.q = r; if (!C.cur) renderQueue(); }).catch(function (e) { var b = $('#cl-box'); if (b && e.status !== 401) b.innerHTML = err(e); });
  }
  var RANK = { with_doctor: 0, ready: 1, waiting: 2, done: 3, left: 4, cancelled: 5 };
  function renderQueue() {
    var box = $('#cl-box'); if (!box || !C.q) return;
    var vs = C.q.visits.slice().sort(function (a, b) { return (RANK[a.status] - RANK[b.status]) || (a.queueNo - b.queueNo); });
    var n = { wait: 0, in: 0, fin: 0 };
    vs.forEach(function (v) { if (v.status === 'waiting' || v.status === 'ready') n.wait++; else if (v.status === 'with_doctor') n.in++; else if (v.status === 'done' || v.status === 'left') n.fin++; });
    $('#cl-doc').textContent = C.q.doctor.name ? '— ' + C.q.doctor.name : '';
    $('#cl-sum').innerHTML = '<div class="sumbar three"><div><b>' + n.wait + '</b>ينتظرون</div><div><b>' + n.in + '</b>عندي الآن</div><div><b>' + n.fin + '</b>انتهت زياراتهم</div></div>';
    var inside = vs.filter(function (v) { return v.status === 'with_doctor'; })[0], next = vs.filter(function (v) { return v.status === 'ready' || v.status === 'waiting'; })[0];
    var hero = inside ? '<div class="hero in"><div><b>عندك الآن: ' + esc(inside.patientName) + '</b><div class="sm">رقم ' + inside.queueNo + (inside.reason ? ' · ' + esc(inside.reason) : '') + '</div></div><button class="btn pri" data-a="cl-open" data-id="' + inside.id + '">متابعة الزيارة</button></div>'
      : next ? '<div class="hero"><div><b>التالي: ' + esc(next.patientName) + '</b><div class="sm">رقم ' + next.queueNo + ' · ينتظر ' + mins(next.arrivedAt) + ' د' + (next.reason ? ' · ' + esc(next.reason) : '') + '</div></div><button class="btn pri" data-a="cl-callopen" data-id="' + next.id + '">استدعاء</button></div>'
        : '<div class="hero idle"><b>لا مراجعين في الانتظار الآن</b></div>';
    box.innerHTML = hero + (vs.length ? vs.map(function (v) {
      var live = v.status === 'waiting' || v.status === 'ready';
      return '<button type="button" class="vrow qrow ' + v.status + '" data-a="cl-open" data-id="' + v.id + '"><span class="no">' + v.queueNo + '</span><span><b>' + esc(v.patientName) + '</b> ' + chip(v.status, v.statusLabel) +
        (v.hasSummary ? ' <span class="chip rx">وصفة ' + v.rxCount + '</span><span class="chip rx">طلبات ' + v.orderCount + '</span>' : '') +
        '<span class="xs muted" style="display:block">' + [v.age, genderOf(v.gender), live ? 'ينتظر ' + mins(v.arrivedAt) + ' د' : (v.calledAt ? 'دخل ' + hm(v.calledAt) : ''), v.reason].filter(Boolean).map(esc).join(' · ') + '</span></span><span class="muted">‹</span></button>';
    }).join('') : '<div class="card muted">لا زيارات مسجّلة لك اليوم بعد. يظهر المراجع هنا حين يسجّل الاستقبال وصوله.</div>');
  }
  F['cl-refresh'] = function () { loadQueue(); };
  F['cl-open'] = function (el) { location.hash = '#/clinic/' + el.getAttribute('data-id'); };
  F['cl-back'] = function () { location.hash = '#/clinic'; };
  F['cl-callopen'] = function (el) {
    var id = el.getAttribute('data-id');
    api('POST', '/clinic/visits/' + id + '/call').then(function () { location.hash = '#/clinic/' + id; }).catch(function (e) { toast(e.message, true); loadQueue(); });
  };

  /* ---------- شاشة الزيارة ---------- */
  function visitView(vid) {
    leave(); C.cur = null;
    $('#view').innerHTML = '<p class="muted">جارٍ التحميل…</p>';
    api('GET', '/clinic/visits/' + encodeURIComponent(vid)).then(function (r) {
      if (!$('#view') || location.hash.indexOf(vid) < 0) return;
      C.cur = r; C.form = formFrom(r.encounter); C.dirty = false; renderVisit();
    }).catch(function (e) { if (e.status === 404) { toast('الزيارة غير موجودة', true); location.hash = '#/clinic'; } else if ($('#view')) $('#view').innerHTML = err(e); });
  }
  function formFrom(e) {
    e = e || {};
    return { complaint: e.complaint || '', diagnosis: e.diagnosis || '', notes: e.notes || '', advice: e.advice || '', followUp: e.followUp || '', publish: e.publish !== false,
      rx: (e.rx || []).map(function (x) { return { drug: x.drug || '', dose: x.dose || '', freq: x.freq || '', duration: x.duration || '', note: x.note || '' }; }),
      orders: (e.orders || []).map(function (x) { return { type: x.type === 'radiology' ? 'radiology' : 'lab', name: x.name || '', note: x.note || '' }; }) };
  }
  function renderVisit() {
    var r = C.cur, v = r.visit, p = r.patient, st = v.status;
    var head = '<div class="tools"><button class="btn ghost sm" data-a="cl-back">→ الطابور</button><span style="flex:1"></span>' + chip(st, v.statusLabel) + '</div>' +
      '<div class="card ptcard"><span class="no big">' + v.queueNo + '</span><div><h2>' + esc(p.name) + '</h2><div class="sm muted">' +
      [esc(p.age), esc(genderOf(p.gender)), '<span class="ltr">' + esc(p.mrn) + '</span>', p.nationalIdMasked ? 'هوية <span class="ltr">' + esc(p.nationalIdMasked) + '</span>' : ''].filter(Boolean).join(' · ') + '</div>' +
      (v.reason ? '<div class="sm"><b>سبب الزيارة:</b> ' + esc(v.reason) + '</div>' : '') + '</div></div>';
    var body = st === 'waiting' || st === 'ready' ? callBox(r) : st === 'with_doctor' ? formHtml() : st === 'cancelled' ? '<div class="card muted">أُلغيت هذه الزيارة.</div>' : doneHtml(r);
    $('#view').innerHTML = head + body + historyHtml(r) + filesHtml(r);
    if (st === 'with_doctor') { renderRows(); setState(''); }
  }
  function callBox(r) {
    var v = r.visit;
    if (r.busy) return '<div class="alert warn">عندك مراجع في العيادة الآن؛ أنهِ زيارته ثم استدعِ هذا المراجع. <button class="btn sm ghost" data-a="cl-open" data-id="' + esc(r.busy) + '">فتح زيارته</button></div>';
    return '<div class="card"><p>المراجع في الانتظار منذ <b>' + mins(v.arrivedAt) + ' د</b>' + (v.status === 'ready' ? ' — جاهز للطبيب.' : '.') + '</p><button class="btn pri big" data-a="cl-call" data-id="' + esc(v.id) + '">استدعاء المراجع</button></div>';
  }
  F['cl-call'] = function (el) {
    var id = el.getAttribute('data-id'); el.disabled = true;
    api('POST', '/clinic/visits/' + id + '/call').then(function () { visitView(id); }).catch(function (e) { toast(e.message, true); visitView(id); });
  };

  /* ---------- نموذج الزيارة ---------- */
  function sec(title, inner, help) { return '<section class="card clsec"><h3>' + title + '</h3>' + inner + (help ? '<p class="help">' + help + '</p>' : '') + '</section>'; }
  function formHtml() {
    var f = C.form;
    var ta = function (k, label, max, rows) { return '<div class="fld"><label for="cf-' + k + '">' + label + '</label><textarea class="in" id="cf-' + k + '" data-cf="' + k + '" maxlength="' + max + '" rows="' + rows + '">' + esc(f[k]) + '</textarea></div>'; };
    return '<form class="clform" data-f="cl-noop" autocomplete="off"><div class="alert danger" id="cl-err" role="alert" hidden></div>' +
      sec('الشكوى والتشخيص', ta('complaint', 'الشكوى', 500, 2) + '<div class="fld"><label for="cf-diagnosis">التشخيص <span class="muted">(مطلوب لإنهاء الزيارة)</span></label><input class="in" id="cf-diagnosis" data-cf="diagnosis" maxlength="500" value="' + esc(f.diagnosis) + '"></div>') +
      sec('الوصفة', '<div id="cl-rx"></div>', 'اكتب الدواء كما تريده في الوصفة. هذه المنظومة التجريبية لا تفحص التداخلات الدوائية ولا الحساسية.') +
      sec('تحاليل وأشعة', '<div id="cl-od"></div>') +
      sec('للمراجع', ta('advice', 'تعليمات (تظهر للمراجع)', 1500, 3) + '<div class="fld"><label for="cf-followUp">موعد المراجعة</label><input class="in" id="cf-followUp" data-cf="followUp" maxlength="200" placeholder="مثال: بعد أسبوع" value="' + esc(f.followUp) + '"></div>') +
      sec('ملاحظات داخلية', ta('notes', 'لا تظهر للمراجع، ويراها الأطباء الذين يعالجونه لاحقاً', 3000, 3)) +
      '<label class="chk"><input type="checkbox" id="cf-publish" ' + (f.publish ? 'checked' : '') + '> أُظهر ملخص الزيارة (التشخيص والتعليمات والوصفة والطلبات) في تطبيق المراجع بعد الإنهاء</label>' +
      '<div class="clbar"><span id="cl-state" class="sm muted" aria-live="polite"></span><button class="btn pri" type="button" data-a="cl-finish">إنهاء الزيارة</button></div></form>' +
      dl('dl-freq', FREQ) + dl('dl-dur', DUR) + dl('dl-lab', LAB) + dl('dl-rad', RAD);
  }
  function renderRows() {
    var f = C.form, rx = $('#cl-rx'), od = $('#cl-od'); if (!rx || !od) return;
    var mini = function (label, attrs, val, list, max) { return '<label class="mini">' + label + '<input class="in" ' + attrs + ' maxlength="' + max + '" value="' + esc(val) + '"' + (list ? ' list="' + list + '"' : '') + '></label>'; };
    rx.innerHTML = f.rx.map(function (r, i) {
      var a = function (k) { return 'data-rx="' + k + '" data-i="' + i + '"'; };
      return '<div class="rxrow"><div class="rxh"><b>دواء ' + (i + 1) + '</b><button type="button" class="btn ghost sm" data-a="cl-rx-del" data-i="' + i + '">حذف</button></div>' + mini('اسم الدواء', a('drug'), r.drug, '', 80) +
        '<div class="rx4">' + mini('الجرعة', a('dose'), r.dose, '', 60) + mini('التكرار', a('freq'), r.freq, 'dl-freq', 60) + mini('المدة', a('duration'), r.duration, 'dl-dur', 60) + mini('ملاحظة', a('note'), r.note, '', 120) + '</div></div>';
    }).join('') + (f.rx.length < LIM.rx ? '<button type="button" class="btn ghost sm" data-a="cl-rx-add">+ إضافة دواء</button>' : '<p class="help">وصلت الحد الأقصى (' + LIM.rx + ').</p>');
    od.innerHTML = f.orders.map(function (r, i) {
      var a = function (k) { return 'data-od="' + k + '" data-i="' + i + '"'; };
      return '<div class="rxrow"><div class="rxh"><b>طلب ' + (i + 1) + '</b><button type="button" class="btn ghost sm" data-a="cl-od-del" data-i="' + i + '">حذف</button></div><div class="rx4">' +
        '<label class="mini">النوع<select class="in" ' + a('type') + '><option value="lab"' + (r.type === 'lab' ? ' selected' : '') + '>تحليل</option><option value="radiology"' + (r.type === 'radiology' ? ' selected' : '') + '>أشعة</option></select></label>' +
        mini('الاسم', a('name'), r.name, r.type === 'lab' ? 'dl-lab' : 'dl-rad', 100) + mini('ملاحظة', a('note'), r.note, '', 120) + '</div></div>';
    }).join('') + (f.orders.length < LIM.od ? '<button type="button" class="btn ghost sm" data-a="cl-od-add">+ إضافة تحليل أو أشعة</button>' : '<p class="help">وصلت الحد الأقصى (' + LIM.od + ').</p>');
  }
  F['cl-rx-add'] = function () { C.form.rx.push({ drug: '', dose: '', freq: '', duration: '', note: '' }); renderRows(); var l = document.querySelectorAll('[data-rx=drug]'); if (l.length) l[l.length - 1].focus(); };
  F['cl-rx-del'] = function (el) { C.form.rx.splice(+el.getAttribute('data-i'), 1); renderRows(); markDirty(); };
  F['cl-od-add'] = function () { C.form.orders.push({ type: 'lab', name: '', note: '' }); renderRows(); var l = document.querySelectorAll('[data-od=name]'); if (l.length) l[l.length - 1].focus(); };
  F['cl-od-del'] = function (el) { C.form.orders.splice(+el.getAttribute('data-i'), 1); renderRows(); markDirty(); };
  F['cl-noop'] = function () { /* لا إرسال بزر Enter */ };

  document.addEventListener('input', function (ev) {
    var t = ev.target; if (!C.cur || !C.form || !t || !t.getAttribute) return;
    var k = t.getAttribute('data-cf'), i = +t.getAttribute('data-i'), rk = t.getAttribute('data-rx'), ok = t.getAttribute('data-od');
    if (k) C.form[k] = t.value; else if (rk && C.form.rx[i]) C.form.rx[i][rk] = t.value; else if (ok && ok !== 'type' && C.form.orders[i]) C.form.orders[i][ok] = t.value; else return;
    markDirty();
  });
  document.addEventListener('change', function (ev) {
    var t = ev.target; if (!C.cur || !C.form || !t || !t.getAttribute) return;
    if (t.id === 'cf-publish') { C.form.publish = !!t.checked; markDirty(); }
    else if (t.getAttribute('data-od') === 'type') {
      var i = +t.getAttribute('data-i'); if (!C.form.orders[i]) return;
      C.form.orders[i].type = t.value === 'radiology' ? 'radiology' : 'lab';
      var nm = t.closest('.rxrow').querySelector('[data-od=name]'); if (nm) nm.setAttribute('list', t.value === 'lab' ? 'dl-lab' : 'dl-rad');
      markDirty();
    }
  });

  /* ---------- الحفظ التلقائي ---------- */
  function setState(msg, bad) { var s = $('#cl-state'); if (s) { s.textContent = msg; s.className = 'sm ' + (bad ? 'bad' : 'muted'); } }
  function markDirty() { C.dirty = true; setState('تعديلات لم تُحفظ بعد…'); clearTimeout(C.timer); C.timer = setTimeout(saveNow, 1200); }
  function payload(full) {
    var f = C.form;
    return { complaint: f.complaint, diagnosis: f.diagnosis, notes: f.notes, advice: f.advice, followUp: f.followUp, publish: f.publish,
      // أثناء الكتابة نتجاوز الصفوف التي لم يُكتب اسمها بعد حتى لا يرفضها الخادم؛ عند الإنهاء تُرسل كلها ويُبلَّغ الطبيب بالناقص
      rx: full ? f.rx : f.rx.filter(function (r) { return r.drug.trim(); }), orders: full ? f.orders : f.orders.filter(function (r) { return r.name.trim(); }) };
  }
  function saveNow() {
    clearTimeout(C.timer);
    if (!C.cur || !C.form || !C.dirty) return Promise.resolve(true);
    if (C.saving) { C.again = true; return C.saving; }
    var vid = C.cur.visit.id, body = payload(false);
    C.dirty = false; setState('جارٍ الحفظ…');
    C.saving = api('PUT', '/clinic/visits/' + vid + '/encounter', body).then(function () {
      C.saving = null;
      if (C.cur && C.cur.visit.id === vid) setState('تم الحفظ ' + hm(new Date().toISOString()));
      if (C.again) { C.again = false; if (C.dirty) return saveNow(); }
      return true;
    }).catch(function (e) {
      C.saving = null; C.again = false;
      if (C.cur && C.cur.visit.id === vid) {
        if (e.code === 'locked' || e.code === 'bad_transition') { C.dirty = false; toast(e.code === 'locked' ? 'انتهت هذه الزيارة ولا يمكن تعديلها' : 'تغيّرت حالة الزيارة، أعدت تحميلها', true); visitView(vid); }
        else { C.dirty = true; setState('تعذّر الحفظ: ' + (e.data && e.data.fields ? X.fieldErr(e) : e.message) + ' — سنعيد المحاولة عند أي تعديل', true); }
      }
      return false;
    });
    return C.saving;
  }
  function leave() { if (C.dirty && C.cur) saveNow(); clearTimeout(C.timer); }
  window.addEventListener('beforeunload', function (ev) { if (C.dirty) { ev.preventDefault(); ev.returnValue = ''; } });
  document.addEventListener('visibilitychange', function () { if (document.hidden && C.dirty) saveNow(); });

  /* ---------- إنهاء الزيارة ---------- */
  function problems() {
    var f = C.form, out = [];
    if (f.diagnosis.trim().length < 2) out.push('اكتب التشخيص');
    f.rx.forEach(function (r, i) { if ((r.dose || r.freq || r.duration || r.note) && !r.drug.trim()) out.push('اكتب اسم الدواء في الدواء ' + (i + 1)); });
    f.orders.forEach(function (r, i) { if (r.note && !r.name.trim()) out.push('اكتب اسم الطلب في الطلب ' + (i + 1)); });
    return out;
  }
  F['cl-finish'] = function () {
    var e = $('#cl-err'), p = problems(); e.hidden = !p.length; e.textContent = p.join(' · ');
    if (p.length) { e.scrollIntoView({ block: 'center' }); return; }
    var f = C.form, n = f.rx.filter(function (r) { return r.drug.trim(); }).length, m = f.orders.filter(function (r) { return r.name.trim(); }).length;
    X.openModal('إنهاء زيارة ' + C.cur.patient.name, '<p class="sm"><b>التشخيص:</b> ' + esc(f.diagnosis) + '<br>' + n + ' دواء · ' + m + ' طلب</p>' +
      '<p class="sm">بعد الإنهاء <b>لا يمكن تعديل الزيارة</b>. ' + (f.publish ? 'سيصل المراجع إشعار بأن ملخصه جاهز في تطبيقه.' : 'لن يظهر الملخص في تطبيق المراجع (ألغيتَ خيار الإظهار)، ويطبعه الاستقبال له.') + '</p>' +
      '<div class="alert danger sm" id="cl-fin-err" hidden></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn pri" data-a="cl-finish-yes">إنهاء الزيارة</button><button class="btn ghost" data-a="modal-close">رجوع للتعديل</button></div>');
  };
  F['cl-finish-yes'] = function (el) {
    el.disabled = true; var vid = C.cur.visit.id, box = $('#cl-fin-err');
    saveNow().then(function () {
      return api('POST', '/clinic/visits/' + vid + '/finish', payload(true));
    }).then(function (r) {
      X.closeModal(); C.dirty = false; clearTimeout(C.timer); toast('تم إنهاء الزيارة'); visitView(vid);
    }).catch(function (e) { el.disabled = false; box.textContent = X.fieldErr(e); box.hidden = false; });
  };

  /* ---------- زيارة منتهية (قراءة فقط) + السجل + الملفات ---------- */
  function rxTable(rx) {
    return rx.length ? '<div class="scrollx"><table class="tbl"><thead><tr><th>الدواء</th><th>الجرعة</th><th>التكرار</th><th>المدة</th><th>ملاحظة</th></tr></thead><tbody>' + rx.map(function (r) {
      return '<tr><td><b>' + esc(r.drug) + '</b></td><td>' + esc(r.dose) + '</td><td>' + esc(r.freq) + '</td><td>' + esc(r.duration) + '</td><td>' + esc(r.note) + '</td></tr>'; }).join('') + '</tbody></table></div>' : '<p class="muted sm">لا أدوية.</p>';
  }
  function orderList(o) { return o.length ? '<ul class="sm" style="margin:0;padding-inline-start:18px">' + o.map(function (x) { return '<li>' + (x.type === 'lab' ? 'تحليل' : 'أشعة') + ': ' + esc(x.name) + (x.note ? ' — ' + esc(x.note) : '') + '</li>'; }).join('') + '</ul>' : '<p class="muted sm">لا طلبات.</p>'; }
  function doneHtml(r) {
    var e = r.encounter, v = r.visit;
    if (!e) return '<div class="card muted">لا سجل سريري لهذه الزيارة (أُغلقت من الاستقبال دون كتابة الطبيب).</div>';
    return '<section class="card"><h3>ملخص الزيارة</h3>' + (e.complaint ? '<p class="sm"><b>الشكوى:</b> ' + esc(e.complaint) + '</p>' : '') + '<p><b>التشخيص:</b> ' + esc(e.diagnosis) + '</p>' + '<h4>الوصفة</h4>' + rxTable(e.rx) + '<h4>تحاليل وأشعة</h4>' + orderList(e.orders) +
      (e.advice ? '<h4>تعليمات للمراجع</h4><p class="sm pre">' + esc(e.advice) + '</p>' : '') + (e.followUp ? '<p class="sm"><b>المراجعة:</b> ' + esc(e.followUp) + '</p>' : '') +
      (e.notes ? '<h4>ملاحظات داخلية</h4><p class="sm pre">' + esc(e.notes) + '</p>' : '') +
      '<p class="sm muted">' + (e.publish ? 'ظاهر للمراجع في تطبيقه.' : 'غير ظاهر للمراجع في تطبيقه.') + (e.finishedAt ? ' أُنهيت ' + hm(e.finishedAt) + '.' : '') + '</p>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn pri" data-a="cl-print" data-id="' + esc(v.id) + '">طباعة الملخص</button><button class="btn ghost" data-a="cl-back">العودة للطابور</button></div></section>';
  }
  F['cl-print'] = function (el) { X.printSummary(el.getAttribute('data-id')); };
  function historyHtml(r) {
    if (!r.history.length) return '<section class="card"><h3>السجل السابق</h3><p class="muted sm">لا زيارات سابقة منتهية لهذا المراجع.</p></section>';
    return '<section class="card"><h3>السجل السابق (' + r.history.length + ')</h3>' + r.history.map(function (h) {
      return '<details class="hist"><summary><b class="ltr">' + esc(h.day) + '</b> — ' + esc(h.doctorName) + ' — ' + esc(h.diagnosis || 'بلا تشخيص') + '</summary>' +
        (h.complaint ? '<p class="sm"><b>الشكوى:</b> ' + esc(h.complaint) + '</p>' : '') + rxTable(h.rx) + orderList(h.orders) + (h.notes ? '<p class="sm pre"><b>ملاحظات:</b> ' + esc(h.notes) + '</p>' : '') + '</details>'; }).join('') + '</section>';
  }
  function filesHtml(r) {
    if (!X.can('files.read')) return '';
    return '<section class="card"><h3>ملفات المراجع (PDF)</h3>' + (r.files.length ? r.files.map(function (f) {
      return '<div class="frow"><span><b>' + esc(f.title) + '</b> <span class="muted xs">' + esc(f.kindLabel) + ' · ' + esc(X.dt(f.uploadedAt)) + '</span></span><button class="btn ghost sm" data-a="cl-file" data-id="' + esc(f.id) + '">فتح</button></div>'; }).join('') :
      '<p class="muted sm">لا ملفات مرفوعة لهذا المراجع (نتائج المختبر والأشعة تصل هنا حين ترفعها الإدارة).</p>') + '</section>';
  }
  F['cl-file'] = function (el) {
    var w = window.open('', '_blank');
    fetch('/api/staff/clinic/files/' + encodeURIComponent(el.getAttribute('data-id')), { headers: { 'Authorization': 'Bearer ' + X.S.token }, cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('تعذر فتح الملف'); return r.blob();
    }).then(function (b) { var u = URL.createObjectURL(b); if (w) w.location = u; else location.href = u; setTimeout(function () { URL.revokeObjectURL(u); }, 60000); })
      .catch(function (e) { if (w) w.close(); toast(e.message, true); });
  };

  /* ---------- التسجيل في الهيكل ---------- */
  X.views.clinic = function () {
    var vid = (location.hash || '').split('/')[2];
    if (vid) visitView(vid); else queueView();
  };
  X.polls.clinic = function () { if (!C.cur) loadQueue(); else if (C.cur.visit.status !== 'with_doctor' && !C.dirty) { /* لا نعيد رسم شاشة يقرؤها الطبيب */ } };
})();
