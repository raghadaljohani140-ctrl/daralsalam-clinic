import json
import unittest
import urllib.parse

from helpers import Env
from test_api import booking_body, DEV

PW = "temp-password-12345"
PW2 = "my-new-password-9876"
Q = urllib.parse.quote("مراجع")


class TestStaff(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e = Env()
        s, d, _ = cls.e.adm("GET", "/entities/branches")
        cls.br = [b["id"] for b in d["items"]]
        s, d, _ = cls.e.adm("GET", "/entities/doctors")
        cls.docs = [x["id"] for x in d["items"]][:3]
        # طبيب مقيّد بفرع واحد لاختبار النطاق
        cls.e.adm("PUT", "/entities/doctors/" + cls.docs[2], dict(next(x for x in d["items"] if x["id"] == cls.docs[2]), branchIds=[cls.br[1]]))

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def setUp(self):
        self.e.app.rl.h.clear()

    # --------------------------------------------------------------- أدوات
    def mk(self, username, role="reception", branch="", password=PW, expect=201):
        s, d, _ = self.e.adm("POST", "/staff", {"username": username, "name": "موظف " + username, "role": role, "branchId": branch, "password": password})
        self.assertEqual(s, expect, d)
        return d

    def login(self, username, password=PW):
        s, d, _ = self.e.req("POST", "/api/staff/login", {"username": username, "password": password})
        return s, d

    def ready(self, username, branch="", role="reception"):
        """ينشئ حساباً ويغيّر كلمته المؤقتة ويعيد ترويسة التوكن الجاهز."""
        self.mk(username, role, branch)
        s, d = self.login(username)
        self.assertEqual(s, 200, d)
        h = {"Authorization": "Bearer " + d["token"]}
        s, d, _ = self.e.req("POST", "/api/staff/password", {"old": PW, "new": PW2}, h)
        self.assertEqual(s, 200, d)
        return {"Authorization": "Bearer " + d["token"]}

    def st(self, method, path, H, body=None):
        return self.e.req(method, "/api/staff" + path, body, H)

    def newrec(self, H, name="مراجع اختبار", phone="0565550001", nid="1000000001", **kw):
        s, d, _ = self.st("POST", "/records", H, dict({"name": name, "phone": phone, "nationalId": nid, "birthDate": "1990-01-01", "gender": "male"}, **kw))
        self.assertIn(s, (200, 201), d)
        return d["record"]["mrn"]

    # --------------------------------------------------------------- الحسابات
    def test_create_validation_and_roles(self):
        self.mk("Bad Name", expect=422)
        self.mk("shortpw", password="123", expect=422)
        self.mk("docuser", role="doctor", expect=422)        # الطبيب يلزمه ربط بسجل طبيب
        self.mk("nurseuser", role="nurse", expect=422)       # دور لم تُبنَ واجهته بعد
        self.mk("nobranch", branch="no-such", expect=422)
        self.mk("dupuser")
        self.mk("DUPUSER", expect=409)
        s, d, _ = self.e.adm("GET", "/roles")
        self.assertEqual(s, 200)
        by = {r["id"]: r for r in d["roles"]}
        self.assertTrue(by["reception"]["ready"] and by["doctor"]["ready"])
        self.assertFalse(by["nurse"]["ready"] or by["lab"]["ready"] or by["pharmacy"]["ready"])
        # بلا توكن إدارة: مرفوض
        self.assertEqual(self.e.req("GET", "/api/admin/staff")[0], 401)

    def test_login_flow_must_change_and_token_invalidation(self):
        self.mk("flow1")
        s, d = self.login("flow1", "wrong-password-1")
        self.assertEqual(s, 401)
        s, d = self.login("flow1")
        self.assertEqual((s, d["user"]["mustChange"]), (200, True))
        old = {"Authorization": "Bearer " + d["token"]}
        # قبل تغيير الكلمة المؤقتة: لا يعمل شيء سوى /me وتغيير الكلمة
        self.assertEqual(self.st("GET", "/records?q=" + Q, old)[0], 403)
        self.assertEqual(self.st("POST", "/password", old, {"old": PW, "new": "short"})[0], 422)
        self.assertEqual(self.st("POST", "/password", old, {"old": "x" * 12, "new": PW2})[0], 401)
        s, d, _ = self.st("POST", "/password", old, {"old": PW, "new": PW2})
        self.assertEqual(s, 200)
        new = {"Authorization": "Bearer " + d["token"]}
        self.assertEqual(self.st("GET", "/records?q=" + Q, new)[0], 200)
        self.assertEqual(self.st("GET", "/me", old)[0], 401)         # التوكن القديم أُبطل بتغيير الكلمة
        self.assertEqual(self.login("flow1")[0], 401)                 # الكلمة المؤقتة لم تعد تعمل
        self.assertEqual(self.login("flow1", PW2)[0], 200)

    def test_lockout_and_no_user_enumeration(self):
        self.mk("lock1")
        msgs = set()
        for _ in range(5):
            s, d = self.login("lock1", "wrong-password-1")
            self.assertEqual(s, 401)
            msgs.add(d["message"])
        s, d = self.login("lock1")                                    # صحيحة لكنه مقفل
        self.assertEqual(s, 401)
        msgs.add(d["message"])
        s, d = self.login("nobody-here")
        msgs.add(d["message"])
        self.assertEqual(len(msgs), 1)                                # رسالة واحدة: لا كشف لوجود الحساب
        self.e.app.db.staff_update(self.e.app.db.staff_get(username="lock1")["id"], locked_until=0)
        self.assertEqual(self.login("lock1")[0], 200)

    def test_token_separation(self):
        H = self.ready("sep1")
        self.assertEqual(self.e.req("GET", "/api/admin/staff", None, H)[0], 401)       # توكن موظف لا يفتح الإدارة
        adm = {"Authorization": "Bearer " + self.e.admin_token()}
        self.assertEqual(self.e.req("GET", "/api/staff/me", None, adm)[0], 401)        # توكن الإدارة لا يفتح واجهة الموظف
        self.assertEqual(self.e.req("GET", "/api/staff/me")[0], 401)
        self.assertEqual(self.st("GET", "/me", H)[0], 200)

    def test_deactivate_and_reset(self):
        H = self.ready("act1")
        sid = self.e.app.db.staff_get(username="act1")["id"]
        s, d, _ = self.e.adm("PATCH", "/staff/" + sid, {"active": False})
        self.assertEqual(s, 200)
        self.assertEqual(self.st("GET", "/me", H)[0], 401)             # فوراً
        self.assertEqual(self.login("act1", PW2)[0], 401)
        self.e.adm("PATCH", "/staff/" + sid, {"active": True, "password": "reset-password-555"})
        self.assertEqual(self.st("GET", "/me", H)[0], 401)             # إعادة التعيين أبطلت التوكن القديم
        s, d = self.login("act1", "reset-password-555")
        self.assertEqual((s, d["user"]["mustChange"]), (200, True))

    # --------------------------------------------------------------- الصلاحيات والنطاق
    def test_permissions_by_role(self):
        R = self.ready("perm_rec")
        M = self.ready("perm_mgr", role="manager")
        self.assertEqual(self.st("GET", "/audit", R)[0], 403)
        self.assertEqual(self.st("GET", "/audit", M)[0], 200)
        s, d, _ = self.st("GET", "/me", R)
        self.assertIn("visits.create", d["user"]["perms"])
        self.assertNotIn("audit.read", d["user"]["perms"])
        self.assertNotIn("staff.manage", d["user"]["perms"])

    def test_branch_scope(self):
        A = self.ready("scopeA", branch=self.br[0])
        B = self.ready("scopeB", branch=self.br[1])
        mrn = self.newrec(A, phone="0565550002", nid="1000000002", name="نطاق فرع")
        doc = self.docs[0]
        s, d, _ = self.st("POST", "/visits", A, {"mrn": mrn, "doctorId": doc})
        self.assertEqual(s, 201, d)
        vid = d["visit"]["id"]
        self.assertEqual(d["visit"]["branchId"], self.br[0])
        # موظف فرع آخر: لا يرى الزيارة ولا يعدلها
        s, d, _ = self.st("GET", "/visits", B)
        self.assertNotIn(vid, [v["id"] for v in d["visits"]])
        self.assertEqual(self.st("POST", "/visits/%s/status" % vid, B, {"status": "ready"})[0], 404)
        s, d, _ = self.st("GET", "/visits", A)
        self.assertIn(vid, [v["id"] for v in d["visits"]])
        # لا يسجّل وصولاً في فرع آخر
        mrn2 = self.newrec(B, phone="0565550003", nid="1000000003", name="مراجع ثان")
        self.assertEqual(self.st("POST", "/visits", B, {"mrn": mrn2, "doctorId": doc, "branchId": self.br[0]})[0], 403)
        # طبيب مقيّد بفرع آخر
        self.assertEqual(self.st("POST", "/visits", A, {"mrn": mrn2, "doctorId": self.docs[2]})[0], 422)
        # قوائم الاختيار تحترم الفرع
        s, d, _ = self.st("GET", "/lookups", A)
        self.assertEqual([b["id"] for b in d["branches"]], [self.br[0]])
        self.assertNotIn(self.docs[2], [x["id"] for x in d["doctors"]])

    # --------------------------------------------------------------- المراجعون
    def test_records(self):
        H = self.ready("rec1")
        self.assertEqual(self.st("GET", "/records?q=a", H)[1]["records"], [])            # حرفان على الأقل
        s, d, _ = self.st("POST", "/records", H, {"name": "عبدالله الاختبار", "phone": "0565550010", "nationalId": "1000000010", "birthDate": "1985-02-03", "gender": "male"})
        self.assertEqual(s, 201, d)
        mrn = d["record"]["mrn"]
        self.assertRegex(mrn, r"^DS-\d{6}$")
        self.assertEqual(d["record"]["nationalIdMasked"], "******0010")
        self.assertNotIn("1000000010", json.dumps(d))                                      # الهوية لا تخرج كاملة
        # نفس الاسم والجوال دون رقم ملف: تحذير تكرار، و force يتجاوزه
        body = {"name": "عبدالله  الاختبار", "phone": "0565550010", "nationalId": "1000000011"}
        s, d, _ = self.st("POST", "/records", H, body)
        self.assertEqual((s, d["error"], d["existing"][0]["mrn"]), (409, "duplicate", mrn))
        s, d, _ = self.st("POST", "/records", H, dict(body, force=True))
        self.assertEqual(s, 201)
        # تحقق المدخلات
        self.assertEqual(self.st("POST", "/records", H, {"name": "س", "phone": "123"})[0], 422)
        self.assertEqual(self.st("POST", "/records", H, {"name": "مراجع", "phone": "0565550012"})[0], 422)   # لا هوية ولا ميلاد
        # تعديل برقم ملف موجود
        s, d, _ = self.st("POST", "/records", H, {"mrn": mrn, "name": "عبدالله الاختبار", "phone": "0565550099", "nationalId": "1000000010"})
        self.assertEqual((s, d["state"], d["record"]["phone"]), (200, "updated", "966565550099"))
        s, d, _ = self.st("GET", "/records?q=" + mrn, H)
        self.assertEqual([r["mrn"] for r in d["records"]], [mrn])
        s, d, _ = self.st("GET", "/records/" + mrn, H)
        self.assertEqual(s, 200)
        self.assertEqual(self.st("GET", "/records/NOPE-1", H)[0], 404)
        acts = [r["action"] for r in self.e.app.db.conn().execute("SELECT action FROM audit WHERE ref=?", (mrn,))]
        for a in ("record_create", "record_update", "record_view"):
            self.assertIn(a, acts)

    # --------------------------------------------------------------- الزيارات
    def test_visit_lifecycle_queue_transfer(self):
        H = self.ready("vis1", branch=self.br[0])
        a = self.newrec(H, phone="0565550021", nid="1000000021", name="مراجع أول")
        b = self.newrec(H, phone="0565550022", nid="1000000022", name="مراجع ثان")
        d0, d1 = self.docs[0], self.docs[1]
        s, d, _ = self.st("POST", "/visits", H, {"mrn": a, "doctorId": d0, "reason": "ألم"})
        v1 = d["visit"]
        s, d, _ = self.st("POST", "/visits", H, {"mrn": b, "doctorId": d0})
        v2 = d["visit"]
        self.assertEqual(v2["queueNo"], v1["queueNo"] + 1)                                   # أرقام الطابور تتسلسل
        s, d, _ = self.st("POST", "/visits", H, {"mrn": a, "doctorId": d1})                    # زيارة جارية عند طبيب آخر
        self.assertEqual(s, 409)
        self.assertIn(v1["doctorName"], d["message"])                                          # الرسالة باسم الطبيب لا بمعرّفه
        self.assertNotIn("dr-", d["message"])
        self.assertEqual(self.st("POST", "/visits", H, {"mrn": "NOPE", "doctorId": d0})[0], 422)
        self.assertEqual(self.st("POST", "/visits", H, {"mrn": a, "doctorId": "no-doc"})[0], 422)
        # تحويل: يذهب لآخر طابور الطبيب الجديد
        mx = max([v["queueNo"] for v in self.st("GET", "/visits", H)[1]["visits"] if v["doctorId"] == d1] or [0])
        s, d, _ = self.st("POST", "/visits/%s/transfer" % v2["id"], H, {"doctorId": d1})
        self.assertEqual((s, d["visit"]["doctorId"], d["visit"]["queueNo"]), (200, d1, mx + 1))
        self.assertEqual(self.st("POST", "/visits/%s/transfer" % v2["id"], H, {"doctorId": d1})[0], 422)   # نفس الطبيب
        # حالات
        S = lambda vid, st: self.st("POST", "/visits/%s/status" % vid, H, {"status": st})
        self.assertEqual(S(v1["id"], "done")[0], 409)                                          # لا قفز من «ينتظر» إلى «انتهت»
        self.assertEqual(S(v1["id"], "ready")[1]["visit"]["statusLabel"], "جاهز للطبيب")
        s, d, _ = S(v1["id"], "with_doctor")
        self.assertTrue(d["visit"]["calledAt"])
        self.assertEqual(self.st("POST", "/visits/%s/transfer" % v1["id"], H, {"doctorId": d1})[0], 409)  # بعد دخوله للطبيب
        self.assertEqual(S(v1["id"], "cancelled")[0], 409)
        s, d, _ = S(v1["id"], "done")
        self.assertTrue(d["visit"]["finishedAt"])
        self.assertEqual(S(v1["id"], "ready")[0], 409)                                         # الحالة الأخيرة نهائية
        # بعد انتهاء الزيارة يمكن تسجيل زيارة جديدة
        self.assertEqual(self.st("POST", "/visits", H, {"mrn": a, "doctorId": d0})[0], 201)
        # إلغاء
        self.assertEqual(S(v2["id"], "cancelled")[1]["visit"]["status"], "cancelled")
        s, d, _ = self.st("GET", "/visits", H)
        self.assertGreaterEqual(len(d["visits"]), 3)
        acts = [r["action"] for r in self.e.app.db.conn().execute("SELECT action FROM audit WHERE ref=?", (v1["id"],))]
        for x in ("visit_create", "visit_ready", "visit_with_doctor", "visit_done"):
            self.assertIn(x, acts)

    def test_concurrent_checkin_numbers_unique(self):
        import threading
        H = self.ready("conc1", branch=self.br[0])
        mrns = [self.newrec(H, phone="05655500%02d" % (30 + i), nid="10000000%02d" % (30 + i), name="متزامن %d" % i) for i in range(8)]
        out = []

        def go(m):
            out.append(self.st("POST", "/visits", H, {"mrn": m, "doctorId": self.docs[0]}))
        ts = [threading.Thread(target=go, args=(m,)) for m in mrns]
        [t.start() for t in ts]
        [t.join() for t in ts]
        nums = sorted(d["visit"]["queueNo"] for s, d, _ in out if s == 201)
        self.assertEqual(len(nums), 8)
        self.assertEqual(len(set(nums)), 8)

    # --------------------------------------------------------------- الحجوزات
    def test_bookings_confirm_and_link_to_visit(self):
        H = self.ready("bk1", branch=self.br[0])
        s, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body(branchId=self.br[0], phone="0565550040", name="صاحب حجز"))
        self.assertEqual(s, 201, d)
        bid = d["booking"]["id"]
        s, d, _ = self.st("GET", "/bookings", H)
        self.assertIn(bid, [b["id"] for b in d["bookings"]])
        self.assertEqual(self.st("PATCH", "/bookings/" + bid, H, {"status": "confirmed"})[0], 422)       # يلزم نص الموعد
        s, d, _ = self.st("PATCH", "/bookings/" + bid, H, {"status": "confirmed", "appointmentText": "الأحد 5 عصراً"})
        self.assertEqual((s, d["booking"]["status"]), (200, "confirmed"))
        s, d, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + DEV)
        self.assertTrue(any("الأحد" in n["body"] for n in d["notifications"]))                         # وصل إشعار المراجع
        mrn = self.newrec(H, phone="0565550040", nid="1000000040", name="صاحب حجز")
        s, d, _ = self.st("POST", "/visits", H, {"mrn": mrn, "doctorId": self.docs[0], "bookingId": bid})
        self.assertEqual((s, d["visit"]["bookingId"]), (201, bid))
        s, d, _ = self.st("GET", "/bookings", H)
        self.assertEqual(next(b for b in d["bookings"] if b["id"] == bid)["visitStatus"], "waiting")
        # موظف فرع آخر لا يرى حجوزات هذا الفرع
        B = self.ready("bk2", branch=self.br[1])
        self.assertNotIn(bid, [b["id"] for b in self.st("GET", "/bookings", B)[1]["bookings"]])
        self.assertEqual(self.st("PATCH", "/bookings/" + bid, B, {"status": "cancelled"})[0], 404)
        self.assertEqual(self.st("POST", "/visits", B, {"mrn": mrn, "doctorId": self.docs[0], "bookingId": bid})[0], 422)

    # --------------------------------------------------------------- التدقيق
    def test_audit_trail_and_no_secrets(self):
        self.mk("aud1")
        self.login("aud1", "wrong-password-xyz")
        s, d = self.login("aud1")
        s, d, _ = self.e.adm("GET", "/audit?who=aud1")
        acts = [a["action"] for a in d["audit"]]
        self.assertIn("staff_login", acts)
        self.assertIn("staff_login_fail", acts)
        blob = json.dumps(d, ensure_ascii=False)
        self.assertNotIn("wrong-password-xyz", blob)
        self.assertNotIn(PW, blob)
        s, d, _ = self.e.adm("GET", "/audit?action=staff_create")
        self.assertTrue(d["audit"])
        self.assertNotIn(PW, json.dumps(d))

    def test_static_app_headers(self):
        s, body, h = self.e.req("GET", "/staff/", raw=True)
        self.assertEqual(s, 200)
        self.assertIn("frame-ancestors 'none'", h["Content-Security-Policy"])


if __name__ == "__main__":
    unittest.main()
