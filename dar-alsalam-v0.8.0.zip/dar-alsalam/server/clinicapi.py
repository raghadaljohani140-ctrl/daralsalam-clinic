"""العيادة: واجهات الطبيب (طابوره، استدعاء مراجع، تشخيص ووصفة وطلبات، إنهاء الزيارة)، ملخص الزيارة للطباعة،
وما يراه المراجع من زياراته المنتهية + إشعاراته (وصول، دورك، انتهت زيارتك).

قواعد الأمان (تُفحص في الخادم):
- الطبيب يرى ويعدّل زياراته هو فقط (staff.doctor_id)، ويفتح ملفات من زاره فقط.
- الزيارة المنتهية لا تُعدَّل.
- المراجع لا يرى إلا ما نشره الطبيب بعد إنهاء الزيارة: التشخيص والتعليمات والوصفة والطلبات، لا الملاحظات الداخلية.
- كل فتح أو حفظ أو إنهاء يُسجَّل في التدقيق (بلا نص التشخيص ولا الأدوية).
"""
import datetime as dt
import re

import rbac
import schema as sch
import sms as smsmod
from staffapi import VISIT_STATUS
from util import riyadh_today

VISIT_ID_RE = r"(v-[0-9a-f]{12})"
DEVICE_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")
MAX_RX, MAX_ORDERS = 20, 20
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
ORDER_TYPES = {"lab": ("orders.lab", "تحليل مخبري"), "radiology": ("orders.radiology", "أشعة")}


def age_label(birth, today=None):
    try:
        b = dt.date.fromisoformat(str(birth)[:10])
    except (ValueError, TypeError):
        return ""
    t = today or riyadh_today()
    months = (t.year - b.year) * 12 + t.month - b.month - (1 if t.day < b.day else 0)
    if months < 0:
        return ""
    if months < 24:
        return "%d شهراً" % months if months else "حديث الولادة"
    return "%d سنة" % (months // 12)


def clean_text(v, mx, multiline=False):
    v = _CTRL.sub("", str(v or "")).replace("\r\n", "\n").replace("\r", "\n")
    v = re.sub(r"[ \t]+", " ", v)
    v = re.sub(r"\n{3,}", "\n\n", v) if multiline else re.sub(r"\s+", " ", v)
    return v.strip()[:mx]


class ClinicMixin:
    # ------------------------------------------------------------------ مساعدات
    def _doctor(self, s):
        """حساب الطبيب المرتبط بسجل طبيب فعّال؛ وإلا 403."""
        if s["role"] != "doctor" or not s.get("doctor_id"):
            self.err(403, "forbidden", "هذه الصفحة لحسابات الأطباء فقط")
            return None
        return s["doctor_id"]

    def _own_visit(self, s, vid):
        did = self._doctor(s)
        if not did:
            return None
        v = self.app.db.visit_get(vid)
        if not v or v["doctor_id"] != did or not self.in_scope(s, v["branch_id"]):
            self.err(404, "not_found", "الزيارة غير موجودة")
            return None
        return v

    def _names(self):
        db = self.app.db
        return {d["id"]: d["name"] for d in db.list_entities("doctors", include_inactive=True)}, \
            {b["id"]: (b.get("shortName") or b["name"]) for b in db.list_entities("branches", include_inactive=True)}

    @staticmethod
    def enc_dict(e):
        if not e:
            return None
        return {"complaint": e["complaint"] or "", "diagnosis": e["diagnosis"] or "", "notes": e["notes"] or "", "advice": e["advice"] or "", "followUp": e["follow_up"] or "",
                "rx": e["rx"], "orders": e["orders"], "publish": e["publish"], "finishedAt": e["finished_at"] or "", "updatedAt": e["updated_at"]}

    def patient_dict(self, r):
        return {"mrn": r["mrn"], "name": r["name"], "gender": r["gender"] or "", "birthDate": r["birth_date"] or "", "age": age_label(r["birth_date"]),
                "nationalIdMasked": ("******" + r["national_id"][-4:]) if r["national_id"] else ""}

    # ------------------------------------------------------------------ توزيع واجهات الطبيب
    def clinic_api(self, method, p, s):
        """يُستدعى من staff_api بعد التحقق من التوكن. يعيد True إن عالج الطلب."""
        if p == "/clinic/queue" and method == "GET":
            return self.clinic_queue(s) or True
        m = re.fullmatch(r"/clinic/visits/" + VISIT_ID_RE, p)
        if m and method == "GET":
            return self.clinic_visit(s, m.group(1)) or True
        m = re.fullmatch(r"/clinic/visits/" + VISIT_ID_RE + r"/(call|encounter|finish)", p)
        if m:
            act = m.group(2)
            if act == "call" and method == "POST":
                return self.clinic_call(s, m.group(1)) or True
            if act == "encounter" and method == "PUT":
                return self.clinic_save(s, m.group(1), finish=False) or True
            if act == "finish" and method == "POST":
                return self.clinic_save(s, m.group(1), finish=True) or True
        m = re.fullmatch(r"/clinic/files/(f-[0-9a-f]{32})", p)
        if m and method == "GET":
            return self.clinic_file(s, m.group(1)) or True
        m = re.fullmatch(r"/visits/" + VISIT_ID_RE + r"/summary", p)
        if m and method == "GET":
            return self.visit_summary(s, m.group(1)) or True
        return False

    # ------------------------------------------------------------------ طابور الطبيب
    def clinic_queue(self, s):
        if not self.need(s, "clinical.read"):
            return
        did = self._doctor(s)
        if not did:
            return
        db = self.app.db
        day = self.qs.get("day") or riyadh_today().isoformat()
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            return self.err(422, "validation", "تاريخ غير صحيح")
        docs, _ = self._names()
        rows = [v for v in db.visits_list(day) if v["doctor_id"] == did and self.in_scope(s, v["branch_id"])]
        encs = db.enc_for_visits([v["id"] for v in rows])
        out = []
        for v in rows:
            r = db.record_get(v["mrn"]) or {}
            d = self.visit_dict(v, docs, encs.get(v["id"]))
            d["age"], d["gender"] = age_label(r.get("birth_date")), r.get("gender") or ""
            out.append(d)
        return self.json(200, {"day": day, "doctor": {"id": did, "name": docs.get(did, did)}, "visits": out})

    def clinic_visit(self, s, vid):
        if not self.need(s, "clinical.read"):
            return
        v = self._own_visit(s, vid)
        if not v:
            return
        db = self.app.db
        rec = db.record_get(v["mrn"])
        if not rec:
            return self.err(404, "not_found", "ملف المراجع غير موجود")
        enc = db.enc_get(vid)
        if not enc and v["status"] == "with_doctor":
            enc = db.enc_ensure(v, "staff:" + s["username"])      # استُدعي من الاستقبال: نبدأ مسودته الآن
        docs, brs = self._names()
        kinds = dict(sch.FILE_KINDS)
        files = [{"id": f["id"], "kind": f["kind"], "kindLabel": kinds.get(f["kind"], f["kind"]), "title": f["title"], "uploadedAt": f["uploaded_at"], "size": f["size"]}
                 for f in db.file_list([rec["mrn"]])] if rbac.can(s["role"], "files.read") else []
        hist = [{"visitId": h["visit_id"], "day": h["day"], "doctorName": docs.get(h["doctor_id"], h["doctor_id"]), "branchName": brs.get(h["branch_id"], ""),
                 "complaint": h["complaint"] or "", "diagnosis": h["diagnosis"] or "", "notes": h["notes"] or "", "rx": h["rx"], "orders": h["orders"]}
                for h in db.enc_history(rec["mrn"], exclude_vid=vid)]
        self.saudit(s, "clinical_view", "visit", vid)
        return self.json(200, {"visit": self.vd(v, docs), "patient": self.patient_dict(rec), "encounter": self.enc_dict(enc), "history": hist, "files": files,
                               "busy": db.doctor_busy(v["doctor_id"], v["day"], vid) or ""}, {"Cache-Control": "private, no-store"})

    def clinic_call(self, s, vid):
        if not self.need(s, "clinical.write"):
            return
        v = self._own_visit(s, vid)
        if not v:
            return
        db = self.app.db
        if v["day"] != riyadh_today().isoformat():
            return self.err(409, "bad_transition", "هذه زيارة ليوم سابق")
        try:
            v2 = db.visit_call(vid, "staff:" + s["username"])
        except ValueError as e:
            if str(e) == "busy":
                return self.err(409, "busy", "عندك مراجع في العيادة الآن؛ أنهِ زيارته أولاً")
            return self.err(409, "bad_transition", "لا يمكن استدعاء هذا المراجع في حالته الحالية")
        db.enc_ensure(v2, "staff:" + s["username"])
        if v["status"] != "with_doctor":
            self.saudit(s, "visit_call", "visit", vid, {"from": v["status"]})
            self.notify_visit(v2, "called")
        docs, _ = self._names()
        return self.json(200, {"visit": self.vd(v2, docs)})

    # ------------------------------------------------------------------ تشخيص ووصفة وطلبات
    def clean_encounter(self, s, body):
        """يتحقق من الحقول الواردة فقط (المسودة جزئية). يعيد (fields, errors)."""
        f, errs = {}, {}
        limits = {"complaint": (500, False), "diagnosis": (500, False), "notes": (3000, True), "advice": (1500, True), "follow_up": (200, False)}
        keys = {"complaint": "complaint", "diagnosis": "diagnosis", "notes": "notes", "advice": "advice", "followUp": "follow_up"}
        for k, col in keys.items():
            if k in body:
                mx, ml = limits[col]
                if len(str(body[k] or "")) > mx + 200:
                    errs[k] = "النص أطول من المسموح (%d حرفاً)" % mx
                f[col] = clean_text(body[k], mx, ml)
        if "rx" in body:
            if not rbac.can(s["role"], "rx.write"):
                errs["rx"] = "ليست لديك صلاحية الوصفات"
            elif not isinstance(body["rx"], list) or len(body["rx"]) > MAX_RX + 5:
                errs["rx"] = "حتى %d دواءً في الوصفة" % MAX_RX
            else:
                rows = []
                for i, it in enumerate(body["rx"]):
                    if not isinstance(it, dict):
                        continue
                    row = {"drug": clean_text(it.get("drug"), 80), "dose": clean_text(it.get("dose"), 60), "freq": clean_text(it.get("freq"), 60),
                           "duration": clean_text(it.get("duration"), 60), "note": clean_text(it.get("note"), 120)}
                    if not any(row.values()):
                        continue                                  # صف فارغ تماماً يُهمَل
                    if not row["drug"]:
                        errs["rx"] = "اكتب اسم الدواء في السطر %d" % (i + 1)
                        break
                    rows.append(row)
                if len(rows) > MAX_RX:
                    errs["rx"] = "حتى %d دواءً في الوصفة" % MAX_RX
                f["rx"] = rows
        if "orders" in body:
            if not isinstance(body["orders"], list) or len(body["orders"]) > MAX_ORDERS + 5:
                errs["orders"] = "حتى %d طلباً" % MAX_ORDERS
            else:
                rows = []
                for i, it in enumerate(body["orders"]):
                    if not isinstance(it, dict):
                        continue
                    typ, name = str(it.get("type", "")), clean_text(it.get("name"), 100)
                    if not name and not it.get("note"):
                        continue
                    if typ not in ORDER_TYPES or not rbac.can(s["role"], ORDER_TYPES[typ][0]):
                        errs["orders"] = "نوع الطلب غير صحيح في السطر %d" % (i + 1)
                        break
                    if not name:
                        errs["orders"] = "اكتب اسم التحليل أو الأشعة في السطر %d" % (i + 1)
                        break
                    rows.append({"type": typ, "name": name, "note": clean_text(it.get("note"), 120)})
                if len(rows) > MAX_ORDERS:
                    errs["orders"] = "حتى %d طلباً" % MAX_ORDERS
                f["orders"] = rows
        if "publish" in body:
            f["publish"] = bool(body["publish"])
        return f, errs

    def clinic_save(self, s, vid, finish):
        if not self.need(s, "clinical.write"):
            return
        v = self._own_visit(s, vid)
        if not v:
            return
        body = self.body_json()
        if body is None:
            return
        db = self.app.db
        enc = db.enc_get(vid)
        if enc and enc["finished_at"]:
            return self.err(409, "locked", "انتهت هذه الزيارة ولا يمكن تعديلها")
        if v["status"] != "with_doctor" or not enc:
            return self.err(409, "bad_transition", "استدعِ المراجع أولاً ثم اكتب زيارته")
        f, errs = self.clean_encounter(s, body)
        if finish:
            diag = f["diagnosis"] if "diagnosis" in f else (enc["diagnosis"] or "")
            if len(diag.strip()) < 2:
                errs["diagnosis"] = "اكتب التشخيص قبل إنهاء الزيارة"
        if errs:
            return self.err(422, "validation", "تحقق من الحقول", errs)
        try:
            enc2 = db.enc_save(vid, "staff:" + s["username"], f, finish=finish)
        except ValueError as e:
            return self.err(409, "locked" if str(e) == "locked" else "bad_transition", "تعذّر الحفظ: تغيّرت حالة الزيارة")
        if not finish:
            self.saudit(s, "encounter_save", "visit", vid)
            return self.json(200, {"encounter": self.enc_dict(enc2)})
        self.saudit(s, "encounter_finish", "visit", vid, {"rx": len(enc2["rx"]), "orders": len(enc2["orders"]), "publish": enc2["publish"]})
        v2 = db.visit_get(vid)
        self.notify_visit(v2, "finished", enc2)
        docs, _ = self._names()
        return self.json(200, {"visit": self.vd(v2, docs), "encounter": self.enc_dict(enc2)})

    def clinic_file(self, s, fid):
        if not self.need(s, "files.read"):
            return
        did = self._doctor(s)
        if not did:
            return
        db = self.app.db
        f = db.file_get(fid)
        if not f or f["deleted_at"] or not db.doctor_has_patient(did, f["mrn"] or ""):
            return self.err(404, "not_found", "الملف غير موجود")
        return self.send_pdf(f, True, "staff:" + s["username"])

    # ------------------------------------------------------------------ ملخص الزيارة للطباعة
    def visit_summary(self, s, vid):
        db = self.app.db
        v = db.visit_get(vid)
        if not v or not self.in_scope(s, v["branch_id"]):
            return self.err(404, "not_found", "الزيارة غير موجودة")
        if s["role"] == "doctor":
            if not self.need(s, "clinical.read"):
                return
            if v["doctor_id"] != s.get("doctor_id"):
                return self.err(404, "not_found", "الزيارة غير موجودة")
        elif not self.need(s, "visits.summary"):
            return
        enc = db.enc_get(vid)
        if not enc or not enc["finished_at"]:
            return self.err(409, "not_ready", "لا ملخص قبل أن ينهي الطبيب الزيارة")
        rec = db.record_get(v["mrn"]) or {}
        docs, brs = self._names()
        st = db.get_kv("settings", {}) or {}
        self.saudit(s, "summary_view", "visit", vid)
        return self.json(200, {"summary": {
            "clinic": st.get("name") or st.get("shortName") or "", "branch": brs.get(v["branch_id"], ""), "day": v["day"], "queueNo": v["queue_no"],
            "doctor": docs.get(v["doctor_id"], v["doctor_id"]), "patient": {"name": rec.get("name") or v["patient_name"], "mrn": v["mrn"], "age": age_label(rec.get("birth_date")),
                                                                       "gender": rec.get("gender") or ""},
            "diagnosis": enc["diagnosis"] if enc["publish"] else "", "rx": enc["rx"], "orders": enc["orders"], "advice": enc["advice"] or "", "followUp": enc["follow_up"] or ""}},
            {"Cache-Control": "private, no-store"})

    # ------------------------------------------------------------------ إشعارات المراجع
    def notify_visit(self, v, event, enc=None):
        """وصل ← حان دورك ← انتهت زيارتك.
        الوصول والاستدعاء (لا يحملان معلومة طبية) يذهبان لجهاز الحجز؛ نهاية الزيارة تذهب للحسابات المرتبطة بالملف،
        وفي وضع التجربة (بلا SMS) لجهاز الحجز. الإشعار لا يحمل التشخيص ولا الدواء أبداً."""
        try:
            app = self.app
            db = app.db
            docs, _ = self._names()
            doc = docs.get(v["doctor_id"], "")
            b = db.get_booking(v["booking_id"]) if v.get("booking_id") else None
            dev = b["device_id"] if b and b["device_id"] and not b["device_id"].startswith("deleted-") else ""
            device_mode = not smsmod.enabled(app.cfg)
            if event == "arrived":
                t, x, ref, targets = "تم تسجيل وصولك", "رقمك %d في طابور %s." % (v["queue_no"], doc), v["booking_id"] or "", [dev]
            elif event == "called":
                t, x, ref, targets = "حان دورك", "تفضّل الآن إلى عيادة %s." % doc, v["booking_id"] or "", [dev]
            elif event == "finished" and enc and enc["publish"]:
                pts = ["pt:" + pid for pid in db.patients_of_mrn(v["mrn"])]
                t, x, ref = "انتهت زيارتك", "ملخص زيارتك ووصفتك متاحان الآن في التطبيق.", "#/visits/" + v["id"]
                targets = pts or ([dev] if device_mode else [])
            else:
                return
            for tg in [x_ for x_ in targets if x_]:
                nid = db.add_notification(t, x, tg, "visit", ref)
                if not tg.startswith("pt:"):
                    app.push.send(db.push_tokens(tg), t, x, {"id": nid, "visit": v["id"]})
        except Exception as e:  # noqa: BLE001 — فشل إشعار لا يُفشل عمل الطبيب أو الاستقبال
            import sys
            sys.stderr.write("WARN notify_visit %s: %r\n" % (event, e))

    # ------------------------------------------------------------------ ما يراه المراجع (التطبيق)
    @staticmethod
    def public_visit(e, docs, brs, full=True):
        d = {"id": e["visit_id"], "day": e["day"], "doctorName": docs.get(e["doctor_id"], ""), "branchName": brs.get(e["branch_id"], ""), "finishedAt": e["finished_at"],
             "diagnosis": e["diagnosis"] or "", "rxCount": len(e["rx"]), "orderCount": len(e["orders"])}
        if full:
            d.update({"advice": e["advice"] or "", "followUp": e["follow_up"] or "", "rx": e["rx"], "orders": e["orders"]})
        return d

    def patient_visits_api(self, method, p):
        """GET /visits و/visits/<id>: حساب موثّق مرتبط بالملف، أو (في وضع التجربة فقط، أي بلا تفعيل SMS) جهاز الحجز نفسه.
        لا يظهر للمراجع إلا ما اعتمد الطبيب نشره بعد إنهاء الزيارة، وبلا الملاحظات الداخلية."""
        app = self.app
        if method != "GET":
            return self.err(405, "method_not_allowed")
        pt = self.current_patient()
        did = self.qs.get("deviceId", "")
        db = app.db
        if pt:
            key, args = "pvis:" + pt["id"], {"mrns": [r["mrn"] for r in db.linked_records(pt["id"])]}
        elif not smsmod.enabled(app.cfg) and DEVICE_RE.fullmatch(did):
            key, args = "pvis:" + did, {"device_id": did}
        else:
            return self.err(401, "unauthorized", "سجّل الدخول لعرض زياراتك")
        if not app.rl.allow(key, 90, 60):
            return self.err(429, "rate_limited", "طلبات كثيرة")
        m = re.fullmatch(r"/" + VISIT_ID_RE, p)
        if not m and p not in ("", "/"):
            return self.err(404, "not_found")
        docs, brs = self._names()
        rows = db.enc_published(vid=m.group(1) if m else None, **args)
        hdr = {"Cache-Control": "private, no-store"}
        if m:
            if not rows:
                return self.err(404, "not_found", "الزيارة غير موجودة")
            return self.json(200, {"visit": self.public_visit(rows[0], docs, brs)}, hdr)
        return self.json(200, {"visits": [self.public_visit(e, docs, brs, full=False) for e in rows]}, hdr)

    def attach_visit_stage(self, bookings):
        """يضيف لكل حجز مرحلة زيارته (ينتظر، عند الطبيب، انتهت…) لتعرضها بطاقة الحجز في التطبيق."""
        db = self.app.db
        vs = db.visits_for_bookings([b["id"] for b in bookings])
        docs, _ = self._names()
        device_mode = not smsmod.enabled(self.app.cfg)
        for b in bookings:
            v = vs.get(b["id"])
            if v:
                b["visit"] = {"id": v["id"], "status": v["status"], "statusLabel": VISIT_STATUS.get(v["status"], v["status"]), "queueNo": v["queue_no"],
                              "doctorName": docs.get(v["doctor_id"], ""), "day": v["day"],
                              "summary": bool(device_mode and v["e_finished"] and v["e_publish"])}
        return bookings
