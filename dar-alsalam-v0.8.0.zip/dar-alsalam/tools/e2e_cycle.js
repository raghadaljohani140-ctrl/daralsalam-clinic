/* اختبار «الدورة الكاملة» بمتصفحات حقيقية منفصلة (كل دور في متصفح خاص به):
   مراجع (تطبيق الجوال) يحجز ← الاستقبال يؤكد ويسجّل الوصول ← الطبيب يستدعي ويكتب (تشخيص، وصفة، تحاليل، أشعة) ويُنهي
   ← الاستقبال يطبع ويسجّل المغادرة ← المراجع يرى ملخص زيارته في تطبيقه. ثم فحوص العزل بين الأدوار.
   NODE_PATH=<playwright> node tools/e2e_cycle.js [BASE_URL] [ADMIN_PASSWORD]
   يحتاج خادماً بقاعدة جديدة (restart_dev.sh). بيانات تجريبية فقط. اللقطات في qa/shots/c*.png */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8090';
const PW = process.argv[3] || 'devpass-12345';
const SHOTS = path.join(__dirname, '..', 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
let fails = 0, passes = 0;
function ok(c, m) { if (c) { passes++; console.log('PASS', m); } else { fails++; console.log('FAIL', m); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function http(method, p, body, token) {
  const h = { Accept: 'application/json' };
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(() => ({})), headers: r.headers };
}

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  const watch = (page, tag) => {
    page.on('pageerror', (e) => errors.push(tag + ' pageerror: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(tag + ' console: ' + m.text()); });
  };
  const desk = () => browser.newContext({ viewport: { width: 1100, height: 820 }, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const phone = () => browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const shot = async (page, n, full) => { await sleep(350); await page.screenshot({ path: path.join(SHOTS, n + '.png'), fullPage: !!full }); };
  const go = async (page, h) => { await page.evaluate((x) => { location.hash = x; }, h); await sleep(400); };
  const waitToast = async (page, re) => {
    await page.waitForFunction((src) => { const t = document.querySelector('#toast'); return !!t && t.classList.contains('on') && new RegExp(src).test(t.innerText); }, re.source);
    return page.locator('#toast').innerText();
  };
  const noHScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);

  /* بيانات الاختبار */
  const MARK = 'ملاحظة-داخلية-سرية-7731';          // لا يجوز أن تصل إلى المراجع ولا إلى الاستقبال ولا إلى سجل التدقيق
  const PAT = 'ناصر الدورة الكاملة', PHONE = '0565550901';
  const DIAG = 'التهاب لب السن', DRUG1 = 'أموكسيسيلين 500 ملغ', DRUG2 = 'إيبوبروفين 400 ملغ', LAB = 'صورة دم كاملة (CBC)', RAD = 'أشعة أسنان بانوراما';
  const ADV = 'تجنب المأكولات الباردة والساخنة جداً', FOLLOW = 'بعد أسبوع';
  const TMP = 'Temp-pass-2468-x', RPW = 'Cycle-Reception-2026', DPW = 'Cycle-Doctor-2026', D2PW = 'Cycle-Doctor2-2026';

  /* =============== 0) التجهيز بصلاحيات المالك (حسابات الاختبار) =============== */
  const alog = await http('POST', '/api/admin/login', { password: PW });
  ok(alog.status === 200 && alog.body.token, 'دخول المالك عبر API');
  const ADM = alog.body.token;
  const adm = (m, p, b) => http(m, '/api/admin' + p, b, ADM);
  const brs = (await adm('GET', '/entities/branches')).body.items.map((b) => b.id);
  const QUBA = brs.includes('quba') ? 'quba' : brs[0];
  ok((await adm('POST', '/staff', { username: 'cy.rec', name: 'منى الاستقبال', role: 'reception', branchId: QUBA, password: TMP })).status === 201, 'حساب استقبال للفرع');
  const activate = async (user, tmp, fin) => {
    const l = await http('POST', '/api/staff/login', { username: user, password: tmp });
    if (l.status !== 200) return '';
    const c = await http('POST', '/api/staff/password', { old: tmp, new: fin }, l.body.token);
    return c.body.token || '';
  };
  const RTOK = await activate('cy.rec', TMP, RPW);
  const rapi = (m, p, b) => http(m, '/api/staff' + p, b, RTOK);
  const lk = (await rapi('GET', '/lookups')).body;
  const DOC = lk.doctors[5], DOC2 = lk.doctors[6];
  ok(!!DOC && !!DOC2 && DOC.id !== DOC2.id, 'طبيبان للاختبار: ' + DOC.name + ' / ' + DOC2.name);

  /* حساب الطبيب من لوحة الإدارة (واجهة حقيقية): الدور «طبيب» يستلزم ربطه بسجل طبيب */
  const actx = await desk();
  const ap = await actx.newPage(); watch(ap, 'admin');
  const dialogs = [];
  ap.on('dialog', async (d) => { dialogs.push(d.message()); await d.accept(); });
  await ap.goto(BASE + '/admin/', { waitUntil: 'networkidle' });
  await ap.fill('#pw', PW); await ap.click('button[type=submit]');
  await ap.waitForSelector('#nav', { timeout: 8000 });
  await go(ap, '#/staff'); await ap.waitForSelector('#st-box');
  await ap.click('[data-a="st-new"]'); await ap.waitForSelector('#modal');
  ok(await ap.locator('#sf-docwrap').isHidden(), 'حقل «الطبيب صاحب الحساب» مخفي لغير الأطباء');
  await ap.fill('#sf-name', 'د. صاحب الحساب'); await ap.fill('#sf-user', 'dr.cycle');
  await ap.selectOption('#sf-role', 'doctor');
  ok(await ap.locator('#sf-docwrap').isVisible(), 'يظهر حقل الطبيب عند اختيار دور «طبيب»');
  const dtmp = await ap.inputValue('#sf-pw');
  await ap.click('form[data-submit="st-create"] button[type=submit]');
  await ap.waitForSelector('#sf-err:not([hidden])');
  ok(true, 'حساب طبيب بلا ربط بسجل طبيب يُرفض: ' + (await ap.locator('#sf-err').innerText()));
  await ap.selectOption('#sf-doc', DOC.id);
  await shot(ap, 'c00-admin-doctor-account');
  await ap.click('form[data-submit="st-create"] button[type=submit]');
  await ap.waitForSelector('#st-box td:has-text("dr.cycle")');
  ok(dialogs.some((m) => m.includes('dr.cycle') && m.includes(dtmp)), 'كلمة المرور المؤقتة للطبيب تظهر مرة واحدة');
  const stl = (await adm('GET', '/staff')).body.staff;
  ok((stl.find((x) => x.username === 'dr.cycle') || {}).doctorId === DOC.id, 'الحساب محفوظ ومربوط بسجل الطبيب');
  const dup = await adm('POST', '/staff', { username: 'dr.cycle2', name: 'حساب ثانٍ لنفس الطبيب', role: 'doctor', branchId: '', password: TMP, doctorId: DOC.id });
  ok(dup.status === 422 && dup.body.fields && dup.body.fields.doctorId, 'لا يُربط طبيب واحد بحسابين فعّالين: ' + dup.status);
  const DTOK = await activate('dr.cycle', dtmp, DPW);
  ok(!!DTOK, 'الطبيب غيّر كلمته المؤقتة');
  ok((await adm('POST', '/staff', { username: 'dr.cycle.b', name: 'د. زميل', role: 'doctor', branchId: '', password: TMP, doctorId: DOC2.id })).status === 201, 'حساب طبيب ثانٍ (لفحص العزل)');
  const D2TOK = await activate('dr.cycle.b', TMP, D2PW);
  const dapi = (m, p, b) => http(m, '/api/staff' + p, b, DTOK);

  /* =============== 1) المراجع: يحجز من تطبيق الجوال =============== */
  const pctx = await phone();
  const pp = await pctx.newPage(); watch(pp, 'patient');
  await pp.goto(BASE + '/app/', { waitUntil: 'networkidle' });
  await pp.waitForSelector('#view .hbn', { timeout: 8000 });
  await pp.evaluate(() => { DS.cfg.liveMs = 1500; });      // التحديث التلقائي 20 ثانية في الإنتاج؛ نسرّعه هنا فقط
  await go(pp, '#/book?sp=dental&br=' + QUBA);
  await pp.fill('#f-name', PAT); await pp.fill('#f-phone', PHONE); await pp.locator('#f-consent').check();
  await shot(pp, 'c01-patient-book');
  await pp.locator('#f-submit').click();
  await pp.waitForSelector('.okmark', { timeout: 8000 });
  const BID = (await pp.locator('.bk-id').innerText()).trim();
  ok(/^DS-[A-Z0-9]{6}$/.test(BID), 'المراجع أرسل طلب حجز: ' + BID);
  const DEV = await pp.evaluate(() => DS.deviceId());
  ok(/ليس موعداً مؤكداً/.test(await pp.locator('#bkroot').innerText()), 'الصياغة الصادقة: ليس موعداً مؤكداً');
  await go(pp, '#/profile');
  await pp.waitForSelector('.bkc, .bk-card, [data-bk]', { timeout: 6000 }).catch(() => {});
  ok((await pp.locator('#view').innerText()).includes(BID), 'الطلب يظهر في «طلباتي»');
  ok(!(await pp.locator('#view').innerText()).includes('سُجّل وصولك'), 'لا مرحلة زيارة قبل وصول المراجع');
  await shot(pp, 'c02-patient-booking-sent');

  /* =============== 2) الاستقبال: يؤكد الحجز ثم يسجّل وصول المراجع =============== */
  const rctx = await desk();
  await rctx.addInitScript(() => { window.__printed = 0; window.__printHtml = ''; window.print = function () { window.__printed++; const a = document.querySelector('#print-area'); window.__printHtml = a ? a.innerHTML : ''; }; });
  const rp = await rctx.newPage(); watch(rp, 'reception');
  rp.on('dialog', async (d) => { dialogs.push(d.message()); await d.accept(); });
  await rp.goto(BASE + '/staff/', { waitUntil: 'networkidle' });
  await rp.fill('#lg-user', 'cy.rec'); await rp.fill('#lg-pw', RPW);
  await rp.click('form[data-f=login] button[type=submit]');
  await rp.waitForSelector('#tabs');
  await go(rp, '#/bookings');
  await rp.waitForSelector('.bk:has-text("' + BID + '")');
  await rp.locator('.bk', { hasText: BID }).locator('[data-a="bk-confirm"]').click();
  await rp.waitForSelector('#bc-t');
  await rp.fill('#bc-t', 'اليوم مع ' + DOC.name);
  await rp.click('form[data-f=bkconfirm] button[type=submit]');
  await rp.waitForFunction((id) => { const b = [...document.querySelectorAll('.bk')].find((x) => x.innerText.includes(id)); return !!b && /الموعد المؤكد/.test(b.innerText); }, BID);
  ok(true, 'الاستقبال أكّد الموعد');
  await shot(rp, 'c03-reception-bookings');
  await rp.locator('.bk', { hasText: BID }).locator('[data-a="bk-arrive"]').click();
  await rp.waitForSelector('.alert.info:has-text("' + BID + '")');
  await rp.waitForFunction(() => /لا نتائج/.test(document.querySelector('#ci-res').innerText));
  await rp.click('[data-a="ci-new"]');
  ok((await rp.inputValue('#rf-name')) === PAT, 'نموذج المراجع الجديد مُعبّأ من الحجز');
  await rp.fill('#rf-bd', '1990-06-15'); await rp.selectOption('#rf-g', 'male');
  await rp.click('form[data-f=recsave] button[type=submit]');
  await rp.waitForSelector('form[data-f=checkin]');
  await rp.selectOption('#ci-doc', DOC.id); await rp.fill('#ci-reason', 'ألم في الأسنان');
  await shot(rp, 'c04-reception-checkin');
  await rp.click('form[data-f=checkin] button[type=submit]');
  await rp.waitForSelector('.vrow:has-text("' + PAT + '")');
  const t1 = await waitToast(rp, /رقم الطابور \d+/);
  const QNO = +((t1.match(/رقم الطابور (\d+)/) || [])[1] || 0);
  ok(QNO >= 1, 'تسجيل الوصول: ' + t1);
  const row = rp.locator('.vrow', { hasText: PAT });
  ok((await row.innerText()).includes('ينتظر') && (await rp.locator('.dcard', { hasText: DOC.name }).count()) === 1, 'ظهر في طابور الطبيب ' + DOC.name);
  await shot(rp, 'c05-reception-board-waiting');

  /* =============== 3) المراجع يرى مرحلته (دون أي معلومة طبية) =============== */
  await go(pp, '#/');
  await pp.waitForFunction((n) => { const t = document.querySelector('#view').innerText; return /سُجّل وصولك/.test(t) && t.includes('رقمك ' + n); }, QNO, { timeout: 8000 });
  ok(true, 'الرئيسية: بطاقة «طلباتي» تعرض «سُجّل وصولك · رقمك ' + QNO + '»');
  await shot(pp, 'c05b-patient-home-arrived');
  await go(pp, '#/profile');
  await pp.waitForFunction((n) => { const t = document.querySelector('#view').innerText; return /سُجّل وصولك/.test(t) && t.includes('رقمك ' + n); }, QNO, { timeout: 8000 });
  const pv1 = await pp.locator('#view').innerText();
  ok(pv1.includes(DOC.name), 'حسابي: سُجّل وصولك · رقمك ' + QNO + ' عند ' + DOC.name);
  ok(!pv1.includes('عرض ملخص الزيارة'), 'لا رابط ملخص قبل انتهاء الزيارة');
  ok(!(await pp.locator('#vs-sec').isVisible()), 'قسم «زياراتي» مخفي حتى تنتهي أول زيارة');
  ok(await pp.evaluate(() => { const st = [...document.querySelectorAll('#bk-list .alert.info')][0], pf = document.querySelector('#pf-form'); return !!st && !!pf && (st.compareDocumentPosition(pf) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0; }), 'حسابي: حالة الزيارة تظهر قبل نموذج «بياناتي» (لا يحتاج المراجع للنزول)');
  ok(await pp.evaluate(() => { const st = document.querySelector('#bk-list .alert.info'); const r = st && st.getBoundingClientRect(); return !!r && r.top < window.innerHeight && r.bottom > 0; }), 'وتقع داخل الشاشة الأولى على الجوال');
  await shot(pp, 'c06-patient-arrived');

  /* =============== 4) الطبيب: يدخل بحسابه ويرى طابوره فقط ويستدعي المراجع =============== */
  const dctx = await desk();
  const dp = await dctx.newPage(); watch(dp, 'doctor');
  dp.on('dialog', async (d) => { dialogs.push(d.message()); await d.accept(); });
  await dp.goto(BASE + '/staff/', { waitUntil: 'networkidle' });
  await dp.fill('#lg-user', 'dr.cycle'); await dp.fill('#lg-pw', DPW);
  await dp.click('form[data-f=login] button[type=submit]');
  await dp.waitForSelector('#tabs');
  const dtabs = await dp.$$eval('#tabs a', (a) => a.map((x) => x.getAttribute('data-t')));
  ok(dtabs.join() === 'clinic', 'الطبيب يرى «عيادتي» فقط (لا حجوزات ولا سجلات ولا تدقيق): ' + dtabs.join());
  await dp.waitForSelector('.hero');
  const hero = await dp.locator('.hero').innerText();
  ok(hero.includes('التالي') && hero.includes(PAT), 'العيادة تعرض المراجع التالي: ' + hero.replace(/\s+/g, ' ').slice(0, 70));
  await shot(dp, 'c07-doctor-queue');
  await dp.click('[data-a="cl-callopen"]');
  await dp.waitForSelector('form.clform');
  const VID = await dp.evaluate(() => location.hash.split('/')[2]);
  ok(/^v-[0-9a-f]{12}$/.test(VID), 'فُتحت زيارة المراجع بعد الاستدعاء: ' + VID);
  ok((await dp.locator('.ptcard').innerText()).includes(PAT) && /عند الطبيب/.test(await dp.locator('.chip').first().innerText()), 'البطاقة: اسم المراجع وحالة «عند الطبيب»');
  ok(!/\d{10}/.test((await dp.locator('.ptcard').innerText()).replace(/DS-\d+/g, '')), 'لا رقم هوية ولا جوال كاملاً في بطاقة المراجع عند الطبيب');
  const nv = await dapi('GET', '/visits');
  ok(nv.status === 403, 'الطبيب لا يملك قائمة زيارات المجمع (403)');
  /* المراجع جالس في الانتظار وصفحته مفتوحة (لم يُعد فتحها): تتحدّث وحدها إلى «أنت الآن عند …» */
  await pp.waitForFunction((n) => document.querySelector('#view').innerText.includes('أنت الآن عند ' + n), DOC.name, { timeout: 15000 });
  ok(true, 'تحديث تلقائي على شاشة المراجع المفتوحة: أنت الآن عند ' + DOC.name);
  await shot(pp, 'c06b-patient-called');

  /* الاستقبال يرى أن الطبيب يكتب ولا يستطيع إنهاء الزيارة من تحته */
  await rp.click('[data-a="bd-refresh"]');
  await rp.waitForFunction((n) => { const r = [...document.querySelectorAll('.vrow')].find((x) => x.innerText.includes(n)); return !!r && /الطبيب يكتب/.test(r.innerText) && /عند الطبيب/.test(r.innerText); }, PAT);
  ok(await rp.locator('.vrow', { hasText: PAT }).locator('[data-st="done"]').count() === 0, 'الاستقبال: زر «انتهت الزيارة» مخفي والطبيب يكتب');
  const fd = await rapi('POST', '/visits/' + VID + '/status', { status: 'done' });
  ok(fd.status === 409 && fd.body.error === 'doctor_writing', 'ولو طُلب عبر API: 409 doctor_writing');
  await shot(rp, 'c08-reception-doctor-writing');

  /* =============== 5) الطبيب يكتب الزيارة =============== */
  await dp.fill('#cf-complaint', 'ألم في الأسنان منذ ثلاثة أيام');
  await dp.fill('#cf-diagnosis', DIAG);
  await dp.click('[data-a="cl-rx-add"]');
  await dp.fill('[data-rx="drug"][data-i="0"]', DRUG1); await dp.fill('[data-rx="dose"][data-i="0"]', 'كبسولة');
  await dp.fill('[data-rx="freq"][data-i="0"]', '3 مرات يومياً'); await dp.fill('[data-rx="duration"][data-i="0"]', '7 أيام');
  await dp.click('[data-a="cl-rx-add"]');
  await dp.fill('[data-rx="drug"][data-i="1"]', DRUG2); await dp.fill('[data-rx="dose"][data-i="1"]', 'حبة');
  await dp.fill('[data-rx="freq"][data-i="1"]', 'عند اللزوم'); await dp.fill('[data-rx="note"][data-i="1"]', 'بعد الأكل');
  await dp.click('[data-a="cl-od-add"]');
  await dp.fill('[data-od="name"][data-i="0"]', LAB);
  await dp.click('[data-a="cl-od-add"]');
  await dp.selectOption('[data-od="type"][data-i="1"]', 'radiology');
  await dp.fill('[data-od="name"][data-i="1"]', RAD); await dp.fill('[data-od="note"][data-i="1"]', 'قبل الموعد القادم');
  await dp.fill('#cf-advice', ADV + '\nنظّف أسنانك بلطف');
  await dp.fill('#cf-followUp', FOLLOW);
  await dp.fill('#cf-notes', MARK);
  await dp.waitForFunction(() => /تم الحفظ/.test(document.querySelector('#cl-state').textContent), null, { timeout: 8000 });
  ok(true, 'الحفظ التلقائي: ' + (await dp.locator('#cl-state').innerText()));
  await shot(dp, 'c09-doctor-form', true);
  /* الحفظ مستمر: إعادة تحميل الصفحة لا تُضيّع شيئاً */
  await dp.reload({ waitUntil: 'networkidle' });
  await dp.waitForSelector('form.clform');
  ok((await dp.inputValue('#cf-diagnosis')) === DIAG && (await dp.locator('#cl-rx .rxrow').count()) === 2 && (await dp.locator('#cl-od .rxrow').count()) === 2, 'بعد إعادة التحميل: التشخيص ودواءان وطلبان كما كُتبت');
  ok((await dp.inputValue('[data-od="type"][data-i="1"]')) === 'radiology' && (await dp.inputValue('#cf-notes')) === MARK, 'نوع الطلب «أشعة» والملاحظة الداخلية محفوظان');

  /* مراجع ثانٍ ينتظر: الطبيب لا يستدعيه وعنده مراجع في العيادة */
  const r2 = await rapi('POST', '/records', { name: 'هند الانتظار', phone: '0565550902', birthDate: '1988-01-01' });
  const v2 = await rapi('POST', '/visits', { mrn: r2.body.record.mrn, doctorId: DOC.id, reason: '' });
  ok(v2.status === 201, 'مراجع ثانٍ ينتظر عند الطبيب نفسه');
  const V2 = v2.body.visit.id;
  const c2 = await dapi('POST', '/clinic/visits/' + V2 + '/call');
  ok(c2.status === 409 && c2.body.error === 'busy', 'لا استدعاء ثانٍ وعنده مراجع: 409 busy');
  await go(dp, '#/clinic');
  await dp.waitForSelector('.hero.in');
  ok((await dp.locator('.hero.in').innerText()).includes(PAT) && (await dp.locator('.vrow', { hasText: 'هند' }).count()) === 1, 'الطابور: «عندك الآن» المراجع الأول والثاني ينتظر');
  await dp.locator('.vrow', { hasText: 'هند' }).click();
  await dp.waitForSelector('.alert.warn:has-text("عندك مراجع في العيادة")');
  ok(await dp.locator('[data-a="cl-call"]').count() === 0, 'شاشة المراجع الثاني: لا زر استدعاء ويُنبَّه الطبيب');
  await shot(dp, 'c10-doctor-busy');
  await go(dp, '#/clinic/' + VID);
  await dp.waitForSelector('form.clform');

  /* إنهاء الزيارة: التشخيص مطلوب ثم تأكيد صريح */
  await dp.fill('#cf-diagnosis', '');
  await dp.click('[data-a="cl-finish"]');
  await dp.waitForSelector('#cl-err:not([hidden])');
  ok((await dp.locator('#cl-err').innerText()).includes('التشخيص'), 'الإنهاء بلا تشخيص يُرفض بنص واضح');
  await dp.fill('#cf-diagnosis', DIAG);
  await dp.click('[data-a="cl-finish"]');
  await dp.waitForSelector('[data-a="cl-finish-yes"]');
  const mt = await dp.locator('#modal').innerText();
  ok(mt.includes(DIAG) && mt.includes('2 دواء') && mt.includes('2 طلب') && mt.includes('لا يمكن تعديل الزيارة') && mt.includes('إشعار'), 'نافذة التأكيد: التشخيص والعدّ والتحذير من القفل وأن المراجع سيُشعَر');
  await shot(dp, 'c11-doctor-finish-confirm');
  await dp.click('[data-a="cl-finish-yes"]');
  await waitToast(dp, /تم إنهاء الزيارة/);
  await dp.waitForSelector('[data-a="cl-print"]');
  const dd = await dp.locator('#view').innerText();
  ok(!(await dp.locator('form.clform').count()) && dd.includes(DIAG) && dd.includes(DRUG1) && dd.includes(RAD) && dd.includes(MARK), 'الزيارة المنتهية للقراءة فقط وتحوي ما كُتب وملاحظات الطبيب الداخلية');
  const lock = await dapi('PUT', '/clinic/visits/' + VID + '/encounter', { diagnosis: 'تعديل بعد الإنهاء' });
  ok(lock.status === 409 && lock.body.error === 'locked', 'التعديل بعد الإنهاء مرفوض: 409 locked');
  await shot(dp, 'c12-doctor-done', true);
  await pp.waitForFunction(() => { const t = document.querySelector('#view').innerText; return /انتهت زيارتك/.test(t) && /عرض ملخص الزيارة/.test(t); }, null, { timeout: 15000 });
  ok(true, 'تحديث تلقائي: «انتهت زيارتك» ومعها رابط ملخص الزيارة، والمراجع لم يُعد فتح الصفحة');

  /* =============== 6) الاستقبال: يطبع الوصفة والتعليمات ويسجّل المغادرة =============== */
  await rp.click('[data-a="bd-refresh"]');
  await rp.waitForFunction((n) => { const r = [...document.querySelectorAll('.vrow')].find((x) => x.innerText.includes(n)); return !!r && /انتهت/.test(r.querySelector('.chip').innerText); }, PAT);
  const dr = rp.locator('.vrow', { hasText: PAT });
  const drt = await dr.innerText();
  ok(/وصفة 2/.test(drt) && /طلبات 2/.test(drt) && !/الطبيب يكتب/.test(drt), 'صف الاستقبال: انتهت الزيارة · وصفة 2 · طلبات 2');
  ok(!drt.includes(MARK) && !drt.includes(DIAG), 'لا تشخيص ولا ملاحظات الطبيب على لوحة الاستقبال');
  await shot(rp, 'c13-reception-done');
  await dr.locator('[data-a="vprint"]').click();
  await rp.waitForFunction(() => window.__printed === 1);
  const ph = await rp.evaluate(() => window.__printHtml);
  ok(ph.includes(PAT) && ph.includes(DOC.name) && ph.includes(DIAG) && ph.includes(DRUG1) && ph.includes(DRUG2) && ph.includes(LAB) && ph.includes(RAD) && ph.includes(FOLLOW), 'الورقة المطبوعة: المراجع والطبيب والتشخيص والدواءان والطلبان والمراجعة');
  ok(ph.includes('نسخة تجريبية — ليست وصفة رسمية') && !ph.includes(MARK), 'الورقة: علامة «نسخة تجريبية» ولا ملاحظات داخلية');
  await rp.pdf({ path: path.join(SHOTS, 'c14-printed-summary.pdf'), format: 'A4', printBackground: true });
  ok(fs.statSync(path.join(SHOTS, 'c14-printed-summary.pdf')).size > 3000, 'تصدير الورقة إلى PDF للمعاينة');
  const bad = await rapi('POST', '/visits/' + VID + '/status', { status: 'ready' });
  ok(bad.status === 409, 'لا رجوع من «انتهت» إلى الانتظار: ' + bad.status);
  await dr.locator('[data-st="left"]').click();
  await rp.waitForFunction((n) => { const r = [...document.querySelectorAll('.vrow')].find((x) => x.innerText.includes(n)); return !!r && /غادر/.test(r.querySelector('.chip').innerText); }, PAT);
  ok(dialogs.some((m) => m.includes('غادر المجمع')) && (await rp.locator('.vrow', { hasText: PAT }).innerText()).includes('غادر'), 'تسجيل المغادرة بتأكيد، ويظهر وقت المغادرة على الصف');
  ok(await rp.locator('.vrow', { hasText: PAT }).locator('[data-a="vs"]').count() === 0, 'الزيارة المغادِرة بلا أزرار أخرى');
  await shot(rp, 'c15-reception-left');

  /* =============== 7) المراجع: يرى ملخص زيارته في تطبيقه =============== */
  await go(pp, '#/more'); await go(pp, '#/profile');
  await pp.waitForFunction(() => /شكراً لزيارتك/.test(document.querySelector('#view').innerText), null, { timeout: 8000 });
  ok(true, 'بطاقة الطلب: شكراً لزيارتك');
  await pp.waitForSelector('#vs-sec:not([hidden])', { timeout: 6000 });
  ok((await pp.locator('#vs-mini').innerText()).includes(DIAG) && (await pp.locator('#vs-mini').innerText()).includes(DOC.name), 'قسم «زياراتي» يظهر بعد أول زيارة منتهية');
  await shot(pp, 'c16-patient-profile-after');
  await pp.locator('a:has-text("عرض ملخص الزيارة")').first().click();
  await pp.waitForSelector('.vrx');
  ok((await pp.evaluate(() => location.hash)) === '#/visits/' + VID, 'رابط الملخص يفتح الزيارة نفسها');
  const sv = await pp.locator('#view').innerText();
  ok(sv.includes(DOC.name) && sv.includes(DIAG) && sv.includes(DRUG1) && sv.includes(DRUG2) && sv.includes('3 مرات يومياً') && sv.includes('7 أيام') && sv.includes('بعد الأكل'), 'الملخص: الطبيب والتشخيص والدواءان بجرعاتهما وتكرارهما ومدتهما');
  ok(sv.includes(LAB) && sv.includes(RAD) && sv.includes('تحليل') && sv.includes('أشعة') && sv.includes(ADV) && sv.includes(FOLLOW), 'الملخص: التحليل والأشعة والتعليمات وموعد المراجعة');
  ok(!sv.includes(MARK) && !/ملاحظات داخلية/.test(sv), 'ملاحظات الطبيب الداخلية لا تصل المراجع أبداً');
  ok(sv.includes('الوصفة المعتمدة هي التي يسلّمها لك المجمع'), 'تنبيه أن الوصفة المعتمدة هي التي يسلّمها المجمع');
  ok(await noHScroll(pp), 'لا تمرير أفقي في ملخص الزيارة على الجوال');
  await shot(pp, 'c17-patient-summary', true);
  await go(pp, '#/visits');
  await pp.waitForSelector('#vs-box a.item');
  ok((await pp.locator('#vs-box').innerText()).includes(DIAG), 'صفحة «زياراتي»: الزيارة المنتهية');
  await shot(pp, 'c18-patient-visits');
  await go(pp, '#/notifications');
  await pp.waitForFunction(() => /انتهت زيارتك/.test(document.querySelector('#view').innerText), null, { timeout: 8000 });
  const nt = await pp.locator('#view').innerText();
  ok(/تم تسجيل وصولك/.test(nt) && /حان دورك/.test(nt) && /انتهت زيارتك/.test(nt), 'الإشعارات الثلاثة: وصلت · حان دورك · انتهت زيارتك');
  ok(!nt.includes(DIAG) && !nt.includes(DRUG1) && !nt.includes(MARK), 'الإشعارات لا تحمل أي معلومة طبية');
  ok((await pp.locator('#view a[href="#/visits/' + VID + '"]').count()) === 1, 'إشعار النهاية يرتبط بملخص الزيارة');
  await shot(pp, 'c19-patient-notifications');

  /* خصوصية الواجهة العامة */
  const mine = await http('GET', '/api/v1/visits?deviceId=' + DEV);
  ok(mine.status === 200 && mine.body.visits.length === 1, 'GET /visits بجهاز الحجز: زيارة واحدة');
  const raw = JSON.stringify(mine.body) + JSON.stringify((await http('GET', '/api/v1/visits/' + VID + '?deviceId=' + DEV)).body);
  ok(!raw.includes(MARK) && !/"notes"/.test(raw) && !raw.includes(PHONE) && !raw.includes('1990-06-15'), 'استجابة المراجع بلا ملاحظات داخلية ولا جوال ولا تاريخ ميلاد');
  const other = 'dev_other_00000000000001';
  ok((await http('GET', '/api/v1/visits?deviceId=' + other)).body.visits.length === 0, 'جهاز آخر لا يرى شيئاً');
  ok((await http('GET', '/api/v1/visits/' + VID + '?deviceId=' + other)).status === 404, 'جهاز آخر لا يفتح زيارة غيره (404)');
  ok((await http('GET', '/api/v1/visits/' + VID)).status >= 400, 'بلا هوية جهاز ولا حساب: مرفوض');

  /* =============== 8) العزل بين الأدوار =============== */
  ok((await rapi('GET', '/clinic/queue')).status === 403, 'الاستقبال لا يفتح عيادة الطبيب (403)');
  ok((await rapi('GET', '/clinic/visits/' + VID)).status === 403, 'ولا ملف الزيارة السريري (403)');
  for (const p of ['/records', '/bookings', '/audit']) ok((await dapi('GET', p)).status === 403, 'الطبيب لا يفتح ' + p + ' (403)');
  ok((await dapi('GET', '/visits/' + VID + '/summary')).status === 200, 'الطبيب يفتح ملخص زيارته هو (للطباعة)');
  ok([403, 404].includes((await http('GET', '/api/staff/visits/' + VID + '/summary', undefined, D2TOK)).status), 'طبيب آخر لا يفتح ملخص زيارة زميله');
  const d2 = await http('GET', '/api/staff/clinic/visits/' + VID, undefined, D2TOK);
  ok(d2.status === 404, 'طبيب آخر لا يفتح زيارة زميله (404)');
  ok((await http('GET', '/api/staff/clinic/queue', undefined, D2TOK)).body.visits.length === 0, 'طابور الطبيب الآخر فارغ (لا يرى مراجعي زميله)');
  ok((await http('GET', '/api/staff/me', undefined, ADM)).status === 401 && (await http('GET', '/api/admin/staff', undefined, DTOK)).status === 401, 'توكن المالك لا يفتح API الموظفين وتوكن الطبيب لا يفتح API الإدارة');

  /* =============== 9) زيارة بلا إظهار للمراجع + شاشة الطبيب على الجوال =============== */
  const mctx = await phone();
  const mp = await mctx.newPage(); watch(mp, 'doctor-mobile');
  mp.on('dialog', async (d) => { dialogs.push(d.message()); await d.accept(); });
  await mp.goto(BASE + '/staff/', { waitUntil: 'networkidle' });
  await mp.fill('#lg-user', 'dr.cycle'); await mp.fill('#lg-pw', DPW);
  await mp.click('form[data-f=login] button[type=submit]');
  await mp.waitForSelector('.hero');
  ok(await noHScroll(mp), 'لا تمرير أفقي في طابور الطبيب على الجوال');
  await shot(mp, 'c20-doctor-mobile-queue');
  await mp.click('[data-a="cl-callopen"]');
  await mp.waitForSelector('form.clform');
  ok(await noHScroll(mp), 'لا تمرير أفقي في نموذج الزيارة على الجوال');
  await mp.fill('#cf-diagnosis', 'فحص روتيني سليم');
  await mp.click('[data-a="cl-rx-add"]'); await mp.fill('[data-rx="drug"][data-i="0"]', 'فيتامين د 1000 وحدة');
  ok(await noHScroll(mp), 'لا تمرير أفقي بعد إضافة صفوف الوصفة');
  await shot(mp, 'c21-doctor-mobile-form', true);
  await mp.locator('#cf-publish').uncheck();
  await mp.click('[data-a="cl-finish"]');
  await mp.waitForSelector('[data-a="cl-finish-yes"]');
  ok((await mp.locator('#modal').innerText()).includes('لن يظهر الملخص في تطبيق المراجع'), 'نافذة الإنهاء تُنبّه: لن يظهر الملخص في تطبيق المراجع');
  await mp.click('[data-a="cl-finish-yes"]');
  await waitToast(mp, /تم إنهاء الزيارة/);
  const sm2 = await rapi('GET', '/visits/' + V2 + '/summary');
  ok(sm2.status === 200 && !JSON.stringify(sm2.body).includes('فحص روتيني سليم'), 'ملخص الاستقبال لزيارة غير منشورة بلا تشخيص (يطبع الدواء فقط)');
  ok(JSON.stringify(sm2.body).includes('فيتامين د'), 'لكن الوصفة تبقى متاحة للطباعة');

  /* =============== 10) سجل التدقيق =============== */
  const aud = (await adm('GET', '/audit?limit=300')).body.audit;
  const acts = new Set(aud.map((a) => a.action));
  ok(['visit_create', 'visit_call', 'encounter_finish', 'summary_view', 'clinical_view'].every((a) => acts.has(a)), 'التدقيق يسجّل: وصول، استدعاء، إنهاء، عرض الملخص، فتح الملف السريري');
  const araw = JSON.stringify(aud);
  ok(!araw.includes(MARK) && !araw.includes(DIAG) && !araw.includes(DRUG1) && !araw.includes(LAB), 'سجل التدقيق لا يحوي نصوصاً طبية (أعداد وأرقام فقط)');
  ok(aud.some((a) => a.who === 'staff:dr.cycle' && a.action === 'encounter_finish') && aud.some((a) => a.who === 'staff:cy.rec' && a.action === 'summary_view'), 'كل عملية منسوبة لمنفّذها (الطبيب/الاستقبال)');

  ok(errors.length === 0, 'لا أخطاء جافاسكربت/CSP في أي صفحة' + (errors.length ? ': ' + errors.slice(0, 6).join(' | ') : ''));
  await browser.close();
  console.log('\n' + passes + ' passed, ' + fails + ' failed');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
