/* اختبار نسخة التجربة (preview.html) مفتوحةً من file:// كما سيفتحها المستخدم، على شاشة جوال.
   NODE_PATH=<playwright> node tools/e2e_preview.js [مسار preview.html]
   لا يحتاج خادماً. يثبت أن: لا طلبات شبكة إطلاقاً، لا انتهاكات CSP، الحجز لا يُرسل، قمر يعمل محلياً. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const FILE = path.resolve(process.argv[2] || path.join(__dirname, '..', 'dist', 'preview.html'));
const SHOTS = path.join(__dirname, '..', 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
let fails = 0, passes = 0;
function ok(c, m) { if (c) { passes++; console.log('PASS', m); } else { fails++; console.log('FAIL', m); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh', offline: true });
  const page = await ctx.newPage();
  const errors = [], nets = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' || /Content Security Policy|violat/i.test(m.text())) errors.push('console: ' + m.text()); });
  page.on('request', (r) => nets.push(r.url()));
  page.on('dialog', (d) => d.dismiss());
  const shot = async (n, full) => { await sleep(350); await page.screenshot({ path: path.join(SHOTS, n + '.png'), fullPage: !!full }); };
  const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await sleep(300); };
  await page.addInitScript(() => {
    window.__csp = [];
    document.addEventListener('securitypolicyviolation', (e) => window.__csp.push(e.violatedDirective + ' ' + e.blockedURI));
  });

  /* ---------- الفتح بدون إنترنت ---------- */
  const t0 = Date.now();
  await page.goto('file://' + FILE, { waitUntil: 'load' });
  ok(await page.locator('#app .splash .sp-mark').count() === 1, 'شاشة البداية المتحركة تظهر أولاً');
  await page.waitForSelector('.tabs', { timeout: 8000 });
  const held = Date.now() - t0;
  ok(held >= 1700 && held < 5000, 'النسخة التجريبية تُبقي شاشة البداية ~1.8 ثانية (' + held + 'ms)');
  ok(true, 'التطبيق يفتح من ملف واحد وبدون إنترنت (offline)');
  ok((await page.locator('.ribbon').innerText()).includes('نسخة تجريبية'), 'الشريط يوضح أنها نسخة تجريبية');
  ok((await page.title()).includes('نسخة تجريبية'), 'عنوان الصفحة يوضح أنها تجريبية');
  ok((await page.locator('.bar h1').innerText()).includes('دار السلام') && await page.locator('.bar .logo-s').count() === 1, 'الرئيسية تعرض شعار واسم المجمع في الشريط العلوي');
  ok(await page.evaluate(() => [...document.images].every((i) => i.complete && i.naturalWidth > 0)), 'كل الصور (الشعار والأقواس) مضمّنة وتُحمَّل بلا إنترنت');
  ok(await page.evaluate(() => /^url\("?data:image\/svg\+xml;base64,/.test(getComputedStyle(document.querySelector('.hb-slide'), '::after').backgroundImage)), 'علامة الأقواس في بانر الرئيسية (CSS) مضمّنة كبيانات');
  const demoBn = await page.locator('.hbn .bn').allInnerTexts();
  ok(demoBn.length === 2 && demoBn.every((t) => t.includes('مثال توضيحي')), 'شريحتان توضيحيتان فقط وكلتاهما موسومتان «مثال توضيحي»: ' + demoBn.length);
  ok(await page.locator('.hbn .dots i').count() === 2, 'نقطتا تنقّل للشريحتين');
  ok(await page.locator('.qcard .qt').count() >= 10 && await page.locator('.qm-card').count() === 1, 'شبكة الإجراءات وبطاقة قمر تعملان في النسخة التجريبية');
  await shot('p01-preview-home');
  await page.locator('.tab.cta').click();
  await page.waitForSelector('#qaroot .sheet.qa');
  ok((await page.locator('#qaroot').innerText()).includes('طلب حجز'), 'الزر المركزي يفتح الإجراءات السريعة في النسخة التجريبية');
  await shot('p01b-preview-quick');
  await page.keyboard.press('Escape'); await sleep(200);
  await go('#/more');
  ok((await page.locator('#view').innerText()).includes('نسخة تجريبية'), 'المزيد: يذكر أن النسخة تجريبية');
  await go('#/');

  /* ---------- التصفح ---------- */
  await go('#/specialties');
  ok(await page.locator('main a[href^="#/specialty/"]').count() >= 10, 'التخصصات تظهر (' + await page.locator('main a[href^="#/specialty/"]').count() + ')');
  await go('#/doctors');
  const nDoc = await page.locator('main a[href^="#/doctor/"]').count();
  ok(nDoc >= 20, 'الأطباء يظهرون (' + nDoc + ')');
  await go('#/branches');
  ok((await page.locator('main').innerText()).includes('قباء') && (await page.locator('main').innerText()).includes('التلال'), 'الفرعان قباء والتلال');
  await go('#/contact');
  ok((await page.locator('main').innerText()).includes('920031134'), 'الرقم الموحد 920031134');
  ok(await page.locator('a[href="tel:920031134"]').count() >= 1, 'زر اتصال بالرقم الموحد');
  await shot('p02-preview-contact');

  /* ---------- قمر محلياً ---------- */
  await go('#/');
  ok(!(await page.locator('.fab').isVisible()), 'الرئيسية: لا أيقونة عائمة (قمر موجود كبطاقة)');
  await page.locator('.qm-in').click();
  await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
  const ask = async (q) => {
    const before = await page.locator('.sheet .m.bot:not(.typing)').count();
    await page.fill('#qin', q);
    await page.locator('.sheet .send').click();
    await page.waitForFunction((n) => document.querySelectorAll('.sheet .m.bot:not(.typing)').length > n, before, { timeout: 10000 });
    await sleep(150);
    return (await page.locator('.sheet .m.bot:not(.typing)').last().innerText()).trim();
  };
  let a = await ask('عندي ألم في الركبة');
  ok(a.includes('عظام'), 'قمر يوجّه لألم الركبة إلى العظام (محلياً)');
  await shot('p03-preview-qamar');
  a = await ask('ألم شديد في الصدر وضيق نفس');
  ok(a.includes('997'), 'قمر: الطوارئ → 997');
  a = await ask('هل يوجد موقف سيارات');
  ok(a.length > 10, 'سؤال غير مفهوم: رد محلي آمن بلا اتصال: «' + a.slice(0, 60).replace(/\n/g, ' ') + '…»');
  a = await ask('أبي أحجز مع طبيب أسنان');
  await page.locator('.sheet .m.bot').last().locator('.act.book').first().click();
  await sleep(500);
  ok((await page.evaluate(() => location.hash)).startsWith('#/book'), 'زر الحجز من قمر ينقل لصفحة الحجز');

  /* ---------- الحجز التجريبي لا يُرسل ---------- */
  ok((await page.locator('#bkroot').innerText()).includes('نسخة تجريبية'), 'صفحة الحجز تنبّه أنها تجريبية');
  await page.fill('#f-name', 'اسم تجريبي');
  await page.fill('#f-phone', '0501234567');
  await page.locator('#f-consent').check();
  await page.locator('#f-submit').click();
  await sleep(500);
  const done = await page.locator('#bkroot').innerText();
  ok(done.includes('لم يُرسَل') && done.includes('نسخة تجريبية') && !/DS-[A-Z0-9]{6}/.test(done), 'بعد «إرسال»: يوضح أنه لم يُرسَل شيء ولا يخترع رقم طلب');
  ok(await page.evaluate(() => { try { return !localStorage.getItem('ds.myBookings') && !Object.keys(localStorage).some((k) => /booking/i.test(k)); } catch (e) { return true; } }), 'لا حجوزات محفوظة محلياً');
  await shot('p04-preview-book-demo');

  /* ---------- حسابي والإشعارات ---------- */
  await go('#/profile');
  ok((await page.locator('main').innerText()).includes('نسخة تجريبية'), 'حسابي: يوضح أنها نسخة تجريبية');
  await go('#/notifications');
  ok((await page.locator('main').innerText()).includes('أمثلة'), 'الإشعارات: أمثلة موضّحة بأنها ليست حقيقية');

  /* ---------- لا شبكة ولا CSP ولا أخطاء ---------- */
  const external = nets.filter((u) => !/^(file|data|about|blob):/.test(u));
  ok(external.length === 0, 'صفر طلبات شبكة (http/https): ' + JSON.stringify(external.slice(0, 3)));
  const csp = await page.evaluate(() => window.__csp);
  ok(csp.length === 0, 'لا انتهاكات CSP: ' + JSON.stringify(csp));
  ok(errors.length === 0, 'لا أخطاء جافاسكربت/كونسول ' + (errors.length ? JSON.stringify(errors.slice(0, 3)) : ''));

  /* ---------- الحماية الفعلية: المتصفح نفسه يمنع الاتصال ---------- */
  const probe = await page.evaluate(() => fetch('https://example.com/').then(() => 'allowed', (e) => 'blocked'));
  ok(probe === 'blocked', 'CSP تمنع فعلياً أي fetch خارجي: ' + probe);
  await page.evaluate(() => { try { navigator.sendBeacon('https://example.com/x', 'a'); } catch (e) { /* محجوب */ } });   // sendBeacon يرجع true حتى لو حُجب لاحقاً، فنفحص الانتهاك والشبكة
  await sleep(400);
  const csp2 = await page.evaluate(() => window.__csp);
  ok(csp2.some((v) => /connect-src/.test(v) && /example\.com\/x/.test(v)) && !nets.some((u) => /example\.com\/x/.test(u)), 'CSP تحجب sendBeacon: لم يخرج أي طلب (انتهاك connect-src مسجّل)');

  /* ---------- لقطات شاشة البداية (صفحة منفصلة كي لا تتأثر قياسات التوقيت أعلاه) ---------- */
  const sp = await ctx.newPage();
  const ts = Date.now();
  await sp.goto('file://' + FILE, { waitUntil: 'commit' });
  for (const [ms, name] of [[500, 'p00a-splash'], [850, 'p00b-splash'], [1450, 'p00c-splash']]) {
    const w = ms - (Date.now() - ts); if (w > 0) await sleep(w);
    await sp.screenshot({ path: path.join(SHOTS, name + '.png') });
  }
  await sp.close();

  await browser.close();
  console.log('\nالنتيجة: ' + passes + ' ناجح، ' + fails + ' فاشل');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('خطأ في الاختبار:', e); process.exit(2); });
