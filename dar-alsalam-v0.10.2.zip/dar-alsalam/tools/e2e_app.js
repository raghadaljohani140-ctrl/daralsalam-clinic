/* اختبار شامل للتطبيق على شاشة جوال (Playwright + Chrome). التشغيل:
   NODE_PATH=<مسار playwright> node tools/e2e_app.js [BASE_URL] [ADMIN_PASSWORD]
   يلتقط لقطات في qa/shots ويطبع PASS/FAIL ويخرج برمز غير صفري عند أي فشل. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8090';
const ADMIN_PW = process.argv[3] || 'devpass-12345';
const SHOTS = path.join(__dirname, '..', 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
let fails = 0, passes = 0;
function ok(cond, msg) { if (cond) { passes++; console.log('PASS', msg); } else { fails++; console.log('FAIL', msg); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('dialog', (d) => d.dismiss());

  const shot = async (name, full) => { await sleep(350); await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: !!full }); };
  const go = async (hash) => { await page.evaluate((h) => { location.hash = h; }, hash); await sleep(250); };
  const text = async (sel) => (await page.locator(sel).first().innerText()).trim();

  /* ---------- التشغيل ---------- */
  await page.goto(BASE + '/app/', { waitUntil: 'networkidle' });
  await page.waitForSelector('#view .hbn', { timeout: 8000 });
  ok(await page.locator('.tabs .tab').count() === 5, 'شريط التبويب فيه 5 عناصر');
  ok((await page.locator('.tabs .tab').evaluateAll((els) => els.map((e) => e.getAttribute('data-tab')))).join() === 'home,doctors,quick,hub,more', 'ترتيب التبويبات: الرئيسية، الأطباء، «+»، الخدمات، المزيد');
  ok(await page.locator('.fab').isVisible() && await page.locator('.qm-card').count() === 0, 'الرئيسية: أيقونة قمر العائمة ظاهرة ولا بطاقة كبيرة لقمر');
  ok((await text('.hbn .welcome h2')).includes('دار السلام'), 'الرئيسية تعرض اسم المجمع في بانر الترحيب');
  ok(await page.evaluate(() => document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]').content === 'black-translucent' && /viewport-fit=cover/.test(document.querySelector('meta[name="viewport"]').content)), 'شريط الحالة في آيفون شفاف والصفحة تمتد تحته (black-translucent + viewport-fit=cover)');
  ok(await page.locator('.ribbon').isVisible(), 'شريط «بيانات قيد المراجعة» ظاهر لأن dataStatus=draft');
  await shot('01-home', false);
  await shot('01-home-full', true);

  /* ---------- الهوية والتنقل: شاشة البداية والتبويبات والزر المركزي ---------- */
  ok(await page.locator('#app .splash').count() === 0, 'شاشة البداية زالت بعد التحميل');
  ok(await page.locator('.tabs .tab.cta').count() === 1 && (await page.locator('.tabs .tab.cta').getAttribute('aria-haspopup')) === 'dialog', 'الزر المركزي «+» موجود ويفتح نافذة');
  ok(await page.locator('.tabs .tab.on').count() === 1 && (await page.locator('.tabs .tab.on').getAttribute('data-tab')) === 'home', 'تبويب الرئيسية وحده نشط');
  ok(await page.evaluate(() => { const i = document.querySelector('#bar .logo-s'); return !!i && i.complete && i.naturalWidth > 0; }), 'شعار الشريط العلوي (الأقواس البيضاء) يُحمَّل');
  ok(await page.evaluate(() => [...document.images].every((i) => i.complete && i.naturalWidth > 0)), 'كل صور الرئيسية تُحمَّل');
  ok(await page.locator('.qcard .qc-page').count() === 2 && await page.locator('.qcard .dots i').count() === 2 && await page.locator('.qcard .dots i.on').count() === 1, 'شبكة الإجراءات: صفحتان ونقطتان ونقطة نشطة واحدة');
  ok(await page.locator('.qcard .qc-page').nth(0).locator('.qt').count() === 6 && await page.locator('.qcard .qc-page').nth(1).locator('.qt').count() === 6, 'الصفحتان: 6 بلاطات في كل صفحة');
  const q1 = (await page.locator('.qcard .qc-page').nth(0).locator('.qt').allInnerTexts()).map((t) => t.trim()).join('|');
  ok(['المواعيد', 'السجلات الطبية', 'نتائج المختبر', 'نتائج الأشعة', 'الوصفات الطبية', 'الموافقات الطبية'].every((w) => q1.includes(w)), 'الصفحة الأولى: ' + q1.replace(/\n/g, ''));
  ok(await page.locator('.qcard .qt.soon').count() === 8 && (await page.locator('.qcard .qc-page').nth(1).innerText()).includes('التثقيف الصحي'), 'بلاطات بيانات المريض «قريباً» (8) والمواعيد والتثقيف تعمل');
  ok((await page.locator('a.qt:has-text("نتائج المختبر")').getAttribute('href')) === '#/results/lab' && (await page.locator('a.qt:has-text("نتائج الأشعة")').getAttribute('href')) === '#/results/radiology', 'بلاطتا «نتائج المختبر» و«نتائج الأشعة» حيّتان (تفتحان صفحة النتائج) وليستا «قريباً»');
  await page.locator('.qcard .qt.soon').first().click(); await sleep(300);
  ok((await page.locator('#toast').innerText()).includes('تتوفر هذه الخدمة قريباً'), 'ضغط بلاطة «قريباً» يوضّح أنها تتوفر بعد الربط ولا يفتح شيئاً');
  ok(await page.locator('#svs .svp').count() === 3 && await page.locator('#svs .svp.em').count() === 1, 'شريط الخدمات الصغير: ثلاث خدمات والطوارئ مميّزة');
  ok(await page.locator('#explore').count() === 0, '«استكشف» لا يظهر حين لا توجد لوحات له (الخدمات لا تملؤه)');
  ok(await page.locator('#view .hs .spec-chip').count() === 13 && await page.locator('#view .hs .doc-card').count() === 0, 'صف التخصصات (13) في الرئيسية، والأطباء ليسوا فيها (لهم تبويب)');
  ok(await page.locator('.stats').count() === 0 && await page.locator('.foot').count() === 0 && await page.locator('.emerg').count() === 0, 'الرئيسية بلا شريط إحصاءات ولا تذييل ولا بطاقة طوارئ مكررة');
  ok(await page.evaluate(() => document.documentElement.scrollHeight < 2.4 * innerHeight), 'الرئيسية قصيرة (أقل من شاشتين ونصف) وليست صفحة طويلة: ' + await page.evaluate(() => Math.round(document.documentElement.scrollHeight / innerHeight * 100) / 100 + ' شاشة'));
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'لا تمرير أفقي في الرئيسية');
  ok(await page.evaluate(() => { const a = document.querySelector('#app').getBoundingClientRect(), b = document.querySelector('.hbn').getBoundingClientRect(); return Math.abs(a.width - b.width) < 1 && Math.abs(a.left - b.left) < 1; }), 'البانر بعرض الشاشة كاملاً بلا هوامش جانبية');

  await page.locator('.tab.cta').click();
  await page.waitForSelector('#qaroot .sheet.qa');
  const qa = (await page.locator('#qaroot .qa-i').allInnerTexts()).map((t) => t.trim());
  ok(['طلب حجز', 'اسأل', 'اتصال', 'الفروع', 'طلباتي'].every((w) => qa.some((t) => t.includes(w))), 'الإجراءات السريعة: ' + qa.join(' | '));
  ok((await page.locator('#qaroot .qa-em').innerText()).includes('997'), 'سطر الإسعاف 997 ظاهر في الإجراءات السريعة');
  ok(await page.evaluate(() => !!document.activeElement && !!document.activeElement.closest('#qaroot')), 'التركيز ينتقل إلى نافذة الإجراءات');
  await shot('23-quick-actions');
  await page.keyboard.press('Escape'); await sleep(200);
  ok(await page.locator('#qaroot').count() === 0, 'Escape يغلق الإجراءات السريعة');
  ok(await page.evaluate(() => !!document.activeElement && document.activeElement.classList.contains('cta')), 'التركيز يعود إلى الزر المركزي');
  await page.locator('.tab.cta').click(); await page.waitForSelector('#qaroot .sheet');
  await page.mouse.click(195, 60);
  await sleep(250);
  ok(await page.locator('#qaroot').count() === 0, 'النقر على الخلفية المعتمة يغلق الإجراءات السريعة');
  await page.locator('.tab.cta').click(); await page.waitForSelector('#qaroot .sheet');
  await page.locator('#qaroot .qa-i', { hasText: 'اسأل' }).click();
  await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
  ok(await page.locator('#qaroot').count() === 0 && await page.locator('.sheet').isVisible(), '«اسأل قمر» من الإجراءات السريعة يفتح قمر ويغلق القائمة');
  await page.locator('.sheet header [data-act="qamar-close"]').click(); await sleep(300);
  await page.locator('.tab.cta').click(); await page.waitForSelector('#qaroot .sheet');
  await page.locator('#qaroot .qa-i', { hasText: 'طلب حجز' }).click(); await sleep(400);
  ok((await page.evaluate(() => location.hash)).startsWith('#/book') && await page.locator('#qaroot').count() === 0, '«طلب حجز» من الإجراءات السريعة ينقل إلى نموذج الحجز');
  ok(await page.locator('.tabs .tab.on').count() === 0, 'صفحة الحجز: لا تبويب نشط (الزر المركزي ليس صفحة)');
  await go('#/');

  /* ---------- المزيد + مشاركة التطبيق ---------- */
  await go('#/more');
  ok(await page.locator('.tabs .tab.on').count() === 1 && (await page.locator('.tabs .tab.on').getAttribute('data-tab')) === 'more', 'صفحة المزيد: تبويب «المزيد» نشط');
  const more = await page.locator('#view').innerText();
  ok(['طلباتي وبياناتي', 'الإشعارات', 'عن المجمعات', 'التواصل', 'مشاركة التطبيق', 'سياسة الخصوصية', 'الإصدار 0.10.2'].every((w) => more.includes(w)), 'صفحة المزيد تحوي الأقسام المتوقعة');
  await shot('24-more');
  await page.evaluate(() => { try { Object.defineProperty(navigator, 'share', { value: undefined, configurable: true }); } catch (e) { /* تجاهل */ } window.__copied = null; navigator.clipboard.writeText = (t) => { window.__copied = t; return Promise.resolve(); }; });
  await page.locator('[data-act="share"]').click(); await sleep(400);
  ok(/^https:\/\/.+/.test(await page.evaluate(() => window.__copied || '')) && (await page.locator('#toast').innerText()).includes('تم نسخ'), 'مشاركة التطبيق بلا مشاركة أصلية: تنسخ رابط التطبيق');
  await page.waitForSelector('#toast:not(.on)', { state: 'attached', timeout: 5000 });
  await go('#/');

  /* ---------- شرائح العروض (تُدار من لوحة الإدارة) ---------- */
  const adm0 = await (await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: ADMIN_PW }) })).json();
  const AH = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + adm0.token };
  const mk = async (b) => { const r = await fetch(BASE + '/api/admin/entities/banners', { method: 'POST', headers: AH, body: JSON.stringify(b) }); return { status: r.status, body: await r.json().catch(() => ({})) }; };
  let bad = await mk({ id: 'bn-e2e-bad1', title: 'x', linkType: 'url', linkRef: 'http://insecure.example' });
  ok(bad.status === 422, 'الخادم يرفض رابطاً خارجياً غير https في اللوحة');
  bad = await mk({ id: 'bn-e2e-bad2', title: 'x', linkType: 'service', linkRef: 'لا-يوجد' });
  ok(bad.status === 422, 'الخادم يرفض خدمة غير موجودة في اللوحة');
  const seeds = [
    { id: 'bn-e2e-1', title: 'اختبار: احجز', text: 'نص توضيحي', buttonLabel: 'اطلب حجزاً', theme: 'blue', linkType: 'book', linkRef: 'dental', sort: 1 },
    { id: 'bn-e2e-2', title: 'اختبار: قمر', text: 'نص توضيحي', buttonLabel: 'ابدأ', theme: 'sky', linkType: 'qamar', sort: 2 },
    { id: 'bn-e2e-3', title: 'اختبار: بطاقة بلا رابط', text: 'قراءة فقط', theme: 'deep', sort: 3 },
    { id: 'bn-e2e-4', title: 'اختبار: مخفية', theme: 'light', active: false, sort: 4 },
  ];
  for (const b of seeds) { const r = await mk(b); ok(r.status === 201, 'إنشاء لوحة ' + b.id + ' عبر واجهة الإدارة'); }
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForSelector('.hbn .bn', { timeout: 8000 });
  ok(await page.locator('.hbn .bn').count() === 3 && await page.locator('.hbn .welcome').count() === 0, 'الشرائح الظاهرة 3 (المخفية لا تظهر) وتحلّ محل الترحيب الافتراضي');
  ok(await page.locator('.hbn .dots i').count() === 3 && await page.locator('.hbn .dots i.on').count() === 1, 'ثلاث نقاط تنقّل ونقطة نشطة واحدة');
  const hrefBook = await page.locator('.hbn .bn').nth(0).getAttribute('href');
  ok(/^#\/book/.test(hrefBook) && hrefBook.includes('dental'), 'شريحة الحجز ترتبط بنموذج الحجز مع التخصص: ' + hrefBook);
  ok((await page.locator('.hbn .bn').nth(2).evaluate((e) => e.tagName)) === 'DIV', 'شريحة بلا رابط تُعرض للقراءة فقط (ليست رابطاً)');
  ok(await page.locator('.hbn .bn').nth(2).locator('.bn-btn').count() === 0, 'لا زر على شريحة بلا رابط');
  ok(await page.evaluate(() => { const a = document.querySelector('#app').getBoundingClientRect(); return [...document.querySelectorAll('.hbn .bn')].every((e) => Math.abs(e.getBoundingClientRect().width - a.width) < 1); }), 'كل شريحة بعرض الشاشة كاملاً');
  await shot('01b-home-banners');
  const dotAt = () => page.evaluate(() => [...document.querySelectorAll('#bn-dots i')].findIndex((d) => d.classList.contains('on')));
  ok((await dotAt()) === 0, 'النقطة الأولى نشطة عند البداية');
  await page.evaluate(() => { const tr = document.querySelector('#bn-track'), s = document.querySelectorAll('#bn-track .bn')[1]; tr.scrollBy({ left: s.getBoundingClientRect().right - tr.getBoundingClientRect().right, behavior: 'auto' }); });
  await sleep(600);
  ok((await dotAt()) === 1, 'التمرير إلى الشريحة الثانية ينقل النقطة النشطة');
  await shot('01c-home-banners-2');
  await page.locator('.hbn .bn').nth(1).click();
  await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
  ok(await page.locator('.sheet').isVisible(), 'شريحة «قمر» تفتح المساعد');
  await page.locator('.sheet header [data-act="qamar-close"]').click(); await sleep(300);
  // رابط مكسور (الجهة المرتبطة حُذفت لاحقاً) → تبقى بطاقة للقراءة فقط بدل رابط ميّت
  await page.evaluate(() => { DS.data.ds.banners.push({ id: 'bn-x', title: 'رابط مكسور', linkType: 'doctor', linkRef: 'zzz', buttonLabel: 'افتح', theme: 'blue', active: true, sort: 9 }); DS.render(); });
  await sleep(300);
  const broken = page.locator('.hbn .bn', { hasText: 'رابط مكسور' });
  ok(await broken.count() === 1 && (await broken.evaluate((e) => e.tagName)) === 'DIV' && await broken.locator('.bn-btn').count() === 0, 'لوحة مرتبطة بعنصر محذوف تتحول إلى بطاقة قراءة فقط');
  for (const b of seeds) await fetch(BASE + '/api/admin/entities/banners/' + b.id + '?hard=1&confirm=' + b.id, { method: 'DELETE', headers: AH });
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForSelector('#view .hbn', { timeout: 8000 });
  ok(await page.locator('.hbn .bn').count() === 0 && await page.locator('.hbn .welcome').count() === 1 && await page.locator('.hbn .dots').count() === 0, 'بعد حذف اللوحات يعود بانر الترحيب الافتراضي بلا نقاط');

  /* ---------- الخدمات تُولَّد من البيانات: خدمة جديدة من لوحة الإدارة تظهر تلقائياً في الرئيسية والمركز ---------- */
  let svcR = await fetch(BASE + '/api/admin/entities/services', { method: 'POST', headers: AH, body: JSON.stringify({ id: 'sv-e2e', name: 'خدمة اختبار آلي', icon: 'heart', description: 'وصف الخدمة التجريبية', sort: 9 }) });
  ok(svcR.status === 201, 'إنشاء خدمة جديدة عبر واجهة الإدارة');
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForSelector('#view .hbn', { timeout: 8000 });
  ok(await page.locator('#svs .svp', { hasText: 'خدمة اختبار آلي' }).count() === 1 && await page.locator('#svs .svp').count() === 4, 'الخدمة الجديدة تظهر في شريط الخدمات بالرئيسية بلا أي تعديل في التطبيق');
  ok((await page.locator('#view').innerText()).includes('خدمة اختبار آلي') && await page.locator('#explore').count() === 0, 'وتظهر في الشريط فقط، لا في «استكشف»');
  await go('#/hub');
  ok((await page.locator('.hg', { hasText: 'الخدمات الطبية' }).innerText()).includes('خدمة اختبار آلي'), 'وتظهر في مركز «الخدمات»');
  await go('#/service/sv-e2e');
  ok((await text('.page-h h2')) === 'خدمة اختبار آلي', 'وتفتح صفحتها');
  svcR = await fetch(BASE + '/api/admin/entities/services/sv-e2e?hard=1&confirm=sv-e2e', { method: 'DELETE', headers: AH });
  ok(svcR.status === 200, 'حذف الخدمة التجريبية');
  await go('#/');
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForSelector('#view .hbn', { timeout: 8000 });
  ok(await page.locator('#svs .svp').count() === 3, 'بعد حذفها تختفي من الرئيسية');

  /* ---------- مركز «الخدمات» + سلامة كل رابط في الرئيسية والمركز ---------- */
  await go('#/hub');
  ok(await page.locator('.tabs .tab.on').count() === 1 && (await page.locator('.tabs .tab.on').getAttribute('data-tab')) === 'hub', 'مركز الخدمات: تبويب «الخدمات» نشط');
  const hubTxt = await page.locator('#view').innerText();
  ok(['اطلب حجزاً', 'التخصصات', 'الأطباء', 'الفروع والمواقع', 'الطوارئ', 'المختبرات', 'الأشعة', 'اسأل قمر', 'نصائح صحية', 'طلباتي', 'الإشعارات', 'اتصل بنا', 'واتساب', 'أرقام التواصل', 'الموقع الإلكتروني', 'عن المجمعات', 'مشاركة التطبيق', 'سياسة الخصوصية'].every((w) => hubTxt.includes(w)), 'مركز الخدمات يحوي كل المجموعات والبلاطات المتوقعة');
  ok(await page.locator('.hg').count() === 5 && await page.locator('.hub-cta[href="#/book"]').count() === 1, 'خمس مجموعات وزر حجز بارز');
  await shot('25-hub');
  const links = new Set();
  for (const h of ['#/', '#/hub', '#/more']) {
    await go(h);
    (await page.locator('#view a[href^="#/"]').evaluateAll((els) => els.map((e) => e.getAttribute('href')))).forEach((x) => links.add(x));
  }
  let dead = [];
  for (const h of links) {
    await go(h);
    const r = await page.evaluate(() => ({ path: DS.current().path, len: document.querySelector('#view').innerText.trim().length, bad: /غير موجود/.test(document.querySelector('#view').innerText) }));
    if (r.len < 15 || r.bad || (h !== '#/' && r.path === '/')) dead.push(h + ' → ' + JSON.stringify(r));
  }
  ok(dead.length === 0 && links.size >= 18, 'كل روابط الرئيسية والمركز والمزيد (' + links.size + ') تفتح صفحات حقيقية' + (dead.length ? ': ' + dead.join(' | ') : ''));
  await go('#/specialties');
  ok((await page.locator('.tabs .tab.on').getAttribute('data-tab')) === 'hub' && await page.locator('.bar [data-act="back"]').count() === 1, 'التخصصات: تبويب «الخدمات» نشط وفيها زر رجوع');
  await go('#/doctors');
  ok((await page.locator('.tabs .tab.on').getAttribute('data-tab')) === 'doctors' && await page.locator('.bar [data-act="back"]').count() === 0, 'الأطباء: تبويب «الأطباء» نشط وبلا زر رجوع');
  await go('#/tips');
  ok(await page.locator('details.acc').count() === 4, 'صفحة النصائح الصحية: 4 نصائح');
  await shot('28-tips');

  /* ---------- أيقونة قمر العائمة: في القوائم فقط، ومخفية حيث تغطي الأزرار ---------- */
  const fabOn = () => page.locator('.fab').isVisible();
  await go('#/doctors'); ok(await fabOn(), 'الأطباء: أيقونة قمر ظاهرة');
  await go('#/hub'); ok(await fabOn(), 'الخدمات: أيقونة قمر ظاهرة');
  await go('#/more'); ok(await fabOn(), 'المزيد: أيقونة قمر ظاهرة');
  await go('#/'); ok(await fabOn(), 'الرئيسية: ظاهرة');
  await go('#/specialty/dental'); ok(!(await fabOn()), 'صفحة التخصص (فيها زر حجز ثابت): مخفية');
  await go('#/doctor/' + (await page.evaluate(() => DS.data.ds.doctors[0].id))); ok(!(await fabOn()), 'صفحة الطبيب: مخفية');
  await go('#/book'); ok(!(await fabOn()), 'نموذج الحجز: مخفية');
  await go('#/doctors');
  ok(await page.evaluate(() => { const f = document.querySelector('.fab').getBoundingClientRect(); return Math.abs(f.height - 46) < 1 && f.width < 150; }), 'زر «اسأل قمر» صغير مكتوب (46px ارتفاعاً، لا يغطي المحتوى)');

  /* ---------- شبكة الإجراءات: تمرير الصفحات ومزامنة النقاط ---------- */
  await go('#/');
  const qdot = () => page.evaluate(() => [...document.querySelectorAll('#qc-dots i')].findIndex((d) => d.classList.contains('on')));
  ok((await qdot()) === 0, 'النقطة الأولى نشطة');
  await page.evaluate(() => { const tr = document.querySelector('#qc-track'); tr.scrollBy({ left: -tr.clientWidth, behavior: 'auto' }); });
  await sleep(600);
  ok((await qdot()) === 1, 'التمرير إلى الصفحة الثانية ينقل النقطة النشطة');
  ok(await page.evaluate(() => { const t = [...document.querySelectorAll('.qc-page')[1].querySelectorAll('.qt')][0].getBoundingClientRect(), c = document.querySelector('#qc-track').getBoundingClientRect(); return t.left >= c.left - 1 && t.right <= c.right + 1; }), 'بلاطات الصفحة الثانية ظاهرة داخل البطاقة');
  await shot('26-quick-page2');
  ok(await page.evaluate(() => getComputedStyle(document.querySelector('.qt')).userSelect === 'none' && getComputedStyle(document.querySelector('.tabs')).userSelect === 'none'), 'عناصر الواجهة لا تُحدَّد بالضغط المطوّل');

  /* ---------- الرجوع يعيد موضع التمرير (سلوك التطبيقات) ---------- */
  await go('#/');
  const maxY = await page.evaluate(() => document.documentElement.scrollHeight - innerHeight), y0 = Math.max(0, Math.min(240, maxY));
  await page.evaluate((y) => window.scrollTo(0, y), y0); await sleep(200);
  await shot('01d-home-scrolled');
  await page.evaluate(() => document.querySelector('#view .spec-chip').click()); await sleep(450);
  ok((await page.evaluate(() => location.hash)).startsWith('#/specialty/') && (await page.evaluate(() => Math.round(scrollY))) === 0, 'فتح التخصص يبدأ من أعلى الصفحة');
  await page.evaluate(() => history.back()); await sleep(800);
  const yBack = await page.evaluate(() => Math.round(scrollY));
  ok((maxY < 20 || y0 >= 20) && Math.abs(yBack - y0) <= 3, 'الرجوع إلى الرئيسية يعيدك إلى الموضع نفسه (' + yBack + ' ≈ ' + y0 + ')');
  await go('#/doctors');
  await page.evaluate(() => window.scrollTo(0, 300)); await sleep(150);
  await page.evaluate(() => document.querySelectorAll('#list .item')[8].click()); await sleep(450);
  await page.evaluate(() => history.back()); await sleep(900);
  const yDoc = await page.evaluate(() => Math.round(scrollY));
  ok(Math.abs(yDoc - 300) <= 3, 'القوائم المرسومة بعد لحظة (الأطباء) تعيد الموضع أيضاً (' + yDoc + ' ≈ 300)');

  /* ---------- التبويبات: لمس غير النشط يفتح بدايته، ولمس النشط يعيدك إلى الأعلى ---------- */
  await go('#/'); await page.evaluate(() => window.scrollTo(0, 240)); await sleep(150);
  await page.locator('.tabs .tab[data-tab="doctors"]').click(); await sleep(450);
  await page.locator('.tabs .tab[data-tab="home"]').click(); await sleep(800);
  ok((await page.evaluate(() => Math.round(scrollY))) === 0 && (await page.evaluate(() => location.hash || '#/')) === '#/', 'لمس تبويب «الرئيسية» يفتحها من أعلاها لا من موضع قديم');
  await page.evaluate(() => window.scrollTo(0, 400)); await sleep(150);
  await page.locator('.tabs .tab[data-tab="home"]').click(); await sleep(1100);
  ok((await page.evaluate(() => Math.round(scrollY))) === 0 && (await page.evaluate(() => location.hash || '#/')) === '#/', 'لمس التبويب النشط يعيد الصفحة إلى أعلاها دون تغيير الصفحة');
  await page.locator('.tabs .tab[data-tab="doctors"]').click(); await sleep(450);
  ok(await page.evaluate(() => history.length > 1) && (await page.evaluate(() => location.hash)) === '#/doctors', 'التنقل بين التبويبات يعمل بعد ذلك');

  /* ---------- حدود الشاشة: لا تمرير أفقي، ولا شيء مخفي تحت الشريطين (محاكاة حواف آيفون) ---------- */
  await page.evaluate(() => { const r = document.documentElement.style; r.setProperty('--safe-area-inset-top', '47px'); r.setProperty('--safe-area-inset-bottom', '34px'); });
  await go('#/');
  await page.evaluate(() => window.scrollTo(0, 0)); await sleep(150);
  const geo = await page.evaluate(() => {
    const bar = document.querySelector('.bar').getBoundingClientRect(), rib = document.querySelector('.ribbon'), hb = document.querySelector('.hbn').getBoundingClientRect();
    return { bar: Math.round(bar.height), top: Math.round(hb.top), ribBottom: Math.round(rib.hidden ? bar.bottom : rib.getBoundingClientRect().bottom) };
  });
  ok(geo.bar === 58 + 47 && geo.top === geo.ribBottom, 'البانر يبدأ تحت الشريط العلوي مباشرة بلا فراغ ولا تداخل (شريط ' + geo.bar + 'px، بداية البانر ' + geo.top + ' = ' + geo.ribBottom + ')');
  for (const hh of ['#/', '#/hub', '#/more', '#/doctors', '#/specialties']) {
    await go(hh);
    await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight)); await sleep(150);
    const g2 = await page.evaluate(() => {
      const kids = [...document.querySelectorAll('#view > *:not(script)')], last = kids[kids.length - 1], t = document.querySelector('.tabs').getBoundingClientRect();
      return { bottom: Math.round(last.getBoundingClientRect().bottom), tabTop: Math.round(t.top), over: document.documentElement.scrollWidth - innerWidth };
    });
    ok(g2.bottom <= g2.tabTop && g2.over <= 0, hh + ': آخر عنصر يظهر فوق شريط التبويب بلا تمرير أفقي (' + g2.bottom + ' ≤ ' + g2.tabTop + ')');
  }
  await page.evaluate(() => { const r = document.documentElement.style; r.removeProperty('--safe-area-inset-top'); r.removeProperty('--safe-area-inset-bottom'); });
  await page.setViewportSize({ width: 360, height: 740 });
  for (const hh of ['#/', '#/hub', '#/more', '#/doctors', '#/specialties', '#/service/emergency', '#/book']) {
    await go(hh);
    ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'عرض 360px: ' + hh + ' بلا تمرير أفقي');
  }
  await go('#/'); await shot('27-home-360');
  await page.setViewportSize({ width: 390, height: 844 });
  await go('#/');

  /* ---------- صفحات المعلومات ---------- */
  await go('#/specialties');
  ok(await page.locator('#list .tile').count() === 13, 'قائمة التخصصات: 13');
  await page.fill('#q', 'ركبة');
  await sleep(200);
  ok(await page.locator('#list .tile').count() >= 1, 'بحث «ركبة» يعيد تخصصاً');
  ok((await page.locator('#list').innerText()).includes('عظام'), 'بحث «ركبة» يقود إلى العظام');
  await page.fill('#q', '');
  await shot('02-specialties');

  await go('#/specialty/internal');
  ok((await text('.page-h h2')) === 'الباطنة', 'صفحة تخصص الباطنة');
  await shot('03-specialty');

  await go('#/doctors');
  ok(await page.locator('#list .item').count() === 27, 'قائمة الأطباء: 27');
  ok(await page.evaluate(() => DS.initials('مصطفى الحردلو') === 'مح' && DS.initials('رامي السمنودي') === 'رس' && DS.initials('قاسم جمال') === 'قج' && DS.initials('') === ''), 'حروف الصورة الرمزية تتجاوز «ال» التعريف');
  await page.locator('#chips .chip').nth(2).click();
  await sleep(200);
  ok(await page.locator('#list .item').count() < 27, 'التصفية بالتخصص تقلّص القائمة');
  await shot('04-doctors');
  await go('#/doctors');
  await page.locator('#list .item').first().click();
  await sleep(300);
  ok(location_hash_ok(await page.evaluate(() => location.hash), '#/doctor/'), 'فتح صفحة طبيب');
  ok(await page.locator('.sticky-cta .btn').isVisible(), 'زر «اطلب حجزاً» ظاهر في صفحة الطبيب');
  await shot('05-doctor');

  await go('#/services');
  ok(await page.locator('.item').count() === 3, 'الخدمات: 3');
  await go('#/service/emergency');
  ok((await page.locator('.sticky-cta').innerText()).includes('اتصل'), 'خدمة الطوارئ فيها اتصال');
  ok(!(await page.locator('.sticky-cta').innerText()).includes('اطلب حجزاً'), 'الطوارئ بدون زر حجز');
  await shot('06-service-emergency');

  await go('#/branches');
  ok(await page.locator('.card .ico-box').count() >= 2, 'قائمة الفروع');
  await shot('07-branches');
  await go('#/branch/quba');
  ok(await page.locator('.mapph').count() === 1, 'بلا إحداثيات: عنصر نائب + روابط الخرائط');
  ok((await page.locator('a[href*="google.com/maps"]').count()) === 1, 'رابط خرائط قوقل موجود');
  await shot('08-branch');
  await go('#/contact');
  ok((await page.locator('body').innerText()).includes('920031134'), 'صفحة التواصل تعرض الرقم الموحد');
  await shot('09-contact');
  await go('#/about');
  await shot('10-about');
  await go('#/privacy');
  ok((await page.locator('.prose').innerText()).includes('ما الذي نجمعه'), 'سياسة الخصوصية');
  ok(!(await page.locator('.prose').innerText()).includes('ذكاء اصطناعي خارجية'), 'الخصوصية: لا فقرة مزوّد خارجي ما دام معطّلاً');
  await page.evaluate(() => { DS.data.ds.qamar.externalAi = true; });
  await go('#/about'); await go('#/privacy');
  const privAi = await page.locator('.prose').innerText();
  ok(privAi.includes('ذكاء اصطناعي خارجية') && privAi.includes('خارج المملكة') && privAi.includes('وكذلك ما أُرسل منها للمزوّد الخارجي'), 'الخصوصية: تظهر فقرة المزوّد الخارجي حين يعلن الخادم تفعيله');
  await page.evaluate(() => { DS.data.ds.qamar.externalAi = false; });
  await go('#/about'); await go('#/privacy');
  ok(!(await page.locator('.prose').innerText()).includes('ذكاء اصطناعي خارجية'), 'الخصوصية: تختفي الفقرة حين يُعطَّل');

  /* ---------- الحجز ---------- */
  await go('#/book');
  await shot('11-book-empty');
  await page.locator('#f-submit').click();
  await sleep(250);
  ok(await page.locator('[data-err="sel"]:not([hidden])').count() === 1, 'خطأ: لم يُختر تخصص');
  ok(await page.locator('[data-err="name"]:not([hidden])').count() === 1, 'خطأ: الاسم');
  ok(await page.locator('[data-err="phone"]:not([hidden])').count() === 1, 'خطأ: الجوال');
  ok(await page.locator('[data-err="consent"]:not([hidden])').count() === 1, 'خطأ: الموافقة');
  await shot('12-book-errors');

  await go('#/book?sp=orthopedics&br=quba');
  await sleep(300);
  const selVal = await page.locator('#f-sel').inputValue();
  ok(selVal.startsWith('sp:'), 'تعبئة التخصص من الرابط: ' + selVal);
  await page.fill('#f-name', 'أحمد تجريبي');
  await page.fill('#f-phone', '٠٥٠١٢٣٤٥٦٧');
  await page.fill('#f-note', 'اختبار آلي — لا تتصلوا');
  await page.locator('#f-consent').check();
  await shot('13-book-filled');
  await page.locator('#f-submit').click();
  await page.waitForSelector('.okmark', { timeout: 8000 });
  const bid = await text('.bk-id');
  ok(/^DS-[A-Z0-9]{6}$/.test(bid), 'رقم الطلب: ' + bid);
  const body = await page.locator('#bkroot').innerText();
  ok(body.includes('ليس موعداً مؤكداً'), 'نص «ليس موعداً مؤكداً» ظاهر بعد الإرسال');
  ok(!body.includes('تم حجز موعدك') && !body.includes('تم تأكيد'), 'لا يوجد ادعاء بتأكيد الحجز');
  await shot('14-book-success');
  await go('#/');
  await page.waitForSelector('#home-bk .bkc', { timeout: 6000 });
  const bkc1 = await page.locator('#home-bk .bkc').innerText();
  ok(bkc1.includes('طلباتي') && bkc1.includes('تم الاستلام') && !bkc1.includes('مؤكد'), 'بطاقة «طلباتي» في الرئيسية: «تم الاستلام» دون ادّعاء تأكيد');

  /* ---------- حسابي ---------- */
  await go('#/profile');
  await page.waitForSelector('.bk', { timeout: 6000 });
  ok((await text('.bk .status')) === 'تم الاستلام', 'حالة الطلب في حسابي: تم الاستلام');
  ok((await page.locator('.bk').innerText()).includes('ليس موعداً مؤكداً'), 'ملاحظة عدم التأكيد في بطاقة الطلب');
  await shot('15-profile');

  // الموظف يؤكد الطلب من لوحة الإدارة (واجهة API) → يظهر الموعد للمراجع
  const login = await (await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: ADMIN_PW }) })).json();
  const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + login.token };
  const lst = await (await fetch(BASE + '/api/admin/bookings', { headers: H })).json();
  ok(lst.bookings.some((b) => b.id === bid), 'الطلب وصل إلى لوحة الإدارة');
  let r = await fetch(BASE + '/api/admin/bookings/' + bid, { method: 'PATCH', headers: H, body: JSON.stringify({ status: 'confirmed' }) });
  ok(r.status === 422, 'الخادم يرفض «مؤكد» بدون نص الموعد (' + r.status + ')');
  r = await fetch(BASE + '/api/admin/bookings/' + bid, { method: 'PATCH', headers: H, body: JSON.stringify({ status: 'confirmed', appointmentText: 'الأحد 10 صباحاً — عيادة العظام' }) });
  ok(r.status === 200, 'الموظف يؤكد الطلب بنص موعد');
  await page.reload({ waitUntil: 'networkidle' });
  await go('#/profile');
  await page.waitForSelector('.bk .status', { timeout: 6000 });
  ok((await text('.bk .status')) === 'مؤكد', 'الحالة تتحول إلى «مؤكد» بعد تثبيت الموظف');
  ok((await page.locator('.bk').innerText()).includes('الأحد 10 صباحاً'), 'نص الموعد يظهر للمراجع');
  await shot('16-profile-confirmed');
  await go('#/');
  await page.waitForSelector('#home-bk .bkc', { timeout: 6000 });
  await page.waitForFunction(() => /مؤكد/.test(document.querySelector('#home-bk .bkc').innerText), null, { timeout: 8000 });
  const bkc2 = await page.locator('#home-bk .bkc').innerText();
  ok(bkc2.includes('الأحد 10 صباحاً'), 'بطاقة «طلباتي» تعرض نص الموعد المؤكد من الخادم');
  await shot('16b-home-my-requests');

  // الإشعارات
  await sleep(200);
  ok(await page.locator('#nbadge:not([hidden])').count() === 1, 'شارة الإشعارات تظهر');
  await go('#/notifications');
  await page.waitForSelector('.nt', { timeout: 6000 });
  ok(await page.locator('.nt').count() >= 1, 'إشعار بتأكيد الطلب');
  await shot('17-notifications');
  await sleep(300);
  ok(await page.locator('#nbadge:not([hidden])').count() === 0, 'الشارة تختفي بعد فتح الإشعارات');

  // طلب ثانٍ ثم إلغاؤه
  await go('#/book?sp=dental');
  await page.fill('#f-name', 'أحمد تجريبي');
  await page.fill('#f-phone', '0501234567');
  await page.locator('#f-consent').check();
  await page.locator('#f-submit').click();
  await page.waitForSelector('.okmark', { timeout: 8000 });
  await go('#/profile');
  await page.waitForSelector('.bk', { timeout: 6000 });
  const cancelBtn = page.locator('[data-act="bk-cancel"]').first();
  await cancelBtn.click();
  ok((await cancelBtn.innerText()).includes('مرة أخرى'), 'الإلغاء يحتاج ضغطتين');
  await cancelBtn.click();
  await sleep(600);
  ok((await page.locator('.bk .status.s-cancelled').count()) === 1, 'الطلب الملغي يظهر «ملغي»');
  // ننتظر زوال إشعار «أُلغي الطلب» العائم كي لا يظهر في لقطات قمر التالية
  await page.waitForSelector('#toast:not(.on)', { state: 'attached', timeout: 5000 });

  /* ---------- قمر ---------- */
  await go('#/');
  await page.evaluate(() => document.querySelector('.fab').click());
  await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
  ok(await page.locator('.sheet').isVisible(), 'نافذة قمر تفتح من الأيقونة العائمة في الرئيسية');
  await shot('18-qamar-open');
  const ask = async (q) => {
    const before = await page.locator('.sheet .m.bot:not(.typing)').count();
    await page.fill('#qin', q);
    await page.locator('.sheet .send').click();
    await page.waitForFunction((n) => document.querySelectorAll('.sheet .m.bot:not(.typing)').length > n, before, { timeout: 15000 });
    await sleep(150);
    return (await page.locator('.sheet .m.bot:not(.typing)').last().innerText()).trim();
  };
  let a = await ask('عندي ألم في الركبة');
  ok(a.includes('عظام'), 'قمر يقترح العظام لألم الركبة');
  ok(await page.locator('.sheet .m.bot').last().locator('.act.book').count() === 1, 'يظهر زر «ابدأ طلب الحجز»');
  await shot('19-qamar-route');
  a = await ask('ألم شديد في الصدر وضيق نفس');
  ok(a.includes('997'), 'حالة طارئة: رد بالإسعاف 997');
  ok(await page.locator('.sheet .m.bot').last().locator('.act.em').count() >= 1, 'زر اتصال بالإسعاف');
  await shot('20-qamar-emergency');
  a = await ask('هل عندي سكر؟');
  ok(!/عندك سكر|مصاب/.test(a), 'قمر لا يشخّص');
  a = await ask('وين الفروع؟');
  ok(a.includes('قباء'), 'قمر يذكر الفروع');
  a = await ask('أبي أحجز مع طبيب عظام');
  await page.locator('.sheet .m.bot').last().locator('.act.book').first().click();
  await sleep(500);
  ok((await page.evaluate(() => location.hash)).startsWith('#/book'), 'زر الحجز في قمر ينقل لصفحة الحجز');
  ok(await page.locator('.sheet').count() === 0, 'النافذة تُغلق بعد الانتقال');
  ok((await page.locator('#f-sel').inputValue()).startsWith('sp:'), 'التخصص معبّأ من قمر');
  await shot('21-book-from-qamar');

  // بدون إنترنت: قمر يعمل محلياً
  await ctx.setOffline(true);
  await go('#/doctors');
  await page.evaluate(() => document.querySelector('.fab').click());
  a = await ask('كم رقم المجمع؟');
  ok(/920031134/.test(a), 'بدون إنترنت: قمر يجيب من القاعدة المحلية');
  await shot('22-qamar-offline');
  await page.locator('.sheet header [data-act="qamar-close"]').click();
  await ctx.setOffline(false);

  // حذف بياناتي
  await go('#/profile');
  const del = page.locator('[data-act="del-data"]');
  await del.click(); await del.click();
  await sleep(800);
  const left = await page.evaluate(() => Object.keys(localStorage).filter((k) => /ds\.(profile|myBookings)/.test(k)).length);
  ok(left === 0, 'حذف بياناتي يمسح التخزين المحلي');
  await go('#/');
  ok(await page.locator('#home-bk .bkc').count() === 0, 'بعد حذف بياناتي تختفي بطاقة «طلباتي» من الرئيسية');

  /* ---------- ترقية التطبيق: يتولّى عامل خدمة جديد الصفحة ← تُعاد مرة واحدة، ولا تُقاطَع صفحة الحجز ---------- */
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForSelector('#view .hbn');
  let controlled = true;
  try { await page.waitForFunction(() => navigator.serviceWorker && navigator.serviceWorker.controller, null, { timeout: 6000 }); } catch (e) { controlled = false; }
  ok(controlled, 'عامل الخدمة يتحكم بالصفحة (يعمل التخزين للتشغيل السريع)');
  await page.evaluate(() => { window.__m = 1; navigator.serviceWorker.dispatchEvent(new Event('controllerchange')); });
  await sleep(1800);
  ok(await page.evaluate(() => window.__m === undefined) && await page.locator('#view .hbn').count() === 1, 'عند صدور نسخة جديدة تُعاد الصفحة تلقائياً مرة واحدة');
  await page.waitForFunction(() => navigator.serviceWorker && navigator.serviceWorker.controller, null, { timeout: 6000 }).catch(() => null);
  await go('#/book');
  await page.evaluate(() => { window.__m = 1; navigator.serviceWorker.dispatchEvent(new Event('controllerchange')); });
  await sleep(1500);
  ok(await page.evaluate(() => window.__m === 1), 'لا تُعاد صفحة طلب الحجز أثناء الكتابة');

  /* ---------- ملخص ---------- */
  const real = errors.filter((e) => !/Failed to load resource.*(404|503)/.test(e) && !/net::ERR_INTERNET_DISCONNECTED/.test(e) && !/ERR_FAILED/.test(e));
  ok(real.length === 0, 'لا أخطاء في وحدة التحكم' + (real.length ? ': ' + real.join(' | ') : ''));
  console.log('\nالنتيجة:', passes, 'ناجح،', fails, 'فاشل');
  await browser.close();
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });

function location_hash_ok(h, prefix) { return String(h).startsWith(prefix); }
