/* إعدادات التشغيل. عند تغليف التطبيق للجوال ضع عنوان الخادم في apiBase (مثال: "https://example.com"). */
window.DS_CONFIG = { apiBase: "", demo: false, version: "0.10.2", build: "dev" };
