// يشغّل منفذ الجافاسكربت على مجموعة أسئلة ويطبع النتائج JSON (يستدعيه server/tests/test_parity.py)
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const kbmod = require(path.join(root, 'web/js/20-kb.js'));
const input = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const seed = JSON.parse(fs.readFileSync(input.seed || path.join(root, 'data/seed.json'), 'utf8'));
const lex = new kbmod.Lexicon(JSON.parse(fs.readFileSync(path.join(root, 'data/lexicon.json'), 'utf8')));
const kb = new kbmod.KB(seed, lex);
const out = input.cases.map(c => kb.answer(c.q, c.history || null));
process.stdout.write(JSON.stringify(out));
