/* يجمع لقطات الاختبارات الآلية (qa/shots) في لوحات مصوّرة تُرفق بالتوثيق (docs/screens).
   التشغيل (بعد تشغيل اختبارات المتصفح):  NODE_PATH=<مسار playwright> node tools/make_contact_sheets.js
   اللقطات تأتي من اختبارات تعمل على بيانات المجمع «المسودة»، وهي ليست تصميماً نهائياً معتمداً. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const SHOTS = path.join(ROOT, 'qa', 'shots');
const OUT = path.join(ROOT, 'docs', 'screens');
fs.mkdirSync(OUT, { recursive: true });

const sheets = [
  {
    file: 'app-screens.png', title: 'تطبيق دار السلام — شاشات الجوال (390×844، بيانات مسودة من اختبارات المتصفح الآلية)',
    groups: [
      {
        title: 'الهوية والتنقل (اللوحات الإعلانية في اللقطتين المعنونتين مضافة لغرض الاختبار فقط ولا وجود لها في بيانات المجمع)', cols: 6, cellW: 300, cellH: 650, items: [
          ['p00c-splash', 'شاشة البداية'], ['01-home', 'الرئيسية'], ['26-quick-page2', 'الأدوات السريعة: الصفحة 2'], ['01d-home-scrolled', 'الرئيسية بعد التمرير'],
          ['25-hub', 'تبويب «الخدمات»'], ['24-more', 'المزيد'],
          ['01b-home-banners', 'الرئيسية مع لوحات إعلانية'], ['23-quick-actions', 'الإجراءات السريعة (+)'], ['16b-home-my-requests', 'بطاقة «طلباتي» في الرئيسية'], ['27-home-360', 'الرئيسية على شاشة 360px'],
        ],
      },
      {
        title: 'الصفحات والحجز وقمر', cols: 6, cellW: 300, cellH: 650, items: [
          ['02-specialties', 'التخصصات'], ['04-doctors', 'الأطباء'], ['05-doctor', 'صفحة الطبيب'], ['06-service-emergency', 'خدمة الطوارئ'], ['28-tips', 'نصائح صحية'], ['08-branch', 'صفحة الفرع'],
          ['09-contact', 'التواصل'], ['13-book-filled', 'طلب حجز'], ['14-book-success', 'تم إرسال الطلب'],
          ['16-profile-confirmed', 'حسابي: طلب مؤكد'], ['17-notifications', 'الإشعارات'], ['19-qamar-route', 'قمر: توجيه للعيادة'],
          ['20-qamar-emergency', 'قمر: حالة طارئة'], ['22-qamar-offline', 'قمر: بلا إنترنت'],
        ],
      },
    ],
  },
  {
    file: 'admin-screens.png', title: 'لوحة الإدارة (حاسوب 1280×820 + جوال)',
    cols: 4, cellW: 470, cellH: 301, items: [
      ['a01-login', 'الدخول'], ['a02-dashboard', 'نظرة عامة'], ['a03-bookings', 'الحجوزات'], ['a04-booking-modal', 'تفاصيل الطلب والتأكيد'],
      ['a05-doctors', 'الأطباء'], ['a06-doctor-form', 'نموذج الطبيب'], ['a07-settings', 'معلومات المجمع'], ['a08-qamar', 'المساعد قمر وأسئلته'],
      ['a13-banners', 'اللوحات الإعلانية'], ['a09-notify', 'الإشعارات'], ['a10-security', 'الأمان والنسخ'],
    ],
  },
  {
    // لقطات الويدجت تُقصّ على منطقة النافذة (x,y,w,h بالبكسل الأصلي 1280×800) كي تُقرأ؛ الصفحة المضيفة فيها عنوان أحمر عمداً لاختبار العزل
    file: 'widget-and-preview.png', title: 'ويدجت قمر لموقع المجمع ونسخة التجربة',
    groups: [
      {
        title: 'الويدجت داخل صفحة مضيفة بتنسيقات عدائية (اختبار العزل) — مقصوصة على منطقة النافذة', cols: 5, cellW: 300, cellH: 650, items: [
          ['w02-widget-open', 'محادثة', [0, 190, 420, 610]], ['w03-widget-book', 'توجيه للحجز', [0, 190, 420, 610]],
          ['w04-widget-emergency', 'طوارئ', [0, 190, 420, 610]], ['w01-widget-closed', 'الأيقونة فقط', [0, 190, 420, 610]],
          ['w05-widget-mobile', 'على شاشة جوال'],
        ],
      },
      {
        title: 'نسخة التجربة dist/preview.html (ملف واحد يعمل بلا خادم، والحجز فيها تجريبي لا يُرسل شيئاً)', cols: 4, cellW: 300, cellH: 650, items: [
          ['p01-preview-home', 'الرئيسية'], ['p02-preview-contact', 'التواصل'], ['p03-preview-qamar', 'قمر'], ['p04-preview-book-demo', 'طلب حجز تجريبي'],
        ],
      },
    ],
  },
];

function pngSize(f) { const b = fs.readFileSync(f); return [b.readUInt32BE(16), b.readUInt32BE(20)]; }

function cellHtml(it, g) {
  const [name, cap, crop] = it;
  const f = path.join(SHOTS, name + '.png');
  if (!fs.existsSync(f)) throw new Error('لقطة ناقصة: ' + f + ' (شغّل اختبارات المتصفح أولاً)');
  if (!crop) return `<figure><div class="img" style="width:${g.cellW}px;height:${g.cellH}px"><img src="file://${f}"></div><figcaption>${cap}</figcaption></figure>`;
  const [W, H] = pngSize(f);
  const k = g.cellW / crop[2];
  const h = Math.round(crop[3] * k);
  return `<figure><div class="img" style="width:${g.cellW}px;height:${h}px;position:relative"><img src="file://${f}" style="position:absolute;max-width:none;object-fit:fill;width:${Math.round(W * k)}px;height:${Math.round(H * k)}px;left:${-Math.round(crop[0] * k)}px;top:${-Math.round(crop[1] * k)}px"></div><figcaption>${cap}</figcaption></figure>`;
}

const groupsOf = (sheet) => sheet.groups || [{ title: null, cols: sheet.cols, cellW: sheet.cellW, cellH: sheet.cellH, items: sheet.items }];

function html(sheet) {
  const body = groupsOf(sheet).map((g) => `${g.title ? `<h2>${g.title}</h2>` : ''}<div class="grid" style="grid-template-columns:repeat(${g.cols},${g.cellW}px)">${g.items.map((it) => cellHtml(it, g)).join('')}</div>`).join('');
  return `<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><style>
    body{margin:0;background:#E8EFF6;font-family:"Noto Sans Arabic","Noto Kufi Arabic","SF Arabic",Tahoma,sans-serif;color:#1B2B36;padding:28px}
    h1{font-size:22px;margin:0 0 20px;color:#064A85}
    h2{font-size:17px;margin:26px 0 14px;color:#1B2B36}
    .grid{display:grid;gap:22px 18px;justify-content:start;align-items:start}
    figure{margin:0}.img{background:#fff;border:1px solid #cfdcdc;border-radius:14px;overflow:hidden;box-shadow:0 2px 8px rgba(10,60,58,.1)}
    .img img{width:100%;height:100%;object-fit:cover;object-position:top;display:block}
    figcaption{margin-top:8px;font-size:15px;text-align:center;font-weight:600}
  </style><body><h1>${sheet.title}</h1>${body}</body></html>`;
}

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  for (const sheet of sheets) {
    const tmp = path.join(require('os').tmpdir(), 'ds-sheet-' + sheet.file.replace('.png', '.html'));
    fs.writeFileSync(tmp, html(sheet));
    const widest = Math.max(...groupsOf(sheet).map((g) => g.cols * (g.cellW + 18)));
    const page = await browser.newPage({ viewport: { width: 400 + widest, height: 900 }, deviceScaleFactor: 1 });
    await page.goto('file://' + tmp, { waitUntil: 'load' });
    await page.evaluate(() => Promise.all([...document.images].map((i) => i.complete ? 0 : new Promise((r) => { i.onload = i.onerror = r; }))));
    await page.screenshot({ path: path.join(OUT, sheet.file), fullPage: true });
    await page.close();
    console.log('docs/screens/' + sheet.file, fs.statSync(path.join(OUT, sheet.file)).size, 'bytes');
  }
  fs.copyFileSync(path.join(SHOTS, 'icons-sheet.png'), path.join(OUT, 'icons.png'));
  console.log('docs/screens/icons.png');
  await browser.close();
})().catch((e) => { console.error(e.message); process.exit(1); });
