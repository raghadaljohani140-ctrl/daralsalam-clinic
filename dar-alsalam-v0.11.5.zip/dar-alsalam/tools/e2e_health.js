/* اختبار «الحالة الصحية للمراجع تظهر للطبيب» (0.11.3) بمتصفح حقيقي وخادم مؤقت (:8097). بيانات تجريبية فقط.
     حساب مراجع بكلمة مرور وملف صحي ← حجز بالحساب ← الاستقبال يسجّل الوصول ← الطبيب يفتح الزيارة ويرى الحالة الصحية (الحساسية بتنبيه)
     ← لا هوية ولا تأمين ولا جهة طوارئ ← زيارة بلا حساب تقول ذلك صراحة.
   NODE_PATH=<playwright> node tools/e2e_health.js     اللقطات: qa/shots/h*.png */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const SHOTS = path.join(ROOT, 'qa', 'shots'); fs.mkdirSync(SHOTS, { recursive: true });
const PW = 'devpass-12345', PORT = 8097, base = 'http://127.0.0.1:' + PORT, TMP = 'Temp-Pass-2026x', FIN = 'Final-Pass-2026x', PAT_PW = 'Salam2026x';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function http(method, p, body, token) {
  const h = { Accept: 'application/json' }; if (body !== undefined) h['Content-Type'] = 'application/json'; if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(base + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(() => ({})) };
}
(async () => {
  const dir = '/tmp/ds-health'; execSync('rm -rf ' + dir + ' && mkdir -p ' + dir);
  const env = Object.assign({}, process.env, { DS_DB: dir + '/clinic.db', DS_PORT: String(PORT), DS_QUIET: '1', DS_PW_ITERS: '1000' });
  execSync('python3 ' + ROOT + '/server/manage.py init --password ' + PW, { env, stdio: 'ignore' });
  const proc = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  for (let i = 0; i < 40; i++) { try { if ((await fetch(base + '/api/v1/health')).ok) break; } catch (e) { /* انتظر */ } await sleep(300); }
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  try {
    const AT = (await http('POST', '/api/admin/login', { password: PW })).body.token;
    ok((await http('PUT', '/api/admin/auth', { mode: 'password' }, AT)).status === 200, 'تفعيل حسابات كلمة المرور');
    const ds = (await http('GET', '/api/v1/clinic')).body, DOC = ds.doctors[0].id, BR = ds.branches[0].id;
    const reg = await http('POST', '/api/v1/auth/register', { phone: '0551119100', password: PAT_PW, password2: PAT_PW, name: 'سعد العتيبي', gender: 'male', birthDate: '1990-05-17', nationalId: '',
      profile: { nationality: 'سعودي', email: '', city: 'المدينة المنورة', emergency: { name: 'فهد العتيبي', relation: 'أخ/أخت', phone: '0551110002' },
        health: { bloodType: 'O+', allergies: { none: false, text: 'بنسلين' }, chronic: { none: false, items: ['diabetes'], other: '' }, medications: { none: false, text: 'ميتفورمين 500' }, surgeries: { none: true, text: '' }, pregnancy: '' },
        insurance: { company: 'بوبا', memberNo: 'BP-12345' } }, consent: { privacy: true, health: true } });
    ok(reg.status === 201, 'تسجيل مراجع بملف صحي: ' + reg.status);
    const day = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
    const bk = await http('POST', '/api/v1/bookings', { deviceId: 'health_dev_0123456789', name: 'سعد العتيبي', phone: '0551119100', branchId: BR, doctorId: DOC, date: day, period: 'morning', note: '', consent: true }, reg.body.token);
    ok(bk.status === 201, 'حجز بالحساب: ' + bk.status + ' ' + JSON.stringify(bk.body).slice(0, 80));
    const mk = async (u, role, extra) => { await http('POST', '/api/admin/staff', Object.assign({ username: u, name: u, role, branchId: BR, password: TMP }, extra || {}), AT);
      const l = await http('POST', '/api/staff/login', { username: u, password: TMP }); return (await http('POST', '/api/staff/password', { old: TMP, new: FIN }, l.body.token)).body.token; };
    const RT = await mk('h.rec', 'reception'); await mk('h.doc', 'doctor', { doctorId: DOC, branchId: '' });
    const rec = await http('POST', '/api/staff/records', { name: 'سعد العتيبي', phone: '0551119100', birthDate: '1990-05-17', gender: 'male' }, RT);
    const v1 = await http('POST', '/api/staff/visits', { mrn: rec.body.record.mrn, doctorId: DOC, reason: '', bookingId: bk.body.booking.id }, RT);
    ok(v1.status === 201, 'الاستقبال يسجّل الوصول للحجز');
    const rec2 = await http('POST', '/api/staff/records', { name: 'بلا حساب', phone: '0551119101', birthDate: '1985-01-01', gender: 'male' }, RT);
    const v2 = await http('POST', '/api/staff/visits', { mrn: rec2.body.record.mrn, doctorId: DOC, reason: '' }, RT);
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errors.push('pageerror: ' + e.message)); p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
    await p.goto(base + '/staff/', { waitUntil: 'networkidle' });
    await p.fill('#lg-user', 'h.doc'); await p.fill('#lg-pw', FIN); await p.click('form[data-f=login] button[type=submit]'); await p.waitForSelector('#tabs');
    await p.evaluate((id) => { location.hash = '#/clinic/' + id; }, v1.body.visit.id);
    await p.waitForSelector('.hcard', { timeout: 8000 });
    const t = await p.locator('.hcard').innerText();
    ok(/بنسلين/.test(t) && /السكري/.test(t) && /ميتفورمين 500/.test(t) && /O\+/.test(t), 'الطبيب يرى الحساسية والمزمن والأدوية وفصيلة الدم');
    ok(await p.locator('.hcard .hrow.warn').count() === 1, 'الحساسية مميّزة بتنبيه');
    const page = await p.locator('#view').innerText();
    ok(!/بوبا|BP-12345|فهد|0551110002/.test(page), 'لا تأمين ولا جهة طوارئ في شاشة الطبيب');
    await p.screenshot({ path: path.join(SHOTS, 'h01-doctor-health.png') });
    await p.evaluate((id) => { location.hash = '#/clinic/' + id; }, v2.body.visit.id);
    await p.waitForFunction(() => /غير مرتبط بحساب/.test(document.querySelector('#view').innerText), null, { timeout: 8000 });
    ok(true, 'زيارة بلا حساب: تُقال صراحة (لا بيانات مختلقة)');
    const aud = (await http('GET', '/api/admin/audit?action=health_view', undefined, AT)).body;
    ok(JSON.stringify(aud).includes('health_view') && !JSON.stringify(aud).includes('بنسلين'), 'فتح الحالة الصحية مسجَّل في التدقيق بلا محتواها');
    ok(errors.length === 0, 'لا أخطاء جافاسكربت ' + errors.join(' | '));
  } catch (e) { fail++; console.log('FAIL استثناء: ' + (e.stack || e)); }
  await browser.close(); proc.kill();
  console.log('\n=== ' + pass + ' PASS / ' + fail + ' FAIL ==='); process.exit(fail ? 1 : 0);
})();
