/* حسابات المراجعين بكلمة مرور (0.11.0) بمتصفح حقيقي وخادم مؤقت منفصل (:8095، لا يمسّ أي خادم آخر):
     الوضع الافتراضي متوقف (الحجز بلا تسجيل كما كان) ← الإدارة تفعّله من لوحتها ← «تأكيد الحجز» يطلب الدخول مع حفظ الاختيار
     ← إنشاء حساب بثلاث خطوات (تحقق كل خطوة، كلمات مرور ضعيفة، رقم مسجّل، موافقتان إلزاميتان) ← العودة للحجز كما تُرك ← إرسال الحجز
     ← حسابي: عرض الملف الصحي وتعديله وحفظه ← تغيير كلمة المرور ← خروج ودخول ← كلمة مؤقتة من الإدارة تُجبر على التغيير قبل الحجز
     ← جهاز مشترك: حساب آخر لا يرى حجوزات الأول ← لوحة الإدارة: قائمة الحسابات وعرض الملف الصحي (بتدقيق) وإيقاف الوضع ← حذف الحساب.
   NODE_PATH=<playwright> node tools/e2e_accounts.js     بيانات تجريبية فقط. اللقطات في qa/shots/ac*.png */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SHOTS = path.join(ROOT, 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const DIR = '/tmp/ds-acc', PORT = 8095, BASE = 'http://127.0.0.1:' + PORT, PW = 'devpass-12345';
const PWD = 'Salam2026x', PWD2 = 'Brand-new-77', PHONE = '0551234567';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  execSync('rm -rf ' + DIR + ' && mkdir -p ' + DIR);
  const env = Object.assign({}, process.env, { DS_DB: DIR + '/clinic.db', DS_PORT: String(PORT), DS_QUIET: '1', DS_PW_ITERS: '1000' });
  execSync('python3 ' + ROOT + '/server/manage.py init --password ' + PW, { env, stdio: 'ignore' });
  const srv = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  for (let i = 0; i < 40; i++) { try { const r = await fetch(BASE + '/api/v1/health'); if (r.ok) break; } catch (e) { /* انتظر */ } await sleep(300); }

  const http = async (m, p, b, tok) => {
    const h = { 'Content-Type': 'application/json' }; if (tok) h.Authorization = 'Bearer ' + tok;
    const r = await fetch(BASE + p, { method: m, headers: h, body: b === undefined ? undefined : JSON.stringify(b) });
    let j = {}; try { j = await r.json(); } catch (e) { /* فارغ */ }
    return { status: r.status, body: j };
  };
  const AT = (await http('POST', '/api/admin/login', { password: PW })).body.token;
  const adm = (m, p, b) => http(m, '/api/admin' + p, b, AT);

  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar-SA' });
  const page = await ctx.newPage();
  const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push('console: ' + m.text()); });
  page.on('dialog', (d) => d.accept());
  const shot = async (n) => { await sleep(250); await page.screenshot({ path: path.join(SHOTS, 'ac' + n + '.png'), fullPage: false }); };
  const shotFull = async (n) => { await sleep(250); await page.screenshot({ path: path.join(SHOTS, 'ac' + n + '.png'), fullPage: true }); };
  const hash = (h) => page.evaluate((x) => { location.hash = x; }, h);
  const visibleErr = (k) => page.locator('[data-err="a-' + k + '"]:not([hidden])').count();
  const nextBtn = () => page.click('#rg-form button[type=submit]');

  /* حجز جاهز للتأكيد من صفحة الحجز */
  const prepareBooking = async (idx) => {
    await page.goto(BASE + '/app/#/book'); await page.reload(); await page.waitForSelector('#f-sel', { timeout: 8000 });     // إعادة تحميل: لنلتقط آخر إعدادات الخادم
    await page.selectOption('#f-sel', { index: idx || 1 }); await page.fill('#f-note', 'ملاحظة اختبار الحسابات'); await page.locator('#f-consent').check();
  };
  const fillStep1 = async (o) => {
    o = Object.assign({ name: 'سعد العتيبي', phone: PHONE, gender: 'male', birthDate: '1990-05-17', pw: PWD, pw2: PWD }, o || {});
    await page.fill('#a-name', o.name); await page.fill('#a-phone', o.phone); await page.selectOption('#a-gender', o.gender);
    await page.fill('#a-birthDate', o.birthDate); await page.fill('#a-password', o.pw); await page.fill('#a-password2', o.pw2);
  };
  const fillStep2 = async () => {
    await page.selectOption('#a-bloodType', 'O+');
    await page.click('label[for="a-allergies-yes"]'); await page.fill('#a-allergiesText', 'بنسلين');
    await page.click('label[for="a-chronic-yes"]'); await page.locator('[data-chr="diabetes"]').check(); await page.locator('[data-chr="hypertension"]').check();
    await page.click('label[for="a-medications-yes"]'); await page.fill('#a-medicationsText', 'ميتفورمين 500');
    await page.click('label[for="a-surgeries-no"]');
  };
  const fillStep3 = async () => {
    await page.fill('#a-nationality', 'سعودي'); await page.fill('#a-city', 'المدينة المنورة');
    await page.fill('#a-emName', 'فهد العتيبي'); await page.selectOption('#a-emRelation', 'أخ/أخت'); await page.fill('#a-emPhone', '0551234568');
    await page.fill('#a-insCompany', 'بوبا'); await page.fill('#a-insNo', 'BP-12345');
    await page.locator('#a-consentPrivacy').check(); await page.locator('#a-consentHealth').check();
  };
  const loginUi = async (phone, pw) => {
    await page.fill('#a-phone', phone); await page.fill('#a-password', pw); await page.click('#au-login button[type=submit]');
  };

  try {
    /* ---------- 1) الوضع الافتراضي: بلا تسجيل كما كان ---------- */
    await page.goto(BASE + '/app/#/book'); await page.waitForSelector('#f-sel', { timeout: 8000 });
    ok(await page.locator('#bk-id').isVisible() && await page.locator('#bk-login-note').isHidden(), 'الوضع المتوقف (الافتراضي): حقول الاسم والجوال ظاهرة ولا يُطلب تسجيل');
    const meta0 = (await http('GET', '/api/v1/clinic')).body.meta.auth;
    ok(meta0 && meta0.enabled === false, 'إعدادات الخادم: التسجيل متوقف افتراضياً');

    /* ---------- 2) الإدارة تفعّله ---------- */
    const on = await adm('PUT', '/auth', { mode: 'password' });
    ok(on.status === 200 && on.body.method === 'password', 'الإدارة تفعّل التسجيل قبل الحجز');
    const meta1 = (await http('GET', '/api/v1/clinic')).body.meta.auth;
    ok(meta1.method === 'password' && meta1.chronic.length === 10 && meta1.bloodTypes.length === 8 && meta1.relations.length >= 6, 'القوائم الطبية تصل من الخادم (أمراض مزمنة 10، فصائل دم 8، صلات القرابة)');

    /* ---------- 3) «تأكيد الحجز» بلا حساب → الدخول مع حفظ الاختيار ---------- */
    await prepareBooking();
    await sleep(500);
    ok(await page.locator('#bk-id').isHidden() && await page.locator('#bk-login-note').isVisible(), 'بعد التفعيل: لا حقول اسم/جوال وتنبيه أن الحجز يلزمه حساب');
    const selVal = await page.inputValue('#f-sel');
    await shot('01-booking-needs-account');
    await page.click('#f-submit'); await page.waitForSelector('#au-login', { timeout: 6000 });
    ok(page.url().includes('#/login') && page.url().includes('next='), '«تأكيد الحجز» بلا حساب يحوّل لشاشة الدخول');
    ok((await page.locator('#au-root').innerText()).includes('حجزك محفوظ'), 'شاشة الدخول تُظهر «حجزك محفوظ»');
    await shot('02-login');
    await page.click('[data-act="au-forgot"]');
    ok(await page.locator('#au-forgot').isVisible() && (await page.locator('#au-forgot').innerText()).includes('تواصل مع المجمع'), '«نسيت كلمة المرور» يوجّه للاتصال بالمجمع');
    await shot('03-forgot');
    await loginUi('0500000000', 'whatever123'); await page.waitForSelector('#au-fail .alert', { timeout: 6000 });
    ok((await page.locator('#au-fail').innerText()).includes('غير صحيحة'), 'دخول برقم غير مسجّل: رسالة عامة (لا تكشف وجود الحساب)');
    await page.fill('#a-phone', '123'); await page.click('#au-login button[type=submit]');
    ok(await visibleErr('phone') === 1, 'رقم جوال غير صحيح يُرفض قبل الإرسال');

    /* ---------- 4) إنشاء حساب: الخطوة 1 ---------- */
    await page.click('a[href^="#/register"]'); await page.waitForSelector('#rg-form');
    ok((await page.locator('#au-root').innerText()).includes('حجزك محفوظ'), 'شاشة التسجيل تُبقي «حجزك محفوظ»');
    await shot('04-register-step1');
    await nextBtn();
    ok(await visibleErr('name') === 1 && await visibleErr('phone') === 1 && await visibleErr('gender') === 1 && await visibleErr('birthDate') === 1 && await visibleErr('password') === 1, 'الخطوة 1 فارغة: خمسة أخطاء ظاهرة');
    await shot('05-step1-errors');
    await fillStep1({ pw: '12345678', pw2: '12345678' }); await nextBtn();
    ok(await visibleErr('password') === 1, 'كلمة مرور أرقام فقط تُرفض');
    await fillStep1({ pw: PWD, pw2: 'Different-123' }); await nextBtn();
    ok(await visibleErr('password2') === 1, 'عدم تطابق كلمتي المرور يُرفض');
    await fillStep1(); await page.click('[data-act="au-eye"][data-for="a-password"]');
    ok(await page.evaluate(() => document.querySelector('#a-password').type === 'text'), 'زر «إظهار» يكشف كلمة المرور');
    await nextBtn(); await page.waitForSelector('#a-allergies-yes', { state: 'attached' });
    ok((await page.locator('#rg-body h3.sh').first().innerText()).includes('الخطوة 2'), 'الانتقال للخطوة 2 (الملف الصحي)');
    ok(await page.locator('#a-pregnancy').count() === 0, 'ذكر: لا يظهر سؤال الحمل');

    /* ---------- 5) الخطوة 2: الملف الصحي ---------- */
    await shot('06-step2-health');
    await nextBtn();
    ok(await visibleErr('allergies') === 1 && await visibleErr('chronic') === 1 && await visibleErr('medications') === 1, 'الإجابات الصريحة إلزامية: الحساسية والأمراض المزمنة والأدوية');
    await page.click('label[for="a-allergies-yes"]');
    ok(await page.locator('#sub-allergies').isVisible(), '«نعم» تُظهر حقل كتابة الحساسية');
    await page.click('label[for="a-allergies-no"]');
    ok(await page.locator('#sub-allergies').isHidden(), '«لا يوجد» تخفيه');
    await shot('07-step2-errors');
    await fillStep2(); await shot('08-step2-filled'); await nextBtn(); await page.waitForSelector('#a-consentHealth');
    ok((await page.locator('#rg-body h3.sh').first().innerText()).includes('الخطوة 3'), 'الانتقال للخطوة 3');

    /* ---------- 6) الخطوة 3 ---------- */
    await page.fill('#a-emName', 'فهد العتيبي'); await nextBtn();
    ok(await visibleErr('emPhone') === 1 && await visibleErr('emRelation') === 1, 'جهة الطوارئ ناقصة (الاسم فقط): يُطلب الباقي');
    ok(await visibleErr('consentPrivacy') === 1 && await visibleErr('consentHealth') === 1, 'الموافقتان إلزاميتان');
    await shotFull('09-step3-errors');
    await page.click('[data-act="rg-prev"]');
    ok(await page.inputValue('#a-bloodType') === 'O+' && await page.locator('[data-chr="diabetes"]').isChecked() && await page.inputValue('#a-allergiesText') === 'بنسلين', 'الرجوع للخطوة السابقة يحفظ ما كتبه');
    await nextBtn(); await page.waitForSelector('#a-consentHealth');
    ok(await page.inputValue('#a-emName') === 'فهد العتيبي', 'والتقدّم يحفظ ما كتبه في الخطوة 3');
    /* فتح سياسة الخصوصية والعودة لا يُضيع ما كتبه */
    await page.click('#a-consentPrivacy ~ span a'); await page.waitForSelector('.prose');
    ok((await page.locator('.prose').innerText()).includes('وبياناتك الصحية التي تدخلها بموافقتك الصريحة'), 'سياسة الخصوصية في التطبيق تشرح الملف الصحي');
    await shotFull('10-privacy');
    await page.goBack(); await page.waitForSelector('#a-consentHealth');
    ok(await page.inputValue('#a-emName') === 'فهد العتيبي', 'العودة من سياسة الخصوصية تُبقي ما كتبه');
    await fillStep3(); await shotFull('11-step3-filled');
    await nextBtn();

    /* ---------- 7) بعد التسجيل: العودة للحجز كما تُرك ---------- */
    await page.waitForSelector('#f-name', { timeout: 10000 });
    ok(page.url().includes('#/book'), 'بعد إنشاء الحساب يعود لصفحة الحجز');
    ok(await page.inputValue('#f-sel') === selVal && await page.inputValue('#f-note') === 'ملاحظة اختبار الحسابات' && await page.locator('#f-consent').isChecked(), 'اختياره وملاحظته وموافقته محفوظة');
    ok(await page.inputValue('#f-name') === 'سعد العتيبي' && await page.inputValue('#f-phone') === PHONE && await page.evaluate(() => document.querySelector('#f-name').readOnly), 'الاسم والجوال من الحساب (للقراءة فقط)');
    ok((await page.locator('#bk-id').innerText()).includes('الحجز باسم صاحب الحساب'), 'تنبيه: الحجز باسم صاحب الحساب، ولشخص آخر يكتب اسمه في الملاحظة');
    await shot('12-booking-after-register');
    await page.click('#f-submit'); await page.waitForSelector('.bk-id', { timeout: 10000 });
    const bid = (await page.locator('.bk-id').innerText()).trim();
    ok(/^DS-[A-Z0-9]{6}$/.test(bid), 'الحجز يُرسل بعد التسجيل: ' + bid);

    /* ---------- 8) حسابي ---------- */
    await hash('#/profile'); await page.waitForSelector('[data-act="au-logout"]'); await page.waitForSelector('#bk-list .bk', { timeout: 8000 });
    ok(await page.locator('#pf-form').count() === 0, 'صفحة حسابي: لا نموذج بيانات محلي مكرر للمسجّل');
    ok((await page.locator('#view').innerText()).includes('ملفي الصحي') && (await page.locator('#bk-list').innerText()).includes(bid), 'بطاقة الحساب وحجزه ظاهران');
    ok(await page.locator('[data-act="del-data"]').count() === 0, 'المسجّل: لا بطاقة «حذف بياناتي» للجهاز (حذف الحساب يكفي ويشمل كل شيء)');
    await shotFull('13-profile');
    await page.click('a[href="#/account"]'); await page.waitForSelector('#ac-form');
    ok(await page.inputValue('#a-allergiesText') === 'بنسلين' && await page.locator('[data-chr="diabetes"]').isChecked() && await page.locator('[data-chr="hypertension"]').isChecked() && await page.inputValue('#a-bloodType') === 'O+', 'صفحة الملف تعرض ما سجّله');
    ok(await page.inputValue('#a-emPhone') === '0551234568' && await page.inputValue('#a-insNo') === 'BP-12345', 'جهة الطوارئ والتأمين محفوظان');
    await shotFull('14-account');
    await page.fill('#a-city', 'جدة'); await page.click('label[for="a-allergies-no"]');
    await page.click('#ac-form button[type=submit]'); await page.waitForSelector('.alert.ok', { timeout: 6000 });
    ok((await page.locator('#au-root').innerText()).includes('تم حفظ التعديلات'), 'تعديل الملف الصحي يُحفظ');
    await page.reload(); await page.waitForSelector('#ac-form');
    ok(await page.inputValue('#a-city') === 'جدة' && await page.locator('#a-allergies-no').isChecked(), 'التعديل محفوظ بعد إعادة التحميل');
    await page.fill('#a-emName', ''); await page.fill('#a-emPhone', '12'); await page.click('#ac-form button[type=submit]');
    ok(await visibleErr('emPhone') + await visibleErr('emRelation') >= 1, 'تعديل غير صالح (جوال طوارئ ناقص) يُرفض');

    /* ---------- 9) تغيير كلمة المرور ---------- */
    await hash('#/password'); await page.waitForSelector('#pw-form');
    await page.fill('#a-current', 'wrong-pass-1'); await page.fill('#a-new', PWD2); await page.fill('#a-new2', PWD2); await page.click('#pw-form button[type=submit]');
    await page.waitForSelector('[data-err="a-current"]:not([hidden])', { timeout: 6000 });
    ok(true, 'كلمة مرور حالية خاطئة تُرفض');
    await page.fill('#a-current', PWD); await page.fill('#a-new', PWD); await page.fill('#a-new2', PWD); await page.click('#pw-form button[type=submit]');
    ok(await visibleErr('new') === 1, 'الجديدة مثل الحالية تُرفض');
    await page.fill('#a-new', PWD2); await page.fill('#a-new2', PWD2); await page.click('#pw-form button[type=submit]');
    await page.waitForFunction(() => !location.hash.startsWith('#/password'), null, { timeout: 8000 });
    ok(true, 'تغيير كلمة المرور ينجح ويعود لحسابي');
    ok((await http('POST', '/api/v1/auth/login', { phone: '0551234567', password: PWD })).status === 401 && (await http('POST', '/api/v1/auth/login', { phone: '0551234567', password: PWD2 })).status === 200, 'القديمة لا تعمل والجديدة تعمل');

    /* ---------- 10) خروج ← دخول ---------- */
    await hash('#/profile'); await page.waitForSelector('[data-act="au-logout"]');
    await page.click('[data-act="au-logout"]'); await sleep(500);
    ok((await page.locator('#view').innerText()).includes('سجّل دخولك') && await page.evaluate(() => !localStorage.getItem('ds.ptoken') && !JSON.stringify(Object.assign({}, localStorage)).includes('بنسلين')), 'بعد الخروج: لا جلسة ولا بيانات صحية على الجهاز');
    ok(await page.evaluate(() => !JSON.stringify(Object.assign({}, localStorage)).includes('Salam2026x') && !JSON.stringify(Object.assign({}, localStorage)).includes('Brand-new-77')), 'كلمة المرور لا تُحفظ على الجهاز');
    await page.goto(BASE + '/app/#/login?next=' + encodeURIComponent('#/profile')); await page.waitForSelector('#au-login');
    await loginUi(PHONE, PWD); await page.waitForSelector('#au-fail .alert', { timeout: 6000 });
    ok((await page.locator('#au-fail').innerText()).includes('غير صحيحة'), 'كلمة المرور القديمة بعد التغيير: مرفوضة');
    await loginUi(PHONE, PWD2); await page.waitForSelector('[data-act="au-logout"]', { timeout: 8000 });
    ok(page.url().includes('#/profile') && (await page.locator('#bk-list').innerText()).includes(bid), 'الدخول الصحيح يعيده إلى حسابه وحجوزاته');

    /* ---------- 11) رقم مسجّل مسبقاً ---------- */
    await page.click('[data-act="au-logout"]'); await sleep(300);
    await page.goto(BASE + '/app/#/register'); await page.waitForSelector('#rg-form');
    await fillStep1({ name: 'شخص آخر', pw: 'Other-pass-99', pw2: 'Other-pass-99' }); await nextBtn(); await page.waitForSelector('#a-allergies-yes', { state: 'attached' });
    await page.click('label[for="a-allergies-no"]'); await page.click('label[for="a-chronic-no"]'); await page.click('label[for="a-medications-no"]'); await nextBtn(); await page.waitForSelector('#a-consentHealth');
    await page.locator('#a-consentPrivacy').check(); await page.locator('#a-consentHealth').check(); await nextBtn();
    await page.waitForSelector('#rg-form .alert.warn', { timeout: 8000 });
    ok((await page.locator('#rg-form').innerText()).includes('مسجّل مسبقاً') && await visibleErr('phone') === 1, 'تسجيل برقم موجود: رسالة «مسجّل مسبقاً» مع رابط الدخول');
    await shot('15-phone-exists');

    /* ---------- 12) كلمة مرور مؤقتة من الإدارة تُجبر على التغيير قبل الحجز ---------- */
    const list = (await adm('GET', '/accounts')).body.accounts;
    ok(list.length === 1 && !JSON.stringify(list).includes('بنسلين'), 'قائمة الإدارة: حساب واحد بلا أي بيانات صحية');
    const pid = list[0].id;
    const rs = await adm('POST', '/accounts/' + pid + '/reset');
    ok(rs.status === 200 && /^[A-Za-z0-9]{10}$/.test(rs.body.password), 'الإدارة تصدر كلمة مرور مؤقتة');
    await page.goto(BASE + '/app/#/login?next=' + encodeURIComponent('#/profile')); await page.waitForSelector('#au-login');
    await loginUi(PHONE, PWD2); await page.waitForSelector('#au-fail .alert', { timeout: 6000 });
    ok(true, 'القديمة لا تعمل بعد إعادة التعيين (الجلسات القديمة منتهية أيضاً)');
    await loginUi(PHONE, rs.body.password); await page.waitForSelector('#pw-form', { timeout: 8000 });
    ok(page.url().includes('#/password') && (await page.locator('#au-root').innerText()).includes('مؤقتة'), 'الدخول بالمؤقتة يفرض شاشة «اختر كلمة مرور جديدة»');
    await shot('16-forced-change');
    await prepareBooking(2); await page.click('#f-submit'); await page.waitForSelector('#pw-form', { timeout: 8000 });
    ok(page.url().includes('#/password') && page.url().includes('book'), 'محاولة الحجز بكلمة مؤقتة تُحوَّل لتغييرها أولاً (والحجز محفوظ)');
    await page.fill('#a-current', rs.body.password); await page.fill('#a-new', 'Third-pass-55'); await page.fill('#a-new2', 'Third-pass-55'); await page.click('#pw-form button[type=submit]');
    await page.waitForSelector('#f-name', { timeout: 8000 });
    ok(await page.inputValue('#f-note') === 'ملاحظة اختبار الحسابات', 'بعد التغيير يعود لحجزه كما تركه');
    await page.click('#f-submit'); await page.waitForSelector('.bk-id', { timeout: 8000 });
    const bid2 = (await page.locator('.bk-id').innerText()).trim();
    ok(/^DS-/.test(bid2) && bid2 !== bid, 'الحجز يعمل بعد تغيير المؤقتة: ' + bid2);

    /* ---------- 13) جهاز مشترك: حساب آخر لا يرى حجوزات الأول ---------- */
    await hash('#/profile'); await page.waitForSelector('[data-act="au-logout"]'); await page.click('[data-act="au-logout"]'); await sleep(300);
    const reg2 = await http('POST', '/api/v1/auth/register', {
      phone: '0559998888', password: 'Second-pass-66', password2: 'Second-pass-66', name: 'نورة القحطاني', gender: 'female', birthDate: '1992-02-02', nationalId: '',
      profile: { health: { allergies: { none: true }, chronic: { none: true }, medications: { none: true }, pregnancy: 'pregnant' } }, consent: { privacy: true, health: true } });
    ok(reg2.status === 201, 'حساب ثانٍ (أنثى، حامل) على الجهاز نفسه عبر الواجهة البرمجية');
    await page.goto(BASE + '/app/#/login?next=' + encodeURIComponent('#/profile')); await page.waitForSelector('#au-login');
    await loginUi('0559998888', 'Second-pass-66'); await page.waitForSelector('[data-act="au-logout"]', { timeout: 8000 });
    await sleep(800);
    const txt = await page.locator('#bk-list').innerText();
    ok(!txt.includes(bid) && !txt.includes(bid2), 'جهاز مشترك: الحساب الثاني لا يرى حجوزات الأول');
    await page.click('a[href="#/account"]'); await page.waitForSelector('#ac-form');
    ok(await page.locator('#a-pregnancy').count() === 1 && await page.inputValue('#a-pregnancy') === 'pregnant', 'الأنثى: يظهر سؤال الحمل/الرضاعة بقيمته المحفوظة');
    await shotFull('17-account-female');

    /* ---------- 14) لوحة الإدارة ---------- */
    const ap = await ctx.newPage(); ap.on('dialog', (d) => d.accept());
    ap.on('pageerror', (e) => errs.push('admin pageerror: ' + e.message));
    await ap.goto(BASE + '/admin/', { waitUntil: 'networkidle' }); await ap.fill('#pw', PW); await ap.click('button[type=submit]'); await ap.waitForSelector('#nav', { timeout: 8000 });
    await ap.evaluate(() => { location.hash = '#/accounts'; }); await ap.waitForSelector('#ac-box table', { timeout: 6000 });
    ok((await ap.locator('#ac-card').innerText()).includes('مفعّل'), 'لوحة الإدارة: وضع التسجيل «مفعّل»');
    ok(await ap.locator('#ac-box tbody tr').count() === 2, 'لوحة الإدارة: حسابان في القائمة');
    ok(!(await ap.locator('#ac-box').innerText()).includes('بنسلين'), 'القائمة لا تعرض أي بيانات صحية');
    await ap.screenshot({ path: path.join(SHOTS, 'ac18-admin-accounts.png') });
    await ap.locator('#ac-box tr', { hasText: 'نورة' }).locator('[data-a="ac-view"]').click(); await ap.waitForSelector('#modal');
    const mt = await ap.locator('#modal').innerText();
    ok(mt.includes('حامل') && mt.includes('فصيلة الدم') && mt.includes('غير موثّق'), 'عرض الملف الصحي بطلب صريح (ويُسجَّل في التدقيق)');
    await ap.screenshot({ path: path.join(SHOTS, 'ac19-admin-account-view.png') });
    await ap.click('#modal [data-a="modal-close"]');
    const aud = (await adm('GET', '/audit')).body.audit.map((x) => x.action);
    ok(aud.includes('account_view') && aud.includes('register') && aud.includes('auth_mode'), 'سجل التدقيق يحوي: التسجيل وتغيير الوضع وفتح الملف');
    ok(!JSON.stringify((await adm('GET', '/audit')).body).includes('بنسلين') && !JSON.stringify((await adm('GET', '/audit')).body).includes('Second-pass-66'), 'سجل التدقيق بلا محتوى صحي ولا كلمات مرور');
    await ap.locator('#ac-box tr', { hasText: 'نورة' }).locator('[data-a="ac-del"]').click(); await sleep(700);
    ok(await ap.locator('#ac-box tbody tr').count() === 1, 'الإدارة تحذف حساباً');
    await ap.locator('[data-a="ac-mode"]').click(); await sleep(700);
    ok((await ap.locator('#ac-card').innerText()).includes('متوقف'), 'الإدارة توقف الوضع من اللوحة');
    ok((await http('GET', '/api/v1/clinic')).body.meta.auth.enabled === false, 'وصل الإيقاف إلى التطبيق');
    await ap.close();

    /* ---------- 15) بعد الإيقاف: الحجز بلا تسجيل كما كان ---------- */
    await page.goto(BASE + '/app/#/book'); await page.waitForSelector('#f-sel', { timeout: 8000 }); await sleep(500);
    ok(await page.locator('#bk-id').isVisible() && await page.locator('#bk-login-note').isHidden(), 'بعد إيقاف الوضع: يعود الحجز بلا تسجيل');
    await adm('PUT', '/auth', { mode: 'password' });

    /* ---------- 16) حذف الحساب من التطبيق ---------- */
    await page.goto(BASE + '/app/#/login?next=' + encodeURIComponent('#/profile')); await page.waitForSelector('#au-login');
    await loginUi(PHONE, 'Third-pass-55'); await page.waitForSelector('[data-act="au-delete"]', { timeout: 8000 });
    await page.click('[data-act="au-delete"]'); await sleep(900);
    ok((await adm('GET', '/accounts')).body.accounts.length === 0, 'حذف الحساب من التطبيق يمحو الحساب كاملاً');
    ok((await http('POST', '/api/v1/auth/login', { phone: PHONE, password: 'Third-pass-55' })).status === 401, 'الدخول بالحساب المحذوف مستحيل');

    ok(errs.length === 0, 'لا أخطاء في وحدة التحكم' + (errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''));
  } catch (e) {
    fail++; console.log('FAIL استثناء:', e.message.split('\n')[0]);
    try { await page.screenshot({ path: path.join(SHOTS, 'ac99-failure.png') }); console.log('URL', page.url()); } catch (e2) { /* تجاهل */ }
  }
  await browser.close(); srv.kill();
  console.log('\n=== ' + pass + ' PASS / ' + fail + ' FAIL ===');
  process.exit(fail ? 1 : 0);
})();
