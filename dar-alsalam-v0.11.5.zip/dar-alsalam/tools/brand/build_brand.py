#!/usr/bin/env python3
"""يحوّل شعار المجمع (logo-source.png، خلفية شفافة) إلى ملفات SVG متجهة نظيفة تُستخدم في التطبيق والأيقونات.
لا يحتاج إلا numpy وopencv وscipy وPillow. التشغيل:  python3 tools/brand/build_brand.py
المخرجات في web/img: mark.svg (الشارة بألوانها)، mark-white.svg (أحادية بيضاء)، wordmark.svg (الاسم)، logo.svg (الشارة+الاسم)،
splash-mark.svg (الشارة متحركة لشاشة البداية).  الألوان والتدرجات تُقاس من الصورة نفسها ولا تُخمَّن."""
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from skimage import measure

HERE = Path(__file__).resolve().parent
OUT = HERE.parent.parent / "web" / "img"
src = np.array(Image.open(HERE / "logo-source.png").convert("RGBA"))
alpha = src[..., 3].astype(np.float32)
lab, ncomp = ndi.label(alpha > 128)
S = 4  # تكبير لاستخراج حدود بدقة أقل من بكسل


def objs():
    out = []
    for i, sl in enumerate(ndi.find_objects(lab), 1):
        if sl is None:
            continue
        area = int((lab[sl] == i).sum())
        out.append(dict(id=i, x0=sl[1].start, x1=sl[1].stop, y0=sl[0].start, y1=sl[0].stop, area=area))
    return out


O = objs()
big = sorted([o for o in O if o["x1"] <= 860 and o["area"] > 5000], key=lambda o: -o["area"])
if len(big) != 3:
    sys.exit("تعذر التعرف على مكونات الشارة (قوسان ونبض): %d" % len(big))
outer, inner = big[0], big[1]
pulse = big[2]
if not (outer["area"] > inner["area"] > pulse["area"]):
    sys.exit("ترتيب المكونات غير متوقع")
MX0 = min(o["x0"] for o in (outer, inner, pulse))
MY0 = min(o["y0"] for o in (outer, inner, pulse))
MX1 = max(o["x1"] for o in (outer, inner, pulse))
MY1 = max(o["y1"] for o in (outer, inner, pulse))
MW, MH = MX1 - MX0, MY1 - MY0


def trace(mask_alpha, x0, y0, x1, y1, ox, oy, tol=0.1, sigma=0.5):
    """حدود دون البكسل بطريقة marching squares على قناة الشفافية عند المستوى 0.5 (بلا تدرّج درجات سلّمية)،
    ثم تبسيط بانحراف أقصى tol بكسل. الإحداثيات نسبة إلى نقطة الأصل (ox, oy) في صورة المصدر."""
    crop = np.pad(mask_alpha[y0:y1, x0:x1].astype(np.float32) / 255.0, 3)
    sm = ndi.gaussian_filter(crop, sigma)
    parts, npts = [], 0
    for c in measure.find_contours(sm, 0.5):
        if len(c) < 8 or np.hypot(*(c[0] - c[-1])) > 1e-6:      # نريد حدوداً مغلقة فقط
            continue
        pts = np.stack([c[:, 1] - 3 + 0.5 + x0 - ox, c[:, 0] - 3 + 0.5 + y0 - oy], axis=1)
        area = 0.5 * abs(np.dot(pts[:, 0], np.roll(pts[:, 1], -1)) - np.dot(pts[:, 1], np.roll(pts[:, 0], -1)))
        if area < 6:
            continue
        q = measure.approximate_polygon(pts, tol)[:-1]
        npts += len(q)
        parts.append("M" + " ".join("%.2f %.2f" % (x, y) for x, y in q) + "Z")
    return "".join(parts), npts


def comp_alpha(i, pad=3):
    d = ndi.binary_dilation(lab == i, iterations=pad)
    return np.where(d, alpha, 0)


def stops_for(o, K=9):
    m = (lab == o["id"]) & (alpha > 250)
    xs = np.where(m.any(axis=0))[0]
    xa, xb = int(xs.min()), int(xs.max())
    st = []
    for k in range(K):
        t = k / (K - 1)
        cx = int(round(xa + t * (xb - xa)))
        sub = m[:, max(cx - 6, 0):cx + 7]
        pix = src[:, max(cx - 6, 0):cx + 7, :3][sub]
        if len(pix):
            st.append((t, "#%02X%02X%02X" % tuple(int(round(v)) for v in pix.mean(axis=0))))
    return xa - MX0, xb - MX0, st


def grad_xml(gid, o):
    xa, xb, st = stops_for(o)
    return ('<linearGradient id="%s" gradientUnits="userSpaceOnUse" x1="%d" y1="0" x2="%d" y2="0">' % (gid, xa, xb) +
            "".join('<stop offset="%.3f" stop-color="%s"/>' % (t, c) for t, c in st) + "</linearGradient>")


pm = lab == pulse["id"]
pulse_color = "#%02X%02X%02X" % tuple(int(round(v)) for v in src[pm & (alpha > 250)][:, :3].mean(axis=0))
TEXT = "#%02X%02X%02X" % tuple(int(round(v)) for v in src[(np.arange(src.shape[1])[None, :] > 860) & (alpha > 250)][:, :3].mean(axis=0))

d_outer, n1 = trace(comp_alpha(outer["id"]), outer["x0"] - 4, outer["y0"] - 4, outer["x1"] + 4, outer["y1"] + 4, MX0, MY0)
d_inner, n2 = trace(comp_alpha(inner["id"]), inner["x0"] - 4, inner["y0"] - 4, inner["x1"] + 4, inner["y1"] + 4, MX0, MY0)
d_pulse, n3 = trace(comp_alpha(pulse["id"]), pulse["x0"] - 4, pulse["y0"] - 4, pulse["x1"] + 4, pulse["y1"] + 4, MX0, MY0)

# الاسم: كل مكونات x>860 معاً (الثقوب والنقاط تُعالج بالحدود المتداخلة)
tx0, tx1 = 870, int(np.where((alpha > 8).any(axis=0))[0].max()) + 6
ty0, ty1 = int(np.where((alpha[:, 860:] > 8).any(axis=1))[0].min()) - 6, int(np.where((alpha[:, 860:] > 8).any(axis=1))[0].max()) + 6
text_alpha = alpha.copy()
text_alpha[:, :860] = 0
LX0, LY0 = MX0, MY0           # إحداثيات الشعار الكامل: نقطة الأصل هي نفسها أصل الشارة
d_text, n4 = trace(text_alpha, tx0, ty0, tx1, ty1, LX0, LY0)
LW, LH = tx1 - LX0 - 6, max(MH, ty1 - LY0 - 6)
# حدود الاسم وحده
d_text_only, _ = trace(text_alpha, tx0, ty0, tx1, ty1, tx0 + 6, ty0 + 6)
WW, WH = tx1 - tx0 - 12, ty1 - ty0 - 12

# نبض القلب كخط (للحركة فقط): رؤوس مضبوطة بالتحسين على قناع النبض الأصلي (التطابق ≈ 0.97)
PULSE_PTS = json.loads((HERE / "pulse_fit.json").read_text())["points"]
PULSE_W = json.loads((HERE / "pulse_fit.json").read_text())["width"]
pp = " ".join("%.1f,%.1f" % (x - MX0, y - MY0) for x, y in PULSE_PTS)

XMLNS = 'xmlns="http://www.w3.org/2000/svg"'


def svg(w, h, body, extra=""):
    return '<svg %s viewBox="0 0 %d %d" width="%d" height="%d"%s>%s</svg>\n' % (XMLNS, w, h, w, h, extra, body)


defs = "<defs>" + grad_xml("go", outer) + grad_xml("gi", inner) + "</defs>"
mark_body = (defs + '<path fill="url(#go)" fill-rule="evenodd" d="%s"/><path fill="url(#gi)" fill-rule="evenodd" d="%s"/><path fill="%s" fill-rule="evenodd" d="%s"/>'
             % (d_outer, d_inner, pulse_color, d_pulse))
(OUT / "mark.svg").write_text(svg(MW, MH, mark_body, ' role="img" aria-label="شعار مجمعات دار السلام الطبية"'), encoding="utf-8")
white_body = '<path fill="#fff" fill-rule="evenodd" d="%s%s%s"/>' % (d_outer, d_inner, d_pulse)
(OUT / "mark-white.svg").write_text(svg(MW, MH, white_body, ' aria-hidden="true"'), encoding="utf-8")
(OUT / "wordmark.svg").write_text(svg(WW, WH, '<path fill="%s" fill-rule="evenodd" d="%s"/>' % (TEXT, d_text_only), ' role="img" aria-label="مجمعات دار السلام الطبية"'), encoding="utf-8")
logo_body = mark_body + '<path fill="%s" fill-rule="evenodd" d="%s"/>' % (TEXT, d_text)
(OUT / "logo.svg").write_text(svg(LW, LH, logo_body, ' role="img" aria-label="مجمعات دار السلام الطبية"'), encoding="utf-8")

# شارة الحركة لشاشة البداية: القوسان ثابتان من أول إطار (فيتطابقان مع شاشة الإطلاق الأصلية الثابتة)،
# ثم يُرسم خط النبض. الحركة داخل الملف نفسه فتعمل حتى عند استعماله كصورة <img>.
anim_css = (
    "@keyframes draw{from{stroke-dashoffset:1050;opacity:0}3%{opacity:1}to{stroke-dashoffset:0;opacity:1}}"
    ".pl{stroke-dasharray:1000 1100;stroke-dashoffset:1050;opacity:0;animation:draw 1.05s cubic-bezier(.55,0,.25,1) .25s forwards}"
    "@media (prefers-reduced-motion:reduce){.pl{animation:none;stroke-dashoffset:0;opacity:1}}"
)
splash_body = ("<style>" + anim_css + "</style>" + defs +
               '<path fill="url(#go)" fill-rule="evenodd" d="%s"/><path fill="url(#gi)" fill-rule="evenodd" d="%s"/>' % (d_outer, d_inner) +
               '<polyline class="pl" pathLength="1000" fill="none" stroke="%s" stroke-width="%.1f" stroke-linecap="round" stroke-linejoin="round" points="%s"/>' % (pulse_color, PULSE_W, pp))
(OUT / "splash-mark.svg").write_text(svg(MW, MH, splash_body, ' aria-hidden="true"'), encoding="utf-8")
# القوسان فقط (بلا نبض) بألوانهما: تُستعمل لصورة شاشة الإطلاق الأصلية الثابتة (tools/make_icons.js)
arches_body = defs + '<path fill="url(#go)" fill-rule="evenodd" d="%s"/><path fill="url(#gi)" fill-rule="evenodd" d="%s"/>' % (d_outer, d_inner)
(HERE / "mark-arches.svg").write_text(svg(MW, MH, arches_body, ' aria-hidden="true"'), encoding="utf-8")
print("mark %dx%d  logo %dx%d  wordmark %dx%d  points: outer %d inner %d pulse %d text %d  colors pulse %s text %s" % (MW, MH, LW, LH, WW, WH, n1, n2, n3, n4, pulse_color, TEXT))
for f in ("mark.svg", "mark-white.svg", "wordmark.svg", "logo.svg", "splash-mark.svg"):
    print(f, (OUT / f).stat().st_size, "bytes")
print("mark-arches.svg", (HERE / "mark-arches.svg").stat().st_size, "bytes")
