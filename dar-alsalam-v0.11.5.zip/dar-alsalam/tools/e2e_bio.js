/* اختبار الدخول ببصمة الوجه (0.11.4–0.11.5) بمحاكاة إضافة NativeBiometric في متصفح حقيقي وخادم مؤقت (:8098). لا يختبر Face ID الفعلي (يحتاج جوالاً).
     عرض التفعيل بعد أول دخول ← حفظ البيانات ← الدخول بالوجه ← إلغاء التحقق يترك كلمة المرور ← تغيّر كلمة المرور يُبطل البصمة
     ← رفض العرض لا يتكرر ← خارج التطبيق الأصلي لا شيء يظهر.   NODE_PATH=<playwright> node tools/e2e_bio.js */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const PW = 'devpass-12345', PORT = 8098, base = 'http://127.0.0.1:' + PORT, PAT = 'Salam2026x', PHONE = '0551119200';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function http(method, p, body, token) {
  const h = { Accept: 'application/json' }; if (body !== undefined) h['Content-Type'] = 'application/json'; if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(base + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(() => ({})) };
}
const MOCK = () => {
  window.__kc = null; window.__verify = 'ok'; window.__calls = [];
  const bio = {
    isAvailable: () => Promise.resolve({ isAvailable: true, biometryType: 2 }),
    verifyIdentity: () => { window.__calls.push('verify'); return window.__verify === 'ok' ? Promise.resolve() : Promise.reject(new Error('cancel')); },
    setCredentials: (o) => { window.__kc = o; window.__calls.push('set'); return Promise.resolve(); },
    getCredentials: (o) => { window.__calls.push('get'); return window.__kc ? Promise.resolve({ username: window.__kc.username, password: window.__kc.password }) : Promise.reject(new Error('none')); },
    deleteCredentials: () => { window.__kc = null; window.__calls.push('del'); return Promise.resolve(); }
  };
  window.Capacitor = { isNativePlatform: () => true, getPlatform: () => 'ios', Plugins: { NativeBiometric: bio,
    PushNotifications: { requestPermissions: () => Promise.resolve({ receive: 'denied' }), addListener: () => Promise.resolve({ remove() {} }), register: () => Promise.resolve() },
    App: { addListener: () => Promise.resolve({ remove() {} }), exitApp() {} }, Browser: { open: () => Promise.resolve() }, Share: { share: () => Promise.resolve() } } };
};
(async () => {
  const dir = '/tmp/ds-bio'; execSync('rm -rf ' + dir + ' && mkdir -p ' + dir);
  const env = Object.assign({}, process.env, { DS_DB: dir + '/clinic.db', DS_PORT: String(PORT), DS_QUIET: '1', DS_PW_ITERS: '1000' });
  execSync('python3 ' + ROOT + '/server/manage.py init --password ' + PW, { env, stdio: 'ignore' });
  const proc = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  for (let i = 0; i < 40; i++) { try { if ((await fetch(base + '/api/v1/health')).ok) break; } catch (e) { /* انتظر */ } await sleep(300); }
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  try {
    const AT = (await http('POST', '/api/admin/login', { password: PW })).body.token;
    await http('PUT', '/api/admin/auth', { mode: 'password' }, AT);
    const reg = await http('POST', '/api/v1/auth/register', { phone: PHONE, password: PAT, password2: PAT, name: 'سعد العتيبي', gender: 'male', birthDate: '1990-05-17', nationalId: '',
      profile: { nationality: 'سعودي', email: '', city: 'المدينة', emergency: {}, health: { bloodType: '', allergies: { none: true, text: '' }, chronic: { none: true, items: [], other: '' }, medications: { none: true, text: '' }, surgeries: { none: true, text: '' }, pregnancy: '' }, insurance: {} }, consent: { privacy: true, health: true } });
    ok(reg.status === 201, 'حساب تجريبي: ' + reg.status);
    const mkpage = async (native, accept) => {
      const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
      const p = await ctx.newPage(); p.__dialogs = [];
      if (native) await p.addInitScript(MOCK);
      p.on('dialog', async (d) => { p.__dialogs.push(d.message()); if (accept) await d.accept(); else await d.dismiss(); });
      p.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
      p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
      return p;
    };
    const open = async (p, h) => { await p.goto(base + '/app/' + h, { waitUntil: 'load' }); await p.waitForSelector('.tabs', { timeout: 15000 }); await p.waitForFunction(() => window.DS && DS.data && DS.data.source === 'network', null, { timeout: 8000 }); await sleep(400); };
    const login = async (p) => { await p.fill('#a-phone', PHONE); await p.fill('#a-password', PAT); await p.click('#au-login button[type=submit]'); };

    /* 1) أول دخول في التطبيق الأصلي: يُعرض التفعيل ويُحفظ */
    const p = await mkpage(true, true);
    await open(p, '#/login');
    ok(await p.locator('[data-act="au-bio"]').count() === 0, 'قبل التفعيل: لا زر بصمة');
    await login(p); await sleep(1500);
    ok(p.__dialogs.length === 1 && /بصمة الوجه/.test(p.__dialogs[0]), 'بعد أول دخول يُعرض تفعيل بصمة الوجه');
    ok(await p.evaluate(() => !!window.__kc && window.__kc.username.length > 8 && window.__kc.server === 'daralsalam-clinic'), 'البيانات حُفظت في المخزن الآمن (Keychain) بمعرّف الخادم');
    ok(await p.evaluate(() => !!DS.auth.token() && localStorage.getItem('ds.bio') === 'true'), 'تم الدخول وتفعيل الميزة');
    ok(!(await p.evaluate(() => JSON.stringify(Object.assign({}, localStorage)))).includes('Salam2026x'), 'كلمة المرور لا تُحفظ في تخزين المتصفح العادي');

    /* 2) خروج ثم دخول بالوجه تلقائياً */
    await p.evaluate(() => { DS.auth.clear(); });
    await p.evaluate(() => { window.__calls.length = 0; window.__auto = DS.auth.bioAuto = false; });
    await p.evaluate(() => { location.hash = '#/login'; }); await sleep(300);
    await p.waitForFunction(() => !!DS.auth.token(), null, { timeout: 8000 }).catch(() => {});
    ok(await p.evaluate(() => !!DS.auth.token()) && (await p.evaluate(() => window.__calls)).join() === 'verify,get', 'فتح شاشة الدخول: تحقق بالوجه ثم الدخول تلقائياً (verify ثم get)');

    /* 3) إلغاء التحقق: تبقى كلمة المرور بلا رسالة خطأ */
    await p.evaluate(() => { DS.auth.clear(); window.__verify = 'cancel'; DS.auth.bioAuto = false; location.hash = '#/'; }); await sleep(300);
    await p.evaluate(() => { location.hash = '#/login'; }); await sleep(1200);
    ok(!(await p.evaluate(() => !!DS.auth.token())) && await p.locator('#au-login').count() === 1 && await p.locator('#au-fail .alert').count() === 0, 'إلغاء التحقق: بلا دخول وبلا رسالة خطأ وكلمة المرور متاحة');
    await p.evaluate(() => { window.__verify = 'ok'; });
    await p.locator('[data-act="au-bio"]').click(); await sleep(1500);
    ok(await p.evaluate(() => !!DS.auth.token()), 'زر «الدخول ببصمة الوجه» يعمل يدوياً');

    /* 4) تغيّرت كلمة المرور: تُبطل البصمة */
    await p.evaluate(() => { DS.auth.clear(); window.__kc.password = 'Wrong-Pass-999x'; DS.auth.bioAuto = false; location.hash = '#/'; }); await sleep(300);
    await p.evaluate(() => { location.hash = '#/login'; }); await sleep(1800);
    ok(await p.evaluate(() => localStorage.getItem('ds.bio')) === null && await p.evaluate(() => window.__kc) === null, 'كلمة مرور محفوظة غير صالحة: تُحذف البصمة من الجهاز');
    ok(/سجّل دخولك بكلمة المرور/.test(await p.locator('#au-fail').innerText()), 'ويُشرح للمراجع ما يفعل');

    /* 5) رفض العرض لا يتكرر */
    const q = await mkpage(true, false);
    await open(q, '#/login'); await login(q); await sleep(1500);
    ok(q.__dialogs.length === 1 && await q.evaluate(() => window.__kc) === null && await q.evaluate(() => !!DS.auth.token()), 'رفض التفعيل: يدخل بلا حفظ شيء');
    await q.evaluate(() => { DS.auth.clear(); location.hash = '#/'; }); await sleep(300);
    await q.evaluate(() => { location.hash = '#/login'; }); await sleep(400); await login(q); await sleep(1500);
    ok(q.__dialogs.length === 1, 'لا يُعاد عرض التفعيل بعد الرفض');

    /* 6) إيقاف الميزة من «المزيد» */
    await p.evaluate(() => { DS.store.set('bio', true); window.__kc = { username: 'x', password: 'y', server: 'daralsalam-clinic' }; location.hash = '#/more'; }); await sleep(600);
    ok(await p.locator('[data-act="bio-off"]').count() === 1, 'المزيد: خيار «إيقاف الدخول ببصمة الوجه»');
    await p.locator('[data-act="bio-off"]').click(); await sleep(500);
    ok(await p.evaluate(() => window.__kc) === null && await p.locator('[data-act="bio-off"]').count() === 0, 'الإيقاف يحذف البيانات من المخزن الآمن');

    /* 7) خارج التطبيق الأصلي: لا شيء */
    const w = await mkpage(false, true);
    await open(w, '#/login'); await login(w); await sleep(1500);
    ok(w.__dialogs.length === 0 && await w.locator('[data-act="au-bio"]').count() === 0, 'في المتصفح العادي: لا عرض ولا زر بصمة');
    /* 8) شاشة الترحيب عند أول فتح: دخول أو ضيف */
    const g = await mkpage(false, true);
    await g.goto(base + '/app/', { waitUntil: 'load' }); await g.waitForSelector('.tabs', { timeout: 15000 });
    await g.waitForFunction(() => location.hash === '#/welcome', null, { timeout: 8000 }).catch(() => {});
    ok(await g.evaluate(() => location.hash) === '#/welcome' && await g.locator('.welcome [href="#/login"]').count() === 1 && await g.locator('[data-act="welcome-guest"]').count() === 1, 'أول فتح: شاشة ترحيب فيها «تسجيل الدخول» و«المتابعة كضيف»');
    ok(await g.locator('.tabs').evaluate((e) => getComputedStyle(e).display) === 'none', 'شاشة الترحيب بلا شريط تبويب');
    await g.locator('[data-act="welcome-guest"]').click(); await sleep(500);
    ok(await g.evaluate(() => location.hash) === '#/' && await g.locator('.tabs').evaluate((e) => getComputedStyle(e).display) !== 'none', 'المتابعة كضيف: تفتح الرئيسية والتبويبات ظاهرة');
    await g.reload({ waitUntil: 'load' }); await g.waitForSelector('.tabs', { timeout: 15000 }); await sleep(1200);
    ok(await g.evaluate(() => location.hash) !== '#/welcome', 'لا تتكرر شاشة الترحيب بعد اختيار الضيف');
    const g2 = await mkpage(false, true);
    await g2.goto(base + '/app/#/doctors', { waitUntil: 'load' }); await g2.waitForSelector('.tabs', { timeout: 15000 }); await sleep(1200);
    ok(await g2.evaluate(() => location.hash) === '#/doctors', 'الرابط العميق لا يُعترض بشاشة الترحيب');
    const g3 = await mkpage(false, true);
    await g3.goto(base + '/app/#/login', { waitUntil: 'load' }); await g3.waitForSelector('#a-phone', { timeout: 15000 }); await login(g3); await sleep(1500);
    ok(await g3.evaluate(() => !!DS.auth.token() && location.hash !== '#/welcome'), 'بعد تسجيل الدخول لا ترحيب');
    ok(errors.length === 0, 'لا أخطاء جافاسكربت ' + errors.join(' | '));
  } catch (e) { fail++; console.log('FAIL استثناء: ' + (e.stack || e)); }
  await browser.close(); proc.kill();
  console.log('\n=== ' + pass + ' PASS / ' + fail + ' FAIL ==='); process.exit(fail ? 1 : 0);
})();
