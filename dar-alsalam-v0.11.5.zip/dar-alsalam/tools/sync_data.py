#!/usr/bin/env python3
"""يولّد النسخة العامة المضمّنة في التطبيق (web/data/) من data/seed.json بنفس منطق الخادم تماماً،
وينسخ قاموس «قمر» المشترك. شغّله بعد أي تعديل على data/seed.json أو data/lexicon.json."""
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "server"))
import db as dbmod  # noqa: E402


def main():
    seed = json.loads((ROOT / "data" / "seed.json").read_text(encoding="utf-8"))
    out = ROOT / "web" / "data"
    out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        d = dbmod.DB(Path(tmp) / "t.db")
        d.seed(seed)
        ds = d.dataset(public=True)
    ds["meta"] = {"version": 0, "source": "seed"}
    (out / "seed.public.json").write_text(json.dumps(ds, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    shutil.copyfile(ROOT / "data" / "lexicon.json", out / "lexicon.json")
    print("web/data/seed.public.json:", (out / "seed.public.json").stat().st_size, "bytes;",
          {k: len(v) for k, v in ds.items() if isinstance(v, list)})


if __name__ == "__main__":
    main()
