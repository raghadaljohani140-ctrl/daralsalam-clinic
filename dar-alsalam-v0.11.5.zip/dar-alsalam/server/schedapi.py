"""واجهات المواعيد: ما يراه المراجع (المواعيد المتاحة، الحجز، الإلغاء، الدفع التجريبي)، وإدارة ساعات الأطباء والسياسة،
واستدعاء الطبيب لمراجع بموعد. المنطق الثقيل في scheddb.py؛ هنا التحقق والصلاحيات والرسائل."""
import datetime as dt
import json
import re
import secrets

import scheddb as sd
from util import riyadh_today

MAX_ROWS, MAX_DAYS = 70, 150
DAY_RE = re.compile(r"\d{4}-\d{2}-\d{2}")


def is_int(x):
    return isinstance(x, int) and not isinstance(x, bool)
SLOT_ERR = {
    "slot_invalid": "هذا الموعد لم يعد متاحاً. اختر موعداً آخر.",
    "slot_taken": "سبقك إليه مراجع آخر قبل لحظات. اختر موعداً آخر.",
    "duplicate_day": "لديك موعد مع هذا الطبيب في اليوم نفسه.",
}


class ScheduleMixin:
    # ------------------------------------------------------------------ نصوص
    def appt_text(self, b):
        docs, brs = self._names()
        day = dt.date.fromisoformat(b["date"])
        return "موعدك مؤكد: %s · %s — د. %s — %s" % (sd.date_ar(day), sd.time_ar(b["slot_start"]), docs.get(b["doctor_id"], ""), brs.get(b["branch_id"], ""))

    def slot_extra(self, items):
        """يضيف لكل حجز بموعد آخر وقت للإلغاء من التطبيق (UTC) حتى تُخفي الواجهة الزر بعد فواته. الخادم هو من يفرض القاعدة فعلاً."""
        pol = None
        for d in items:
            s = d.get("slot")
            if s:
                pol = pol or self.app.db.sched_policy()
                t = sd.slot_dt(dt.date.fromisoformat(d["date"]), sd.parse_hhmm(s["start"])) - dt.timedelta(hours=pol["cancelBeforeH"])
                s["cancelUntil"] = t.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                if d.get("pay"):
                    d["pay"]["test"] = self.app.cfg.pay_provider == "test"
        return items

    def pay_on(self, pol=None):
        """الدفع المسبق فعّال فقط إن فعّلته الإدارة وكان هناك مزوّد مربوط (حالياً: مزوّد «تجريبي» لا يحصّل مالاً)."""
        pol = pol or self.app.db.sched_policy()
        return bool(pol["prepay"]["enabled"] and pol["prepay"]["amount"] > 0 and self.app.cfg.pay_provider == "test")

    # ------------------------------------------------------------------ المراجع: المواعيد المتاحة
    def slots_api(self):
        app = self.app
        if not app.rl.allow("slots:" + self.ip, 120, 60):
            return self.err(429, "rate_limited")
        did, br = self.qs.get("doctorId", ""), self.qs.get("branchId", "")
        ds = app.public_dataset()[1]
        if not any(d["id"] == did for d in ds["doctors"]):
            return self.err(404, "not_found", "الطبيب غير موجود")
        bids = {b["id"] for b in ds["branches"]}
        if br and br not in bids:
            return self.err(422, "validation", "فرع غير موجود")
        db, pol = app.db, app.db.sched_policy()
        scheduled = did in db.sched_doctor_ids()
        days = []
        if scheduled:
            days = db.sched_days(did, br or None, pol)
            for d in days:
                d["slots"] = [s for s in d["slots"] if s["branchId"] in bids]
        branches = [b for b in (db.sched_summary().get(did, {}).get("branches") or []) if b in bids]
        pay = self.pay_on(pol)
        return self.json(200, {"doctorId": did, "scheduled": scheduled and bool(branches), "branches": branches, "days": days,
                               "policy": {"horizonDays": pol["horizonDays"], "minNoticeMin": pol["minNoticeMin"], "cancelBeforeH": pol["cancelBeforeH"],
                                          "checkin": bool(pol["requireCheckin"]),
                                          "prepay": {"enabled": pay, "amount": pol["prepay"]["amount"] if pay else 0, "holdMin": pol["prepay"]["holdMin"], "test": pay}}},
                         {"Cache-Control": "no-store"})

    # ------------------------------------------------------------------ المراجع: حجز موعد
    def slot_booking_create(self, body, did, name, phone, sp, dr, br, sv, note, patient_id=None):
        """يُستدعى من api_booking_create بعد التحقق العام من الاسم والجوال والموافقة. يعيد الاستجابة كاملة."""
        app, db = self.app, self.app.db
        sl = body.get("slot")
        def bad():
            return self.err(422, "validation", "اختر موعداً من المواعيد المتاحة", {"slot": "اختر موعداً من المواعيد المتاحة"})
        if not isinstance(sl, dict) or not dr or not br:
            return bad()
        ds_, st_ = sl.get("day"), sl.get("start")
        if not isinstance(ds_, str) or not DAY_RE.fullmatch(ds_) or not isinstance(st_, str):
            return bad()
        try:
            day = dt.date.fromisoformat(ds_)
        except ValueError:
            return bad()
        start = sd.parse_hhmm(st_)
        if start is None:
            return bad()
        if dr not in db.sched_doctor_ids():
            return self.err(409, "not_scheduled", "هذا الطبيب لا يقبل الحجز بموعد حالياً. أرسل طلب حجز عادياً.")
        if db.count_recent_bookings(did, 24) >= 8:
            return self.err(429, "too_many", "وصلت للحد اليومي من الحجوزات، تواصل مع المجمع هاتفياً")
        pol = db.sched_policy()
        hold = pol["prepay"]["holdMin"] if self.pay_on(pol) else 0
        db.upsert_device(did, str(body.get("platform", ""))[:20], "")
        docs, brs = self._names()
        text = "موعدك مؤكد: %s · %s — د. %s — %s" % (sd.date_ar(day), sd.time_ar(start), docs.get(dr, ""), brs.get(br, ""))
        try:
            b = db.sched_book({"name": name, "phone": phone, "device_id": did, "specialty_id": sp, "service_id": sv, "note": note, "source": str(body.get("source", "app"))[:20],
                               "patient_id": patient_id},
                              dr, br, day, start, text, pol, hold_min=hold, amount=pol["prepay"]["amount"])
        except ValueError as e:
            code = str(e)
            msg = ("لديك %d مواعيد قادمة. ألغِ أحدها أو انتظر موعده لتحجز موعداً جديداً." % pol["maxActive"]) if code == "too_many_active" else SLOT_ERR.get(code, "تعذّر الحجز")
            return self.err(409, code, msg)
        return self.json(201, {"booking": self.slot_extra([self.public_booking(b)])[0], "appointment": True})

    def slot_cancel_ok(self, b):
        """إلغاء المراجع لموعد مؤكد: قبل الموعد بمهلة السياسة، وما لم تُفتح زيارته. يرسل الخطأ ويعيد False عند المنع."""
        db = self.app.db
        if db.visits_for_bookings([b["id"]]).get(b["id"]):
            self.err(409, "not_cancellable", "بدأت زيارة هذا الموعد فلا يمكن إلغاؤه")
            return False
        h = db.sched_policy()["cancelBeforeH"]
        if sd.slot_dt(dt.date.fromisoformat(b["date"]), b["slot_start"]) - sd.riyadh_now() < dt.timedelta(hours=h):
            self.err(409, "too_late", "لا يمكن إلغاء الموعد قبل أقل من %d ساعة من وقته من التطبيق. تواصل مع المجمع." % h if h else "فات وقت هذا الموعد. تواصل مع المجمع.")
            return False
        return True

    def slot_pay(self, bid):
        """دفع مسبق بمزوّد «تجريبي» فقط: لا يُحصَّل أي مبلغ ولا يُنفَّذ أي شراء. وجوده لاختبار منطق الحجز المؤقت ومهلته."""
        app, db = self.app, self.app.db
        if app.cfg.pay_provider != "test":
            return self.err(404, "not_found")
        body = self.body_json()
        if body is None:
            return
        b = db.get_booking(bid)
        pt = self.current_patient() if app.accounts_method() else None
        if not b or not self.booking_owner_ok(b, pt, str(body.get("deviceId", ""))) or b["slot_start"] is None:
            return self.err(404, "not_found", "الطلب غير موجود")
        try:
            b2 = db.sched_pay(bid, "test-" + secrets.token_hex(4), self.appt_text(b))
        except ValueError as e:
            if str(e) == "expired":
                return self.err(409, "expired", "انتهت مهلة حجز هذا الموعد. اختر موعداً جديداً.")
            return self.err(409, "state", "هذا الموعد ليس بانتظار دفع")
        return self.json(200, {"booking": self.slot_extra([self.public_booking(b2)])[0]})

    # ------------------------------------------------------------------ الإدارة
    def admin_sched_api(self, method, p):
        """/schedules · /schedules/<doctorId> · /scheduling  (توكن المالك)."""
        app, db = self.app, self.app.db
        if method == "GET" and p == "/schedules":
            summ = db.sched_summary()
            brs = [{"id": b["id"], "name": b.get("shortName") or b["name"]} for b in db.list_entities("branches")]
            docs = [{"id": d["id"], "name": d["name"], "branchIds": d.get("branchIds") or [], "rows": summ.get(d["id"], {}).get("rows", 0),
                     "scheduledBranches": summ.get(d["id"], {}).get("branches", [])} for d in db.list_entities("doctors")]
            return self.json(200, {"doctors": docs, "branches": brs, "policy": db.sched_policy(), "payProvider": app.cfg.pay_provider, "slotChoices": list(sd.SLOT_CHOICES)})
        if method == "PUT" and p == "/scheduling":
            return self.admin_policy_put()
        m = re.fullmatch(r"/schedules/([a-z0-9-]{1,60})", p)
        if not m:
            return self.err(404, "not_found")
        doc = db.get_entity("doctors", m.group(1))
        if not doc:
            return self.err(404, "not_found", "الطبيب غير موجود")
        if method == "GET":
            return self.json(200, self.sched_state(doc))
        if method == "PUT":
            return self.admin_sched_put(doc)
        return self.err(405, "method_not_allowed")

    def sched_state(self, doc):
        db = self.app.db
        rows, days = db.sched_get(doc["id"])
        today = riyadh_today().isoformat()
        return {"doctor": {"id": doc["id"], "name": doc["name"], "branchIds": doc.get("branchIds") or []},
                "rows": [{"branchId": r["branch_id"], "weekday": r["weekday"], "start": sd.hhmm(r["start_min"]), "end": sd.hhmm(r["end_min"]), "slot": r["slot_min"]} for r in rows],
                "days": [{"branchId": d["branch_id"], "day": d["day"], "kind": d["kind"], "start": sd.hhmm(d["start_min"]) if d["start_min"] is not None else "",
                          "end": sd.hhmm(d["end_min"]) if d["end_min"] is not None else "", "slot": d["slot_min"] or 0, "note": d["note"] or ""} for d in days if d["day"] >= today],
                "outside": db.sched_outside(doc["id"])}

    def admin_sched_put(self, doc):
        db = self.app.db
        body = self.body_json()
        if body is None:
            return
        brs = {b["id"] for b in db.list_entities("branches")}
        allowed = set(doc.get("branchIds") or []) or brs
        errs, rows, days = {}, [], []
        raw_rows, raw_days = body.get("rows"), body.get("days", [])
        if not isinstance(raw_rows, list) or not isinstance(raw_days, list) or len(raw_rows) > MAX_ROWS or len(raw_days) > MAX_DAYS:
            return self.err(422, "validation", "بيانات غير صحيحة")
        for i, r in enumerate(raw_rows):
            if not isinstance(r, dict):
                errs["rows"] = "صف غير صحيح"
                break
            br, wd, a, e, sl = str(r.get("branchId", "")), r.get("weekday"), sd.parse_hhmm(r.get("start")), sd.parse_end(r.get("end")), r.get("slot")
            if br not in brs or br not in allowed:
                errs["rows"] = "السطر %d: اختر فرعاً يعمل فيه الطبيب" % (i + 1)
            elif not is_int(wd) or not 0 <= wd <= 6:
                errs["rows"] = "السطر %d: اليوم غير صحيح" % (i + 1)
            elif a is None or e is None or a >= e:
                errs["rows"] = "السطر %d: وقت النهاية يجب أن يكون بعد البداية" % (i + 1)
            elif not is_int(sl) or sl not in sd.SLOT_CHOICES or e - a < sl:
                errs["rows"] = "السطر %d: مدة الموعد غير صحيحة أو أطول من فترة العمل" % (i + 1)
            if errs:
                break
            rows.append({"branch_id": br, "weekday": wd, "start_min": a, "end_min": e, "slot_min": sl})
        if not errs:
            for wd in range(7):
                lst = sorted((r["start_min"], r["end_min"]) for r in rows if r["weekday"] == wd)
                if any(lst[i][1] > lst[i + 1][0] for i in range(len(lst) - 1)):
                    errs["rows"] = "تداخل في ساعات يوم %s (الطبيب لا يكون في مكانين معاً)" % sd.AR_WEEKDAYS[wd]
                    break
        today = riyadh_today().isoformat()
        if not errs:
            for i, d in enumerate(raw_days):
                if not isinstance(d, dict):
                    errs["days"] = "استثناء غير صحيح"
                    break
                try:
                    if not isinstance(d.get("day"), str) or not DAY_RE.fullmatch(d["day"]):
                        raise ValueError
                    day = dt.date.fromisoformat(d["day"]).isoformat()
                except ValueError:
                    errs["days"] = "الاستثناء %d: تاريخ غير صحيح" % (i + 1)
                    break
                kind, br = str(d.get("kind", "")), str(d.get("branchId", "") or "")
                note = re.sub(r"[\x00-\x1f]", " ", str(d.get("note", "") or "")).strip()[:100]
                if day < today:
                    continue                                        # الماضي لا يُحفظ
                if kind == "off":
                    if br and (br not in brs or br not in allowed):
                        errs["days"] = "الاستثناء %d: فرع غير صحيح" % (i + 1)
                        break
                    days.append({"branch_id": br, "day": day, "kind": "off", "note": note})
                elif kind == "hours":
                    a, e, sl = sd.parse_hhmm(d.get("start")), sd.parse_end(d.get("end")), d.get("slot")
                    if br not in brs or br not in allowed:
                        errs["days"] = "الاستثناء %d: اختر الفرع لساعات خاصة" % (i + 1)
                    elif a is None or e is None or a >= e or not is_int(sl) or sl not in sd.SLOT_CHOICES or e - a < sl:
                        errs["days"] = "الاستثناء %d: الأوقات أو مدة الموعد غير صحيحة" % (i + 1)
                    if errs:
                        break
                    days.append({"branch_id": br, "day": day, "kind": "hours", "start_min": a, "end_min": e, "slot_min": sl, "note": note})
                else:
                    errs["days"] = "الاستثناء %d: النوع غير صحيح" % (i + 1)
                    break
        if not errs:
            for dd in {x["day"] for x in days if x["kind"] == "hours"}:
                lst = sorted((x["start_min"], x["end_min"]) for x in days if x["day"] == dd and x["kind"] == "hours")
                if any(lst[i][1] > lst[i + 1][0] for i in range(len(lst) - 1)):
                    errs["days"] = "تداخل في الساعات الخاصة بتاريخ %s" % dd
                    break
        if errs:
            return self.err(422, "validation", "تحقق من الحقول", errs)
        db.sched_replace(doc["id"], rows, days)
        db.audit("admin", "schedule_update", "doctor", doc["id"], json.dumps({"rows": len(rows), "days": len(days)}))
        return self.json(200, self.sched_state(doc))

    def admin_policy_put(self):
        app, db = self.app, self.app.db
        body = self.body_json()
        if body is None:
            return
        errs, cur = {}, db.sched_policy()

        def num(key, lo, hi, label, src=None):
            v = (src if src is not None else body).get(key, (src if src is not None else cur).get(key))
            if not is_int(v) or not lo <= v <= hi:
                errs[key] = "%s: رقم بين %d و%d" % (label, lo, hi)
                return cur.get(key)
            return v
        out = {"horizonDays": num("horizonDays", 1, 60, "مدة الحجز المسبق (أيام)"), "minNoticeMin": num("minNoticeMin", 0, 1440, "أقل مهلة قبل الموعد (دقائق)"),
               "cancelBeforeH": num("cancelBeforeH", 0, 72, "الإلغاء قبل الموعد (ساعات)"), "maxActive": num("maxActive", 1, 20, "الحد الأقصى للمواعيد القادمة للجوال الواحد"),
               "requireCheckin": body.get("requireCheckin", cur["requireCheckin"])}
        if not isinstance(out["requireCheckin"], bool):
            errs["requireCheckin"] = "قيمة غير صحيحة"
        pp = body.get("prepay") if isinstance(body.get("prepay"), dict) else {}
        pcur = cur["prepay"]
        pre = {"enabled": pp.get("enabled", pcur["enabled"]), "amount": pp.get("amount", pcur["amount"]), "holdMin": pp.get("holdMin", pcur["holdMin"])}
        if not isinstance(pre["enabled"], bool):
            errs["prepay"] = "قيمة غير صحيحة"
        for k, lo, hi, label in (("amount", 0, 100000, "المبلغ (ريال)"), ("holdMin", 5, 120, "مهلة الدفع (دقائق)")):
            if not is_int(pre[k]) or not lo <= pre[k] <= hi:
                errs["prepay"] = "%s: رقم بين %d و%d" % (label, lo, hi)
        if not errs and pre["enabled"]:
            if app.cfg.pay_provider != "test":
                errs["prepay"] = "لا يمكن تفعيل الدفع المسبق: لا توجد بوابة دفع مربوطة بالنظام. (الربط يحتاج حساب تاجر عند مزوّد دفع وموافقتك.)"
            elif pre["amount"] <= 0:
                errs["prepay"] = "حدّد مبلغ الدفع المسبق"
        if errs:
            return self.err(422, "validation", "تحقق من الحقول", errs)
        out["prepay"] = pre
        db.sched_policy_set(out)
        db.audit("admin", "scheduling_policy", "settings", "", json.dumps({k: out[k] for k in ("horizonDays", "minNoticeMin", "cancelBeforeH", "maxActive", "requireCheckin")}))
        return self.json(200, {"policy": db.sched_policy()})

    # ------------------------------------------------------------------ الطبيب: استدعاء مراجع بموعد
    def clinic_appt_call(self, s, bid):
        if not self.need(s, "clinical.write"):
            return
        did = self._doctor(s)
        if not did:
            return
        db = self.app.db
        b = db.get_booking(bid)
        if not b or b["doctor_id"] != did or b["slot_start"] is None or not self.in_scope(s, b["branch_id"]):
            return self.err(404, "not_found", "الموعد غير موجود")
        try:
            v, prov = db.appt_call(bid, did, "staff:" + s["username"], riyadh_today().isoformat(), db.sched_policy()["requireCheckin"])
        except ValueError as e:
            code = str(e)
            if code.startswith("duplicate:"):
                return self.err(409, "duplicate", "لدى هذا المراجع زيارة جارية اليوم مسجّلة باسم آخر؛ اطلب من الاستقبال ربطها بموعده")
            msg = {"busy": "عندك مراجع في العيادة الآن؛ أنهِ زيارته أولاً", "not_today": "هذا ليس موعد اليوم",
                   "checkin_required": "إعدادات المجمع تشترط أن يسجّل الاستقبال وصول المراجع قبل استدعائه",
                   "state": "لا يمكن استدعاء هذا الموعد في حالته الحالية"}.get(code, "تعذّر الاستدعاء")
            return self.err(409, "busy" if code == "busy" else code, msg)
        self.saudit(s, "appt_call", "visit", v["id"], {"booking": bid, "provisional": prov})
        self.notify_visit(v, "called")
        return self.json(200, {"visit": self.vd(v), "provisional": prov})

    def clinic_appointments(self, s, did, day):
        """قائمة مواعيد الطبيب ليوم (للطابور): بلا جوال المراجع."""
        db = self.app.db
        out = []
        for b in db.appt_list(did, day):
            if not self.in_scope(s, b["branch_id"]):
                continue
            out.append({"id": b["id"], "time": sd.hhmm(b["slot_start"]), "timeLabel": sd.time_ar(b["slot_start"]), "min": b["slot_min"], "name": b["name"],
                        "note": b["note"] or "", "branchId": b["branch_id"] or ""})
        return out
