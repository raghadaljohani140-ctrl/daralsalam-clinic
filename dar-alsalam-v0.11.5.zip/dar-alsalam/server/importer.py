"""استيراد سجلات المراجعين من Excel (xlsx) أو CSV بمكتبة بايثون القياسية فقط (بلا تثبيت أي حزمة)."""
import csv
import datetime as dt
import io
import re
import zipfile
import xml.etree.ElementTree as ET

MAX_ROWS = 20000
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")

HEADERS = {
    "mrn": ["رقم الملف", "رقم الملف الطبي", "الملف الطبي", "رقم المريض", "mrn", "file no", "file number", "file_no", "patient id", "medical record number"],
    "name": ["الاسم", "اسم المراجع", "اسم المريض", "الاسم الكامل", "name", "full name", "patient name"],
    "phone": ["الجوال", "رقم الجوال", "جوال", "الهاتف", "رقم الهاتف", "phone", "mobile", "mobile no", "phone number"],
    "national_id": ["الهوية", "رقم الهوية", "رقم الهوية/الإقامة", "الهوية/الإقامة", "رقم الإقامة", "الهوية الوطنية", "national id", "id", "id number", "nid", "iqama"],
    "birth_date": ["تاريخ الميلاد", "الميلاد", "birth date", "birthdate", "dob", "date of birth"],
    "gender": ["الجنس", "النوع", "gender", "sex"],
}
LABELS = {"mrn": "رقم الملف", "name": "الاسم", "phone": "الجوال", "national_id": "الهوية", "birth_date": "تاريخ الميلاد", "gender": "الجنس"}


class ImportError_(Exception):
    pass


def _norm_header(s):
    return re.sub(r"[\s_\-./]+", " ", str(s or "").strip().lower().replace("أ", "ا").replace("إ", "ا").replace("ة", "ه")).strip()


_HMAP = {_norm_header(a): k for k, v in HEADERS.items() for a in v}


def _col(ref):
    letters = re.match(r"[A-Z]+", ref).group(0)
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n - 1


def read_xlsx(raw):
    try:
        z = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile:
        raise ImportError_("الملف ليس Excel (xlsx) صالحاً")
    if sum(i.file_size for i in z.infolist()) > 60 * 1024 * 1024:
        raise ImportError_("الملف كبير جداً بعد فك الضغط")
    names = set(z.namelist())
    shared = []
    if "xl/sharedStrings.xml" in names:
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
            shared.append("".join(t.text or "" for t in si.iter("{%s}t" % NS["m"])))
    sheet = "xl/worksheets/sheet1.xml"
    if sheet not in names:
        cands = sorted(n for n in names if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"))
        if not cands:
            raise ImportError_("لم أجد ورقة بيانات في الملف")
        sheet = cands[0]
    rows = []
    for row in ET.fromstring(z.read(sheet)).iter("{%s}row" % NS["m"]):
        cells = {}
        for c in row.findall("m:c", NS):
            t = c.get("t")
            v = c.find("m:v", NS)
            if t == "s" and v is not None:
                val = shared[int(v.text)]
            elif t == "inlineStr":
                val = "".join(x.text or "" for x in c.iter("{%s}t" % NS["m"]))
            elif t == "str" or t == "b" or t == "e":
                val = v.text if v is not None else ""
            else:
                val = float(v.text) if v is not None and v.text not in (None, "") else ""
            cells[_col(c.get("r"))] = val
        if cells:
            rows.append([cells.get(i, "") for i in range(max(cells) + 1)])
        else:
            rows.append([])
        if len(rows) > MAX_ROWS + 5:
            raise ImportError_("عدد الصفوف أكبر من %d" % MAX_ROWS)
    return rows


def read_csv(raw):
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1256", errors="replace")
    sample = text[:2000]
    delim = ";" if sample.count(";") > sample.count(",") else ("\t" if sample.count("\t") > sample.count(",") else ",")
    return [r for r in csv.reader(io.StringIO(text), delimiter=delim)]


def _text(v):
    if isinstance(v, float):
        v = str(int(v)) if v == int(v) else repr(v)
    return str(v or "").translate(AR_DIGITS).strip()


def _date(v):
    if isinstance(v, float) and 10000 < v < 80000:  # رقم تسلسلي لتاريخ Excel
        return (dt.date(1899, 12, 30) + dt.timedelta(days=int(v))).isoformat()
    s = _text(v)
    if not s:
        return ""
    m = re.fullmatch(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[ T].*)?", s)
    if m:
        y, mo, d = map(int, m.groups())
    else:
        m = re.fullmatch(r"(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})", s)
        if not m:
            return None
        d, mo, y = map(int, m.groups())
    try:
        out = dt.date(y, mo, d)
    except ValueError:
        return None
    return out.isoformat() if dt.date(1900, 1, 1) <= out <= dt.date.today() else None


def _gender(v):
    s = _text(v).lower()
    if not s:
        return ""
    if s in ("m", "male", "ذكر", "ذ", "رجل"):
        return "male"
    if s in ("f", "female", "أنثى", "انثى", "ا", "أ", "امرأة"):
        return "female"
    return None


def parse(raw, norm_phone):
    """يعيد (rows, errors): rows قائمة قواميس نظيفة، errors قائمة (رقم_الصف، رسالة)."""
    rows = read_xlsx(raw) if raw[:2] == b"PK" else read_csv(raw)
    return _parse_grid([r for r in rows], norm_phone)


def parse_rows(items, norm_phone):
    """للإدخال اليدوي: قائمة قواميس (mrn,name,phone,nationalId,birthDate,gender) بنفس قواعد الاستيراد. يعيد (rows, errors[{row,error}])."""
    keys = ("mrn", "name", "phone", "national_id", "birth_date", "gender")
    alt = {"national_id": "nationalId", "birth_date": "birthDate"}
    grid = [[LABELS[k] for k in keys]]
    for it in items:
        grid.append([str(it.get(k) or it.get(alt.get(k, k)) or "") for k in keys])
    rows, errs = _parse_grid(grid, norm_phone)
    return rows, [{"row": r, "error": m} for r, m in errs]


def _parse_grid(rows, norm_phone):
    if not rows:
        raise ImportError_("الملف فارغ")
    head = None
    for i, r in enumerate(rows[:10]):
        m = {}
        for j, cell in enumerate(r):
            k = _HMAP.get(_norm_header(cell))
            if k and k not in m:
                m[k] = j
        if "mrn" in m and "name" in m:
            head, hi = m, i
            break
    if head is None:
        raise ImportError_("لم أجد سطر العناوين. يلزم عمودا «رقم الملف» و«الاسم» على الأقل (استخدم القالب)")
    missing = [LABELS[k] for k in ("phone",) if k not in head]
    if "national_id" not in head and "birth_date" not in head:
        missing.append("الهوية أو تاريخ الميلاد (أحدهما على الأقل للتحقق من هوية المراجع)")
    if missing:
        raise ImportError_("أعمدة ناقصة: " + "، ".join(missing))
    out, errors, seen = [], [], {}
    for idx, r in enumerate(rows[hi + 1:], start=hi + 2):
        def g(k):
            j = head.get(k)
            return r[j] if j is not None and j < len(r) else ""
        if not any(_text(c) for c in r):
            continue
        errs = []
        mrn = _text(g("mrn"))
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9\-_/.]{0,29}", mrn):
            errs.append("رقم الملف غير صالح")
        name = re.sub(r"\s+", " ", _text(g("name")))
        if not (2 <= len(name) <= 80):
            errs.append("الاسم غير صالح")
        phone = norm_phone(_text(g("phone")))
        if not phone or not phone.startswith("9665"):
            errs.append("رقم الجوال غير صحيح")
        nid = re.sub(r"\D", "", _text(g("national_id")))
        if nid and not re.fullmatch(r"[12]\d{9}", nid):
            errs.append("رقم الهوية/الإقامة غير صحيح")
        bd = _date(g("birth_date")) if "birth_date" in head else ""
        if bd is None:
            errs.append("تاريخ الميلاد غير صالح (استخدم 1990-05-21 أو 21/05/1990)")
        gender = _gender(g("gender")) if "gender" in head else ""
        if gender is None:
            errs.append("الجنس غير مفهوم (ذكر/أنثى)")
        if not errs and not nid and not bd:
            errs.append("يلزم الهوية أو تاريخ الميلاد لهذا المراجع")
        if not errs and mrn.lower() in seen:
            errs.append("رقم الملف مكرر في الملف نفسه (الصف %d)" % seen[mrn.lower()])
        if errs:
            errors.append((idx, "؛ ".join(errs)))
            continue
        seen[mrn.lower()] = idx
        out.append({"mrn": mrn, "name": name, "phone": phone, "national_id": nid or None, "birth_date": bd or None, "gender": gender or None, "row": idx})
    if len(out) + len(errors) > MAX_ROWS:
        raise ImportError_("عدد الصفوف أكبر من %d" % MAX_ROWS)
    return out, errors
