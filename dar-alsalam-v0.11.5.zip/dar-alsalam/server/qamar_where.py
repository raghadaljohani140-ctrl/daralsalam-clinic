"""قمر و«أين الطبيب؟»: يجيب عن سؤال «الدكتور فلان في أي فرع اليوم/غداً/الآن؟ ومتى دوامه؟» من جدول الطبيب الفعلي.

قواعد ثابتة (مثل qamar_slots):
- الفرع والأوقات تُبنى هنا من قاعدة البيانات (ساعات الطبيب بعد الإجازات والساعات الخاصة)، ولا يكتب النموذج اللغوي شيئاً منها.
- لا يُخترع دوام: طبيب بلا ساعات مضبوطة يُقال صراحةً إن جدوله غير متوفر لدينا ويُحال إلى المجمع.
- هذا دوام الطبيب لا توفّر مواعيد؛ المواعيد المتاحة فعلاً تبقى في مسار الحجز.
يعمل بلا نموذج لغوي، فلا تكلفة إضافية عليه."""
import datetime as dt
import sys

import kb as kbmod
import qamar_slots as qs
import scheddb as sd

_WHERE = {"فرع", "الفرع", "فروع", "وين", "اين", "موجود", "موجوده", "متواجد", "متواجده", "يتواجد", "يداوم", "مداوم", "مناوب", "يشتغل", "دوام",
          "دوامه", "دوامها", "اوقات", "ساعات", "متى", "جدول", "جدوله", "ايام", "مكان", "مكانه", "يداومون"}
_NOW = {"الان", "الحين", "حاليا"}
_DAYS_AHEAD = 14                                     # عن أقرب دوام قادم نبحث حتى أسبوعين


def has_cue(message):
    return bool(set(kbmod.normalize(message or "").split()) & _WHERE)


def _windows(db, did, day):
    """{branch_id: [(start, end), ...]} لنوافذ عمل الطبيب في يوم (بعد الإجازات والساعات الخاصة)."""
    out = {}
    for br, s, e, _m in db.sched_windows(did, day):
        out.setdefault(br, []).append((s, e))
    return {b: sorted(v) for b, v in out.items()}


def _times(wins):
    if any(s == 0 and e >= 1440 for s, e in wins):
        return "على مدار 24 ساعة"
    return "، و".join("من %s إلى %s" % (sd.time_ar(s), "منتصف الليل" if e >= 1440 else sd.time_ar(e)) for s, e in wins)


def _bname(kb, bid):
    b = kb.by_id.get(("branches", bid))
    return (b.get("shortName") or b["name"]) if b else ""


def _where_text(kb, per_branch):
    """«في فرع قباء من 9:00 ص إلى 12:30 م، ومن 4:00 م إلى 10:00 م» (وإن تعدد الفرع في اليوم نفسه تُذكر كلها)."""
    return " وفي ".join("%s %s" % (_bname(kb, b) or "فرع", _times(w)) for b, w in sorted(per_branch.items()))


def _next_work(db, did, start_day):
    for i in range(1, _DAYS_AHEAD + 1):
        d = start_day + dt.timedelta(days=i)
        w = _windows(db, did, d)
        if w:
            return d, w
    return None, None


def plan(db, kb, message, history, res):
    """يعيد خطة الرد أو None إن لم يكن السؤال «أين الطبيب/متى دوامه» عن طبيب مسمّى."""
    if res.get("emergency") or not has_cue(message) or qs.has_cue(message):
        return None                                   # طلبات الموعد والحجز لها مسارها (qamar_slots)
    ents = res.get("entities") or {}
    docs = list(ents.get("doctors") or [])
    if not docs:
        m = qs._ctx_entities(kb, history, message)
        docs = list((m or {}).get("doctors") or [])
    docs = [d for d in docs if ("doctors", d) in kb.by_id][:3]
    if not docs:
        return None
    today = sd.riyadh_now().date()
    when = qs.parse_when(message, today)
    toks = set(kbmod.normalize(message).split())
    return {"doctors": docs, "day": when["day"], "now": bool(toks & _NOW) and not when["day"]}


def _one(db, kb, did, pl, now):
    """فقرة واحدة عن طبيب. تعيد (النص، فرع الزر أو None)."""
    doc = kb.by_id[("doctors", did)]
    name = kb.doc_label(doc)
    today = now.date()
    if did not in set(db.sched_doctor_ids()):
        known = [_bname(kb, b) for b in (doc.get("branchIds") or []) if ("branches", b) in kb.by_id]
        extra = " (مسجّل في %s)" % " و".join(known) if known else ""
        return ("%s%s: ما عندي جدول دوام مؤكد له حالياً، فما أقدر أحدد لك فرعه ولا وقته. تواصل مع المجمع وعطوك الدوام." % (name, extra)), None
    day = pl["day"]
    if day:
        w = _windows(db, did, day)
        label = qs._day_label(day, today)
        if w:
            br = next(iter(w)) if len(w) == 1 else None
            return "%s يداوم %s %s." % (name, label, _where_text(kb, w)), br
        nd, nw = _next_work(db, did, day)
        tail = (" وأقرب دوام له %s %s." % (qs._day_label(nd, today), _where_text(kb, nw))) if nd else ""
        return "%s ما عنده دوام %s.%s" % (name, label, tail), None
    # بلا يوم محدد: حالته الآن + دوام اليوم، ثم أقرب دوام إن لم يعد له دوام اليوم
    w = _windows(db, did, today)
    mnow = now.hour * 60 + now.minute
    cur = {b: [x for x in v if x[0] <= mnow < x[1]] for b, v in w.items()}
    cur = {b: v for b, v in cur.items() if v}
    if cur:
        br = next(iter(cur)) if len(cur) == 1 else None
        return "%s موجود الآن في %s، ودوامه اليوم %s." % (name, " و".join(_bname(kb, b) for b in sorted(cur)), _where_text(kb, w)), br
    later = {b: [x for x in v if x[0] > mnow] for b, v in w.items()}
    later = {b: v for b, v in later.items() if v}
    if later:
        br = next(iter(later)) if len(later) == 1 else None
        return "%s ما هو في الدوام الآن، لكن يداوم اليوم %s." % (name, _where_text(kb, later)), br
    nd, nw = _next_work(db, did, today)
    head = "%s انتهى دوامه اليوم." % name if w else "%s ما عنده دوام اليوم." % name
    return (head + (" وأقرب دوام له %s %s." % (qs._day_label(nd, today), _where_text(kb, nw)) if nd else "")), None


def respond(db, kb, pl, out):
    now = sd.riyadh_now()
    texts, acts = [], []
    for did in pl["doctors"]:
        t, br = _one(db, kb, did, pl, now)
        texts.append(t)
        if len(pl["doctors"]) == 1:
            acts.append(dict(kb._book_action(None, did, br), label="احجز موعداً عنده"))
    tail = "\n\nهذا دوام الطبيب، وليس توفّراً للمواعيد. الأوقات المتاحة للحجز تظهر في صفحة الحجز."
    out["text"] = "\n".join(texts) + tail
    out["actions"] = acts or [kb._call_main()]
    out["chips"] = []
    out["intent"] = "doctor_where"


def log_error(e):
    try:
        sys.stderr.write("qamar-where-error: %s: %s\n" % (type(e).__name__, str(e)[:160]))
        sys.stderr.flush()
    except (OSError, ValueError):
        pass
