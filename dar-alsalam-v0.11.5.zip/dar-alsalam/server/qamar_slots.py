"""قمر والمواعيد: يفهم من كلام المراجع «متى» (يوم وفترة أو ساعة) و«مع من» (طبيب أو تخصص أو خدمة أو فرع)، ثم يجلب من نظام
المواعيد المتاحة فعلاً ويبني منها أزراراً تفتح نموذج الحجز معبّأً.

قواعد ثابتة:
- لا يكتب النموذج اللغوي أي وقت أو تاريخ أو توفّر. حين تُعرض مواعيد، الرد كله (النص والأزرار) يُبنى هنا من قاعدة البيانات.
- المراجع هو من يؤكد الحجز بنفسه في التطبيق بعد أن يراجع الموعد ويكتب بياناته. قمر لا ينشئ أي حجز أبداً.
- لا يُعرض شيء إلا لأطباء لهم ساعات عمل مضبوطة؛ غير ذلك يبقى مسار «طلب حجز» كما هو.
يعمل بلا نموذج لغوي أيضاً (وضع «قاعدة المعرفة فقط»)، فلا تكلفة إضافية عليه."""
import datetime as dt
import re
import sys

import kb as kbmod
import scheddb as sd

# ---------------------------------------------------------------- فهم «متى»
# النص يُطبَّع أولاً (kbmod.normalize): الهمزات والتشكيل والتاء المربوطة تُوحَّد، وعلامات الترقيم تصير فراغات («5:30» ← «5 30»)
_WEEKDAY = {"احد": 6, "اثنين": 0, "اتنين": 0, "ثلاثاء": 1, "ثلاثا": 1, "تلات": 1, "اربعاء": 2, "اربعا": 2, "خميس": 3, "جمعه": 4, "سبت": 5}  # weekday() في بايثون
_AM = {"صباح", "صباحا", "الصباح", "الصبح", "صبح", "الفجر", "فجرا"}
_EVE = {"مساء", "مساءا", "المساء", "المسا", "مسا"}
_ASR = {"العصر", "عصر", "عصرا"}
_NIGHT = {"المغرب", "مغرب", "الليل", "ليل", "ليلا", "الليله", "العشاء", "عشاء"}
_NOON_PM = {"ظهرا"}
# الفترة ← (من، إلى) بالدقائق: am صباحاً · asr العصر · eve المساء · night الليل/المغرب/العشاء · pm بعد الظهر
_RANGES = {"am": (0, 720), "pm": (720, 1440), "asr": (900, 1080), "eve": (960, 1440), "night": (1080, 1440)}
_GREET_NEXT = {"الخير", "النور"}                      # «صباح الخير» تحية لا فترة
_CUES = {"موعد", "مواعيد", "موعدي", "احجز", "احجزلي", "احجزني", "حجز", "كشف", "اراجع", "مراجعه", "زياره", "ازور", "اشوف", "اقابل"}
_OFFER_INTENTS = {None, "unknown", "booking", "doctor", "doctors", "route", "which_clinic", "specialties", "service", "services"}
_AT_HOUR = re.compile(r"\bالساعه\s+(\d{1,2})(?:\s+(\d{2}))?(?:\s+(صباحا|مساء|ظهرا|عصرا|ليلا))?\b")
_AT_SUFFIX = re.compile(r"\b(\d{1,2})(?:\s+(\d{2}))?\s+(صباحا|مساء|ظهرا|عصرا|ليلا|ص|م)\b")
_NEAR_MIN = 90                                         # «الساعة 5» ← مواعيد ضمن ساعة ونصف من هذا الوقت
_NO_SLOTS = "لا توجد مواعيد متاحة حالياً في الأيام القادمة. تقدر ترسل طلب حجز ويتواصل معك المجمع."


def _minutes_of(h, mi, word):
    """«5» + «مساء» ← 1020. دون كلمة: ساعات الدوام المعتادة (9–11 صباحاً، 1–8 مساءً). غير ذلك None."""
    mi = int(mi or 0)
    if h > 24 or mi > 59:
        return None
    if h >= 13:
        return None if h == 24 and mi else h * 60 + mi
    if word in ("مساء", "م", "عصرا"):
        h = h % 12 + 12
    elif word == "ليلا":
        h = 0 if h == 12 else h % 12 + 12
    elif word in ("صباحا", "ص"):
        h = h % 12
    elif word == "ظهرا":
        h = 12 if h == 12 else h % 12 + 12
    elif 9 <= h <= 11:
        pass
    elif 1 <= h <= 8:
        h += 12
    else:
        return None
    return h * 60 + mi


def parse_when(message, today):
    """يعيد {'day': date|None, 'period': 'am'|'pm'|None, 'at': دقائق|None}. لا نخمّن تاريخاً غير مذكور."""
    norm = kbmod.normalize(message or "")
    toks = norm.split()
    day, period, at = None, None, None
    for i, t in enumerate(toks):
        nxt = toks[i + 1] if i + 1 < len(toks) else ""
        prv = toks[i - 1] if i else ""
        if t in ("بكره", "بكرا", "غدا", "غد"):
            day = today + dt.timedelta(days=2 if prv == "بعد" else 1)
        elif t == "اليوم":
            day = day or today
        elif t == "الليله":
            day = day or today
        else:
            bare = t[2:] if t.startswith("ال") else t
            if bare in _WEEKDAY and (t.startswith("ال") or prv == "يوم"):
                ahead = (_WEEKDAY[bare] - today.weekday()) % 7 or 7     # أقرب قادم، فلا نعيد «اليوم» نفسه
                day = today + dt.timedelta(days=ahead)
        if nxt in _GREET_NEXT:
            continue
        if t in _AM:
            period = period or "am"
        elif t in _EVE:
            period = period or "eve"
        elif t in _ASR:
            period = period or "asr"
        elif t in _NIGHT:
            period = period or "night"
        elif t in _NOON_PM or (t == "الظهر" and prv == "بعد"):
            period = period or "pm"
    for m in list(_AT_HOUR.finditer(norm)) + list(_AT_SUFFIX.finditer(norm)):
        at = _minutes_of(int(m.group(1)), m.group(2), m.group(3)) if at is None else at
    return {"day": day, "period": period, "at": at}


def has_cue(message):
    return bool(set(kbmod.normalize(message or "").split()) & _CUES)


# ---------------------------------------------------------------- اختيار الأطباء
def _ctx_entities(kb, history, message):
    """إن لم يذكر المراجع تخصصاً أو طبيباً في رسالته («بكرة الصبح»)، نأخذه من آخر الرسائل."""
    skipped = False
    for m in reversed((history or [])[-6:]):
        content = str(m.get("content", ""))
        if not skipped and m.get("role") == "user" and content.strip() == (message or "").strip():
            skipped = True
            continue
        ents = kb.mentions(content)
        if ents["doctors"] or ents["specialties"] or ents["services"]:
            return ents
    return None


def plan(db, kb, message, history, res):
    """يقرر هل نعرض مواعيد، ولمن. يعيد None إن لم يكن الطلب طلب موعد أو لم يوجد طبيب مجدول يناسبه (فيبقى الرد كما هو)."""
    intent = res.get("intent")
    if res.get("emergency"):
        return None
    sched = set(db.sched_doctor_ids())
    if not sched:
        return None
    today = sd.riyadh_now().date()
    when = parse_when(message, today)
    if intent not in _OFFER_INTENTS and not (intent == "hours" and when["at"] is not None and has_cue(message)):
        return None
    explicit = intent == "booking" or has_cue(message)
    if not (explicit or when["day"] or when["period"]):
        return None
    ents = res.get("entities") or {}
    docs, specs = list(ents.get("doctors") or []), list(ents.get("specialties") or [])[:1]
    svcs, brs = list(ents.get("services") or []), list(ents.get("branches") or [])
    if not (docs or specs or svcs):
        if not (explicit or intent in (None, "unknown")):
            return None                                 # «وش خدماتكم اليوم؟» ليست طلب موعد
        m = _ctx_entities(kb, history, message)
        if not m:
            if not explicit:
                return None
            have = [sp for sp in kb.specs if any(d.get("active", True) and d["id"] in sched and sp["id"] in (d.get("specialtyIds") or []) for d in kb.doctors)]
            return {"ask": True, "specs": [sp["id"] for sp in have[:6]], "intent": intent} if have else None
        docs, specs, svcs = list(m["doctors"]), list(m["specialties"])[:1], list(m["services"])
        brs = brs or list(m.get("branches") or [])[:1]
    pool = [d for d in kb.doctors if d.get("active", True) and d["id"] in sched]
    if docs:
        cands = [d for d in pool if d["id"] in docs]
    elif specs:
        cands = [d for d in pool if specs[0] in (d.get("specialtyIds") or [])]
    else:
        cands = [d for d in pool if svcs[0] in (d.get("serviceIds") or [])]
    if not cands:
        return None
    cands.sort(key=lambda d: d.get("sort", 0))
    return {"doctors": [d["id"] for d in cands[:4]], "branch": brs[0] if len(brs) == 1 and ("branches", brs[0]) in kb.by_id else None,
            "when": when, "spec": specs[0] if specs else None, "svc": svcs[0] if svcs and not specs and not docs else None,
            "named": bool(docs), "intent": intent}


# ---------------------------------------------------------------- جلب المواعيد
def _spread(slots, n):
    """موزّعة على اليوم لا العشرين دقيقة الأولى فقط."""
    if len(slots) <= n:
        return list(slots)
    if n == 1:
        return [slots[0]]
    return [slots[i] for i in sorted({round(i * (len(slots) - 1) / (n - 1)) for i in range(n)})]


def _day_label(day, today):
    delta = (day - today).days
    if delta == 0:
        return "اليوم"
    if delta == 1:
        return "غداً"
    lbl = "%s %d" % (sd.AR_WEEKDAYS[sd.weekday_of(day)], day.day)
    return lbl if day.month == today.month else lbl + " " + sd.AR_MONTHS[day.month - 1]


def offers(db, kb, pl, limit=4):
    """المواعيد المتاحة فعلاً للخطة: {'actions': [...], 'shifted': bool, 'count': n}.
    إن لم يوجد ما يطابق اليوم/الفترة/الساعة المطلوبة نعرض أقرب المتاح ونقول ذلك صراحة (shifted)."""
    pol = db.sched_policy()
    now = sd.riyadh_now()
    today = now.date()
    when = pl["when"]
    want = when["day"].isoformat() if when["day"] else None
    at, period = when.get("at"), when["period"]
    bids = {b["id"] for b in kb.branches}
    per_doc = []
    for did in pl["doctors"]:
        days = db.sched_days(did, pl["branch"], pol, now)
        per_doc.append((did, [(d["day"], s) for d in days for s in d["slots"] if s["branchId"] in bids]))

    def time_ok(s):
        m = sd.parse_hhmm(s["start"])
        if at is not None:
            return abs(m - at) <= _NEAR_MIN
        return period is None or _RANGES[period][0] <= m < _RANGES[period][1]

    def pick(flt):
        out = []
        for did, pool in per_doc:
            m = [(dd, s) for dd, s in pool if flt(dd, s)]
            if m:
                out.append((did, [x for x in m if x[0] == m[0][0]]))      # أول يوم يطابق
        return out

    steps = [(lambda dd, s: (not want or dd == want) and time_ok(s), False)]
    if want or period or at is not None:
        if want and (period or at is not None):
            steps.append((lambda dd, s: dd == want, True))
        steps.append((lambda dd, s: (not want or dd >= want) and time_ok(s), True))
        steps.append((lambda dd, s: True, True))
    chosen, shifted = [], False
    for flt, sh in steps:
        chosen = pick(flt)
        if chosen:
            shifted = sh
            break
    per = max(1, limit // max(1, len(chosen)))
    multi = len(chosen) > 1
    rows = []
    for did, ms in chosen:
        if at is not None and not shifted:
            ms = sorted(ms, key=lambda x: abs(sd.parse_hhmm(x[1]["start"]) - at))[:per]
            ms.sort(key=lambda x: x[1]["start"])
        else:
            ms = _spread(ms, per)
        for dd, s in ms:
            rows.append((dd, s, did))
    rows.sort(key=lambda r: (r[0], r[1]["start"], r[2]))
    rows = rows[:limit]
    many_br = len({s["branchId"] for _, s, _ in rows}) > 1
    acts = []
    for dd, s, did in rows:
        doc = kb.by_id[("doctors", did)]
        parts = [_day_label(dt.date.fromisoformat(dd), today), sd.time_ar(sd.parse_hhmm(s["start"]))]
        if multi:
            parts.append(kb.doc_label(doc))
        if many_br:
            b = kb.by_id.get(("branches", s["branchId"]))
            parts.append((b.get("shortName") or b["name"]) if b else "")
        a = {"type": "slot", "doctorId": did, "branchId": s["branchId"], "day": dd, "start": s["start"], "label": " · ".join(p for p in parts if p)}
        if pl["spec"] and pl["spec"] in (doc.get("specialtyIds") or []):
            a["specialtyId"] = pl["spec"]
        acts.append(a)
    return {"actions": acts, "shifted": shifted, "count": len(acts)}


# ---------------------------------------------------------------- النص (يُبنى هنا لا من النموذج)
def _when_phrase(when, today):
    bits = []
    if when["day"]:
        delta = (when["day"] - today).days
        bits.append("اليوم" if delta == 0 else "غداً" if delta == 1 else "يوم " + sd.AR_WEEKDAYS[sd.weekday_of(when["day"])])
    if when.get("at") is not None:
        bits.append("حوالي " + sd.time_ar(when["at"]))
    elif when["period"]:
        bits.append({"am": "صباحاً", "asr": "عصراً"}.get(when["period"], "مساءً"))
    return (" " + " ".join(bits)) if bits else ""


def _target(kb, pl):
    if pl["named"] and len(pl["doctors"]) == 1:
        return "مع " + kb.doc_label(kb.by_id[("doctors", pl["doctors"][0])])
    if pl["spec"]:
        return "في عيادة " + kb.by_id[("specialties", pl["spec"])]["name"]
    if pl["svc"]:
        return "لخدمة " + kb.by_id[("services", pl["svc"])]["name"]
    return ""


def tail(pl, off, today):
    """الجملة التي تصف الأزرار. الأزرار تحمل الأوقات، والجملة لا تذكر وقتاً من عندها."""
    ph = _when_phrase(pl["when"], today)
    done = "اختر وقتاً وأكمل الحجز، ويتأكد موعدك عند الضغط على «تأكيد الحجز»."
    if off["shifted"]:
        return "ما وجدت مواعيد متاحة%s، وهذه أقرب المواعيد المتاحة فعلياً. %s" % (ph, done)
    return "هذه أقرب المواعيد المتاحة%s فعلياً في النظام. %s" % (ph, done)


def _strip_ask(text):
    """قوالب المحرك تنتهي بسؤال «تبي أرتّب لك طلب حجز؟»؛ حين نعرض المواعيد الفعلية لا معنى له."""
    t = (text or "").rstrip()
    m = re.search(r"[^.؟!\n]*حجز[^.؟!\n]*؟\s*$", t)
    return t[:m.start()].rstrip() if m else t


def apply(out, kb, pl, off):
    """يضيف المواعيد لرد قمر (يعدّل out)."""
    today = sd.riyadh_now().date()
    if off["count"]:
        sentence = tail(pl, off, today)
        if pl["intent"] in ("booking", "unknown", "hours", None):
            tgt = _target(kb, pl)
            out["text"] = ("تمام، أرتّب لك الحجز %s. " % tgt if tgt else "تمام. ") + sentence
        else:
            out["text"] = (_strip_ask(out["text"]) + "\n\n" + sentence).strip()
        rest = [dict(a, label="عرض كل المواعيد") if a.get("type") == "book" else a for a in out["actions"]]
        if not any(a.get("type") == "book" for a in rest):          # رابط صفحة الحجز الكاملة دائماً بجانب المواعيد المقترحة
            full = {"type": "book", "label": "عرض كل المواعيد"}
            if pl["spec"]:
                full["specialtyId"] = pl["spec"]
            if pl["named"] and len(pl["doctors"]) == 1:
                full["doctorId"] = pl["doctors"][0]
            rest.insert(0, full)
        out["actions"] = off["actions"] + rest
        out["chips"] = []
    elif pl["intent"] != "booking":
        out["text"] = (_strip_ask(out["text"]) + "\n\n" + _NO_SLOTS).strip()


def _ask(kb, pl, out):
    out["text"] = "تمام، أي عيادة تبي تحجز فيها؟ اختر من الأزرار أو اكتب التخصص أو اسم الدكتور، وأعرض لك المواعيد المتاحة فعلياً."
    out["chips"] = ["موعد " + kb.by_id[("specialties", i)]["name"] for i in pl["specs"]]


def respond(db, kb, pl, out):
    """نقطة الدخول الوحيدة من قمر: إما سؤال «أي عيادة؟» بأزرار، وإما المواعيد الفعلية."""
    if pl.get("ask"):
        _ask(kb, pl, out)
    else:
        apply(out, kb, pl, offers(db, kb, pl))


def log_error(e):
    try:
        sys.stderr.write("qamar-slots-error: %s: %s\n" % (type(e).__name__, str(e)[:160]))
        sys.stderr.flush()
    except (OSError, ValueError):
        pass
