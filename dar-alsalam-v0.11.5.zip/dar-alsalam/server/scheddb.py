"""المواعيد: ساعات عمل كل طبيب (أسبوعية + استثناءات بتاريخ) وحجز موعد محدّد داخل جدول الحجوزات نفسه.

الحجز بموعد = صف في `bookings` له slot_start (دقائق من منتصف الليل بتوقيت الرياض) وslot_min.
الحجوزات القديمة (طلبات بلا موعد) لا تتغير، والطبيب الذي بلا ساعات عمل يبقى على نظام «طلب حجز».
منع الحجز المزدوج على مستويين: فهرس فريد جزئي على (الطبيب، اليوم، بداية الموعد) + فحص التداخل داخل المعاملة نفسها."""
import datetime as dt
import json
import re
import secrets
import time

RIYADH = dt.timezone(dt.timedelta(hours=3))
SLOT_CHOICES = (5, 10, 15, 20, 30, 45, 60)
AR_WEEKDAYS = ("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
AR_MONTHS = ("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
ACTIVE_STATUS = "('new','contacted','confirmed')"
POLICY_DEFAULT = {"horizonDays": 14, "minNoticeMin": 60, "cancelBeforeH": 2, "maxActive": 3, "requireCheckin": False,
                  "prepay": {"enabled": False, "amount": 0, "holdMin": 15}}


def riyadh_now():
    return dt.datetime.now(RIYADH)


def utc_iso(offset_min=0):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + offset_min * 60))


def weekday_of(d):
    """0 = الأحد … 6 = السبت (أسبوع السعودية)."""
    return (d.weekday() + 1) % 7


def hhmm(m):
    return "%02d:%02d" % (m // 60, m % 60)


def parse_hhmm(s):
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", str(s or "").strip())
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    return h * 60 + mi if h <= 24 and mi < 60 and (h * 60 + mi) <= 24 * 60 else None


def parse_end(s):
    """وقت نهاية فترة العمل. «23:59» تعني حتى منتصف الليل (24:00)، لأن حقل الوقت في المتصفح لا يقبل 24:00."""
    m = parse_hhmm(s)
    return 24 * 60 if m == 24 * 60 - 1 else m


def time_ar(m):
    h, mi = divmod(int(m), 60)
    return "%d:%02d %s" % (h % 12 or 12, mi, "ص" if h < 12 else "م")


def date_ar(d):
    return "%s %d %s %d" % (AR_WEEKDAYS[weekday_of(d)], d.day, AR_MONTHS[d.month - 1], d.year)


def slot_dt(day, start_min):
    """لحظة بداية الموعد بتوقيت الرياض (day: date)."""
    return dt.datetime(day.year, day.month, day.day, tzinfo=RIYADH) + dt.timedelta(minutes=int(start_min))


def norm_ar(s):
    s = re.sub(r"[ً-ٟـ]", "", str(s or ""))
    s = s.translate(str.maketrans("أإآىة", "ااايه"))
    return re.sub(r"\s+", " ", s).strip().lower()


class SchedDB:
    """يُخلط في DB (يستعمل conn() وtx() وget_kv() وset_kv() وget_booking() وغيرها منها)."""

    # ------------------------------------------------------------------ السياسة
    def sched_policy(self):
        st = self.get_kv("scheduling", {}) or {}
        p = {k: (dict(v) if isinstance(v, dict) else v) for k, v in POLICY_DEFAULT.items()}
        for k, lo, hi in (("horizonDays", 1, 60), ("minNoticeMin", 0, 1440), ("cancelBeforeH", 0, 72), ("maxActive", 1, 20)):
            try:
                p[k] = min(hi, max(lo, int(st.get(k, p[k]))))
            except (TypeError, ValueError):
                pass
        p["requireCheckin"] = bool(st.get("requireCheckin", False))
        pp = st.get("prepay") or {}
        try:
            amount, hold = int(pp.get("amount", 0) or 0), int(pp.get("holdMin", 15) or 15)
        except (TypeError, ValueError):
            amount, hold = 0, 15
        p["prepay"] = {"enabled": bool(pp.get("enabled", False)), "amount": min(100000, max(0, amount)), "holdMin": min(120, max(5, hold))}
        return p

    def sched_policy_set(self, p):
        self.set_kv("scheduling", p)

    # ------------------------------------------------------------------ ساعات العمل
    def sched_get(self, doctor_id):
        c = self.conn()
        rows = [dict(r) for r in c.execute("SELECT * FROM schedules WHERE doctor_id=? ORDER BY weekday, branch_id, start_min", (doctor_id,))]
        days = [dict(r) for r in c.execute("SELECT * FROM schedule_days WHERE doctor_id=? ORDER BY day, branch_id, start_min", (doctor_id,))]
        return rows, days

    def sched_replace(self, doctor_id, rows, days):
        """يستبدل ساعات الطبيب كلها (الأسبوعية والاستثناءات) في معاملة واحدة. المواعيد المحجوزة لا تُمسّ."""
        self.sched_replace_many([(doctor_id, rows, days)])

    def sched_replace_many(self, items):
        """يستبدل ساعات عدة أطباء في معاملة واحدة: تنجح كلها أو لا يتغير شيء. items: [(doctor_id, rows, days)]."""
        t = utc_iso()
        with self.tx() as c:
            for doctor_id, rows, days in items:
                c.execute("DELETE FROM schedules WHERE doctor_id=?", (doctor_id,))
                c.execute("DELETE FROM schedule_days WHERE doctor_id=?", (doctor_id,))
                for r in rows:
                    c.execute("INSERT INTO schedules(doctor_id,branch_id,weekday,start_min,end_min,slot_min,updated_at) VALUES(?,?,?,?,?,?,?)",
                              (doctor_id, r["branch_id"], r["weekday"], r["start_min"], r["end_min"], r["slot_min"], t))
                for d in days:
                    c.execute("INSERT INTO schedule_days(doctor_id,branch_id,day,kind,start_min,end_min,slot_min,note,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                              (doctor_id, d["branch_id"], d["day"], d["kind"], d.get("start_min"), d.get("end_min"), d.get("slot_min"), d.get("note", ""), t))
        self._bump()                      # قائمة «الأطباء القابلون للحجز بموعد» جزء من البيانات العامة

    def sched_doctor_ids(self):
        return sorted(r["doctor_id"] for r in self.conn().execute("SELECT DISTINCT doctor_id FROM schedules"))

    def sched_public_hours(self, doctor_ids):
        """الساعات الأسبوعية المعتادة للعرض العلني (ليست سراً): {doctor_id: [[branch_id, weekday, start_min, end_min], ...]}.
        لا تشمل الإجازات والاستثناءات (يعرضها الحجز نفسه وقمر)، ولا مدة الموعد."""
        want, out = set(doctor_ids), {}
        for r in self.conn().execute("SELECT doctor_id, branch_id, weekday, start_min, end_min FROM schedules ORDER BY doctor_id, branch_id, weekday, start_min"):
            if r["doctor_id"] in want:
                out.setdefault(r["doctor_id"], []).append([r["branch_id"], r["weekday"], r["start_min"], r["end_min"]])
        return out

    def sched_summary(self):
        out = {}
        for r in self.conn().execute("SELECT doctor_id, branch_id, COUNT(*) n FROM schedules GROUP BY doctor_id, branch_id"):
            out.setdefault(r["doctor_id"], {"rows": 0, "branches": []})
            out[r["doctor_id"]]["rows"] += r["n"]
            out[r["doctor_id"]]["branches"].append(r["branch_id"])
        return out

    def sched_outside(self, doctor_id, limit=50):
        """مواعيد قادمة محجوزة لم تعد داخل ساعات الطبيب بعد تعديل الجدول. لا تُلغى تلقائياً (القرار للإدارة)؛ تُعرض لتتواصل مع أصحابها."""
        today = riyadh_now().date().isoformat()
        out = []
        for r in self.conn().execute("SELECT id,date,branch_id,slot_start,slot_min FROM bookings WHERE doctor_id=? AND slot_start IS NOT NULL AND date>=? AND status IN "
                                     + ACTIVE_STATUS + " ORDER BY date, slot_start", (doctor_id, today)):
            day = dt.date.fromisoformat(r["date"])
            if not any(s <= r["slot_start"] and r["slot_start"] + r["slot_min"] <= e for _br, s, e, _m in self.sched_windows(doctor_id, day, r["branch_id"])):
                out.append({"id": r["id"], "day": r["date"], "time": hhmm(r["slot_start"])})
                if len(out) >= limit:
                    break
        return out

    # ------------------------------------------------------------------ نوافذ العمل والمواعيد المتاحة
    def sched_windows(self, doctor_id, day, branch_id=None):
        """نوافذ عمل الطبيب في يوم معيّن بعد الاستثناءات: [(branch, start, end, slot)].
        القاعدة: «ساعات خاصة» لفرع في تاريخ تستبدل ساعاته؛ و«إجازة» (لفرع أو لكل الفروع) تلغي الساعات الأسبوعية لذلك التاريخ."""
        c = self.conn()
        base = {}
        for r in c.execute("SELECT branch_id,start_min,end_min,slot_min FROM schedules WHERE doctor_id=? AND weekday=? ORDER BY start_min", (doctor_id, weekday_of(day))):
            base.setdefault(r["branch_id"], []).append((r["start_min"], r["end_min"], r["slot_min"]))
        hours, off_all, off_br = {}, False, set()
        for r in c.execute("SELECT branch_id,kind,start_min,end_min,slot_min FROM schedule_days WHERE doctor_id=? AND day=? ORDER BY start_min", (doctor_id, day.isoformat())):
            if r["kind"] == "hours":
                hours.setdefault(r["branch_id"], []).append((r["start_min"], r["end_min"], r["slot_min"] or 20))
            elif r["branch_id"] == "":
                off_all = True
            else:
                off_br.add(r["branch_id"])
        out = {br: lst for br, lst in base.items() if not (br in hours or off_all or br in off_br)}
        out.update(hours)
        return [(br, s, e, m) for br, lst in sorted(out.items()) for (s, e, m) in lst if not branch_id or br == branch_id]

    def sched_free(self, doctor_id, day, branch_id, policy, now_dt=None):
        """المواعيد المتاحة فعلاً ليوم واحد: [(branch, start_min, slot_min)] — بلا المحجوز ولا ما فات وقته أو ضاق عن مهلة الحجز."""
        now_dt = now_dt or riyadh_now()
        today = now_dt.date()
        if day < today or day > today + dt.timedelta(days=policy["horizonDays"]):
            return []
        booked = [(r["slot_start"], r["slot_min"]) for r in self.conn().execute(
            "SELECT slot_start, slot_min FROM bookings WHERE doctor_id=? AND date=? AND slot_start IS NOT NULL AND status IN " + ACTIVE_STATUS, (doctor_id, day.isoformat()))]
        notice = dt.timedelta(minutes=policy["minNoticeMin"])
        out = []
        for br, s, e, m in self.sched_windows(doctor_id, day, branch_id):
            t = s
            while t + m <= e:
                if slot_dt(day, t) - now_dt >= notice and not any(t < bs + bm and bs < t + m for bs, bm in booked):
                    out.append((br, t, m))
                t += m
        return out

    def sched_days(self, doctor_id, branch_id, policy, now_dt=None):
        """كل أيام المهلة (اليوم … اليوم + horizonDays) مع مواعيدها المتاحة، لعرض شريط التواريخ في التطبيق."""
        now_dt = now_dt or riyadh_now()
        self.sched_release_holds()
        out = []
        for i in range(policy["horizonDays"] + 1):
            d = now_dt.date() + dt.timedelta(days=i)
            sl = self.sched_free(doctor_id, d, branch_id, policy, now_dt)
            out.append({"day": d.isoformat(), "weekday": weekday_of(d), "slots": [{"start": hhmm(t), "min": m, "branchId": br} for br, t, m in sl]})
        return out

    # ------------------------------------------------------------------ الحجز بموعد
    def sched_release_holds(self):
        """موعد ينتظر الدفع وانتهت مهلته يُفرَج عنه (يُلغى) فيعود متاحاً لغيره. آمن للاستدعاء المتكرر."""
        t = utc_iso()
        if not self.conn().execute("SELECT 1 FROM bookings WHERE pay_status='pending' AND hold_until<? LIMIT 1", (t,)).fetchone():
            return 0
        with self.tx() as c:
            return c.execute("UPDATE bookings SET status='cancelled', pay_status='expired', updated_at=? WHERE pay_status='pending' AND hold_until<?", (t, t)).rowcount

    def sched_book(self, rec, doctor_id, branch_id, day, start_min, text, policy, hold_min=0, amount=0):
        """ينشئ موعداً مؤكداً (أو محجوزاً بانتظار الدفع) داخل معاملة واحدة تعيد فحص كل شيء:
        ValueError: slot_invalid (ليس موعداً في ساعات الطبيب أو خارج المهلة) · slot_taken · too_many_active · duplicate_day."""
        bid = self.new_booking_id()
        now_dt = riyadh_now()
        t = utc_iso()
        with self.tx() as c:
            c.execute("UPDATE bookings SET status='cancelled', pay_status='expired', updated_at=? WHERE pay_status='pending' AND hold_until<?", (t, t))
            slot = next((m for br, s, e, m in self.sched_windows(doctor_id, day, branch_id) if s <= start_min and start_min + m <= e and (start_min - s) % m == 0), None)
            if slot is None or day < now_dt.date() or day > now_dt.date() + dt.timedelta(days=policy["horizonDays"]) \
                    or slot_dt(day, start_min) - now_dt < dt.timedelta(minutes=policy["minNoticeMin"]):
                raise ValueError("slot_invalid")
            for r in c.execute("SELECT slot_start, slot_min FROM bookings WHERE doctor_id=? AND date=? AND slot_start IS NOT NULL AND status IN " + ACTIVE_STATUS, (doctor_id, day.isoformat())):
                if start_min < r["slot_start"] + r["slot_min"] and r["slot_start"] < start_min + slot:
                    raise ValueError("slot_taken")
            if c.execute("SELECT COUNT(*) FROM bookings WHERE phone=? AND slot_start IS NOT NULL AND date>=? AND status IN " + ACTIVE_STATUS,
                         (rec["phone"], now_dt.date().isoformat())).fetchone()[0] >= policy["maxActive"]:
                raise ValueError("too_many_active")
            if c.execute("SELECT 1 FROM bookings WHERE phone=? AND doctor_id=? AND date=? AND slot_start IS NOT NULL AND status IN " + ACTIVE_STATUS,
                         (rec["phone"], doctor_id, day.isoformat())).fetchone():
                raise ValueError("duplicate_day")
            held = hold_min > 0
            c.execute("INSERT INTO bookings(id,created_at,updated_at,status,name,phone,device_id,specialty_id,doctor_id,branch_id,service_id,date,period,note,source,"
                      "appointment_text,slot_start,slot_min,pay_status,pay_amount,hold_until,patient_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (bid, t, t, "new" if held else "confirmed", rec["name"], rec["phone"], rec["device_id"], rec.get("specialty_id"), doctor_id, branch_id, rec.get("service_id"),
                       day.isoformat(), "morning" if start_min < 720 else "evening", rec.get("note", ""), rec.get("source", "app"), "" if held else text,
                       start_min, slot, "pending" if held else None, int(amount) if held else None, utc_iso(hold_min) if held else None, rec.get("patient_id")))
        return self.get_booking(bid)

    def sched_pay(self, bid, ref, text):
        """تأكيد دفع موعد محجوز مؤقتاً. ValueError: state (ليس بانتظار دفع) · expired (انتهت المهلة وأُفرج عن الموعد)."""
        self.sched_release_holds()
        with self.tx() as c:
            b = c.execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
            if not b:
                raise ValueError("state")
            if b["pay_status"] == "expired":
                raise ValueError("expired")
            if b["pay_status"] != "pending" or b["status"] not in ("new", "contacted"):
                raise ValueError("state")
            c.execute("UPDATE bookings SET status='confirmed', pay_status='paid', pay_ref=?, appointment_text=?, hold_until=NULL, updated_at=? WHERE id=?", (ref, text, utc_iso(), bid))
        return self.get_booking(bid)

    # ------------------------------------------------------------------ للطبيب والاستقبال
    def appt_list(self, doctor_id, day, branch_id=None):
        """مواعيد يوم الطبيب المؤكدة التي لم تُفتح لها زيارة بعد، مرتبة بالوقت."""
        sql = ("SELECT b.* FROM bookings b WHERE b.doctor_id=? AND b.date=? AND b.slot_start IS NOT NULL AND b.status='confirmed' "
               "AND NOT EXISTS(SELECT 1 FROM visits v WHERE v.booking_id=b.id)")
        args = [doctor_id, day]
        if branch_id:
            sql += " AND b.branch_id=?"
            args.append(branch_id)
        return [dict(r) for r in self.conn().execute(sql + " ORDER BY b.slot_start, b.created_at", args)]

    def appt_times(self, bids):
        bids = [b for b in bids if b]
        if not bids:
            return {}
        q = ",".join("?" * len(bids))
        return {r["id"]: {"start": r["slot_start"], "min": r["slot_min"]} for r in self.conn().execute(
            "SELECT id, slot_start, slot_min FROM bookings WHERE slot_start IS NOT NULL AND id IN (" + q + ")", bids)}

    def _appt_record(self, c, b):
        """سجل المراجع لموعد: الملف المرتبط بحسابه، وإلا ملف وحيد بالجوال والاسم نفسيهما، وإلا ملف مؤقت جديد يكمله الاستقبال."""
        want = norm_ar(b["name"])
        mrns = [r["mrn"] for r in c.execute("SELECT l.mrn FROM record_links l JOIN patients p ON p.id=l.patient_id WHERE p.phone=?", (b["phone"],))]
        cands = [dict(r) for m in mrns for r in c.execute("SELECT * FROM records WHERE mrn=? COLLATE NOCASE", (m,))]
        pick = [x for x in cands if norm_ar(x["name"]) == want] or (cands if len(cands) == 1 else [])
        if not pick:
            pick = [dict(r) for r in c.execute("SELECT * FROM records WHERE phone=?", (b["phone"],)) if norm_ar(r["name"]) == want]
        if len(pick) == 1:
            return pick[0], False
        r = c.execute("SELECT value FROM kv WHERE key='mrn_seq'").fetchone()
        n = (json.loads(r["value"]) if r else 100000) + 1
        while c.execute("SELECT 1 FROM records WHERE mrn=? COLLATE NOCASE", ("DS-%d" % n,)).fetchone():
            n += 1
        c.execute("INSERT INTO kv(key,value,updated_at) VALUES('mrn_seq',?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at", (json.dumps(n), utc_iso()))
        t = utc_iso()
        c.execute("INSERT INTO records(mrn,name,phone,national_id,birth_date,gender,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                  ("DS-%d" % n, b["name"], b["phone"], None, None, None, "appointment", t, t))
        return {"mrn": "DS-%d" % n, "name": b["name"]}, True

    def appt_call(self, bid, doctor_id, by, today_iso, require_checkin=False):
        """الطبيب يستدعي مراجعاً بموعد: تُنشأ زيارته (وملف مؤقت إن لزم) ويدخل «عند الطبيب» في معاملة واحدة.
        يعيد (visit, provisional). ValueError: not_found · state · not_today · busy · checkin_required · duplicate:<vid>."""
        t = utc_iso()
        with self.tx() as c:
            b = c.execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
            if not b or b["doctor_id"] != doctor_id or b["slot_start"] is None:
                raise ValueError("not_found")
            if b["status"] != "confirmed":
                raise ValueError("state")
            if b["date"] != today_iso:
                raise ValueError("not_today")
            busy = c.execute("SELECT 1 FROM visits WHERE doctor_id=? AND day=? AND status='with_doctor' LIMIT 1", (doctor_id, today_iso)).fetchone()
            v = c.execute("SELECT * FROM visits WHERE booking_id=? ORDER BY arrived_at DESC LIMIT 1", (bid,)).fetchone()
            provisional = False
            if v:                                    # الاستقبال سجّل وصوله قبل أن يستدعيه الطبيب
                if v["status"] not in ("waiting", "ready", "with_doctor"):
                    raise ValueError("state")
                vid = v["id"]
                if v["status"] != "with_doctor":
                    if busy:
                        raise ValueError("busy")
                    c.execute("UPDATE visits SET status='with_doctor', called_at=COALESCE(NULLIF(called_at,''),?), updated_at=?, updated_by=? WHERE id=?", (t, t, by, vid))
            else:
                if require_checkin:
                    raise ValueError("checkin_required")
                if busy:
                    raise ValueError("busy")
                rec, provisional = self._appt_record(c, b)
                vid = self._visit_insert(c, today_iso, b["branch_id"], doctor_id, rec, bid, "موعد " + time_ar(b["slot_start"]), by, status="with_doctor", called=t)
            vrow = c.execute("SELECT * FROM visits WHERE id=?", (vid,)).fetchone()
            self._enc_insert(c, vid, vrow["mrn"], doctor_id, vrow["reason"], by)
        return self.visit_get(vid), provisional
