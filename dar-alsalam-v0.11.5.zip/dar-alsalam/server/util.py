"""أدوات مشتركة صغيرة (كلمات المرور، الجوال، تاريخ الرياض) يستعملها الخادم وواجهات الموظفين."""
import base64
import datetime as dt
import hashlib
import hmac
import re
import secrets

AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def hash_password(pw, salt=None, iters=200_000):
    salt = salt or secrets.token_bytes(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, iters)
    return {"salt": salt.hex(), "hash": h.hex(), "iter": iters}


def check_password(pw, rec):
    if not rec:
        return False
    h = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(rec["salt"]), rec["iter"])
    return hmac.compare_digest(h.hex(), rec["hash"])


def norm_phone(v):
    s = re.sub(r"[\s\-().]", "", str(v or "").translate(AR_DIGITS))
    intl = s.startswith("+") or s.startswith("00")
    d = re.sub(r"\D", "", s)
    if d.startswith("00"):
        d = d[2:]
    if d.startswith("966"):
        rest = d[3:]
        if rest.startswith("0"):
            rest = rest[1:]
        return "966" + rest if re.fullmatch(r"5\d{8}", rest) else None
    if re.fullmatch(r"05\d{8}", d):
        return "966" + d[1:]
    if re.fullmatch(r"5\d{8}", d):
        return "966" + d
    if intl and 8 <= len(d) <= 15:
        return "+" + d
    return None


def riyadh_today():
    return dt.datetime.now(dt.timezone(dt.timedelta(hours=3))).date()


def b64url(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def b64url_dec(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
