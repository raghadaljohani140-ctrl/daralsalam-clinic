"""مصدر بيانات المراجعين (رقم الملف الطبي).

- local: البيانات في قاعدة بيانات التطبيق (من Excel أو إدخال يدوي). هو الوضع العامل اليوم.
- api  : واجهة جاهزة للربط مع نظام المستوصف إن وفّرت الشركة المشغّلة API. العقد المطلوب في docs/INTEGRATION-API-ar.md.
         لا يعمل إلا بضبط DS_RECORDS_SOURCE=api مع الرابط والمفتاح، ولم يُختبر مع نظام فعلي.
         تُنسخ السجلات المُرجعة إلى جدول records المحلي (source='api') ثم يستمر الربط والملفات كما هي.
"""
import json
import urllib.error
import urllib.parse
import urllib.request

import importer


class LocalSource:
    name = "local"

    def __init__(self, cfg):
        self.cfg = cfg

    def candidates(self, db, phone, norm_phone):
        return db.records_for_phone(phone)


class ApiSource(LocalSource):
    name = "api"

    def candidates(self, db, phone, norm_phone):
        try:
            for r in self.fetch(phone, norm_phone):
                db.record_upsert(r, "api")
        except (urllib.error.URLError, OSError, ValueError):
            pass  # تعذّر النظام الخارجي: نعمل بما لدينا محلياً، ولا نكشف تفاصيل الخطأ للمراجع
        return db.records_for_phone(phone)

    def fetch(self, phone, norm_phone):
        url = self.cfg.records_api_url + "/patients?" + urllib.parse.urlencode({"phone": phone})
        req = urllib.request.Request(url, headers={"Authorization": "Bearer " + self.cfg.records_api_token, "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read(2_000_000).decode("utf-8"))
        items = data.get("patients", []) if isinstance(data, dict) else []
        rows, _errs = importer.parse_rows([i for i in items if isinstance(i, dict)], norm_phone)
        return [r for r in rows if r["phone"] == phone]


def get(cfg):
    if cfg.records_source == "api" and cfg.records_api_url and cfg.records_api_token:
        return ApiSource(cfg)
    return LocalSource(cfg)
