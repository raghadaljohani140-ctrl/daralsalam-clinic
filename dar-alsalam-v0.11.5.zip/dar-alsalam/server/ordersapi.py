"""طلبات المختبر والأشعة: من الطبيب إلى القسم ثم النتيجة ثم مراجعة الطبيب ثم ما يراه المراجع.

الدورة: يكتب الطبيب الطلب في زيارته ← عند «إنهاء الزيارة» يُرسَل تلقائياً إلى قائمة قسمه (db.enc_save) ←
فني القسم يبدأ التنفيذ ويدخل النتيجة ويعتمدها ← تصل الطبيب (تبويب «النتائج») فيراجعها ويقرر نشرها للمراجع ← تظهر في التطبيق.

قواعد الأمان (تُفحص في الخادم):
- حساب المختبر لا يرى إلا طلبات المختبر، وحساب الأشعة لا يرى إلا طلبات الأشعة، ضمن نطاق فرعه؛ ولا يرى من الزيارة إلا اسم المراجع وعمره
  ورقم ملفه واسم الفحص وملاحظة الطبيب عليه واسم الطبيب (لا التشخيص ولا الوصفة ولا الملاحظات الداخلية).
- الطبيب يراجع نتائج طلباته هو فقط. النتيجة تُعدَّل من القسم حتى يراجعها الطبيب، ثم تُقفل.
- المراجع لا يرى نتيجة إلا بعد أن يراجعها الطبيب ويقرر نشرها. وإشعاره لا يحمل اسم الفحص ولا قيمته أبداً.
- كل تغيير يُسجَّل في التدقيق (بلا قيم النتائج).
"""
import re

import rbac
import sms as smsmod
from clinicapi import VISIT_ID_RE, age_label, clean_text
from util import riyadh_today

ORDER_ID_RE = r"(o-[0-9a-f]{12})"
UNIT_LABEL = {"lab": "المختبر", "radiology": "الأشعة"}
KIND_LABEL = {"lab": "تحليل", "radiology": "أشعة"}
ROLE_KIND = {"lab": "lab", "radiology": "radiology"}
FLAGS = ("", "normal", "high", "low", "critical")
MAX_ROWS = 40
# صياغة الحالة بحسب من يقرؤها
ST_DOCTOR = {"sent": "أُرسل للقسم", "in_progress": "قيد التنفيذ", "resulted": "النتيجة جاهزة للمراجعة", "reviewed": "تمت المراجعة", "cancelled": "ملغى"}
ST_UNIT = {"sent": "جديد", "in_progress": "قيد التنفيذ", "resulted": "أُرسلت للطبيب", "reviewed": "راجعها الطبيب", "cancelled": "ملغى"}
ST_PATIENT = {"sent": "أُرسل إلى القسم", "in_progress": "قيد التنفيذ", "resulted": "النتيجة عند الطبيب للمراجعة", "reviewed": "راجع الطبيب النتيجة", "cancelled": "أُلغي"}


def clean_result(kind, body, complete):
    """يتحقق من نتيجة القسم: صفوف (اسم، نتيجة، وحدة، مرجع، علامة) وملاحظة/تقرير نصي. يعيد (rows, text, errors)."""
    errs, rows = {}, []
    raw = body.get("rows", [])
    if not isinstance(raw, list) or len(raw) > MAX_ROWS + 10:
        errs["rows"] = "حتى %d سطر نتيجة" % MAX_ROWS
    else:
        for i, it in enumerate(raw):
            if not isinstance(it, dict):
                continue
            row = {"name": clean_text(it.get("name"), 60), "value": clean_text(it.get("value"), 60), "unit": clean_text(it.get("unit"), 20),
                   "ref": clean_text(it.get("ref"), 40), "flag": str(it.get("flag", "") or "")}
            if row["flag"] not in FLAGS:
                errs["rows"] = "علامة غير صحيحة في السطر %d" % (i + 1)
                break
            if not (row["name"] or row["value"] or row["unit"] or row["ref"]):
                continue                                           # سطر فارغ يُهمَل
            if not row["name"] or not row["value"]:
                errs["rows"] = "اكتب اسم الفحص ونتيجته في السطر %d" % (i + 1)
                break
            rows.append(row)
        if len(rows) > MAX_ROWS:
            errs["rows"] = "حتى %d سطر نتيجة" % MAX_ROWS
    text = clean_text(body.get("text"), 3000, True)
    if complete and "rows" not in errs:
        if kind == "lab" and not rows and len(text) < 2:
            errs["rows"] = "أدخل نتيجة واحدة على الأقل قبل الاعتماد"
        elif kind == "radiology" and len(text) < 2:
            errs["text"] = "اكتب تقرير الأشعة (أو عبارة مثل: تم التصوير)"
    return rows, text, errs


class OrdersMixin:
    # ------------------------------------------------------------------ مساعدات
    def order_dict(self, o, docs, recs, view):
        """طلب بصيغة الواجهة. view: unit (القسم) | doctor (الطبيب). recs: ذاكرة مؤقتة {mrn: سجل المراجع} لتقليل الاستعلامات."""
        st = ST_UNIT if view == "unit" else ST_DOCTOR
        mrn = o["mrn"]
        if mrn not in recs:
            recs[mrn] = self.app.db.record_get(mrn) or {}
        r = recs[mrn]
        return {"id": o["id"], "kind": o["kind"], "kindLabel": KIND_LABEL.get(o["kind"], o["kind"]), "unitLabel": UNIT_LABEL.get(o["kind"], ""), "name": o["name"], "note": o["note"] or "",
                "status": o["status"], "statusLabel": st.get(o["status"], o["status"]), "seq": o["seq"], "day": o["day"], "visitId": o["visit_id"], "mrn": mrn,
                "patientName": o["patient_name"], "age": age_label(r.get("birth_date")), "gender": r.get("gender") or "", "doctorId": o["doctor_id"],
                "doctorName": docs.get(o["doctor_id"], o["doctor_id"]), "branchId": o["branch_id"] or "", "sentAt": o["sent_at"], "startedAt": o["started_at"] or "",
                "resultedAt": o["resulted_at"] or "", "reviewedAt": o["reviewed_at"] or "", "released": o["released"], "rows": o["rows"], "text": o["result_text"] or "",
                "cancelReason": o["cancel_reason"] or "", "cancelledAt": o["cancelled_at"] or ""}

    def _unit_kind(self, s):
        kind = ROLE_KIND.get(s["role"])
        if not kind or not rbac.can(s["role"], "unit." + kind):
            self.err(403, "forbidden", "هذه الصفحة لحسابات المختبر والأشعة فقط")
            return None
        return kind

    def _unit_order(self, s, oid):
        kind = self._unit_kind(s)
        if not kind:
            return None
        o = self.app.db.order_get(oid)
        if not o or o["kind"] != kind or not self.in_scope(s, o["branch_id"]):
            self.err(404, "not_found", "الطلب غير موجود")
            return None
        return o

    def _own_order(self, s, oid):
        did = self._doctor(s)
        if not did:
            return None
        o = self.app.db.order_get(oid)
        if not o or o["doctor_id"] != did or not self.in_scope(s, o["branch_id"]):
            self.err(404, "not_found", "الطلب غير موجود")
            return None
        return o

    # ------------------------------------------------------------------ التوزيع
    def orders_api(self, method, p, s):
        """يُستدعى من clinic_api لمسارات القسم (/unit/...) ونتائج الطبيب (/clinic/results، /clinic/orders/...). يعيد True إن عالج الطلب."""
        if p == "/unit/orders" and method == "GET":
            return self.unit_queue(s) or True
        m = re.fullmatch(r"/unit/orders/" + ORDER_ID_RE + r"/(start|result|complete|cancel)", p)
        if m:
            oid, act = m.group(1), m.group(2)
            if act == "start" and method == "POST":
                return self.unit_start(s, oid) or True
            if act == "result" and method == "PUT":
                return self.unit_result(s, oid, complete=False) or True
            if act == "complete" and method == "POST":
                return self.unit_result(s, oid, complete=True) or True
            if act == "cancel" and method == "POST":
                return self.unit_cancel(s, oid) or True
        if p == "/clinic/results" and method == "GET":
            return self.doc_results(s) or True
        m = re.fullmatch(r"/clinic/visits/" + VISIT_ID_RE + "/orders", p)
        if m and method == "GET":
            return self.doc_visit_orders(s, m.group(1)) or True
        m = re.fullmatch(r"/clinic/orders/" + ORDER_ID_RE + r"/(review|cancel)", p)
        if m and method == "POST":
            return (self.doc_review(s, m.group(1)) if m.group(2) == "review" else self.doc_cancel(s, m.group(1))) or True
        return False

    # ------------------------------------------------------------------ قسم المختبر/الأشعة
    def unit_queue(self, s):
        kind = self._unit_kind(s)
        if not kind:
            return
        today = riyadh_today().isoformat()
        rows = self.app.db.orders_unit(kind, s["branch_id"] or None, today)
        docs, recs = self._docs(), {}
        return self.json(200, {"unit": kind, "unitLabel": UNIT_LABEL[kind], "today": today, "orders": [self.order_dict(o, docs, recs, "unit") for o in rows]}, {"Cache-Control": "private, no-store"})

    def unit_start(self, s, oid):
        o = self._unit_order(s, oid)
        if not o:
            return
        try:
            o2 = self.app.db.order_start(oid, "staff:" + s["username"])
        except ValueError:
            return self.err(409, "bad_transition", "تغيّرت حالة الطلب؛ حدّث القائمة")
        self.saudit(s, "order_start", "order", oid)
        return self.json(200, {"order": self.order_dict(o2, self._docs(), {}, "unit")})

    def unit_result(self, s, oid, complete):
        o = self._unit_order(s, oid)
        if not o:
            return
        body = self.body_json()
        if body is None:
            return
        if "rows" not in body:
            body["rows"] = o["rows"]                               # الاعتماد بلا إعادة إرسال: نعتمد ما حُفظ
        if "text" not in body:
            body["text"] = o["result_text"] or ""
        rows, text, errs = clean_result(o["kind"], body, complete)
        if errs:
            return self.err(422, "validation", "تحقق من الحقول", errs)
        try:
            o2 = self.app.db.order_result_save(oid, "staff:" + s["username"], rows, text, complete=complete)
        except ValueError:
            return self.err(409, "locked", "راجع الطبيب هذه النتيجة أو أُلغي الطلب، فلا يمكن تعديلها")
        if complete and o["status"] != "resulted":
            self.saudit(s, "order_complete", "order", oid, {"kind": o["kind"], "rows": len(rows)})
        else:
            self.saudit(s, "result_edit" if o["status"] == "resulted" else "result_save", "order", oid, {"rows": len(rows)})
        return self.json(200, {"order": self.order_dict(o2, self._docs(), {}, "unit")})

    def unit_cancel(self, s, oid):
        o = self._unit_order(s, oid)
        if not o:
            return
        body = self.body_json()
        if body is None:
            return
        reason = clean_text(body.get("reason"), 200)
        if len(reason) < 2:
            return self.err(422, "validation", "اكتب سبب تعذّر التنفيذ", {"reason": "اكتب سبب تعذّر التنفيذ"})
        try:
            o2 = self.app.db.order_cancel(oid, "staff:" + s["username"], reason, ("sent", "in_progress"))
        except ValueError:
            return self.err(409, "bad_transition", "لا يمكن إلغاء هذا الطلب في حالته الحالية")
        self.saudit(s, "order_cancel", "order", oid, {"by": "unit"})
        return self.json(200, {"order": self.order_dict(o2, self._docs(), {}, "unit")})

    # ------------------------------------------------------------------ الطبيب: نتائج طلباته
    def doc_results(self, s):
        if not self.need(s, "results.review"):
            return
        did = self._doctor(s)
        if not did:
            return
        db = self.app.db
        docs, recs = self._docs(), {}
        keep = lambda rows: [self.order_dict(o, docs, recs, "doctor") for o in rows if self.in_scope(s, o["branch_id"])]  # noqa: E731
        opened = keep(db.orders_doctor_open(did))
        return self.json(200, {"needReview": [o for o in opened if o["status"] == "resulted"], "pending": [o for o in opened if o["status"] != "resulted"],
                               "recent": keep(db.orders_doctor_recent(did))}, {"Cache-Control": "private, no-store"})

    def doc_visit_orders(self, s, vid):
        if not self.need(s, "clinical.read"):
            return
        v = self._own_visit(s, vid)
        if not v:
            return
        docs = self._docs()
        return self.json(200, {"orders": [self.order_dict(o, docs, {}, "doctor") for o in self.app.db.orders_for_visit(vid)]}, {"Cache-Control": "private, no-store"})

    def doc_review(self, s, oid):
        if not self.need(s, "results.review"):
            return
        o = self._own_order(s, oid)
        if not o:
            return
        body = self.body_json()
        if body is None:
            return
        release = bool(body.get("release"))
        try:
            o2 = self.app.db.order_review(oid, "staff:" + s["username"], release)
        except ValueError:
            return self.err(409, "bad_transition", "هذه النتيجة ليست بانتظار مراجعتك")
        self.saudit(s, "order_review", "order", oid, {"kind": o["kind"], "release": o2["released"]})
        if o2["released"] and not o["released"]:
            self.notify_result(o2)
        return self.json(200, {"order": self.order_dict(o2, self._docs(), {}, "doctor")})

    def doc_cancel(self, s, oid):
        if not self.need(s, "clinical.write"):
            return
        o = self._own_order(s, oid)
        if not o:
            return
        try:
            o2 = self.app.db.order_cancel(oid, "staff:" + s["username"], "ألغاه الطبيب", ("sent",))
        except ValueError:
            return self.err(409, "bad_transition", "بدأ القسم تنفيذ هذا الطلب فلا يمكن إلغاؤه من عندك؛ تواصل مع القسم")
        self.saudit(s, "order_cancel", "order", oid, {"by": "doctor"})
        return self.json(200, {"order": self.order_dict(o2, self._docs(), {}, "doctor")})

    # ------------------------------------------------------------------ المراجع
    def notify_result(self, o):
        """إشعار المراجع بنشر نتيجة جديدة: لا يحمل اسم الفحص ولا قيمته. الحسابات المرتبطة بالملف، وفي وضع التجربة (بلا SMS) جهاز الحجز."""
        try:
            app = self.app
            db = app.db
            v = db.visit_get(o["visit_id"])
            b = db.get_booking(v["booking_id"]) if v and v.get("booking_id") else None
            dev = b["device_id"] if b and b["device_id"] and not b["device_id"].startswith("deleted-") else ""
            pts = ["pt:" + pid for pid in db.patients_of_mrn(o["mrn"])]
            targets = pts or ([dev] if dev and not smsmod.enabled(app.cfg) else [])
            t, x = "نتيجة جديدة", "نُشرت نتيجة جديدة في تطبيقك."
            own = self.notify_target(b) if b and dev and b.get("patient_id") else ""
            for tg in targets:
                nid = db.add_notification(t, x, own if (own and tg == dev) else tg, "result", "#/results")
                if not tg.startswith("pt:"):
                    app.push.send(db.push_tokens(tg), t, x, {"id": nid, "result": o["id"]})
        except Exception as e:  # noqa: BLE001 — فشل إشعار لا يُفشل عمل الطبيب
            import sys
            sys.stderr.write("WARN notify_result: %r\n" % (e,))

    @staticmethod
    def merge_orders(items, ords):
        """طلبات الزيارة كما يراها المراجع: الحالة دائماً، والنتيجة (قيم وتقرير) بعد نشرها فقط. الطلبات القديمة (قبل 0.9.0) بلا حالة."""
        by = {o["id"]: o for o in (ords or [])}
        out = []
        for it in items:
            d = {"type": it.get("type", "lab"), "name": it.get("name", ""), "note": it.get("note", "")}
            o = by.get(it.get("oid"))
            if o:
                d.update({"id": o["id"], "status": o["status"], "statusLabel": ST_PATIENT.get(o["status"], ""), "released": o["released"]})
                if o["released"]:
                    d.update({"rows": o["rows"], "text": o["result_text"] or "", "reviewedAt": o["reviewed_at"] or ""})
            out.append(d)
        return out

    def patient_results_api(self, method, p):
        """GET /results: نتائج المراجع التي نشرها الطبيب (حساب موثّق، أو جهاز الحجز في وضع التجربة)، الأحدث أولاً."""
        if method != "GET":
            return self.err(405, "method_not_allowed")
        if p not in ("", "/"):
            return self.err(404, "not_found")
        sc = self._patient_scope("pres:")
        if not sc:
            return
        docs, brs = self._names()
        out = []
        for o in self.app.db.orders_released(**sc):
            out.append({"id": o["id"], "kind": o["kind"], "kindLabel": KIND_LABEL.get(o["kind"], ""), "name": o["name"], "day": o["day"], "doctorName": docs.get(o["doctor_id"], ""),
                        "branchName": brs.get(o["branch_id"], ""), "reviewedAt": o["reviewed_at"] or "", "rows": o["rows"], "text": o["result_text"] or ""})
        return self.json(200, {"results": out}, {"Cache-Control": "private, no-store"})
