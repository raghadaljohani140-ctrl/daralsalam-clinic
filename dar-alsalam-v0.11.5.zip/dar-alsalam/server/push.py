"""إشعارات اختيارية: تنبيه موظفين عبر تيليجرام (بدون بيانات شخصية) وإشعارات دفع FCM v1.
كلها معطّلة افتراضياً ولا ترمي أخطاء: أي فشل يُسجَّل فقط. ملاحظة: مسار FCM لم يُختبر مع خوادم قوقل الحقيقية في بيئة البناء."""
import base64
import json
import os
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request


def _b64url(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def make_jwt(sa, scope="https://www.googleapis.com/auth/firebase.messaging", now=None):
    """يبني JWT موقّعاً RS256 عبر openssl (بدون مكتبات)."""
    now = int(now or time.time())
    header = {"alg": "RS256", "typ": "JWT"}
    claims = {"iss": sa["client_email"], "scope": scope, "aud": sa.get("token_uri", "https://oauth2.googleapis.com/token"),
              "iat": now, "exp": now + 3600}
    signing_input = _b64url(json.dumps(header, separators=(",", ":")).encode()) + "." + _b64url(json.dumps(claims, separators=(",", ":")).encode())
    fd, path = tempfile.mkstemp(suffix=".pem")
    try:
        os.write(fd, sa["private_key"].encode())
        os.close(fd)
        os.chmod(path, 0o600)
        sig = subprocess.run(["openssl", "dgst", "-sha256", "-sign", path], input=signing_input.encode(), capture_output=True, check=True, timeout=10).stdout
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    return signing_input + "." + _b64url(sig)


class Push:
    def __init__(self, cfg):
        self.cfg = cfg
        self._tok = (0, "")
        self._sa = None

    # ---------------------------------------------------------------- تيليجرام للموظفين
    def staff_alert(self, text):
        if not (self.cfg.telegram_token and self.cfg.telegram_chat):
            return False
        try:
            data = urllib.parse.urlencode({"chat_id": self.cfg.telegram_chat, "text": text[:500]}).encode()
            urllib.request.urlopen("https://api.telegram.org/bot%s/sendMessage" % self.cfg.telegram_token, data=data, timeout=8)  # noqa: S310
            return True
        except Exception as e:  # noqa: BLE001
            print("telegram alert failed:", type(e).__name__)
            return False

    # ---------------------------------------------------------------- FCM
    @property
    def fcm_enabled(self):
        return bool(self.cfg.fcm_project and self.cfg.fcm_service_account and os.path.exists(self.cfg.fcm_service_account))

    def _access_token(self):
        if self._tok[0] > time.time() + 60:
            return self._tok[1]
        if self._sa is None:
            self._sa = json.load(open(self.cfg.fcm_service_account, encoding="utf-8"))
        jwt = make_jwt(self._sa)
        body = urllib.parse.urlencode({"grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer", "assertion": jwt}).encode()
        with urllib.request.urlopen(self._sa.get("token_uri", "https://oauth2.googleapis.com/token"), data=body, timeout=10) as r:  # noqa: S310
            d = json.loads(r.read().decode())
        self._tok = (time.time() + int(d.get("expires_in", 3000)), d["access_token"])
        return self._tok[1]

    def send(self, tokens, title, body, data=None):
        """يرسل لكل رمز على حدة (واجهة v1). يعيد (نجح، فشل). آمن ضد الأخطاء."""
        if not self.fcm_enabled or not tokens:
            return (0, 0)
        ok = bad = 0
        try:
            access = self._access_token()
        except Exception as e:  # noqa: BLE001
            print("fcm auth failed:", type(e).__name__)
            return (0, len(tokens))
        url = "https://fcm.googleapis.com/v1/projects/%s/messages:send" % self.cfg.fcm_project
        for t in tokens[:500]:
            msg = {"message": {"token": t, "notification": {"title": title[:80], "body": body[:200]},
                               "data": {k: str(v) for k, v in (data or {}).items()}}}
            req = urllib.request.Request(url, data=json.dumps(msg).encode(), method="POST",
                                         headers={"content-type": "application/json", "authorization": "Bearer " + access})
            try:
                urllib.request.urlopen(req, timeout=8)  # noqa: S310
                ok += 1
            except (urllib.error.URLError, OSError):
                bad += 1
        return (ok, bad)
