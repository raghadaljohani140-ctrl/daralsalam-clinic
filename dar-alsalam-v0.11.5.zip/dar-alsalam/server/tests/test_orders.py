"""طلبات المختبر والأشعة: الطبيب ← قسم المختبر/الأشعة ← النتيجة ← مراجعة الطبيب ← ما يراه المراجع.
مع عزل الأقسام والأطباء والفروع، وقفل النتيجة بعد المراجعة، وخصوصية الإشعارات والتدقيق."""
import json
import threading
from urllib.parse import quote

from test_api import booking_body
from test_clinic import DX, SECRET_NOTE, Base
from test_files import login as patient_login

MARK = "قيمة-فريدة-7731"
LAB_ROWS = [{"name": "Hemoglobin", "value": "13.2", "unit": "g/dL", "ref": "12-16", "flag": "normal"},
            {"name": "WBC", "value": "14.8", "unit": "x10^3/uL", "ref": "4-11", "flag": "high"}]
SECRETS = (DX["diagnosis"], SECRET_NOTE, DX["advice"], DX["complaint"], "أموكسيسيلين", "باراسيتامول")
LAB_ONLY = [{"type": "lab", "name": "سكر صائم", "note": ""}]


class OrdersBase(Base):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.D = cls.ready("doc_ord1", "doctor", cls.br[0], cls.docs[0])
        cls.D2 = cls.ready("doc_ord2", "doctor", cls.br[0], cls.docs[1])
        cls.LAB = cls.ready("lab_a", "lab", cls.br[0])
        cls.LAB2 = cls.ready("lab_b", "lab", cls.br[0])
        cls.RAD = cls.ready("rad_a", "radiology", cls.br[0])

    # --------------------------------------------------------------- أدوات
    def book(self, name="مراجع الطلبات"):
        dev = "ord_device_%03d_0123456789" % self.uniq()
        s, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev, branchId=self.br[0], phone="05656%05d" % self.uniq(), name=name))
        self.assertEqual(s, 201, d)
        return dev, d["booking"]["id"]

    def visit(self, D, doctor, orders=None, name="مراجع الطلبات", finish=True):
        """زيارة من الحجز حتى الإنهاء (أو حتى حفظ المسودة). يعيد (mrn, vid, dev)."""
        dev, bid = self.book(name)
        mrn, v = self.checkin(doctor, name, booking=bid)
        self.call(D, v["id"])
        body = dict(DX, orders=DX["orders"] if orders is None else orders)
        if finish:
            self.finish(D, v["id"], body)
        else:
            self.save(D, v["id"], body)
        return mrn, v["id"], dev

    def unit(self, H, vid=None):
        s, d, _ = self.st("GET", "/unit/orders", H)
        self.assertEqual(s, 200, d)
        return [o for o in d["orders"] if vid is None or o["visitId"] == vid]

    def oids(self, vid):
        return [o["id"] for o in self.e.app.db.orders_for_visit(vid)]

    def put(self, H, oid, body, expect=200):
        s, d, _ = self.st("PUT", "/unit/orders/%s/result" % oid, H, body)
        self.assertEqual(s, expect, d)
        return d

    def complete(self, H, oid, body=None, expect=200):
        s, d, _ = self.st("POST", "/unit/orders/%s/complete" % oid, H, {} if body is None else body)
        self.assertEqual(s, expect, d)
        return d

    def start(self, H, oid, expect=200):
        s, d, _ = self.st("POST", "/unit/orders/%s/start" % oid, H)
        self.assertEqual(s, expect, d)
        return d

    def review(self, D, oid, release=True, expect=200):
        s, d, _ = self.st("POST", "/clinic/orders/%s/review" % oid, D, {"release": release})
        self.assertEqual(s, expect, d)
        return d

    def results(self, dev):
        return self.e.req("GET", "/api/v1/results?deviceId=" + dev)

    def patient_orders(self, vid, dev):
        s, d, _ = self.e.req("GET", "/api/v1/visits/%s?deviceId=%s" % (vid, dev))
        self.assertEqual(s, 200, d)
        return d["visit"]["orders"]

    def result_notifs(self, dev):
        return [x for x in self.notifs(dev) if x["kind"] == "result"]

    def sql(self, q, args=()):
        with self.e.app.db.tx() as c:
            c.execute(q, args)


class TestOrdersCycle(OrdersBase):
    """الدورة كاملة في وضع التجربة (بلا SMS): المراجع يرى نتائجه عبر جهاز الحجز."""

    def test_full_cycle(self):
        e, db = self.e, self.e.app.db
        mrn, vid, dev = self.visit(self.D, self.docs[0], finish=False)
        # قبل «إنهاء الزيارة» الطلبات مسودة عند الطبيب فقط: لا تصل الأقسام
        self.assertEqual((self.unit(self.LAB, vid), self.unit(self.RAD, vid), db.orders_for_visit(vid)), ([], [], []))
        self.finish(self.D, vid)
        # عند الإنهاء: يصل كل طلب إلى قائمة قسمه، مرتبطاً بالطبيب والزيارة والفرع
        lab, rad = self.unit(self.LAB, vid), self.unit(self.RAD, vid)
        self.assertEqual([(o["kind"], o["name"], o["note"], o["status"], o["statusLabel"]) for o in lab], [("lab", "صورة دم كاملة", "", "sent", "جديد")])
        self.assertEqual([(o["kind"], o["name"], o["note"], o["status"]) for o in rad], [("radiology", "أشعة صدر", "وضع أمامي", "sent")])
        o = lab[0]
        self.assertEqual((o["visitId"], o["mrn"], o["doctorId"], o["doctorName"], o["branchId"], o["patientName"]),
                         (vid, mrn, self.docs[0], self.names[self.docs[0]], self.br[0], "مراجع الطلبات"))
        self.assertTrue(o["seq"] >= 1 and o["age"])
        raw = json.dumps(self.st("GET", "/unit/orders", self.LAB)[1], ensure_ascii=False)
        for secret in SECRETS:                                                          # القسم لا يرى التشخيص ولا الوصفة ولا الملاحظات
            self.assertNotIn(secret, raw)
        # كل بند في مسودة الزيارة يحمل معرّف طلبه
        self.assertEqual([it["oid"] for it in db.enc_get(vid)["orders"]], self.oids(vid))
        lab_id, rad_id = lab[0]["id"], rad[0]["id"]
        # لوحة الاستقبال: طلبان بانتظار الأقسام
        board = next(x for x in self.st("GET", "/visits", self.R)[1]["visits"] if x["id"] == vid)
        self.assertEqual(board["orderStat"], {"total": 2, "open": 2, "await": 0, "done": 0, "cancelled": 0})
        # المختبر يبدأ التنفيذ؛ التكرار 409
        d = self.start(self.LAB, lab_id)
        self.assertEqual((d["order"]["status"], d["order"]["statusLabel"]), ("in_progress", "قيد التنفيذ"))
        self.assertEqual(self.start(self.LAB, lab_id, expect=409)["error"], "bad_transition")
        # الطبيب يرى الحالة، والمراجع يرى الحالة بلا نتيجة
        s, d, _ = self.st("GET", "/clinic/visits/%s/orders" % vid, self.D)
        self.assertEqual([(x["kind"], x["status"], x["statusLabel"]) for x in d["orders"]], [("lab", "in_progress", "قيد التنفيذ"), ("radiology", "sent", "أُرسل للقسم")])
        po = self.patient_orders(vid, dev)
        self.assertEqual([(x["type"], x["status"], x["statusLabel"], x["released"]) for x in po], [("lab", "in_progress", "قيد التنفيذ", False), ("radiology", "sent", "أُرسل إلى القسم", False)])
        self.assertTrue(all("rows" not in x and "text" not in x for x in po))
        # مسودة النتيجة تُحفظ دون إرسالها للطبيب، ثم الاعتماد بلا إعادة إرسال الصفوف
        d = self.put(self.LAB, lab_id, {"rows": LAB_ROWS})
        self.assertEqual((d["order"]["status"], len(d["order"]["rows"])), ("in_progress", 2))
        self.assertNotIn(lab_id, [o_["id"] for o_ in self.st("GET", "/clinic/results", self.D)[1]["needReview"]])      # المسودة لا تصل الطبيب
        d = self.complete(self.LAB, lab_id)
        self.assertEqual((d["order"]["status"], d["order"]["statusLabel"], len(d["order"]["rows"])), ("resulted", "أُرسلت للطبيب", 2))
        # تصل الطبيب بانتظار مراجعته، ولا يراها المراجع بعد
        r = self.st("GET", "/clinic/results", self.D)[1]
        mine = next(x for x in r["needReview"] if x["id"] == lab_id)
        self.assertEqual((mine["statusLabel"], mine["rows"][1]["flag"], mine["patientName"], mine["mrn"]), ("النتيجة جاهزة للمراجعة", "high", "مراجع الطلبات", mrn))
        self.assertGreaterEqual(self.st("GET", "/clinic/queue", self.D)[1]["pendingReview"], 1)
        board = next(x for x in self.st("GET", "/visits", self.R)[1]["visits"] if x["id"] == vid)
        self.assertEqual((board["orderStat"]["await"], board["orderStat"]["open"]), (1, 1))
        self.assertEqual(self.results(dev)[1], {"results": []})
        po = self.patient_orders(vid, dev)
        self.assertEqual((po[0]["status"], po[0]["statusLabel"], po[0]["released"], "rows" in po[0]), ("resulted", "النتيجة عند الطبيب للمراجعة", False, False))
        self.assertEqual(self.result_notifs(dev), [])
        # القسم يصحح نتيجته ما دام الطبيب لم يراجعها
        rows2 = [dict(LAB_ROWS[0], value="13.5")] + LAB_ROWS[1:]
        d = self.put(self.LAB, lab_id, {"rows": rows2})
        self.assertEqual((d["order"]["status"], d["order"]["rows"][0]["value"]), ("resulted", "13.5"))
        # الطبيب يراجع وينشر
        d = self.review(self.D, lab_id, True)
        self.assertEqual((d["order"]["status"], d["order"]["released"], d["order"]["statusLabel"]), ("reviewed", True, "تمت المراجعة"))
        # إشعار عام لا يحمل اسم الفحص ولا قيمته
        n = self.result_notifs(dev)
        self.assertEqual([(x["title"], x["ref"]) for x in n], [("نتيجة جديدة", "#/results")])
        blob = json.dumps(n, ensure_ascii=False)
        for leak in ("Hemoglobin", "13.5", "صورة دم", "WBC"):
            self.assertNotIn(leak, blob)
        # المراجع يرى نتيجته (لا بيانات الزيارة الداخلية) من قائمة النتائج ومن تفاصيل زيارته
        s, d, _ = self.results(dev)
        self.assertEqual(s, 200)
        self.assertEqual([(x["id"], x["kind"], x["kindLabel"], x["name"], x["doctorName"]) for x in d["results"]], [(lab_id, "lab", "تحليل", "صورة دم كاملة", self.names[self.docs[0]])])
        self.assertEqual([r_["value"] for r_ in d["results"][0]["rows"]], ["13.5", "14.8"])
        for secret in SECRETS:
            self.assertNotIn(secret, json.dumps(d, ensure_ascii=False))
        po = self.patient_orders(vid, dev)
        self.assertEqual((po[0]["released"], [r_["value"] for r_ in po[0]["rows"]]), (True, ["13.5", "14.8"]))
        # بعد المراجعة تُقفل النتيجة
        self.assertEqual(self.put(self.LAB, lab_id, {"rows": LAB_ROWS}, expect=409)["error"], "locked")
        self.assertEqual(self.complete(self.LAB, lab_id, expect=409)["error"], "locked")
        self.assertEqual(self.start(self.LAB, lab_id, expect=409)["error"], "bad_transition")
        self.assertEqual(self.review(self.D, lab_id, True, expect=409)["error"], "bad_transition")
        self.assertEqual(self.st("POST", "/clinic/orders/%s/cancel" % lab_id, self.D)[0], 409)
        # ===== الأشعة: تقرير نصي، يُراجَع بلا نشر ثم يُنشر لاحقاً =====
        self.put(self.RAD, rad_id, {"text": "تقرير تجريبي: الرئتان سليمتان"})                       # الحفظ الأول يبدأ التنفيذ
        self.assertEqual(db.order_get(rad_id)["status"], "in_progress")
        d = self.complete(self.RAD, rad_id)
        self.assertEqual((d["order"]["status"], d["order"]["text"]), ("resulted", "تقرير تجريبي: الرئتان سليمتان"))
        d = self.review(self.D, rad_id, False)
        self.assertEqual((d["order"]["status"], d["order"]["released"]), ("reviewed", False))
        self.assertEqual([x["id"] for x in self.results(dev)[1]["results"]], [lab_id])                # لم يُنشر
        self.assertEqual(len(self.result_notifs(dev)), 1)                                              # ولا إشعار
        po = self.patient_orders(vid, dev)
        self.assertEqual((po[1]["status"], po[1]["statusLabel"], po[1]["released"], "text" in po[1]), ("reviewed", "راجع الطبيب النتيجة", False, False))
        d = self.review(self.D, rad_id, True)                                                         # النشر لاحقاً
        self.assertTrue(d["order"]["released"])
        self.assertEqual([x["id"] for x in self.results(dev)[1]["results"]], [rad_id, lab_id])        # الأحدث أولاً
        self.assertEqual(len(self.result_notifs(dev)), 2)
        self.assertEqual(self.review(self.D, rad_id, True, expect=409)["error"], "bad_transition")     # لا إشعار مكرر
        self.assertEqual(len(self.result_notifs(dev)), 2)
        board = next(x for x in self.st("GET", "/visits", self.R)[1]["visits"] if x["id"] == vid)
        self.assertEqual(board["orderStat"], {"total": 2, "open": 0, "await": 0, "done": 2, "cancelled": 0})
        # جهاز آخر لا يرى شيئاً
        other = "other_orders_device_0123"
        self.assertEqual(self.results(other)[1], {"results": []})
        self.assertEqual(e.req("GET", "/api/v1/results")[0], 401)
        self.assertEqual(e.req("POST", "/api/v1/results?deviceId=" + dev, {})[0], 405)
        self.assertEqual(e.req("GET", "/api/v1/results/abc?deviceId=" + dev)[0], 404)

    def test_unit_isolation_and_permissions(self):
        db = self.e.app.db
        mrn, vid, dev = self.visit(self.D, self.docs[0])
        lab_id, rad_id = self.oids(vid)
        self.assertEqual({o["kind"] for o in self.unit(self.LAB)}, {"lab"})
        self.assertEqual({o["kind"] for o in self.unit(self.RAD)}, {"radiology"})
        # كل قسم لا يعالج طلب الآخر
        for act, m, body in (("start", "POST", None), ("result", "PUT", {"text": "xx"}), ("complete", "POST", {}), ("cancel", "POST", {"reason": "سبب"})):
            self.assertEqual(self.st(m, "/unit/orders/%s/%s" % (lab_id, act), self.RAD, body)[0], 404, act)
            self.assertEqual(self.st(m, "/unit/orders/%s/%s" % (rad_id, act), self.LAB, body)[0], 404, act)
        self.assertEqual((db.order_get(lab_id)["status"], db.order_get(rad_id)["status"]), ("sent", "sent"))
        # حساب القسم لا يدخل أي واجهة سريرية أو استقبال
        for H in (self.LAB, self.RAD):
            for path in ("/visits", "/clinic/queue", "/clinic/visits/" + vid, "/clinic/results", "/bookings", "/audit", "/records?q=" + quote("مراجع"),
                         "/clinic/visits/%s/orders" % vid, "/visits/%s/summary" % vid, "/lookups"):
                code = self.st("GET", path, H)[0]
                self.assertIn(code, (403,) if path != "/lookups" else (200, 403), path)
            self.assertEqual(self.st("POST", "/clinic/visits/%s/call" % vid, H)[0], 403)
            self.assertEqual(self.st("POST", "/clinic/orders/%s/review" % lab_id, H, {"release": True})[0], 403)
            self.assertEqual(self.st("POST", "/clinic/orders/%s/cancel" % lab_id, H)[0], 403)
            self.assertEqual(self.st("POST", "/visits", H, {"mrn": mrn, "doctorId": self.docs[3]})[0], 403)
        me = self.st("GET", "/me", self.LAB)[1]["user"]
        self.assertEqual((me["role"], me["roleLabel"], "unit.lab" in me["perms"], "unit.radiology" in me["perms"], "clinical.read" in me["perms"]), ("lab", "المختبر", True, False, False))
        me = self.st("GET", "/me", self.RAD)[1]["user"]
        self.assertEqual((me["role"], "unit.radiology" in me["perms"], "unit.lab" in me["perms"]), ("radiology", True, False))
        # الطبيب والاستقبال لا يدخلان قائمة الأقسام ولا يعالجان طلباً
        for H in (self.D, self.R):
            self.assertEqual(self.st("GET", "/unit/orders", H)[0], 403)
            self.assertEqual(self.st("POST", "/unit/orders/%s/start" % lab_id, H)[0], 403)
            self.assertEqual(self.st("PUT", "/unit/orders/%s/result" % lab_id, H, {"rows": LAB_ROWS})[0], 403)
        self.assertEqual(self.st("GET", "/clinic/results", self.R)[0], 403)                          # مراجعة النتائج للطبيب فقط
        self.assertEqual(self.st("POST", "/clinic/orders/%s/review" % lab_id, self.R, {"release": True})[0], 403)
        self.assertEqual(db.order_get(lab_id)["status"], "sent")

    def test_doctor_only_sees_and_reviews_own_orders(self):
        db = self.e.app.db
        mrn, vid, dev = self.visit(self.D, self.docs[0])
        lab_id = self.oids(vid)[0]
        self.put(self.LAB, lab_id, {"rows": LAB_ROWS})
        self.complete(self.LAB, lab_id)
        r = self.st("GET", "/clinic/results", self.D2)[1]
        self.assertEqual([o["id"] for k in ("needReview", "pending", "recent") for o in r[k] if o["id"] == lab_id], [])
        self.assertEqual(self.st("POST", "/clinic/orders/%s/review" % lab_id, self.D2, {"release": True})[0], 404)
        self.assertEqual(self.st("POST", "/clinic/orders/%s/cancel" % lab_id, self.D2)[0], 404)
        self.assertEqual(self.st("GET", "/clinic/visits/%s/orders" % vid, self.D2)[0], 404)
        self.assertEqual(self.st("GET", "/clinic/visits/" + vid, self.D2)[0], 404)
        self.assertEqual(db.order_get(lab_id)["status"], "resulted")
        self.assertIn(lab_id, [o["id"] for o in self.st("GET", "/clinic/results", self.D)[1]["needReview"]])
        self.review(self.D, lab_id, False)
        r = self.st("GET", "/clinic/results", self.D)[1]
        self.assertIn(lab_id, [o["id"] for o in r["recent"]])
        self.assertNotIn(lab_id, [o["id"] for o in r["needReview"]])

    def test_cancel_rules(self):
        mrn, vid, dev = self.visit(self.D, self.docs[0])
        lab_id, rad_id = self.oids(vid)
        # الطبيب يلغي ما لم يبدأه القسم
        s, d, _ = self.st("POST", "/clinic/orders/%s/cancel" % rad_id, self.D)
        self.assertEqual((s, d["order"]["status"], d["order"]["cancelReason"], d["order"]["statusLabel"]), (200, "cancelled", "ألغاه الطبيب", "ملغى"))
        self.assertEqual(self.unit(self.RAD, vid), [])
        self.assertEqual(self.start(self.RAD, rad_id, expect=409)["error"], "bad_transition")
        self.assertEqual(self.st("POST", "/clinic/orders/%s/cancel" % rad_id, self.D)[0], 409)
        self.assertEqual(self.put(self.RAD, rad_id, {"text": "xx"}, expect=409)["error"], "locked")
        # بعد أن يبدأ القسم لا يلغيه الطبيب
        self.start(self.LAB, lab_id)
        self.assertEqual(self.st("POST", "/clinic/orders/%s/cancel" % lab_id, self.D)[0], 409)
        # القسم يلغي بسبب مكتوب
        s, d, _ = self.st("POST", "/unit/orders/%s/cancel" % lab_id, self.LAB, {})
        self.assertEqual((s, "reason" in d["fields"]), (422, True))
        self.assertEqual(self.st("POST", "/unit/orders/%s/cancel" % lab_id, self.LAB, {"reason": "x"})[0], 422)
        s, d, _ = self.st("POST", "/unit/orders/%s/cancel" % lab_id, self.LAB, {"reason": "العينة غير صالحة"})
        self.assertEqual((s, d["order"]["status"], d["order"]["cancelReason"]), (200, "cancelled", "العينة غير صالحة"))
        self.assertEqual(self.st("POST", "/unit/orders/%s/cancel" % lab_id, self.LAB, {"reason": "مرة ثانية"})[0], 409)
        # الطبيب يرى المُلغى وسببه، والمراجع يرى «أُلغي» بلا نتيجة ولا إشعار نتيجة
        r = self.st("GET", "/clinic/results", self.D)[1]
        got = {o["id"]: o for o in r["recent"]}
        self.assertEqual((got[lab_id]["cancelReason"], got[rad_id]["cancelReason"]), ("العينة غير صالحة", "ألغاه الطبيب"))
        po = self.patient_orders(vid, dev)
        self.assertEqual([(x["status"], x["statusLabel"], x["released"]) for x in po], [("cancelled", "أُلغي", False), ("cancelled", "أُلغي", False)])
        self.assertEqual(self.results(dev)[1], {"results": []})
        self.assertEqual(self.result_notifs(dev), [])
        # بعد اعتماد النتيجة لا يلغيها القسم (تعديلها فقط حتى مراجعة الطبيب)
        _, vid2, _ = self.visit(self.D, self.docs[0], LAB_ONLY, name="مراجع ثانٍ")
        o2 = self.oids(vid2)[0]
        self.put(self.LAB, o2, {"text": "طبيعي"})
        self.complete(self.LAB, o2)
        self.assertEqual(self.st("POST", "/unit/orders/%s/cancel" % o2, self.LAB, {"reason": "سبب كافٍ"})[0], 409)
        self.assertEqual(self.st("POST", "/clinic/orders/%s/cancel" % o2, self.D)[0], 409)

    def test_result_validation(self):
        mrn, vid, dev = self.visit(self.D, self.docs[0])
        lab_id, rad_id = self.oids(vid)
        for bad in ("o-000000000000", "o-ABCDEF123456"):
            self.assertIn(self.st("POST", "/unit/orders/%s/start" % bad, self.LAB)[0], (404,), bad)
        self.assertEqual(self.st("POST", "/unit/orders/not-an-id/start", self.LAB)[0], 404)
        # حقول الصفوف
        for body in ({"rows": [{"name": "X", "value": "1", "flag": "bogus"}]}, {"rows": [{"name": "X", "value": ""}]}, {"rows": [{"name": "", "value": "5"}]},
                     {"rows": "ليست قائمة"}, {"rows": [{"name": "n%d" % i, "value": "1"} for i in range(41)]}):
            s, d, _ = self.st("PUT", "/unit/orders/%s/result" % lab_id, self.LAB, body)
            self.assertEqual((s, "rows" in d["fields"]), (422, True), body)
        # الأسطر الفارغة تُهمَل، والمسودة تقبل ما لم يكتمل
        d = self.put(self.LAB, lab_id, {"rows": [{"name": "", "value": ""}, {"name": " Glucose ", "value": " 95 ", "unit": "mg/dL", "flag": ""}]})
        self.assertEqual(d["order"]["rows"], [{"name": "Glucose", "value": "95", "unit": "mg/dL", "ref": "", "flag": ""}])
        d = self.put(self.LAB, lab_id, {"rows": []})                                                  # مسودة فارغة مقبولة
        self.assertEqual(d["order"]["rows"], [])
        # الاعتماد: المختبر يلزمه صف أو نص، والأشعة يلزمها تقرير
        s, d, _ = self.st("POST", "/unit/orders/%s/complete" % lab_id, self.LAB, {})
        self.assertEqual((s, "rows" in d["fields"]), (422, True))
        s, d, _ = self.st("POST", "/unit/orders/%s/complete" % rad_id, self.RAD, {"rows": LAB_ROWS})
        self.assertEqual((s, "text" in d["fields"]), (422, True))
        self.assertEqual(self.st("POST", "/unit/orders/%s/complete" % rad_id, self.RAD, {"text": "x"})[0], 422)
        self.assertEqual(self.db_status(lab_id), "in_progress")                                         # الفشل لا يغيّر الحالة
        d = self.complete(self.LAB, lab_id, {"text": "لا توجد قيم رقمية؛ العينة طبيعية"})                # نص فقط يكفي للمختبر
        self.assertEqual((d["order"]["status"], d["order"]["rows"], d["order"]["text"]), ("resulted", [], "لا توجد قيم رقمية؛ العينة طبيعية"))
        d = self.complete(self.RAD, rad_id, {"text": "ت" * 4000})                                         # النص الطويل يُقصّ ولا يُفشل
        self.assertEqual(len(d["order"]["text"]), 3000)

    def db_status(self, oid):
        return self.e.app.db.order_get(oid)["status"]

    def test_numbering_and_worklist(self):
        db = self.e.app.db
        vids = [self.visit(self.D, self.docs[0], LAB_ONLY + [{"type": "radiology", "name": "أشعة قدم", "note": ""}], name="مراجع %d" % i)[1] for i in range(3)]
        labs = [self.unit(self.LAB, v)[0] for v in vids]
        rads = [self.unit(self.RAD, v)[0] for v in vids]
        self.assertEqual([o["seq"] for o in labs], [labs[0]["seq"] + i for i in range(3)])             # ترقيم متتابع لكل قسم/يوم/فرع
        self.assertEqual([o["seq"] for o in rads], [rads[0]["seq"] + i for i in range(3)])
        # الطبيب الآخر في الفرع نفسه يكمل الترقيم نفسه
        _, vid4, _ = self.visit(self.D2, self.docs[1], LAB_ONLY, name="مراجع د2")
        self.assertEqual(self.unit(self.LAB, vid4)[0]["seq"], labs[2]["seq"] + 1)
        # «قيد التنفيذ» أولاً ثم الجديد بترتيب الوصول
        mine = {o["id"] for o in labs}
        self.start(self.LAB, labs[2]["id"])
        order = [o["id"] for o in self.unit(self.LAB) if o["id"] in mine]
        self.assertEqual(order, [labs[2]["id"], labs[0]["id"], labs[1]["id"]])
        # المفتوح يبقى في القائمة أياً كان يومه
        self.sql("UPDATE orders SET day='2000-01-01', sent_at='2000-01-01T00:00:00Z' WHERE id=?", (labs[0]["id"],))
        self.assertIn(labs[0]["id"], [o["id"] for o in self.unit(self.LAB)])
        # المنجز يظهر في قائمة القسم يوم إنجازه فقط، ويبقى عند الطبيب
        self.put(self.LAB, labs[1]["id"], {"text": "طبيعي"})
        self.complete(self.LAB, labs[1]["id"])
        self.assertIn(labs[1]["id"], [o["id"] for o in self.unit(self.LAB)])
        self.sql("UPDATE orders SET done_day='2000-01-01' WHERE id=?", (labs[1]["id"],))
        self.assertNotIn(labs[1]["id"], [o["id"] for o in self.unit(self.LAB)])
        self.assertIn(labs[1]["id"], [o["id"] for o in self.st("GET", "/clinic/results", self.D)[1]["needReview"]])
        self.assertEqual(db.order_get(labs[1]["id"])["status"], "resulted")

    def test_audit_and_notification_privacy(self):
        db = self.e.app.db
        mrn, vid, dev = self.visit(self.D, self.docs[0])
        lab_id, rad_id = self.oids(vid)
        self.put(self.LAB, lab_id, {"rows": [{"name": "Marker", "value": MARK, "flag": "critical"}], "text": MARK})
        self.complete(self.LAB, lab_id)
        self.put(self.LAB, lab_id, {"rows": [{"name": "Marker", "value": MARK + "x"}], "text": MARK})     # تعديل قبل المراجعة
        self.review(self.D, lab_id, True)
        actions = self.audit(lab_id)
        for a in ("order_send", "result_save", "order_complete", "result_edit", "order_review"):
            self.assertIn(a, actions)
        rows = [dict(r) for r in db.conn().execute("SELECT * FROM audit WHERE ref=?", (lab_id,))]
        blob = json.dumps(rows, ensure_ascii=False)
        for leak in (MARK, "Marker", "سكر", "صورة دم"):
            self.assertNotIn(leak, blob)
        whole = json.dumps([dict(r) for r in db.conn().execute("SELECT detail FROM audit")], ensure_ascii=False)
        self.assertNotIn(MARK, whole)                                                                  # ولا في أي سجل آخر
        self.assertEqual(db.conn().execute("SELECT COUNT(*) FROM notifications WHERE body LIKE ? OR title LIKE ?", ("%" + MARK + "%", "%" + MARK + "%")).fetchone()[0], 0)
        self.assertTrue(all(r["who"].startswith("staff:") for r in rows))
        self.assertEqual(self.st("POST", "/unit/orders/%s/cancel" % rad_id, self.RAD, {"reason": "لا يوجد جهاز"})[0], 200)
        self.assertIn("order_cancel", self.audit(rad_id))

    def test_previous_orders_in_next_visit(self):
        db = self.e.app.db
        mrn, vid, dev = self.visit(self.D, self.docs[0])
        lab_id, rad_id = self.oids(vid)
        self.put(self.LAB, lab_id, {"rows": LAB_ROWS})
        self.complete(self.LAB, lab_id)
        self.review(self.D, lab_id, False)
        self.st("POST", "/clinic/orders/%s/cancel" % rad_id, self.D)
        self.status(vid, "left")
        _, v2 = self.checkin(self.docs[1], mrn=mrn)                                                   # زيارة جديدة عند طبيب آخر
        self.call(self.D2, v2["id"])
        s, det, _ = self.st("GET", "/clinic/visits/" + v2["id"], self.D2)
        self.assertEqual(det["orders"], [])
        self.assertEqual([(o["id"], o["status"], len(o["rows"])) for o in det["prevOrders"]], [(lab_id, "reviewed", 2)])   # الملغى لا يظهر
        self.assertEqual(det["prevOrders"][0]["doctorName"], self.names[self.docs[0]])
        # وطلب القسم لا يتسرب لمراجع آخر
        _, v3 = self.checkin(self.docs[2], mrn=self.newrec("مراجع آخر"))
        self.assertEqual(db.orders_for_mrn(self.e.app.db.visit_get(v3["id"])["mrn"]), [])

    def test_legacy_orders_without_oid(self):
        """زيارات أُنهيت قبل 0.9.0: بنودها في مسودة الزيارة بلا معرّف طلب ولا حالة؛ يجب أن تبقى تُعرض كما كانت."""
        mrn, vid, dev = self.visit(self.D, self.docs[0])
        legacy = [{"type": "lab", "name": "صورة دم كاملة", "note": ""}, {"type": "radiology", "name": "أشعة صدر", "note": "وضع أمامي"}]
        self.sql("DELETE FROM orders WHERE visit_id=?", (vid,))
        self.sql("UPDATE encounters SET orders=? WHERE visit_id=?", (json.dumps(legacy, ensure_ascii=False), vid))
        po = self.patient_orders(vid, dev)
        self.assertEqual([(x["type"], x["name"], x["note"]) for x in po], [("lab", "صورة دم كاملة", ""), ("radiology", "أشعة صدر", "وضع أمامي")])
        self.assertTrue(all("status" not in x and "rows" not in x for x in po))
        s, det, _ = self.st("GET", "/clinic/visits/" + vid, self.D)
        self.assertEqual((s, det["orders"], len(det["encounter"]["orders"])), (200, [], 2))
        board = next(x for x in self.st("GET", "/visits", self.R)[1]["visits"] if x["id"] == vid)
        self.assertEqual((board["orderCount"], board["orderStat"]["total"]), (2, 0))
        self.assertEqual(self.unit(self.LAB, vid), [])

    def test_finish_is_atomic_with_orders(self):
        import db as dbmod
        db = self.e.app.db
        dev, bid = self.book("مراجع الذرّية")
        mrn, v = self.checkin(self.docs[0], "مراجع الذرّية", booking=bid)
        vid = v["id"]
        self.call(self.D, vid)
        self.save(self.D, vid, DX)
        orig = dbmod.DB.__dict__["_send_orders"]

        def boom(*a, **k):
            raise RuntimeError("boom")
        dbmod.DB._send_orders = staticmethod(boom)
        try:
            s, d, _ = self.st("POST", "/clinic/visits/%s/finish" % vid, self.D, {})
        finally:
            dbmod.DB._send_orders = orig
        self.assertGreaterEqual(s, 500)
        self.assertFalse(db.enc_get(vid)["finished_at"])                                               # لم تنتهِ الزيارة
        self.assertEqual((db.visit_get(vid)["status"], db.orders_for_visit(vid)), ("with_doctor", []))
        self.assertEqual(self.results(dev)[1], {"results": []})
        self.finish(self.D, vid)                                                                      # وإعادة المحاولة تنجح
        self.assertEqual(len(db.orders_for_visit(vid)), 2)
        self.assertEqual(db.visit_get(vid)["status"], "done")

    def test_concurrent_start_has_one_winner(self):
        mrn, vid, dev = self.visit(self.D, self.docs[0], LAB_ONLY)
        oid = self.oids(vid)[0]
        res = []

        def go(H):
            res.append(self.st("POST", "/unit/orders/%s/start" % oid, H)[0])
        ts = [threading.Thread(target=go, args=(H,)) for H in (self.LAB, self.LAB2)]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
        self.assertEqual(sorted(res), [200, 409])
        self.assertEqual(self.db_status(oid), "in_progress")

    def test_branch_scope(self):
        db = self.e.app.db
        _, d, _ = self.e.adm("GET", "/entities/doctors")
        spare = [x["id"] for x in d["items"] if (not x.get("branchIds") or self.br[1] in x["branchIds"]) and x["id"] not in self.docs[:2]]
        self.assertTrue(spare)
        D3 = self.ready("doc_ord3", "doctor", "", spare[0])
        REC_ANY = self.ready("rec_any_ord", "reception", "")
        LAB_B1 = self.ready("lab_b1", "lab", self.br[1])
        LAB_ALL = self.ready("lab_all", "lab", "")
        mrn = self.newrec("مراجع الفرع الثاني", H=REC_ANY)
        s, d, _ = self.st("POST", "/visits", REC_ANY, {"mrn": mrn, "doctorId": spare[0], "branchId": self.br[1]})
        self.assertEqual(s, 201, d)
        vid = d["visit"]["id"]
        self.call(D3, vid)
        self.finish(D3, vid, dict(DX, orders=[{"type": "lab", "name": "فحص الفرع الثاني", "note": ""}]))
        oid = self.oids(vid)[0]
        self.assertEqual((db.order_get(oid)["branch_id"], db.order_get(oid)["seq"]), (self.br[1], 1))   # ترقيم الفرع يبدأ من 1
        self.assertEqual(self.unit(self.LAB, vid), [])                                                 # حساب الفرع الأول لا يراه
        self.assertEqual(self.start(self.LAB, oid, expect=404)["error"], "not_found")
        self.assertEqual([o["id"] for o in self.unit(LAB_B1, vid)], [oid])
        self.assertEqual([o["id"] for o in self.unit(LAB_ALL, vid)], [oid])                            # حساب بلا فرع يرى الفروع كلها
        self.assertEqual(self.put(LAB_B1, oid, {"text": "طبيعي"})["order"]["status"], "in_progress")
        self.complete(LAB_B1, oid)
        # الطبيب بلا فرع يراجع نتيجة طلبه
        self.assertIn(oid, [o["id"] for o in self.st("GET", "/clinic/results", D3)[1]["needReview"]])


class TestOrdersAccounts(OrdersBase):
    """وضع الإنتاج (SMS مفعّل): النتيجة لا يراها إلا حساب موثّق ومرتبط بملف المراجع."""
    ENV = {"DS_SMS_PROVIDER": "test"}

    def test_account_visibility(self):
        e, db = self.e, self.e.app.db
        P = patient_login(e, "0565557101")
        Q = patient_login(e, "0565557102")
        mrn = self.newrec("صاحب الحساب", nationalId="1020304051", phone="0565557101")
        self.assertEqual(e.req("POST", "/api/v1/records/link", {"nationalId": "1020304051"}, headers=P)[0], 200)
        _, v = self.checkin(self.docs[0], mrn=mrn)
        vid = v["id"]
        self.call(self.D, vid)
        self.finish(self.D, vid, dict(DX))
        lab_id, rad_id = self.oids(vid)
        self.put(self.LAB, lab_id, {"rows": LAB_ROWS})
        self.complete(self.LAB, lab_id)
        dev = "account_orders_device_0123456"
        # قبل نشر الطبيب: لا شيء. والجهاز وحده لا يكفي في الإنتاج
        self.assertEqual(e.req("GET", "/api/v1/results", headers=P)[1], {"results": []})
        self.review(self.D, lab_id, True)
        self.assertEqual(e.req("GET", "/api/v1/results?deviceId=" + dev)[0], 401)
        self.assertEqual(e.req("GET", "/api/v1/results")[0], 401)
        # صاحب الحساب المرتبط يرى؛ حساب غير مرتبط لا يرى
        s, d, _ = e.req("GET", "/api/v1/results", headers=P)
        self.assertEqual([(x["id"], x["name"]) for x in d["results"]], [(lab_id, "صورة دم كاملة")])
        self.assertEqual(e.req("GET", "/api/v1/results", headers=Q)[1], {"results": []})
        # تفاصيل الزيارة تعرض النتيجة المنشورة لصاحب الحساب وحده
        po = e.req("GET", "/api/v1/visits/" + vid, headers=P)[1]["visit"]["orders"]
        self.assertEqual((po[0]["released"], len(po[0]["rows"]), po[1]["status"]), (True, 2, "sent"))
        self.assertEqual(e.req("GET", "/api/v1/visits/" + vid, headers=Q)[0], 404)
        # فك الربط يسحب الصلاحية فوراً
        e.req("POST", "/api/v1/records/unlink", {"mrn": mrn}, headers=P)
        self.assertEqual(e.req("GET", "/api/v1/results", headers=P)[1], {"results": []})
        e.req("POST", "/api/v1/records/link", {"nationalId": "1020304051"}, headers=P)
        self.assertEqual(len(e.req("GET", "/api/v1/results", headers=P)[1]["results"]), 1)
        # الإشعار للحساب المرتبط فقط وبلا محتوى طبي
        pid = db.patients_of_mrn(mrn)
        self.assertEqual(len(pid), 1)
        n = db.list_notifications(dev, 0, 50, patient_id=pid[0])
        hit = [x for x in n if x["title"] == "نتيجة جديدة"]
        self.assertEqual([(x["ref"], x["kind"]) for x in hit], [("#/results", "result")])
        self.assertNotIn("Hemoglobin", json.dumps(hit, ensure_ascii=False))
        self.assertFalse(any(x["kind"] == "result" for x in db.list_notifications(dev, 0, 50, patient_id=None)))
