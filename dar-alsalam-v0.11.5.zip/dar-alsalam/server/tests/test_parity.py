"""يتأكد أن منفذ الجافاسكربت (web/js/20-kb.js) يعطي نفس نتائج kb.py تماماً على آلاف الأسئلة المولّدة."""
import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from helpers import ROOT
import kb as kbmod

HAND = ["السلام عليكم", "أبي أحجز موعد", "عندي ألم في الأسنان", "وين الفروع؟", "أرقام التواصل", "وش التخصصات؟", "عندي ألم شديد في الصدر", "أبغى دكتور عظام",
        "كم سعر الكشف؟", "هل عندكم تأمين؟", "متى دوامكم؟", "شكراً", "فيه دكتورة نساء وولادة؟", "عندي طفح جلدي", "ابي اسوي تحليل دم", "وين فرع قباء",
        "ما أقدر أتنفس", "ابغى انتحر", "عندي ألم في ركبتي ويش اخذ دواء", "من هو الدكتور ايمن", "عيادة الاطفال", "ابي اشعه", "عندي صداع", "اريد اكل بيتزا",
        "هل الحجز يعني تأكيد الموعد؟", "هل بياناتي محفوظة وخصوصية", "من هي قمر وش تسوي", "قمر", "كم عمر القمر", "كيف ألغي حجزي", "نصيحة للحجاج", "وش نصايح الحر",
        "نصائح صحية", "عندي حمى", "فيروس سي", "ابي احجز اسنان والتحاليل", "هل عندي سكر", "نعم", "لا", "لا ابي", "هلا", "وين الفروع والتخصصات", "ابغى موعد عند دكتور ايمن",
        "ابي احجز عند دكتورة رشا", "وين فرع التلال", "عندكم طوارئ؟", "عندكم دكاترة؟", "متى يفتح فرع قباء", "ابي رقم الواتساب", "من انتم", "وش تقدر تسوي", "ابني ما يتنفس",
        "عندي نزيف شديد", "ابي احجز لان عندي الم في قلبي", "ختان ولدي", "ابي دكتور قلب", "عندي مغص", "ضغط وسكر", "الاسنان والعظام", "", "   ", "؟؟؟", "hello", "x-ray"]


def corpus(seed):
    qs = list(HAND)
    for k in ("specialties", "services"):
        for e in seed[k]:
            for kw in e.get("keywords", []) + [e["name"]]:
                qs += [kw, "عندي " + kw, "ابي احجز " + kw, "وين " + kw, "هل عندكم " + kw, "و" + kw]
    for d in seed["doctors"]:
        parts = d["name"].split()
        qs += [d["name"], "د. " + d["name"], "ابي دكتور " + parts[0], "ابي احجز عند " + " ".join(parts[:2]), parts[-1]]
    for f in seed["faqs"]:
        qs += [f["question"]] + f.get("keywords", []) + ["كيف " + k for k in f.get("keywords", [])]
    lex = json.loads((ROOT / "data" / "lexicon.json").read_text(encoding="utf-8"))
    for name, phrases in lex["intents"].items():
        qs += phrases + ["ابي " + p for p in phrases]
    qs += lex["advice"] + lex["selfHarm"]
    for r in lex["emergency"]:
        for p in r.get("any", []):
            qs.append(p)
        groups = r.get("all", [])
        if groups:
            qs.append(" ".join(g[0] for g in groups))
    for b in seed["branches"]:
        qs += [b["name"], b.get("shortName", ""), b.get("landmark", ""), "وين " + b.get("area", "")]
    out, seen = [], set()
    for q in qs:
        if q not in seen:
            seen.add(q)
            out.append({"q": q})
    hist = [{"role": "assistant", "content": "من كلامك، العيادة الأقرب لما ذكرته هي «الأسنان». تبي أرتّب لك طلب حجز؟"}]
    for q in ("نعم", "ايوه", "اكيد", "تمام", "لا", "ابشر"):
        out.append({"q": q, "history": hist})
    out.append({"q": "نعم", "history": [{"role": "assistant", "content": "تفضل الفروع: قباء والتلال"}]})
    return out


class TestParity(unittest.TestCase):
    def test_js_matches_python(self):
        if not shutil.which("node"):
            self.skipTest("node غير متوفر")
        seed = json.loads((ROOT / "data" / "seed.json").read_text(encoding="utf-8"))
        kb = kbmod.KB(seed, kbmod.Lexicon.load())
        cases = corpus(seed)
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "c.json"
            f.write_text(json.dumps({"cases": cases}, ensure_ascii=False), encoding="utf-8")
            r = subprocess.run(["node", str(ROOT / "tools" / "parity_runner.js"), str(f)], capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stderr)
        js = json.loads(r.stdout)
        self.assertEqual(len(js), len(cases))
        diffs = []
        for c, j in zip(cases, js):
            p = kb.answer(c["q"], c.get("history"))
            if json.dumps(p, sort_keys=True, ensure_ascii=False) != json.dumps(j, sort_keys=True, ensure_ascii=False):
                diffs.append((c, p, j))
        if diffs:
            c, p, j = diffs[0]
            self.fail("%d فروقات من %d. أولها: %r\nPY: %s\nJS: %s" % (len(diffs), len(cases), c, json.dumps(p, ensure_ascii=False)[:600], json.dumps(j, ensure_ascii=False)[:600]))
        print("\nparity ok:", len(cases), "cases")


if __name__ == "__main__":
    unittest.main()
