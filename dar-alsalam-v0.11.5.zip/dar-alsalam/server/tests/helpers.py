import json
import os
import shutil
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "server"))
os.environ["DS_QUIET"] = "1"

import app as appmod  # noqa: E402
import config as cfgmod  # noqa: E402


class Env:
    """خادم حقيقي على منفذ عشوائي مع قاعدة بيانات مؤقتة."""

    def __init__(self, extra=None):
        self.tmp = Path(tempfile.mkdtemp(prefix="ds-test-"))
        env = {"DS_DB": str(self.tmp / "clinic.db"), "DS_PORT": "0", "DS_HOST": "127.0.0.1",
               "DS_SEED": str(ROOT / "data" / "seed.json"), "DS_LEXICON": str(ROOT / "data" / "lexicon.json"),
               "DS_WEB_DIR": str(ROOT / "web"), "DS_ADMIN_DIR": str(ROOT / "admin"), "DS_WIDGET_DIR": str(ROOT / "widget")}
        env.update(extra or {})
        self.cfg = cfgmod.Config(env=env)
        self.srv = appmod.make_server(self.cfg)
        self.app = self.srv.app
        self.app.set_admin_password("test-password-123")
        self.port = self.srv.server_address[1]
        self.base = "http://127.0.0.1:%d" % self.port
        self.t = threading.Thread(target=self.srv.serve_forever, daemon=True)
        self.t.start()

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def req(self, method, path, body=None, headers=None, raw=False):
        data = None if body is None else json.dumps(body).encode("utf-8")
        h = {"Content-Type": "application/json"}
        h.update(headers or {})
        r = urllib.request.Request(self.base + path, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(r, timeout=10) as resp:
                b = resp.read()
                return resp.status, (b if raw else (json.loads(b) if b and resp.headers.get_content_type() == "application/json" else b)), dict(resp.headers)
        except urllib.error.HTTPError as e:
            b = e.read()
            try:
                return e.code, (b if raw else json.loads(b)), dict(e.headers)
            except ValueError:
                return e.code, b, dict(e.headers)

    def admin_token(self, fresh=False):
        if fresh or not getattr(self, "_tok", None):
            s, d, _ = self.req("POST", "/api/admin/login", {"password": "test-password-123"})
            assert s == 200, (s, d)
            self._tok = d["token"]
        return self._tok

    def adm(self, method, path, body=None):
        return self.req(method, "/api/admin" + path, body, {"Authorization": "Bearer " + self.admin_token()})
