"""اختبار أداة النسخة الاحتياطية tools/snapshot_site.py على موقع وهمي محلي (لا يصل لأي موقع حقيقي)."""
import importlib.util
import json
import shutil
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("snapshot_site", ROOT / "tools" / "snapshot_site.py")
snap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(snap)

HOME = """<!doctype html><html lang="ar"><head><meta charset="utf-8"><title>الرئيسية</title>
<link rel="stylesheet" href="/css/site.css"><link rel="icon" href="/img/fav.ico"><script src="/js/app.js"></script></head><body>
<h1>مرحباً بكم</h1><p>نص الصفحة الرئيسية</p><img src="/img/logo.png" srcset="/img/logo@2x.png 2x">
<a href="/ar/doctors">الأطباء</a> <a href="/ar/branches">الفروع</a> <a href="/private/secret">سري</a> <a href="/old">قديم</a>
<a href="/ar/missing">مفقود</a> <a href="https://example.org/x">خارجي</a> <a href="mailto:a@b.c">بريد</a> <a href="tel:920031134">اتصال</a> <a href="#top">أعلى</a>
<a href="/files/big.bin">كبير</a> <a href="/ar/%2e%2e/%2e%2e/etc/passwd">اجتياز</a> <a href="/a/../../../x">اجتياز2</a>
@@Q@@
<script>var secret = "لا يظهر في النص";</script></body></html>"""
PAGES = {
    "/ar": HOME.replace("@@Q@@", "".join('<a href="/ar/doctors?page=%d">p%d</a>' % (i, i) for i in range(1, 21))),
    "/ar/doctors": "<html><body><h2>الأطباء</h2><p>د. أحمد</p><a href='/ar'>الرئيسية</a></body></html>",
    "/ar/branches": "<html><body><h2>الفروع</h2><p>قباء</p></body></html>",
    "/private/secret": "<html><body>لا يجب أن يُنزَّل</body></html>",
}
CSS = "body{background:url(/img/bg.jpg)} .x{background:url('data:image/png;base64,AAAA')} @font-face{src:url(/fonts/a.woff2)}"


class Handler(BaseHTTPRequestHandler):
    hits = []
    methods = []

    def log_message(self, *a):
        pass

    def do_GET(self):
        Handler.hits.append(self.path)
        Handler.methods.append("GET")
        path = self.path.split("?")[0]
        if path == "/robots.txt":
            return self._r(200, "text/plain", b"User-agent: *\nDisallow: /private/\nCrawl-delay: 0\n")
        if path == "/old":
            self.send_response(301)
            self.send_header("Location", "/ar/branches")
            self.send_header("Content-Length", "0")
            return self.end_headers()
        if path in PAGES or path.startswith("/ar/doctors"):
            body = PAGES.get(path) or PAGES["/ar/doctors"]
            return self._r(200, "text/html; charset=utf-8", body.encode("utf-8"))
        if path == "/css/site.css":
            return self._r(200, "text/css", CSS.encode())
        if path in ("/js/app.js", "/img/logo.png", "/img/logo@2x.png", "/img/fav.ico", "/img/bg.jpg", "/fonts/a.woff2"):
            return self._r(200, "application/octet-stream" if "woff" in path else "image/png" if "img" in path else "application/javascript", b"X" * 50)
        if path == "/files/big.bin":
            return self._r(200, "application/octet-stream", b"B" * 20000)
        self._r(404, "text/html", b"nf")

    def do_POST(self):
        Handler.methods.append("POST")
        self._r(405, "text/plain", b"no")

    def _r(self, code, ctype, body):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class TestSnapshot(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        Handler.hits, Handler.methods = [], []
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.tmp = Path(tempfile.mkdtemp(prefix="ds-snap-"))
        cls.out = cls.tmp / "out"
        rc = snap.main(["http://127.0.0.1:%d/ar" % cls.port, "--out", str(cls.out), "--delay", "0", "--max-file-bytes", "10000", "--max-query-variants", "3"])
        cls.rc = rc
        cls.m = json.loads((cls.out / "manifest.json").read_text(encoding="utf-8"))
        cls.by = {r["url"].split(str(cls.port))[1]: r for r in cls.m["files"]}

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_finishes_and_writes_manifest(self):
        self.assertEqual(self.rc, 0)
        self.assertEqual(self.m["tool"], "snapshot_site/1.0")
        self.assertIn("read-only", self.m["user_agent"])

    def test_only_get_requests(self):
        self.assertEqual(set(Handler.methods), {"GET"})

    def test_robots_respected(self):
        self.assertNotIn("/private/secret", Handler.hits)
        self.assertEqual(self.by["/private/secret"]["skipped"], "robots")
        self.assertFalse(any((self.out / "files").rglob("secret*")))

    def test_pages_assets_and_css_urls_saved(self):
        for p in ("/ar", "/ar/doctors", "/ar/branches", "/css/site.css", "/js/app.js", "/img/logo.png", "/img/logo@2x.png", "/img/fav.ico", "/img/bg.jpg", "/fonts/a.woff2"):
            self.assertTrue(self.by[p].get("saved"), p)
        self.assertTrue((self.out / "manifest.json").exists())

    def test_offsite_mailto_tel_fragment_ignored(self):
        self.assertFalse(any("example.org" in r["url"] for r in self.m["files"]))
        self.assertFalse(any(u.startswith(("mailto", "tel", "data:")) for u in (r["url"] for r in self.m["files"])))
        self.assertFalse(any("example.org" in h for h in Handler.hits))

    def test_redirect_followed_within_site(self):
        r = self.by["/old"]
        self.assertEqual(r["redirects"][0]["status"], 301)
        self.assertTrue(r["final_url"].endswith("/ar/branches"))
        self.assertEqual(r["status"], 200)

    def test_404_recorded_not_saved(self):
        r = self.by["/ar/missing"]
        self.assertEqual(r["status"], 404)
        self.assertFalse(r.get("saved"))

    def test_query_variants_capped(self):
        q = [r for r in self.m["files"] if "/ar/doctors?page=" in r["url"]]
        self.assertEqual(sum(1 for r in q if r.get("saved")), 3)
        self.assertTrue(any(r.get("skipped") == "too_many_query_variants" for r in q))

    def test_big_file_skipped(self):
        r = self.by["/files/big.bin"]
        self.assertTrue(str(r.get("skipped", "")).startswith("too_large"))
        self.assertFalse(r.get("saved"))

    def test_text_extraction_excludes_scripts(self):
        files = list((self.out / "text").rglob("*.txt"))
        self.assertTrue(files)
        home = next(f for f in files if "مرحباً بكم" in f.read_text(encoding="utf-8"))
        txt = home.read_text(encoding="utf-8")
        self.assertIn("نص الصفحة الرئيسية", txt)
        self.assertNotIn("لا يظهر في النص", txt)

    def test_nothing_written_outside_out_dir(self):
        for f in self.tmp.rglob("*"):
            self.assertIn(self.out.resolve(), list(f.resolve().parents) + [f.resolve()], str(f))
        self.assertFalse((self.tmp / "etc").exists())
        self.assertFalse(any(p.name == "passwd" for p in self.tmp.rglob("*")))

    def test_sha256_matches_saved_bytes(self):
        import hashlib
        r = self.by["/css/site.css"]
        data = (self.out / r["saved"]).read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(), r["sha256"])


class TestSnapshotGuards(unittest.TestCase):
    def test_refuses_non_http(self):
        with self.assertRaises(SystemExit):
            snap.main(["ftp://example.com", "--out", tempfile.mkdtemp()])

    def test_refuses_when_robots_is_server_error(self):
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                self.send_response(500)
                self.send_header("Content-Length", "0")
                self.end_headers()
        srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        tmp = tempfile.mkdtemp()
        try:
            with self.assertRaises(SystemExit):
                snap.main(["http://127.0.0.1:%d/" % srv.server_address[1], "--out", tmp, "--delay", "0"])
        finally:
            srv.shutdown()
            srv.server_close()
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
