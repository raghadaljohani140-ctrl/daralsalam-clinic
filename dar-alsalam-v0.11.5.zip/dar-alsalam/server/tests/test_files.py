import json
import re
import unittest
import urllib.error
import urllib.request

from helpers import Env
from xlsxmake import make as make_xlsx
from urllib.parse import urlencode

PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n" + b"x" * 300 + b"\n%%EOF\n"
PDF2 = b"%PDF-1.4\n% second version\n" + b"y" * 400 + b"\n%%EOF\n"
PROFILE = {"name": "مراجع اختبار", "gender": "male", "birthDate": "1990-01-01", "nationalId": ""}


def raw_req(e, method, path, data=None, headers=None):
    r = urllib.request.Request(e.base + path, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(r, timeout=10) as resp:
            return resp.status, resp.read(), dict(resp.headers)
    except urllib.error.HTTPError as ex:
        return ex.code, ex.read(), dict(ex.headers)


def login(e, phone):
    e.app.rl.h.clear()
    e.req("POST", "/api/v1/auth/otp", {"phone": phone})
    ph = re.sub(r"^0", "966", phone)
    lines = [json.loads(x) for x in (e.tmp / "sms-test.log").read_text(encoding="utf-8").strip().splitlines()]
    code = re.search(r"(\d{6})", [m for m in lines if m["phone"] == ph][-1]["text"]).group(1)
    s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": phone, "code": code, "profile": PROFILE})
    assert s == 200, d
    return {"Authorization": "Bearer " + d["token"]}


HDR = ["رقم الملف", "الاسم", "الجوال", "الهوية", "تاريخ الميلاد", "الجنس"]
NID_A, NID_B = "1000000001", "1000000002"


def good_rows():
    return [HDR,
            ["M-1001", "مراجع أول", "0565551111", NID_A, "1990-01-01", "ذكر"],
            ["M-1002", "ابنة المراجع", "0565551111", "", "2015-06-30", "أنثى"],
            ["M-2001", "مراجع ثان", "0566662222", NID_B, "1985-03-04", "ذكر"]]


class TestRecordsFiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e = Env({"DS_SMS_PROVIDER": "test"})
        tok = {"Authorization": "Bearer " + cls.e.admin_token(), "Content-Type": "application/octet-stream"}
        s, b, _ = raw_req(cls.e, "POST", "/api/admin/records/import?commit=1&by=" + urllib.request.quote("موظف"), make_xlsx(good_rows()), tok)
        assert s == 200, b
        cls.A = login(cls.e, "0565551111")
        cls.B = login(cls.e, "0566662222")

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def imp(self, data, commit=0, by="موظف", token=True):
        h = {"Content-Type": "application/octet-stream"}
        if token:
            h["Authorization"] = "Bearer " + self.e.admin_token()
        s, b, _ = raw_req(self.e, "POST", "/api/admin/records/import?" + urlencode({"commit": commit, "by": by}), data, h)
        return s, json.loads(b or b"{}")

    def up(self, mrn="M-1001", kind="lab", title="تحليل دم", by="سارة", data=PDF, token=True):
        h = {"Content-Type": "application/pdf"}
        if token:
            h["Authorization"] = "Bearer " + self.e.admin_token()
        s, b, _ = raw_req(self.e, "POST", "/api/admin/files?" + urlencode({"mrn": mrn, "kind": kind, "title": title, "by": by}), data, h)
        return s, json.loads(b or b"{}")

    def adm(self, method, path, body=None):
        return self.e.adm(method, path, body)

    def link(self, H, **body):
        return self.e.req("POST", "/api/v1/records/link", body, headers=H)

    # ---------------------------------------------------------------- الاستيراد
    def test_import_preview_commit_and_errors(self):
        rows = good_rows() + [["M-3001", "جديد", "0577773333", "1000000003", "", ""]]
        s, d = self.imp(make_xlsx(rows), commit=0)
        self.assertEqual((s, d["new"], d["same"], d["updated"], d["committed"]), (200, 1, 3, 0, False))
        self.assertIsNone(self.e.app.db.record_get("M-3001"))  # المعاينة لا تكتب
        s, d = self.imp(make_xlsx(rows), commit=1)
        self.assertEqual((s, d["new"]), (200, 1))
        self.assertIsNotNone(self.e.app.db.record_get("M-3001"))
        # تحديث: الاسم تغيّر، والحقل الفارغ لا يمسح الموجود
        rows[1] = ["M-1001", "مراجع أول معدّل", "0565551111", "", "1990-01-01", ""]
        s, d = self.imp(make_xlsx(rows), commit=1)
        self.assertEqual(d["updated"], 1)
        r = self.e.app.db.record_get("M-1001")
        self.assertEqual((r["name"], r["national_id"], r["birth_date"]), ("مراجع أول معدّل", NID_A, "1990-01-01"))
        # صفوف خاطئة: المعاينة تعرضها بأرقامها والتثبيت يُرفض كاملاً
        bad = good_rows() + [["", "بلا رقم", "0565551111", NID_A, "", ""], ["M-9", "جوال خاطئ", "123", NID_A, "", ""], ["M-1001", "مكرر", "0565551111", NID_A, "", ""]]
        s, d = self.imp(make_xlsx(bad), commit=0)
        self.assertEqual((s, d["errorCount"]), (200, 3))
        self.assertEqual([x["row"] for x in d["errors"]], [5, 6, 7])
        s, d = self.imp(make_xlsx(bad), commit=1)
        self.assertEqual(s, 409)
        self.assertIsNone(self.e.app.db.record_get("M-9"))

    def test_import_guards(self):
        self.assertEqual(self.imp(make_xlsx(good_rows()), token=False)[0], 401)
        self.assertEqual(self.imp(make_xlsx(good_rows()), by="")[0], 422)
        self.assertEqual(self.imp(b"PK\x03\x04 not really zip")[0], 422)
        self.assertEqual(self.imp(make_xlsx([["a", "b"], ["1", "2"]]))[0], 422)  # لا عناوين معروفة
        self.assertEqual(self.imp(make_xlsx([["رقم الملف", "الاسم", "الجوال"], ["M-1", "س", "0565551111"]]))[0], 422)  # لا هوية ولا ميلاد
        csv = "رقم الملف,الاسم,الجوال,الهوية\nM-C1,مراجع csv,0565551111,1000000009\n"
        s, d = self.imp(csv.encode("utf-8"), commit=1)
        self.assertEqual((s, d["new"]), (200, 1))
        # توكن مريض لا يستورد
        s, _, _ = raw_req(self.e, "POST", "/api/admin/records/import?by=xx", make_xlsx(good_rows()), {"Authorization": self.A["Authorization"]})
        self.assertEqual(s, 401)

    def test_manual_record_and_search(self):
        s, d, _ = self.adm("POST", "/records?by=" + urllib.request.quote("موظف"), {"mrn": "M-7001", "name": "إدخال يدوي", "phone": "0588880000", "nationalId": "1000000007"})
        self.assertEqual((s, d["state"]), (200, "new"), d)
        s, d, _ = self.adm("GET", "/records?q=M-7001")
        self.assertEqual([r["mrn"] for r in d["records"]], ["M-7001"])
        s, d, _ = self.adm("GET", "/records?q=" + urllib.request.quote("مراجع"))
        self.assertGreaterEqual(len(d["records"]), 2)
        s, d, _ = self.adm("GET", "/records/NOPE")
        self.assertEqual(s, 404)

    # ---------------------------------------------------------------- الربط
    def test_link_flow_and_isolation(self):
        # قبل الربط: لا ملفات
        s, d = self.up(mrn="M-1001", title="نتيجة أ")
        self.assertEqual(s, 201, d)
        fid = d["file"]["id"]
        s, d, _ = self.e.req("GET", "/api/v1/files", headers=self.A)
        self.assertEqual(d["files"], [])
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.A)[0], 404)
        # عامل خاطئ
        self.assertEqual(self.link(self.A, nationalId="1999999999")[0], 404)
        self.assertEqual(self.link(self.A, birthDate="1970-01-01")[0], 404)
        # صحيح بالهوية: يربط ملف M-1001 فقط
        s, d, _ = self.link(self.A, nationalId=NID_A)
        self.assertEqual((s, [r["mrn"] for r in d["records"]]), (200, ["M-1001"]))
        s, d, _ = self.e.req("GET", "/api/v1/files", headers=self.A)
        self.assertEqual([(x["id"], x["mrn"]) for x in d["files"]], [(fid, "M-1001")])
        s, body, h = raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.A)
        self.assertEqual((s, body, h["Content-Type"]), (200, PDF, "application/pdf"))
        self.assertIn("no-store", h["Cache-Control"])
        # العائلة: ملف الابنة (نفس الجوال) بتاريخ ميلادها
        s, d, _ = self.link(self.A, birthDate="2015-06-30")
        self.assertEqual(sorted(r["mrn"] for r in d["records"]), ["M-1001", "M-1002"])
        # مراجع آخر لا يرى شيئاً ولا يفتح الملف
        s, d, _ = self.e.req("GET", "/api/v1/files", headers=self.B)
        self.assertEqual(d["files"], [])
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.B)[0], 404)
        # حساب آخر لا يستطيع ربط ملف جواله مختلف حتى لو عرف الهوية
        self.assertEqual(self.link(self.B, nationalId=NID_A)[0], 404)
        # إلغاء الربط يخفي الملفات
        self.e.req("POST", "/api/v1/records/unlink", {"mrn": "M-1001"}, headers=self.A)
        self.assertEqual(self.e.req("GET", "/api/v1/files", headers=self.A)[1]["files"], [])
        self.assertEqual(self.e.req("GET", "/api/v1/records/mine", headers=self.A)[1]["records"][0]["mrn"], "M-1002")
        for path in ("/files/" + fid + ".pdf", "/uploads/" + fid + ".pdf", "/data/files/" + fid + ".pdf"):
            self.assertEqual(raw_req(self.e, "GET", path)[0], 404, path)
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid)[0], 401)
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid, headers={"Authorization": "Bearer " + self.e.admin_token()})[0], 401)

    def test_link_rate_limit(self):
        C = login(self.e, "0599990000")
        for _ in range(5):
            self.assertEqual(self.link(C, nationalId="1999999999")[0], 404)
        self.assertEqual(self.link(C, nationalId="1999999999")[0], 429)

    def test_nid_wins_over_birthdate(self):
        # سجل فيه هوية: تاريخ الميلاد وحده لا يكفي إذا أُرسلت هوية خاطئة معه
        D = login(self.e, "0566662222")
        self.assertEqual(self.link(D, nationalId="1999999999", birthDate="1985-03-04")[0], 404)

    # ---------------------------------------------------------------- الرفع والإشعار
    def test_upload_validation(self):
        self.assertEqual(self.up(token=False)[0], 401)
        self.assertEqual(self.up(data=b"<html>x</html>" * 20)[0], 415)
        self.assertEqual(self.up(data=b"%PDF-1.4 no eof " + b"x" * 200)[0], 415)
        self.assertEqual(self.up(kind="nope")[0], 422)
        self.assertEqual(self.up(by="")[0], 422)
        self.assertEqual(self.up(mrn="NOPE-1")[0], 422)  # رقم ملف غير موجود
        self.assertEqual(self.up(kind="prescriptions", title="وصفة")[0], 201)
        import http.client
        c = http.client.HTTPConnection("127.0.0.1", self.e.port, timeout=10)
        c.putrequest("POST", "/api/admin/files?mrn=M-1001&kind=lab&title=xx&by=yy")
        c.putheader("Authorization", "Bearer " + self.e.admin_token())
        c.putheader("Content-Length", str(13 * 1024 * 1024))
        c.endheaders()
        self.assertEqual(c.getresponse().status, 413)
        c.close()

    def test_notification_on_upload_only_to_linked(self):
        E = login(self.e, "0566662222")
        self.link(E, nationalId=NID_B)
        did = "d" * 20
        s, d = self.up(mrn="M-2001", kind="radiology", title="أشعة صدر")
        self.assertEqual(s, 201)
        s, n, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + did, headers=E)
        mine = [x for x in n["notifications"] if x["kind"] == "file"]
        self.assertEqual((len(mine), mine[0]["ref"]), (1, "#/files/radiology"))
        self.assertIn("أشعة صدر", mine[0]["body"])
        # بلا توكن أو بحساب آخر: لا تظهر
        s, n, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + did)
        self.assertEqual([x for x in n["notifications"] if x["kind"] == "file"], [])
        s, n, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + did, headers=self.A)
        self.assertEqual([x for x in n["notifications"] if x["kind"] == "file" and "أشعة" in x["body"]], [])

    def test_replace_update_delete_with_audit(self):
        self.link(self.A, nationalId=NID_A)
        s, d = self.up(mrn="M-1001", title="للاستبدال", by="موظف أول")
        fid = d["file"]["id"]
        self.assertEqual((d["file"]["uploadedBy"], d["file"]["mrn"]), ("موظف أول", "M-1001"))
        tok = {"Authorization": "Bearer " + self.e.admin_token(), "Content-Type": "application/pdf"}
        s, b, _ = raw_req(self.e, "POST", "/api/admin/files/%s/replace?by=%s" % (fid, urllib.request.quote("موظف ثان")), PDF2, tok)
        self.assertEqual(s, 200, b)
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.A)[1], PDF2)
        s, d, _ = self.adm("POST", "/files/%s/update?by=%s" % (fid, urllib.request.quote("موظف ثالث")), {"kind": "prescriptions", "title": "وصفة جديدة"})
        self.assertEqual((s, d["file"]["kindLabel"]), (200, "الوصفات الطبية"))
        self.assertEqual(self.adm("DELETE", "/files/%s?by=" % fid)[0], 422)
        self.assertEqual(self.adm("DELETE", "/files/%s?by=%s" % (fid, urllib.request.quote("موظف رابع")))[0], 200)
        self.assertEqual(raw_req(self.e, "GET", "/api/v1/files/" + fid, headers=self.A)[0], 404)
        s, d, _ = self.adm("GET", "/records/M-1001?deleted=1")
        rec = next(x for x in d["files"] if x["id"] == fid)
        self.assertEqual((rec["deletedBy"], rec["updatedBy"]), ("موظف رابع", "موظف ثالث"))
        acts = [r["action"] for r in self.e.app.db.conn().execute("SELECT action FROM audit WHERE ref=?", (fid,))]
        for a in ("file_upload", "file_replace", "file_update", "file_delete", "file_view"):
            self.assertIn(a, acts)

    def test_meta_and_disabled(self):
        _, ds, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertTrue(ds["meta"]["files"]["enabled"])
        self.assertEqual(len(ds["meta"]["files"]["kinds"]), 11)
        e = Env()
        try:
            self.assertEqual(e.req("GET", "/api/v1/files")[0], 503)
            self.assertEqual(e.req("POST", "/api/v1/records/link", {"nationalId": "1"})[0], 503)
        finally:
            e.close()

    def test_api_source_stub(self):
        """مصدر API: يجلب سجلات الجوال من خادم خارجي (وهمي هنا) ويخزنها محلياً ثم يعمل الربط. لم يُجرَّب مع نظام فعلي."""
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        class H(BaseHTTPRequestHandler):
            def do_GET(s):
                ok = s.headers.get("Authorization") == "Bearer k-test" and "phone=966544440000" in s.path
                body = json.dumps({"patients": [{"mrn": "X-1", "name": "من النظام", "phone": "0544440000", "nationalId": "1000000055"}] if ok else []}).encode()
                s.send_response(200)
                s.send_header("Content-Type", "application/json")
                s.end_headers()
                s.wfile.write(body)

            def log_message(s, *a):
                pass
        srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        e = Env({"DS_SMS_PROVIDER": "test", "DS_RECORDS_SOURCE": "api", "DS_RECORDS_API_URL": "http://127.0.0.1:%d" % srv.server_port, "DS_RECORDS_API_TOKEN": "k-test"})
        try:
            P = login(e, "0544440000")
            s, d, _ = e.req("POST", "/api/v1/records/link", {"nationalId": "1000000055"}, headers=P)
            self.assertEqual((s, d["records"][0]["mrn"]), (200, "X-1"))
            self.assertEqual(e.app.db.record_get("X-1")["source"], "api")
            # خادم النظام لا يعرف هذا الجوال ولا سجل محلي: لا ربط
            Q = login(e, "0544441111")
            self.assertEqual(e.req("POST", "/api/v1/records/link", {"nationalId": "1000000055"}, headers=Q)[0], 404)
        finally:
            e.close()
            srv.shutdown()

    def test_legacy_phone_files_migrate(self):
        import sqlite3, tempfile, pathlib, sys
        sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
        import db as dbmod
        p = pathlib.Path(tempfile.mkdtemp()) / "old.db"
        c = sqlite3.connect(p)
        c.executescript("CREATE TABLE patient_files(id TEXT PRIMARY KEY, phone TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL, note TEXT, size INTEGER NOT NULL, sha256 TEXT NOT NULL, uploaded_by TEXT NOT NULL, uploaded_at TEXT NOT NULL, updated_by TEXT, updated_at TEXT, deleted_by TEXT, deleted_at TEXT);"
                        "INSERT INTO patient_files VALUES('f-" + "a" * 32 + "','966565551111','lab','قديم','',1,'x','س','2026-01-01',NULL,NULL,NULL,NULL);")
        c.commit()
        c.close()
        d = dbmod.DB(p)
        f = d.file_get("f-" + "a" * 32)
        self.assertEqual(f["mrn"], "LEGACY-565551111")
        self.assertEqual(d.record_get(f["mrn"])["phone"], "966565551111")


if __name__ == "__main__":
    unittest.main()
