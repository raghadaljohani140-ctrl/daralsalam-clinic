"""حسابات المراجعين بكلمة مرور (0.11.0): تسجيل جديد بالبيانات الطبية المتعارف عليها ← دخول ← حجز مرتبط بالحساب.
تشمل: التحقق الصارم من الحقول، القفل بعد المحاولات الخاطئة، إبطال الجلسات عند تغيير كلمة المرور، إدارة الحسابات من الإدارة،
حماية الملف الطبي (لا ربط ولا نتائج لحساب جواله غير موثّق)، وترحيل قاعدة بيانات قديمة."""
import json
import re
import shutil
import sqlite3
import tempfile
import unittest
from pathlib import Path
from urllib.parse import quote

from helpers import Env, ROOT
from test_api import booking_body, DEV, DEV2
from test_auth import last_code
from test_schedule import SchedBase, day
from test_staff import PW as STAFF_PW

import accounts as acc  # noqa: E402
import app as appmod  # noqa: E402
import config as cfgmod  # noqa: E402
import db as dbmod  # noqa: E402

PW = "Salam2026x"
FAST = {"DS_PW_ITERS": "1000"}          # اختبارات سريعة؛ القيمة الافتراضية الحقيقية تُفحص في test_default_cost_is_strong


def profile(**over):
    p = {"nationality": "سعودي", "email": "", "city": "المدينة المنورة",
         "emergency": {"name": "فهد العتيبي", "relation": "أخ/أخت", "phone": "0551110002"},
         "health": {"bloodType": "O+", "allergies": {"none": False, "text": "بنسلين"},
                    "chronic": {"none": False, "items": ["diabetes", "hypertension"], "other": ""},
                    "medications": {"none": False, "text": "ميتفورمين 500"}, "surgeries": {"none": True, "text": ""}, "pregnancy": ""},
         "insurance": {"company": "بوبا", "memberNo": "BP-12345"}}
    p.update(over)
    return p


def reg_body(phone="0551110001", **over):
    b = {"phone": phone, "password": PW, "password2": PW, "name": "سعد العتيبي", "gender": "male", "birthDate": "1990-05-17", "nationalId": "",
         "profile": profile(), "consent": {"privacy": True, "health": True}}
    b.update(over)
    return b


def auth(tok):
    return {"Authorization": "Bearer " + tok}


class AccBase(unittest.TestCase):
    ENV = FAST

    @classmethod
    def setUpClass(cls):
        cls.e = Env(cls.ENV)
        s, d, _ = cls.e.adm("PUT", "/auth", {"mode": "password"})
        assert s == 200 and d["method"] == "password", (s, d)
        cls.n = 0

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def setUp(self):
        self.e.app.rl.h.clear()

    def phone(self):
        type(self).n += 1
        return "05511%05d" % self.n

    def register(self, phone=None, expect=201, **over):
        phone = phone or self.phone()
        s, d, _ = self.e.req("POST", "/api/v1/auth/register", reg_body(phone, **over))
        self.assertEqual(s, expect, d)
        return phone, d

    def login(self, phone, pw=PW, expect=200):
        s, d, _ = self.e.req("POST", "/api/v1/auth/login", {"phone": phone, "password": pw})
        self.assertEqual(s, expect, d)
        return d

    def me(self, tok, expect=200):
        s, d, _ = self.e.req("GET", "/api/v1/auth/me", headers=auth(tok))
        self.assertEqual(s, expect, d)
        return d


# ====================================================================== الدوال النقية
class TestValidators(unittest.TestCase):
    def test_password_policy(self):
        bad = ["", "abc", "1234567", "12345678", "123456789012", "password", "Password1".lower(), "aaaaaaaa", "abababab", " Salam2026x", "Salam2026x ",
               "x" * 101, None, 12345678]
        for pw in bad:
            self.assertTrue(acc.pw_problem(pw), repr(pw))
        for pw in ["Salam2026x", "جمال-الطيب 7", "كلمة مرور طويلة وسهلة", "ab12cd34"]:
            self.assertEqual(acc.pw_problem(pw, "966551112233"), "", pw)
        # لا تحتوي رقم الجوال أو الهوية
        self.assertTrue(acc.pw_problem("pw0551112233", "966551112233"))
        self.assertTrue(acc.pw_problem("pw551112233x", "966551112233"))
        self.assertTrue(acc.pw_problem("abc1012345678z", "966551112233", "1012345678"))

    def test_temp_password_always_passes_policy(self):
        for _ in range(300):
            pw = acc.temp_password()
            self.assertEqual(len(pw), 10)
            self.assertEqual(acc.pw_problem(pw), "")
            self.assertFalse(set(pw) & set("0O1lI"), pw)

    def test_profile_whitelist_and_hidden_chars(self):
        f = {}
        raw = profile(isAdmin=True, nationality="سعودي‮<script>")
        raw["health"]["secret"] = "x"
        raw["health"]["allergies"] = {"none": False, "text": "بنسلين\n\n\tوغبار​", "evil": 1}
        out = acc.clean_profile(raw, "male", f)
        self.assertEqual(f, {})
        self.assertNotIn("isAdmin", out)
        self.assertNotIn("secret", out["health"])
        self.assertEqual(out["health"]["allergies"], {"none": False, "text": "بنسلين وغبار"})
        self.assertNotIn("‮", out["nationality"])                  # محارف اتجاه خفية تُحذف (تُستعمل لتزوير العرض)
        self.assertEqual(set(out), {"nationality", "city", "email", "emergency", "health", "insurance"})

    def test_required_health_answers_need_explicit_choice(self):
        f = {}
        acc.clean_profile({"health": {}}, "male", f)
        self.assertEqual(set(f), {"allergies", "chronic", "medications"})
        f = {}
        acc.clean_profile({"health": {"allergies": {"none": False, "text": ""}, "chronic": {"none": False, "items": [], "other": ""},
                                      "medications": {"none": "no"}}}, "male", f)
        self.assertEqual(set(f), {"allergies", "chronic", "medications"})
        f = {}
        acc.clean_profile({"health": {}}, "male", f, required_health=False)
        self.assertEqual(f, {})

    def test_field_rules(self):
        f = {}
        acc.clean_profile(profile(email="no-at-sign", city="x" * 50), "male", f)
        self.assertEqual(set(f), {"email", "city"})
        f = {}
        raw = profile()
        raw["health"]["bloodType"] = "Z+"
        raw["health"]["chronic"] = {"none": False, "items": ["diabetes", "made-up"], "other": ""}
        raw["emergency"] = {"name": "فهد", "relation": "جار", "phone": "123"}
        raw["insurance"] = {"company": "", "memberNo": "ab"}
        acc.clean_profile(raw, "female", f)
        self.assertEqual(set(f), {"bloodType", "chronic", "emRelation", "emPhone", "insCompany", "insNo"})
        # الحمل للإناث فقط: عند الذكر يُمسح بلا خطأ
        f = {}
        raw = profile()
        raw["health"]["pregnancy"] = "pregnant"
        self.assertEqual(acc.clean_profile(raw, "male", f)["health"]["pregnancy"], "")
        self.assertEqual(acc.clean_profile(raw, "female", f)["health"]["pregnancy"], "pregnant")
        self.assertEqual(f, {})
        raw["health"]["pregnancy"] = "maybe"
        acc.clean_profile(raw, "female", f)
        self.assertIn("pregnancy", f)

    def test_default_cost_is_strong(self):
        self.assertGreaterEqual(cfgmod.Config(env={}).pw_iters, 600000)


# ====================================================================== الوضع (من الإدارة)
class TestMode(unittest.TestCase):
    def test_off_by_default_booking_still_open(self):
        e = Env(FAST)
        try:
            _, ds, _ = e.req("GET", "/api/v1/clinic")
            self.assertEqual(ds["meta"]["auth"], {"enabled": False, "method": ""})
            for path in ("/register", "/login", "/otp", "/verify"):
                s, d, _ = e.req("POST", "/api/v1/auth" + path, {})
                self.assertEqual((s, d["error"]), (503, "auth_disabled"), path)
            s, _, _ = e.req("POST", "/api/v1/bookings", booking_body())
            self.assertEqual(s, 201)
        finally:
            e.close()

    def test_admin_switch_updates_app_immediately(self):
        e = Env(FAST)
        try:
            self.assertEqual(e.req("GET", "/api/admin/auth")[0], 401)
            self.assertEqual(e.req("PUT", "/api/admin/auth", {"mode": "password"})[0], 401)
            self.assertEqual(e.req("GET", "/api/admin/accounts")[0], 401)
            s, d, _ = e.adm("GET", "/auth")
            self.assertEqual((s, d["mode"], d["method"], d["smsEnabled"]), (200, "off", "", False))
            for bad in ({}, {"mode": "sms"}, {"mode": ""}, {"mode": 1}):
                self.assertEqual(e.adm("PUT", "/auth", bad)[0], 422, bad)
            _, ds0, h0 = e.req("GET", "/api/v1/clinic")
            s, d, _ = e.adm("PUT", "/auth", {"mode": "password"})
            self.assertEqual((s, d["method"]), (200, "password"))
            _, ds, h1 = e.req("GET", "/api/v1/clinic")
            a = ds["meta"]["auth"]
            self.assertEqual((a["enabled"], a["method"], a["consentVersion"]), (True, "password", acc.CONSENT_VER))
            self.assertEqual([c["id"] for c in a["chronic"]], list(acc.CHRONIC_IDS))
            self.assertIn("O+", a["bloodTypes"])
            self.assertNotEqual(h0.get("ETag"), h1.get("ETag"))
            # حجز بلا حساب صار مرفوضاً، وإيقاف الوضع يعيده كما كان
            s, d, _ = e.req("POST", "/api/v1/bookings", booking_body())
            self.assertEqual((s, d["error"]), (401, "login_required"))
            self.assertEqual(e.adm("PUT", "/auth", {"mode": "off"})[1]["method"], "")
            self.assertEqual(e.req("POST", "/api/v1/bookings", booking_body())[0], 201)
            self.assertEqual(e.req("POST", "/api/v1/auth/login", {"phone": "0551110001", "password": PW})[1]["error"], "auth_disabled")
            audit = [a for a in e.adm("GET", "/audit")[1]["audit"] if a["action"] == "auth_mode"]
            self.assertEqual([a["ref"] for a in audit][:2], ["off", "password"])
        finally:
            e.close()

    def test_sms_provider_takes_over_and_password_endpoints_close(self):
        e = Env(dict(FAST, DS_SMS_PROVIDER="test"))
        try:
            e.adm("PUT", "/auth", {"mode": "password"})
            _, ds, _ = e.req("GET", "/api/v1/clinic")
            self.assertEqual(ds["meta"]["auth"], {"enabled": True, "method": "sms"})
            self.assertEqual(e.req("POST", "/api/v1/auth/register", reg_body())[1]["error"], "auth_disabled")
            self.assertEqual(e.req("POST", "/api/v1/auth/login", {"phone": "0551110001", "password": PW})[1]["error"], "auth_disabled")
        finally:
            e.close()


# ====================================================================== التسجيل والدخول
class TestRegisterLogin(AccBase):
    def test_register_returns_session_and_profile_but_no_secrets(self):
        phone, d = self.register()
        self.assertTrue(d["token"])
        p = d["patient"]
        self.assertEqual((p["name"], p["phone"], p["gender"], p["birthDate"], p["verified"]), ("سعد العتيبي", "966" + phone[1:], "male", "1990-05-17", False))
        self.assertEqual(d["profile"]["health"]["allergies"], {"none": False, "text": "بنسلين"})
        self.assertEqual(d["profile"]["health"]["chronic"]["items"], ["diabetes", "hypertension"])
        self.assertEqual(d["consent"]["version"], acc.CONSENT_VER)
        self.assertFalse(d["mustChange"])
        raw = json.dumps(d, ensure_ascii=False)
        for secret in (PW, '"pw"', "salt", "pbkdf2"):
            self.assertNotIn(secret, raw)
        me = self.me(d["token"])
        self.assertEqual(me["profile"], d["profile"])

    def test_password_is_never_stored_or_logged_in_clear(self):
        phone, d = self.register(password="UniqueSecret9z", password2="UniqueSecret9z")
        self.assertTrue(self.login(phone, "UniqueSecret9z")["token"])
        db = self.e.app.db
        pid = d["patient"]["id"]
        rec = db.patient_auth_get(pid)["pw"]
        self.assertEqual((rec["iter"], len(rec["salt"]), len(rec["hash"])), (1000, 32, 64))
        blob = b""
        for suffix in ("", "-wal"):
            f = self.e.tmp / ("clinic.db" + suffix)
            if f.exists():
                blob += f.read_bytes()
        self.assertNotIn(b"UniqueSecret9z", blob)
        for r in db.conn().execute("SELECT * FROM audit"):
            self.assertNotIn("UniqueSecret9z", json.dumps(dict(r), ensure_ascii=False))

    def test_duplicate_phone_is_rejected_and_formats_collapse(self):
        phone, _ = self.register()
        for variant in (phone, "+966" + phone[1:], "966" + phone[1:], phone[1:]):
            s, d, _ = self.e.req("POST", "/api/v1/auth/register", reg_body(variant))
            self.assertEqual((s, d["error"]), (409, "phone_exists"), variant)
        self.assertEqual(self.e.app.db.conn().execute("SELECT COUNT(*) FROM patients WHERE phone=?", ("966" + phone[1:],)).fetchone()[0], 1)

    def test_validation_reports_every_bad_field_and_creates_nothing(self):
        before = self.e.app.db.patients_count()["total"]
        body = reg_body("12345", password="123", password2="456", name="س", gender="x", birthDate="2999-01-01", nationalId="55",
                        profile={"health": {}}, consent={"privacy": True})
        s, d, _ = self.e.req("POST", "/api/v1/auth/register", body)
        self.assertEqual(s, 422)
        self.assertGreaterEqual(set(d["fields"]), {"phone", "password", "name", "gender", "birthDate", "nationalId", "allergies", "chronic", "medications", "consentHealth"})
        self.assertNotIn("consentPrivacy", d["fields"])
        self.assertEqual(self.e.app.db.patients_count()["total"], before)
        # كلمتا المرور غير المتطابقتين
        s, d, _ = self.e.req("POST", "/api/v1/auth/register", reg_body(self.phone(), password2=PW + "x"))
        self.assertEqual((s, list(d["fields"])), (422, ["password2"]))
        # الموافقتان إلزاميتان معاً
        for consent in ({}, {"privacy": True}, {"health": True}, {"privacy": "yes", "health": "yes"}, None, "yes"):
            s, d, _ = self.e.req("POST", "/api/v1/auth/register", reg_body(self.phone(), consent=consent))
            self.assertEqual(s, 422, consent)
            self.assertTrue({"consentPrivacy", "consentHealth"} & set(d["fields"]), consent)

    def test_unknown_keys_never_reach_storage(self):
        prof = profile(role="admin", health=dict(profile()["health"], diagnosis="مخفي"))
        phone, d = self.register(profile=prof, isAdmin=True, phone_verified=1, verified=True)
        pt = self.e.app.db.patient_by_phone("966" + phone[1:])
        self.assertEqual(pt["phone_verified"], 0)                                   # الجوال غير موثّق مهما أرسل العميل
        data = self.e.app.db.patient_profile_get(pt["id"])["data"]
        self.assertNotIn("role", data)
        self.assertNotIn("diagnosis", data["health"])

    def test_login_flow_and_identical_failure_for_unknown_and_wrong(self):
        phone, d = self.register()
        ok = self.login(phone)
        self.assertEqual(ok["patient"]["id"], d["patient"]["id"])
        self.assertEqual(ok["profile"], d["profile"])
        self.assertTrue(self.login("+966" + phone[1:])["token"])                  # أي صيغة للرقم
        s1, wrong, _ = self.e.req("POST", "/api/v1/auth/login", {"phone": phone, "password": "wrong-pass-1"})
        s2, unknown, _ = self.e.req("POST", "/api/v1/auth/login", {"phone": "0559999999", "password": "wrong-pass-1"})
        self.assertEqual((s1, s2), (401, 401))
        self.assertEqual(wrong, unknown)                                          # لا فرق يكشف أي الأرقام مسجّل
        self.assertEqual(wrong["error"], "bad_credentials")
        for body in ({}, {"phone": phone}, {"password": PW}, {"phone": "123", "password": PW}, {"phone": phone, "password": ""}, {"phone": phone, "password": 5}):
            self.assertEqual(self.e.req("POST", "/api/v1/auth/login", body)[0], 422, body)

    def test_lockout_after_five_failures_then_admin_unlock(self):
        phone, d = self.register()
        for i in range(5):
            self.login(phone, "bad-password-%d" % i, expect=401)
        s, r, _ = self.e.req("POST", "/api/v1/auth/login", {"phone": phone, "password": PW})
        self.assertEqual((s, r["error"]), (429, "locked"))                        # حتى بكلمة المرور الصحيحة
        row = [a for a in self.e.adm("GET", "/accounts?q=" + phone)[1]["accounts"] if a["id"] == d["patient"]["id"]][0]
        self.assertTrue(row["locked"])
        self.assertEqual(self.e.adm("POST", "/accounts/%s/unlock" % d["patient"]["id"])[0], 200)
        self.assertTrue(self.login(phone)["token"])
        # الرقم غير المسجّل يُقفل بنفس الشكل (لا يُعرف إن كان مسجّلاً)
        for _ in range(5):
            self.login("0558888888", "bad-password-x", expect=401)
        s, r, _ = self.e.req("POST", "/api/v1/auth/login", {"phone": "0558888888", "password": PW})
        self.assertEqual((s, r["error"]), (429, "locked"))

    def test_success_resets_the_failure_counter(self):
        phone, _ = self.register()
        for _ in range(4):
            self.login(phone, "bad-password-1", expect=401)
        self.login(phone)
        for _ in range(4):
            self.login(phone, "bad-password-2", expect=401)
        self.login(phone)

    def test_registration_is_rate_limited_per_ip(self):
        for i in range(10):
            self.register("05522%05d" % i)
        s, d, _ = self.e.req("POST", "/api/v1/auth/register", reg_body("0552299999"))
        self.assertEqual(s, 429)

    def test_change_password_invalidates_every_older_session(self):
        phone, d = self.register()
        tok_a = d["token"]
        tok_b = self.login(phone)["token"]                                       # جهاز آخر
        s, r, _ = self.e.req("POST", "/api/v1/auth/password", {"current": "not-my-password", "new": "NewPass2027y"}, auth(tok_a))
        self.assertEqual((s, r["error"]), (401, "bad_password"))
        for new in ("123", "12345678", PW):                                      # ضعيفة، أرقام فقط، مثل الحالية
            self.assertEqual(self.e.req("POST", "/api/v1/auth/password", {"current": PW, "new": new}, auth(tok_a))[0], 422, new)
        self.assertEqual(self.e.req("POST", "/api/v1/auth/password", {"current": PW, "new": "NewPass2027y"})[0], 401)      # بلا جلسة
        s, r, _ = self.e.req("POST", "/api/v1/auth/password", {"current": PW, "new": "NewPass2027y"}, auth(tok_a))
        self.assertEqual(s, 200, r)
        self.me(tok_a, expect=401)                                                # الرمز القديم بطل
        self.me(tok_b, expect=401)                                                # وكذلك جهاز آخر
        self.me(r["token"])                                                       # الرمز الجديد يعمل
        self.login(phone, PW, expect=401)
        self.assertTrue(self.login(phone, "NewPass2027y")["token"])

    def test_profile_update_keeps_consent_and_validates(self):
        phone, d = self.register()
        tok = d["token"]
        body = {"name": "سعد محمد العتيبي", "gender": "male", "birthDate": "1990-05-17", "profile": profile()}
        body["profile"]["health"]["allergies"] = {"none": True, "text": ""}
        body["profile"]["health"]["bloodType"] = "AB-"
        s, r, _ = self.e.req("POST", "/api/v1/auth/me", body, auth(tok))
        self.assertEqual(s, 200, r)
        self.assertEqual((r["patient"]["name"], r["profile"]["health"]["allergies"]["none"], r["profile"]["health"]["bloodType"]), ("سعد محمد العتيبي", True, "AB-"))
        self.assertEqual(r["consent"]["version"], acc.CONSENT_VER)               # الموافقة السابقة باقية (لا تُطلب من جديد)
        bad = dict(body, profile=profile(health={}))
        s, r, _ = self.e.req("POST", "/api/v1/auth/me", bad, auth(tok))
        self.assertEqual((s, set(r["fields"])), (422, {"allergies", "chronic", "medications"}))
        self.assertEqual(self.me(tok)["profile"]["health"]["bloodType"], "AB-")  # الفاشل لم يغيّر شيئاً
        # تحديث بلا ملف صحي (الواجهة القديمة): الاسم فقط ولا يمسح الملف
        s, r, _ = self.e.req("POST", "/api/v1/auth/me", {"name": "سعد الجديد", "gender": "male", "birthDate": "1990-05-17"}, auth(tok))
        self.assertEqual((s, r["patient"]["name"], r["profile"]["health"]["bloodType"]), (200, "سعد الجديد", "AB-"))

    def test_profile_requires_consent_when_none_recorded(self):
        # حساب أُنشئ بلا ملف صحي (كحساب رمز SMS قديم): أول حفظ للملف يشترط الموافقة
        db = self.e.app.db
        pt = db.patient_register("966551119999", "مراجع قديم", "male", "1980-01-01", None, {"salt": "00" * 16, "hash": "00" * 32, "iter": 1000}, {}, acc.CONSENT_VER)
        with db.tx() as c:
            c.execute("DELETE FROM patient_profiles WHERE patient_id=?", (pt["id"],))
        tok = self.e.app.make_patient_token(pt["id"])
        body = {"name": "مراجع قديم", "gender": "male", "birthDate": "1980-01-01", "profile": profile()}
        s, r, _ = self.e.req("POST", "/api/v1/auth/me", body, auth(tok))
        self.assertEqual((s, {"consentPrivacy", "consentHealth"} <= set(r["fields"])), (422, True))
        s, r, _ = self.e.req("POST", "/api/v1/auth/me", dict(body, consent={"privacy": True, "health": True}), auth(tok))
        self.assertEqual((s, r["consent"]["version"]), (200, acc.CONSENT_VER))

    def test_delete_account_removes_everything_and_frees_the_phone(self):
        phone, d = self.register()
        pid, tok = d["patient"]["id"], d["token"]
        s, b, _ = self.e.req("POST", "/api/v1/bookings", booking_body(), auth(tok))
        self.assertEqual(s, 201, b)
        self.assertEqual(self.e.req("POST", "/api/v1/auth/delete", {}, auth(tok))[0], 200)
        c = self.e.app.db.conn()
        for table, col in (("patients", "id"), ("patient_auth", "patient_id"), ("patient_profiles", "patient_id")):
            self.assertEqual(c.execute("SELECT COUNT(*) FROM %s WHERE %s=?" % (table, col), (pid,)).fetchone()[0], 0, table)
        bk = self.e.app.db.get_booking(b["booking"]["id"])
        self.assertEqual((bk["name"], bk["phone"], bk["patient_id"]), ("(محذوف)", "", None))
        self.me(tok, expect=401)
        self.login(phone, expect=401)
        self.register(phone)                                                      # يمكن التسجيل من جديد بالرقم نفسه

    def test_lone_surrogates_are_a_clean_400_not_a_server_error(self):
        import urllib.error
        import urllib.request

        def post(path, text):
            r = urllib.request.Request(self.e.base + path, data=text.encode("utf-8"), method="POST", headers={"Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(r, timeout=10) as resp:
                    return resp.status, json.loads(resp.read())
            except urllib.error.HTTPError as ex:
                return ex.code, json.loads(ex.read())

        phone, _ = self.register()
        for path, text in (("/api/v1/auth/login", '{"phone": "%s", "password": "\\ud800abcdefgh"}' % phone),
                           ("/api/v1/auth/register", json.dumps(reg_body(self.phone()), ensure_ascii=False).replace('"المدينة المنورة"', '"\\ud800x"')),
                           ("/api/v1/auth/register", json.dumps(reg_body(self.phone()), ensure_ascii=False).replace('"سعد العتيبي"', '"\\ud800سعد"'))):
            s, d = post(path, text)
            self.assertEqual((s, d["error"]), (400, "bad_json"), path)
        # الرمز التعبيري الصحيح (زوج UTF-16 مكتمل) مقبول ويُحفظ
        body = json.dumps(reg_body(self.phone()), ensure_ascii=False).replace("بنسلين", "بنسلين \\ud83d\\ude00")
        s, d = post("/api/v1/auth/register", body)
        self.assertEqual(s, 201, d)
        self.assertIn("\U0001F600", d["profile"]["health"]["allergies"]["text"])

    def test_forged_or_tampered_tokens_are_refused(self):
        _, d = self.register()
        tok = d["token"]
        self.me(tok + "x", expect=401)
        head, sig = tok.split(".")
        self.me(head + "." + "0" * len(sig), expect=401)
        import base64
        pl = json.loads(base64.urlsafe_b64decode(head + "=" * (-len(head) % 4)))
        pl["pv"] = 0
        forged = base64.urlsafe_b64encode(json.dumps(pl).encode()).decode().rstrip("=") + "." + sig
        self.me(forged, expect=401)
        self.me("", expect=401)


# ====================================================================== الحجز مرتبط بالحساب
class TestBookingWithAccount(AccBase):
    def test_booking_needs_login_and_uses_account_identity(self):
        phone, d = self.register(name="سعد العتيبي")
        tok = d["token"]
        s, r, _ = self.e.req("POST", "/api/v1/bookings", booking_body())
        self.assertEqual((s, r["error"]), (401, "login_required"))
        self.assertEqual(self.e.req("POST", "/api/v1/bookings", booking_body(), auth("bad.token"))[0], 401)
        s, r, _ = self.e.req("POST", "/api/v1/bookings", booking_body(name="اسم مزوّر", phone="0500000000"), auth(tok))
        self.assertEqual(s, 201, r)
        bk = self.e.app.db.get_booking(r["booking"]["id"])
        self.assertEqual((bk["name"], bk["phone"], bk["patient_id"]), ("سعد العتيبي", "966" + phone[1:], d["patient"]["id"]))

    def test_my_bookings_follow_the_account_across_devices(self):
        phone, d = self.register()
        tok = d["token"]
        s, r, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=DEV), auth(tok))
        bid = r["booking"]["id"]
        # جهاز آخر + نفس الحساب: يرى الحجز ويستطيع إلغاءه
        s, l, _ = self.e.req("GET", "/api/v1/bookings?deviceId=" + DEV2, headers=auth(tok))
        self.assertEqual([b["id"] for b in l["bookings"]], [bid])
        # جهاز آخر بلا حساب أو بحساب غيره: لا يرى شيئاً
        self.assertEqual(self.e.req("GET", "/api/v1/bookings?deviceId=" + DEV2)[1]["bookings"], [])
        _, other = self.register()
        self.assertEqual(self.e.req("GET", "/api/v1/bookings?deviceId=" + DEV2, headers=auth(other["token"]))[1]["bookings"], [])
        s, r, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % bid, {"deviceId": DEV2}, auth(other["token"]))
        self.assertEqual(s, 404)
        self.assertEqual(self.e.req("POST", "/api/v1/bookings/%s/cancel" % bid, {"deviceId": DEV2})[0], 404)
        s, r, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % bid, {"deviceId": DEV2}, auth(tok))
        self.assertEqual((s, r["booking"]["status"]), (200, "cancelled"))

    def test_duplicate_check_is_per_account_not_per_device(self):
        _, a = self.register()
        _, b = self.register()
        body = booking_body(deviceId=DEV)
        s, r1, _ = self.e.req("POST", "/api/v1/bookings", body, auth(a["token"]))
        self.assertEqual(s, 201)
        s, r2, _ = self.e.req("POST", "/api/v1/bookings", body, auth(a["token"]))
        self.assertEqual((s, r2.get("duplicate"), r2["booking"]["id"]), (200, True, r1["booking"]["id"]))     # الحساب نفسه: يُعاد حجزه
        s, r3, _ = self.e.req("POST", "/api/v1/bookings", body, auth(b["token"]))                              # حساب آخر على الجهاز نفسه: حجز جديد
        self.assertEqual((s, r3.get("duplicate")), (201, None))
        self.assertNotEqual(r3["booking"]["id"], r1["booking"]["id"])

    def test_temporary_password_blocks_booking_until_changed(self):
        phone, d = self.register()
        pid = d["patient"]["id"]
        s, r, _ = self.e.adm("POST", "/accounts/%s/reset" % pid)
        self.assertEqual(s, 200)
        temp = r["password"]
        self.login(phone, PW, expect=401)
        lg = self.login(phone, temp)
        self.assertTrue(lg["mustChange"])
        s, b, _ = self.e.req("POST", "/api/v1/bookings", booking_body(), auth(lg["token"]))
        self.assertEqual((s, b["error"]), (403, "password_change_required"))
        s, c, _ = self.e.req("POST", "/api/v1/auth/password", {"current": temp, "new": "Brand-new-77"}, auth(lg["token"]))
        self.assertEqual(s, 200, c)
        self.assertFalse(self.me(c["token"])["mustChange"])
        self.assertEqual(self.e.req("POST", "/api/v1/bookings", booking_body(), auth(c["token"]))[0], 201)


class TestSharedDeviceIsolation(AccBase):
    """جهاز واحد يستعمله أكثر من شخص: كل حساب يرى حجوزاته وإشعاراته ويلغيها ويحذفها وحده؛ ولا يراها من لا حساب له."""

    def ids(self, tok=None):
        s, l, _ = self.e.req("GET", "/api/v1/bookings?deviceId=" + DEV, headers=auth(tok) if tok else None)
        self.assertEqual(s, 200, l)
        return [b["id"] for b in l["bookings"]]

    def test_bookings_of_an_account_are_invisible_to_others_on_the_same_device(self):
        _, a = self.register()
        _, b = self.register()
        s, r, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=DEV), auth(a["token"]))
        self.assertEqual(s, 201, r)
        bid = r["booking"]["id"]
        self.assertIn(bid, self.ids(a["token"]))
        self.assertNotIn(bid, self.ids(b["token"]))                    # حساب آخر على الجهاز نفسه
        self.assertNotIn(bid, self.ids())                              # زائر بلا حساب على الجهاز نفسه
        for hdr in (auth(b["token"]), None):                           # لا إلغاء بمعرّف الجهاز وحده ولا بحساب غير صاحبه
            self.assertEqual(self.e.req("POST", "/api/v1/bookings/%s/cancel" % bid, {"deviceId": DEV}, hdr)[0], 404)
        self.assertEqual(self.e.app.db.get_booking(bid)["status"], "new")
        s, c, _ = self.e.req("POST", "/api/v1/bookings/%s/cancel" % bid, {"deviceId": DEV}, auth(a["token"]))
        self.assertEqual((s, c["booking"]["status"]), (200, "cancelled"))

    def test_old_device_bookings_without_account_stay_with_the_device(self):
        _, a = self.register()
        self.assertEqual(self.e.adm("PUT", "/auth", {"mode": "off"})[0], 200)
        try:
            s, r, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=DEV))
            self.assertEqual(s, 201, r)
        finally:
            self.assertEqual(self.e.adm("PUT", "/auth", {"mode": "password"})[0], 200)
        old = r["booking"]["id"]
        self.assertIsNone(self.e.app.db.get_booking(old)["patient_id"])
        self.assertIn(old, self.ids())                                  # حجز قديم بلا حساب: يبقى لحامل الجهاز كما كان
        self.assertIn(old, self.ids(a["token"]))
        self.assertEqual(self.e.req("POST", "/api/v1/bookings/%s/cancel" % old, {"deviceId": DEV})[0], 200)

    def test_device_wipe_never_touches_account_bookings(self):
        _, a = self.register(name="سعد العتيبي")
        s, r, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=DEV), auth(a["token"]))
        bid = r["booking"]["id"]
        self.assertEqual(self.e.req("POST", "/api/v1/devices/%s/delete" % DEV, {})[0], 200)
        bk = self.e.app.db.get_booking(bid)
        self.assertEqual((bk["name"], bk["patient_id"]), ("سعد العتيبي", a["patient"]["id"]))

    def test_status_notifications_go_to_the_account_inbox_only(self):
        _, a = self.register()
        _, b = self.register()
        s, r, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=DEV), auth(a["token"]))
        bid = r["booking"]["id"]
        self.assertEqual(self.e.adm("PATCH", "/bookings/" + bid, {"status": "contacted"})[0], 200)

        def inbox(tok=None):
            s, n, _ = self.e.req("GET", "/api/v1/notifications?deviceId=" + DEV, headers=auth(tok) if tok else None)
            self.assertEqual(s, 200, n)
            return [x["ref"] for x in n["notifications"]]
        self.assertIn(bid, inbox(a["token"]))
        self.assertNotIn(bid, inbox(b["token"]))
        self.assertNotIn(bid, inbox())


class TestSlotBookingWithAccount(SchedBase):
    ENV = FAST

    def test_slot_booking_is_bound_to_the_account(self):
        self.e.adm("PUT", "/auth", {"mode": "password"})
        self.hours()
        s, d, _ = self.e.req("POST", "/api/v1/auth/register", reg_body("0551130001"))
        self.assertEqual(s, 201, d)
        tok, pid = d["token"], d["patient"]["id"]
        start = self.free(self.DOC, 1)[0]
        body = {"deviceId": "sch_device_acct_0123456789", "doctorId": self.DOC, "branchId": self.A, "consent": True, "name": "اسم مزوّر", "phone": "0500000000",
                "slot": {"day": day(1), "start": start}}
        s, r, _ = self.e.req("POST", "/api/v1/bookings", body)
        self.assertEqual((s, r["error"]), (401, "login_required"))
        s, r, _ = self.e.req("POST", "/api/v1/bookings", body, auth(tok))
        self.assertEqual((s, r.get("appointment")), (201, True), r)
        bk = self.e.app.db.get_booking(r["booking"]["id"])
        self.assertEqual((bk["patient_id"], bk["phone"], bk["name"], bk["status"]), (pid, "966551130001", "سعد العتيبي", "confirmed"))
        # يظهر في «طلباتي» من جهاز آخر بالحساب نفسه
        s, l, _ = self.e.req("GET", "/api/v1/bookings?deviceId=other_device_0123456789", headers=auth(tok))
        self.assertEqual([b["id"] for b in l["bookings"]], [bk["id"]])
        self.assertEqual(l["bookings"][0]["slot"]["start"], start)


# ====================================================================== الإدارة
class TestAdminAccounts(AccBase):
    def test_list_has_no_health_data_and_detail_is_audited(self):
        phone, d = self.register(name="خالد الشمري")
        pid = d["patient"]["id"]
        s, lst, _ = self.e.adm("GET", "/accounts")
        self.assertEqual(s, 200)
        raw = json.dumps(lst, ensure_ascii=False)
        for secret in ("بنسلين", "ميتفورمين", "diabetes", "O+", "BP-12345", "فهد العتيبي", PW, "salt", '"pw"'):
            self.assertNotIn(secret, raw)
        row = [a for a in lst["accounts"] if a["id"] == pid][0]
        self.assertEqual((row["name"], row["verified"], row["hasPassword"], row["hasProfile"], row["mustChange"], row["locked"]),
                         ("خالد الشمري", False, True, True, False, False))
        n0 = len([a for a in self.e.adm("GET", "/audit")[1]["audit"] if a["action"] == "account_view"])
        s, det, _ = self.e.adm("GET", "/accounts/" + pid)
        self.assertEqual(s, 200)
        self.assertEqual(det["profile"]["health"]["allergies"]["text"], "بنسلين")
        self.assertEqual(det["consent"]["version"], acc.CONSENT_VER)
        self.assertEqual([c["id"] for c in det["lists"]["chronic"]], list(acc.CHRONIC_IDS))
        views = [a for a in self.e.adm("GET", "/audit")[1]["audit"] if a["action"] == "account_view"]
        self.assertEqual(len(views), n0 + 1)
        self.assertNotIn("بنسلين", json.dumps(views, ensure_ascii=False))       # التدقيق يسجل الفتح لا المحتوى

    def test_search_by_name_and_any_phone_format(self):
        phone, d = self.register(name="عبدالرحمن الحربي")
        pid = d["patient"]["id"]
        for q in ("عبدالرحمن", "الحربي", phone, "+966" + phone[1:], phone[-6:]):
            ids = [a["id"] for a in self.e.adm("GET", "/accounts?q=" + quote(q))[1]["accounts"]]
            self.assertIn(pid, ids, q)
        self.assertEqual(self.e.adm("GET", "/accounts?q=%25")[1]["accounts"], [])        # الرمز % ليس بديلاً عن أي شيء
        self.assertEqual(self.e.adm("GET", "/accounts?q=zzzz-none")[1]["accounts"], [])

    def test_reset_gives_one_time_temporary_password(self):
        phone, d = self.register()
        pid, old_tok = d["patient"]["id"], d["token"]
        s, r, _ = self.e.adm("POST", "/accounts/%s/reset" % pid)
        self.assertEqual(s, 200)
        temp = r["password"]
        self.assertEqual(acc.pw_problem(temp), "")
        self.me(old_tok, expect=401)                                             # الجلسات السابقة أُبطلت
        self.login(phone, PW, expect=401)
        lg = self.login(phone, temp)
        self.assertTrue(lg["mustChange"])
        self.assertTrue(self.e.adm("GET", "/accounts?q=" + phone)[1]["accounts"][0]["mustChange"])
        blob = b"".join((self.e.tmp / n).read_bytes() for n in ("clinic.db", "clinic.db-wal") if (self.e.tmp / n).exists())
        self.assertNotIn(temp.encode(), blob)                                    # لا تُحفظ نصاً
        for r_ in self.e.app.db.conn().execute("SELECT * FROM audit WHERE action='account_reset_pw'"):
            self.assertNotIn(temp, json.dumps(dict(r_), ensure_ascii=False))
        # إعادة تعيين مرة ثانية تعطي كلمة مختلفة وتبطل السابقة
        r2 = self.e.adm("POST", "/accounts/%s/reset" % pid)[1]["password"]
        self.assertNotEqual(r2, temp)
        self.login(phone, temp, expect=401)

    def test_admin_delete_and_bad_ids(self):
        phone, d = self.register()
        pid = d["patient"]["id"]
        self.assertEqual(self.e.adm("DELETE", "/accounts/" + pid)[0], 200)
        self.assertEqual(self.e.adm("GET", "/accounts/" + pid)[0], 404)
        self.assertEqual(self.e.adm("POST", "/accounts/%s/reset" % pid)[0], 404)
        for bad in ("/accounts/x", "/accounts/pt-123", "/accounts/pt-0123456789ab/hack", "/accounts/PT-0123456789AB"):
            self.assertEqual(self.e.adm("GET", bad)[0], 404, bad)
        self.me(d["token"], expect=401)

    def test_patient_token_is_not_an_admin_token(self):
        _, d = self.register()
        for path in ("/accounts", "/auth"):
            self.assertEqual(self.e.req("GET", "/api/admin" + path, headers=auth(d["token"]))[0], 401, path)
        self.assertEqual(self.e.req("POST", "/api/admin/accounts/%s/reset" % d["patient"]["id"], {}, auth(d["token"]))[0], 401)

    def test_staff_roles_cannot_use_account_admin(self):
        s, _, _ = self.e.adm("POST", "/staff", {"username": "rec_acc", "name": "موظف", "role": "reception", "branchId": "quba", "password": STAFF_PW})
        self.assertEqual(s, 201)
        s, d, _ = self.e.req("POST", "/api/staff/login", {"username": "rec_acc", "password": STAFF_PW})
        self.assertEqual(s, 200, d)
        for path in ("/accounts", "/auth"):
            self.assertEqual(self.e.req("GET", "/api/admin" + path, headers=auth(d["token"]))[0], 401, path)


# ====================================================================== حماية الملف الطبي
class TestUnverifiedPhoneNeverUnlocksMedicalRecords(unittest.TestCase):
    """التسجيل بكلمة مرور لا يثبت ملكية الجوال. فمن سجّل برقم غيره لا يجوز أن يربط ملفه ولا يرى نتائجه."""

    def setUp(self):
        self.e = Env(dict(FAST, DS_SMS_PROVIDER="test"))
        self.addCleanup(self.e.close)

    def test_link_refused_until_sms_verification(self):
        db = self.e.app.db
        pt = db.patient_register("966551140001", "منتحل", "male", "1980-01-01", None, {"salt": "00" * 16, "hash": "00" * 32, "iter": 1000}, {}, acc.CONSENT_VER)
        self.assertEqual(pt["phone_verified"], 0)
        tok = self.e.app.make_patient_token(pt["id"])
        body = {"nationalId": "1012345678", "birthDate": "1980-01-01"}
        s, d, _ = self.e.req("POST", "/api/v1/records/link", body, auth(tok))
        self.assertEqual((s, d["error"]), (403, "phone_unverified"))
        self.assertEqual(db.linked_records(pt["id"]), [])
        # بعد نجاح رمز SMS لنفس الرقم يصبح موثّقاً فيصل الطلب إلى المطابقة (ولا ملف مطابقاً هنا)
        self.assertEqual(self.e.req("POST", "/api/v1/auth/otp", {"phone": "0551140001"})[0], 200)
        s, v, _ = self.e.req("POST", "/api/v1/auth/verify", {"phone": "0551140001", "code": last_code(self.e, "966551140001")})
        self.assertEqual(s, 200, v)
        self.assertEqual(v["patient"]["id"], pt["id"])
        self.assertTrue(v["patient"]["verified"])
        self.assertEqual(db.patient_by_id(pt["id"])["phone_verified"], 1)
        s, d, _ = self.e.req("POST", "/api/v1/records/link", body, auth(v["token"]))
        self.assertEqual((s, d["error"]), (404, "no_match"))

    def test_otp_created_accounts_are_verified_from_the_start(self):
        self.e.req("POST", "/api/v1/auth/otp", {"phone": "0551140002"})
        s, v, _ = self.e.req("POST", "/api/v1/auth/verify", {"phone": "0551140002", "code": last_code(self.e, "966551140002"),
                                                             "profile": {"name": "مراجع", "gender": "male", "birthDate": "1985-01-01"}})
        self.assertEqual((s, v["patient"]["verified"]), (200, True))

    def test_old_token_without_version_still_works_for_sms_accounts(self):
        """رموز ما قبل 0.11.0 لا تحمل pv: تبقى صالحة لحسابات SMS (لا كلمة مرور لها) ولا يُسجَّل خروج الجميع بالترقية."""
        import base64
        db = self.e.app.db
        pt = db.patient_create("966551140003", "قديم", "male", "1985-01-01", None)
        payload = base64.urlsafe_b64encode(json.dumps({"k": "pt", "pid": pt["id"], "exp": 4102444800}).encode()).decode().rstrip("=")
        import hashlib
        import hmac
        tok = payload + "." + hmac.new(self.e.app.secret, payload.encode(), hashlib.sha256).hexdigest()
        s, d, _ = self.e.req("GET", "/api/v1/auth/me", headers=auth(tok))
        self.assertEqual((s, d["patient"]["id"]), (200, pt["id"]))


# ====================================================================== الترحيل
class TestMigration(unittest.TestCase):
    def test_old_database_gets_new_columns_and_existing_patients_stay_verified(self):
        tmp = Path(tempfile.mkdtemp(prefix="ds-mig-"))
        self.addCleanup(shutil.rmtree, tmp, True)
        path = tmp / "old.db"
        d0 = dbmod.DB(path)
        # نعيد القاعدة إلى شكل ما قبل 0.11.0
        c = d0.conn()
        c.execute("DROP TABLE patient_auth")
        c.execute("DROP TABLE patient_profiles")
        c.execute("DROP INDEX ix_bookings_patient")
        c.execute("ALTER TABLE patients DROP COLUMN phone_verified")
        c.execute("ALTER TABLE bookings DROP COLUMN patient_id")
        c.execute("INSERT INTO patients(id,phone,name,gender,birth_date,national_id,created_at,last_login) VALUES('pt-aaaaaaaaaaaa','966551150001','قديم','male','1980-01-01',NULL,'2026-01-01','2026-01-01')")
        c.close()
        d1 = dbmod.DB(path)
        self.assertEqual(d1.patient_by_id("pt-aaaaaaaaaaaa")["phone_verified"], 1)          # أُنشئ برمز SMS سابقاً
        cols = {r["name"] for r in d1.conn().execute("PRAGMA table_info(bookings)")}
        self.assertIn("patient_id", cols)
        self.assertEqual(d1.patient_pw_ver("pt-aaaaaaaaaaaa"), 0)
        new = d1.patient_register("966551150002", "جديد", "female", "1990-01-01", None, {"salt": "00" * 16, "hash": "00" * 32, "iter": 1000}, {}, acc.CONSENT_VER)
        self.assertEqual(new["phone_verified"], 0)
        d2 = dbmod.DB(path)                                                                  # تكرار الترحيل آمن ولا يوثّق الجديد
        self.assertEqual(d2.patient_by_id(new["id"])["phone_verified"], 0)
        self.assertEqual(d2.patient_by_id("pt-aaaaaaaaaaaa")["phone_verified"], 1)
        with self.assertRaises(sqlite3.IntegrityError):
            d2.patient_register("966551150002", "مكرر", "male", "1990-01-01", None, {"salt": "00" * 16, "hash": "00" * 32, "iter": 1000}, {}, acc.CONSENT_VER)
        self.assertEqual(d2.conn().execute("SELECT COUNT(*) FROM patient_auth").fetchone()[0], 1)         # المعاملة تراجعت كاملة


# ====================================================================== نص الخصوصية
class TestHealthDataNeverReachesQamar(unittest.TestCase):
    """الملف الصحي وبيانات الحساب لا تصل إلى «قمر» ولا إلى مزوّد الذكاء الاصطناعي: لا في نص الطلب ولا في تعليمات النظام،
    حتى لو حمل طلب قمر رمز المراجع المسجّل."""

    def test_provider_never_sees_account_or_health_data(self):
        from test_qamar_llm import FakeLLM, OFF
        fake = FakeLLM()
        e = Env({"QAMAR_PROVIDER": "anthropic", "QAMAR_API_KEY": "sk-test", "QAMAR_BASE_URL": fake.url, "QAMAR_MODEL": "claude-haiku-5-5",
                 "QAMAR_DAILY_CAP": "50", "DS_PW_ITERS": "1000"})
        try:
            self.assertEqual(e.adm("PUT", "/auth", {"mode": "password"})[0], 200)
            secrets_ = ["حساسية-سرية-777", "دواء-سري-888", "عملية-سرية-999", "سعد الاختبار", "0551110099", "551110099", "بوبا", "BP-12345", "فهد العتيبي", "O+"]
            health = {"bloodType": "O+", "allergies": {"none": False, "text": secrets_[0]}, "chronic": {"none": False, "items": ["diabetes"], "other": ""},
                      "medications": {"none": False, "text": secrets_[1]}, "surgeries": {"none": False, "text": secrets_[2]}, "pregnancy": ""}
            s, d, _ = e.req("POST", "/api/v1/auth/register", reg_body("0551110099", name="سعد الاختبار", profile=profile(health=health)))
            self.assertEqual(s, 201, d)
            tok = d["token"]
            for q in OFF[:3]:
                s, r, _ = e.req("POST", "/api/v1/qamar", {"deviceId": DEV, "message": q, "history": []}, auth(tok))
                self.assertEqual(s, 200, r)
            self.assertTrue(fake.calls, "لم يُستدعَ المزوّد أصلاً: الاختبار لا يثبت شيئاً")
            blob = json.dumps(fake.calls, ensure_ascii=False)
            for secret in secrets_:
                self.assertNotIn(secret, blob, "تسرّب إلى المزوّد: " + secret)
        finally:
            fake.close()
            e.close()


class TestPrivacyText(unittest.TestCase):
    def test_server_page_and_app_copy_agree_for_password_accounts(self):
        js = (ROOT / "web" / "js" / "40-booking.js").read_text(encoding="utf-8")
        settings = {"name": "المجمع", "phones": [{"type": "main", "number": "920000000"}], "emergencyNumber": "997"}
        page = appmod.privacy_html(settings, False, "password")
        self.assertTrue(appmod.PRIVACY_PASSWORD_LI in page, "فقرة الخصوصية غير موجودة في صفحة الخادم")
        self.assertTrue(appmod.PRIVACY_PASSWORD_LI in js, "فقرة الخصوصية غير موجودة في نسخة التطبيق (web/js/40-booking.js)")
        self.assertNotIn(appmod.PRIVACY_PASSWORD_LI, appmod.privacy_html(settings, False, ""))
        self.assertNotIn(appmod.PRIVACY_PASSWORD_LI, appmod.privacy_html(settings, False, "sms"))
        self.assertNotIn("رمز تحقق", page)                                                  # لا وعد برسالة نصية لا تُرسَل
        for word in ("الحساسية", "الأمراض المزمنة", "الأدوية", "«قمر»", "موافقتك الصريحة"):
            self.assertIn(word, appmod.PRIVACY_PASSWORD_LI)


if __name__ == "__main__":
    unittest.main()
