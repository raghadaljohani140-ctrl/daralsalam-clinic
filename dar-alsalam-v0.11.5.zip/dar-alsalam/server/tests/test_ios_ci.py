"""مسار بناء iOS ← TestFlight (mobile/ci/ios-build.sh + .github/workflows/ios-testflight.yml)، ومعه فحص ملف أندرويد (android-apk.yml) لأن الاثنين يبنيان من ملف zip.

لا يوجد macOS ولا حساب Apple هنا، فيُشغَّل السكربت الحقيقي بأوامر وهمية (ios_fake_tools.py) ليُفحص ترتيب الخطوات والمعاملات
ومعالجة الأخطاء وحذف المفتاح وعدم تسريب الأسرار. هذا لا يثبت نجاحه على أجهزة Apple؛ يثبت أن منطقه سليم."""
import json
import os
import plistlib
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

from helpers import ROOT  # noqa: F401  (يضبط مسارات الخادم)
import ios_fake_tools as fake

SCRIPT_REL = "mobile/ci/ios-build.sh"
WF_REL = ".github/workflows/ios-testflight.yml"
UUID = "69a6de7e-1234-47e3-9abc-0123456789ab"
BASH = shutil.which("bash")
NODE = shutil.which("node")
OPENSSL = shutil.which("openssl")


def make_pem(tmp):
    """مفتاح EC P-256 مؤقت بصيغة PKCS#8 (مثل ملفات .p8 من Apple)."""
    p = Path(tmp) / "k.pem"
    subprocess.run([OPENSSL, "genpkey", "-algorithm", "EC", "-pkeyopt", "ec_paramgen_curve:P-256", "-out", str(p)], check=True, capture_output=True)
    return p.read_text()


def der_digest(pem_text, tmp):
    p = Path(tmp) / "d.pem"
    p.write_text(pem_text)
    r = subprocess.run([OPENSSL, "pkey", "-in", str(p), "-outform", "DER"], capture_output=True)
    return r.returncode, r.stdout


class TestStaticFiles(unittest.TestCase):
    def test_script_syntax_and_bash32_compat(self):
        if not BASH:
            self.skipTest("bash غير متاح")
        r = subprocess.run([BASH, "-n", str(ROOT / SCRIPT_REL)], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        text = (ROOT / SCRIPT_REL).read_text(encoding="utf-8")
        self.assertTrue(text.startswith("#!/usr/bin/env bash"))
        # bash على macOS هو 3.2: لا ميزات 4+ (مصفوفات ترابطية، mapfile، تحويل الحالة، &>>)
        for bad in (r"\bmapfile\b", r"\breadarray\b", r"declare\s+-A", r"\$\{[A-Za-z_]+(,,|\^\^)", r"&>>", r";&"):
            self.assertIsNone(re.search(bad, text), "ميزة غير متاحة في bash 3.2: " + bad)

    def test_new_files_have_no_secret_patterns_and_are_packaged(self):
        sys.path.insert(0, str(ROOT / "tools"))
        import package
        files = [SCRIPT_REL, WF_REL, "docs/TESTFLIGHT-ar.md", "docs/STORE_RELEASE.md", "docs/GO-LIVE-ar.md"]
        self.assertEqual(package.scan_secrets(files), [])
        packed = set(package.collect())
        for f in files:
            self.assertIn(f, packed, f + " لا يُغلَّف")

    def test_workflow_shape_and_security(self):
        import yaml
        doc = yaml.safe_load((ROOT / WF_REL).read_text(encoding="utf-8"))
        trig = doc.get("on", doc.get(True))
        self.assertEqual(list(trig), ["workflow_dispatch"], "يجب أن يكون يدوياً فقط (لا push ولا pull_request)")
        self.assertEqual(doc["permissions"], {"contents": "read"})
        job = doc["jobs"]["ios"]
        self.assertEqual(job["runs-on"], "macos-26")
        inp = trig["workflow_dispatch"]["inputs"]
        self.assertEqual(set(inp), {"version", "api_base", "upload"})
        self.assertIs(inp["upload"]["default"], True)
        self.assertEqual(inp["version"]["default"], "latest")
        # الأسرار في خطوة البناء وحدها، لا على مستوى المهمة ولا في خطوة فك الحزمة
        self.assertNotIn("secrets.", json.dumps({k: v for k, v in job.items() if k != "steps"}))
        holders = [s["name"] for s in job["steps"] if "secrets." in json.dumps(s)]
        self.assertEqual(holders, [job["steps"][-1]["name"]])
        last = job["steps"][-1]
        for s in ("APPLE_TEAM_ID", "ASC_KEY_ID", "ASC_ISSUER_ID", "ASC_KEY_P8"):
            self.assertEqual(last["env"][s], "${{ secrets.%s }}" % s)
        self.assertIn("mobile/ci/ios-build.sh", last["run"])
        self.assertNotIn("${{ secrets", job["steps"][2]["run"])

    def test_guide_yaml_block_equals_workflow_file(self):
        """الدليل يطلب من المستخدم لصق نص الملف من الجوال: يجب أن يطابق الملف في الحزمة حرفاً بحرف."""
        guide = (ROOT / "docs/TESTFLIGHT-ar.md").read_text(encoding="utf-8")
        blocks = re.findall(r"```yaml\n(.*?)\n```", guide, re.S)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0], (ROOT / WF_REL).read_text(encoding="utf-8").rstrip("\n"))

    def test_guide_names_match_the_workflow_and_project(self):
        import yaml
        guide = (ROOT / "docs/TESTFLIGHT-ar.md").read_text(encoding="utf-8")
        for s in ("APPLE_TEAM_ID", "ASC_KEY_ID", "ASC_ISSUER_ID", "ASC_KEY_P8"):
            self.assertIn(s, guide)
        self.assertIn(yaml.safe_load((ROOT / WF_REL).read_text(encoding="utf-8"))["name"], guide)
        self.assertIn(json.loads((ROOT / "mobile/capacitor.config.json").read_text(encoding="utf-8"))["appId"], guide)
        self.assertIn(".github/workflows/ios-testflight.yml", guide)
        # صدق الحالة: لا يدّعي أنه جُرّب ولا أنه ينشر
        self.assertIn("لم يُجرَّب على أجهزة Apple", guide)
        self.assertIn("لا يُنشر شيء في App Store", guide)

    def test_docs_require_admin_role_and_do_not_claim_app_manager_works(self):
        for rel in ("docs/TESTFLIGHT-ar.md", "docs/STORE_RELEASE.md", "docs/GO-LIVE-ar.md"):
            t = (ROOT / rel).read_text(encoding="utf-8")
            self.assertIn("Admin", t, rel)
            self.assertNotRegex(t, r"بصلاحية App Manager", rel)
        wf = (ROOT / WF_REL).read_text(encoding="utf-8")
        self.assertNotIn("App Manager", wf)


@unittest.skipUnless(BASH and NODE and OPENSSL, "يلزم bash وnode وopenssl")
class TestHelpersFunctions(unittest.TestCase):
    """دوال السكربت المنفردة (يُحمَّل السكربت بـ source دون تشغيل main)."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ds-ios-fn-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def sh(self, code):
        return subprocess.run([BASH, "-c", 'source "%s"; %s' % (ROOT / SCRIPT_REL, code)], capture_output=True, text=True, cwd=self.tmp)

    def test_normalize_p8_accepts_pasted_variants(self):
        pem = make_pem(self.tmp)
        rc0, der0 = der_digest(pem, self.tmp)
        self.assertEqual(rc0, 0)
        flat = " ".join(pem.split())                    # فقد فواصل الأسطر
        variants = {
            "كما هو": pem, "CRLF": pem.replace("\n", "\r\n"), "سطر واحد": flat,
            "فراغات حول المفتاح": "\n  " + pem + "  \n\n", "بلا سطر أخير": pem.rstrip("\n"),
        }
        for name, v in variants.items():
            (self.tmp / "in.txt").write_text(v)
            r = self.sh('normalize_p8 "$(cat in.txt)" > out.pem')
            self.assertEqual(r.returncode, 0, name + r.stderr)
            out = (self.tmp / "out.pem").read_text()
            rc, der = der_digest(out, self.tmp)
            self.assertEqual((rc, der), (rc0, der0), name)
            self.assertTrue(all(len(line) <= 64 for line in out.splitlines()[1:-1]), name)

    def test_normalize_p8_rejects_empty_and_garbage_is_not_a_key(self):
        self.assertNotEqual(self.sh('normalize_p8 "" > /dev/null').returncode, 0)
        self.assertNotEqual(self.sh("normalize_p8 \"$(printf ' \\n ')\" > /dev/null").returncode, 0)
        r = self.sh('normalize_p8 "hello world not a key" > out.pem')
        self.assertEqual(r.returncode, 0)  # يُحوَّل لـPEM شكلاً؛ التحقق الفعلي بـopenssl في main
        self.assertNotEqual(subprocess.run([OPENSSL, "pkey", "-in", str(self.tmp / "out.pem"), "-noout"], capture_output=True).returncode, 0)

    def test_png_alpha_detector(self):
        cases = {"rgb": 1, "rgba": 0, "palette": 1, "palette_trns": 0}
        for kind, want in cases.items():
            f = self.tmp / (kind + ".png")
            fake.make_png(f, kind)
            self.assertEqual(self.sh('png_has_alpha "%s"' % f).returncode, want, kind)
        bad = self.tmp / "x.png"
        bad.write_bytes(b"not a png at all, just text bytes......")
        self.assertEqual(self.sh('png_has_alpha "%s"' % bad).returncode, 2)

    def test_flatten_pngs_with_real_sharp_removes_alpha(self):
        probe = subprocess.run([NODE, "-e", "require.resolve('sharp')"], capture_output=True, cwd=self.tmp)
        if probe.returncode != 0:
            self.skipTest("مكتبة sharp غير متاحة هنا (تأتي مع @capacitor/assets على المنفّذ)")
        f = self.tmp / "icon.png"
        fake.make_png(f, "rgba")
        self.assertEqual(self.sh('png_has_alpha "%s"' % f).returncode, 0)
        r = self.sh('flatten_pngs "%s"' % f)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(self.sh('png_has_alpha "%s"' % f).returncode, 1, "ما زالت فيه شفافية بعد التسطيح")

    def test_export_options_plist_is_valid_and_internal_only(self):
        for internal in ("true", "false"):
            r = self.sh('APPLE_TEAM_ID=ABCDE12345 INTERNAL_ONLY=%s write_export_options o.plist upload' % internal)
            self.assertEqual(r.returncode, 0, r.stderr)
            d = plistlib.loads((self.tmp / "o.plist").read_bytes())
            self.assertEqual(d, {"method": "app-store-connect", "destination": "upload", "teamID": "ABCDE12345", "signingStyle": "automatic",
                                 "uploadSymbols": True, "manageAppVersionAndBuildNumber": False, "testFlightInternalTestingOnly": internal == "true"})

    def test_explain_failure_maps_known_errors(self):
        cases = {
            "error: exportArchive Cloud signing permission error": "Admin",
            "error: exportArchive No profiles for 'com.x.y' were found": "APPLE_TEAM_ID",
            "Authentication failed: NOT_AUTHORIZED": "ASC_KEY_P8",
            "Cannot determine the Apple ID from Bundle ID 'com.x.y'": "New App",
            "ERROR ITMS-90717: Invalid large app icon. alpha channel": "أيقونة",
            "The bundle version must be higher than the previously uploaded version": "رقم البناء",
            "something unexpected": "أول سطر",
        }
        for line, hint in cases.items():
            (self.tmp / "l.log").write_text(line + "\n")
            r = self.sh("explain_failure l.log")
            self.assertIn(hint, r.stdout, line)
            self.assertIn("::error::", r.stdout)


@unittest.skipUnless(BASH and NODE and OPENSSL, "يلزم bash وnode وopenssl")
class TestBuildFlowWithFakeTools(unittest.TestCase):
    """يشغّل ios-build.sh كاملاً على نسخة من المشروع بأوامر Apple وهمية."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="ds-ios-flow-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.proj = self.tmp / "dar-alsalam"
        shutil.copytree(ROOT / "web", self.proj / "web")
        for rel in ("scripts", "ci", "assets"):
            shutil.copytree(ROOT / "mobile" / rel, self.proj / "mobile" / rel)
        for f in ("capacitor.config.json", "package.json"):
            shutil.copy(ROOT / "mobile" / f, self.proj / "mobile" / f)
        self.bin, self.home, self.runner = self.tmp / "bin", self.tmp / "home", self.tmp / "runner"
        for d in (self.bin, self.home, self.runner):
            d.mkdir()
        self.log = self.tmp / "calls.log"
        tools = Path(fake.__file__).resolve()
        for t in ("npm", "npx", "xcodebuild", "plutil", "shasum"):
            p = self.bin / t
            p.write_text('#!/bin/sh\nexec "%s" "%s" %s "$@"\n' % (sys.executable, tools, t))
            p.chmod(0o755)
        self.pem = make_pem(self.tmp)
        self.version = json.loads((ROOT / "mobile/package.json").read_text())["version"]
        self.summary = self.tmp / "summary.md"

    def env(self, **kw):
        e = dict(os.environ, PATH="%s:%s" % (self.bin, os.environ["PATH"]), HOME=str(self.home), RUNNER_TEMP=str(self.runner),
                 IOS_BUILD_DRYRUN="1", SHIM_LOG=str(self.log), GITHUB_STEP_SUMMARY=str(self.summary),
                 API_BASE="https://daralsalamclinic.duckdns.org", APPLE_TEAM_ID="ABCDE12345", ASC_KEY_ID="KEY1234567",
                 ASC_ISSUER_ID=UUID, ASC_KEY_P8=self.pem, UPLOAD="true")
        for k in ("BUNDLE_ID", "BUILD_NO", "INTERNAL_ONLY", "FAKE_ICON_ALPHA", "FAKE_EXPORT_FAIL", "FAKE_FAIL_STEP", "WORK_DIR"):
            e.pop(k, None)
        e["NODE_PATH"] = ""  # لا نريد أن يجد السكربت مكتبة sharp عامة من الجهاز: الاختبار يجب ألا يتأثر ببيئة المنفّذ
        e.update(kw)
        return e

    def run_script(self, **kw):
        return subprocess.run([BASH, str(self.proj / SCRIPT_REL)], env=self.env(**kw), capture_output=True, text=True, timeout=180)

    def calls(self):
        return [json.loads(x) for x in self.log.read_text(encoding="utf-8").splitlines()] if self.log.exists() else []

    def sig(self, c):
        return c["tool"] + " " + " ".join(c["args"])

    def assert_no_secret_leak(self, r):
        body = "".join(self.pem.strip().splitlines()[1:-1])
        for chunk in self.pem.strip().splitlines()[1:-1]:
            self.assertNotIn(chunk, r.stdout + r.stderr, "المفتاح ظهر في السجل")
        self.assertNotIn(body, r.stdout + r.stderr)

    def key_file(self):
        return self.home / ".appstoreconnect/private_keys/AuthKey_KEY1234567.p8"

    # ---------------- المسار الناجح
    def test_upload_flow_order_flags_and_cleanup(self):
        r = self.run_script(BUILD_NO="777")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        sigs = [self.sig(c) for c in self.calls()]
        order = ["npm install", "npx cap add ios --packagemanager SPM", "npx capacitor-assets generate --ios", "npx cap sync ios",
                 "plutil -replace ITSAppUsesNonExemptEncryption -bool NO", "plutil -replace NSFaceIDUsageDescription -string", "xcodebuild -resolvePackageDependencies",
                 "xcodebuild archive", "xcodebuild -exportArchive"]
        pos = -1
        for want in order:
            nxt = next((i for i, s in enumerate(sigs) if i > pos and s.startswith(want)), None)
            self.assertIsNotNone(nxt, "لم تُستدعَ بالترتيب: %s\n%s" % (want, "\n".join(sigs)))
            pos = nxt
        arch = next(c for c in self.calls() if c["tool"] == "xcodebuild" and c["args"][0] == "archive")
        a = arch["args"]
        for need in ("-project", "App.xcodeproj", "-scheme", "App", "-configuration", "Release", "generic/platform=iOS", "CODE_SIGNING_ALLOWED=NO",
                     "CODE_SIGNING_REQUIRED=NO", "MARKETING_VERSION=" + self.version, "CURRENT_PROJECT_VERSION=777"):
            self.assertIn(need, a)
        self.assertTrue(arch["cwd"].endswith("mobile/ios/App"))
        self.assertNotIn("-allowProvisioningUpdates", a, "الأرشفة بلا توقيع: لا تطلب شهادة تطوير (تحتاج جهازاً مسجّلاً)")
        exp = next(c for c in self.calls() if c["tool"] == "xcodebuild" and c["args"][0] == "-exportArchive")["export"]
        self.assertTrue(exp["archive_exists"] and exp["allowProvisioningUpdates"])
        self.assertEqual((exp["keyId"], exp["issuerId"]), ("KEY1234567", UUID))
        self.assertTrue(exp["keyValid"], "المفتاح لم يكن صالحاً عند التصدير")
        self.assertEqual(exp["keyMode"], 0o600)
        self.assertEqual(exp["options"], {"method": "app-store-connect", "destination": "upload", "teamID": "ABCDE12345", "signingStyle": "automatic",
                                          "uploadSymbols": True, "manageAppVersionAndBuildNumber": False, "testFlightInternalTestingOnly": True})
        self.assertFalse(self.key_file().exists(), "مفتاح .p8 بقي على الجهاز بعد انتهاء البناء")
        self.assert_no_secret_leak(r)
        self.assertIn("رُفع البناء", r.stdout)
        self.assertIn("TestFlight", self.summary.read_text(encoding="utf-8"))
        # الواجهة جُهّزت فعلاً بعنوان الخادم (السكربت الحقيقي prepare-www.js يعمل هنا)
        cfg = (self.proj / "mobile/www/config.js").read_text(encoding="utf-8")
        self.assertIn('"apiBase":"https://daralsalamclinic.duckdns.org"', cfg)
        self.assertIn('"build":"777"', cfg)
        self.assertIn('"push":false', cfg)
        info = plistlib.loads((self.proj / "mobile/ios/App/App/Info.plist").read_bytes())
        self.assertIs(info["ITSAppUsesNonExemptEncryption"], False)

    def test_build_only_mode_exports_ipa_and_does_not_upload(self):
        r = self.run_script(UPLOAD="false", INTERNAL_ONLY="false")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        exp = next(c for c in self.calls() if c["tool"] == "xcodebuild" and c["args"][0] == "-exportArchive")["export"]
        self.assertEqual(exp["options"]["destination"], "export")
        self.assertIs(exp["options"]["testFlightInternalTestingOnly"], False)
        self.assertTrue((self.runner / "ds-ios/export/App.ipa").is_file())
        self.assertIn("لم يُرفع", r.stdout)

    def test_default_build_number_is_time_based_and_increasing(self):
        r = self.run_script()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        arch = next(c for c in self.calls() if c["tool"] == "xcodebuild" and c["args"][0] == "archive")["args"]
        n = int(next(x for x in arch if x.startswith("CURRENT_PROJECT_VERSION=")).split("=")[1])
        self.assertGreater(n, 400000)  # دقائق منذ 2026-01-01 (نوفمبر 2026 ≈ 470 ألفاً)
        self.assertLess(n, 2 ** 31)

    def test_bundle_id_override_is_written_to_config(self):
        r = self.run_script(BUNDLE_ID="sa.example.daralsalam")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        cfg = json.loads((self.proj / "mobile/capacitor.config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["appId"], "sa.example.daralsalam")
        self.assertEqual(cfg["appName"], "دار السلام")
        info = plistlib.loads((self.proj / "mobile/ios/App/App/Info.plist").read_bytes())
        self.assertEqual(info["CFBundleIdentifier"], "sa.example.daralsalam")

    def test_pasted_key_variants_still_sign(self):
        for name, val in (("سطر واحد", " ".join(self.pem.split())), ("CRLF", self.pem.replace("\n", "\r\n"))):
            self.log.unlink(missing_ok=True)
            r = self.run_script(ASC_KEY_P8=val)
            self.assertEqual(r.returncode, 0, name + r.stdout + r.stderr)
            exp = next(c for c in self.calls() if c["tool"] == "xcodebuild" and c["args"][0] == "-exportArchive")["export"]
            self.assertTrue(exp["keyValid"], name)

    # ---------------- الفشل المبكر (قبل أي عمل مكلف)
    def test_invalid_inputs_fail_before_any_build_step(self):
        cases = {
            "مفتاح غير صالح": ({"ASC_KEY_P8": "this is not a key"}, "ASC_KEY_P8"),
            "مفتاح فارغ": ({"ASC_KEY_P8": ""}, "ASC_KEY_P8"),
            "فريق خاطئ": ({"APPLE_TEAM_ID": "abc"}, "APPLE_TEAM_ID"),
            "Key ID خاطئ": ({"ASC_KEY_ID": "short"}, "ASC_KEY_ID"),
            "Issuer خاطئ": ({"ASC_ISSUER_ID": "not-a-uuid"}, "ASC_ISSUER_ID"),
            "خادم http": ({"API_BASE": "http://example.com"}, "https://"),
            "UPLOAD غريب": ({"UPLOAD": "maybe"}, "UPLOAD"),
            "معرّف حزمة سيئ": ({"BUNDLE_ID": "nodots"}, "معرّف الحزمة"),
        }
        for name, (kw, hint) in cases.items():
            self.log.unlink(missing_ok=True)
            r = self.run_script(**kw)
            self.assertNotEqual(r.returncode, 0, name)
            self.assertIn("::error::", r.stdout, name)
            self.assertIn(hint, r.stdout, name)
            self.assertEqual([c for c in self.calls() if c["tool"] in ("npm", "npx", "xcodebuild") and c["args"][:1] != ["-version"]], [], name + ": بدأ البناء رغم المدخلات الخاطئة")
            self.assertFalse(self.key_file().exists(), name)
            self.assert_no_secret_leak(r)

    def test_refuses_to_run_outside_macos_without_dryrun(self):
        if sys.platform == "darwin":
            self.skipTest("يعمل على macOS فعلاً")
        e = self.env()
        e.pop("IOS_BUILD_DRYRUN")
        r = subprocess.run([BASH, str(self.proj / SCRIPT_REL)], env=e, capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("macOS", r.stdout)
        self.assertEqual(self.calls(), [])

    # ---------------- أخطاء Apple
    def test_cloud_signing_error_is_explained_and_key_removed(self):
        r = self.run_script(FAKE_EXPORT_FAIL="error: exportArchive Cloud signing permission error\nerror: exportArchive No signing certificate \"iOS Distribution\" found")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("Admin", r.stdout)
        self.assertIn("فشل التوقيع", r.stdout)
        self.assertFalse(self.key_file().exists())
        self.assert_no_secret_leak(r)

    def test_archive_and_resolve_failures_stop_the_flow(self):
        for step, marker in (("resolve", "تنزيل"), ("archive", "الأرشفة")):
            self.log.unlink(missing_ok=True)
            r = self.run_script(FAKE_FAIL_STEP=step)
            self.assertNotEqual(r.returncode, 0, step)
            self.assertIn(marker, r.stdout, step)
            self.assertFalse(any(c["tool"] == "xcodebuild" and c["args"][0] == "-exportArchive" for c in self.calls()), step)
            self.assertFalse(self.key_file().exists(), step)

    # ---------------- الأيقونة
    def test_alpha_icon_is_flattened_when_sharp_is_available(self):
        flat = self.tmp / "flat.png"
        fake.make_png(flat, "rgb")
        sharp = self.proj / "mobile/node_modules/sharp"
        sharp.mkdir(parents=True)
        (sharp / "index.js").write_text(
            "const fs=require('fs');module.exports=(f)=>{const o={flatten(){return o},removeAlpha(){return o},png(){return o},"
            "toBuffer:async()=>fs.readFileSync(%s)};return o};" % json.dumps(str(flat)))
        r = self.run_script(FAKE_ICON_ALPHA="1")
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("قناة شفافية", r.stdout)
        icon = self.proj / "mobile/ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png"
        self.assertEqual(icon.read_bytes()[25], 2)  # RGB بلا ألفا

    def test_alpha_icon_without_sharp_fails_early_with_clear_message(self):
        r = self.run_script(FAKE_ICON_ALPHA="1")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("شفافية", r.stdout)
        self.assertFalse(any(c["tool"] == "xcodebuild" and c["args"][0] == "archive" for c in self.calls()), "كان سيُبنى 10 دقائق ثم يُرفض")
        self.assertFalse(self.key_file().exists())


@unittest.skipUnless(BASH and shutil.which("unzip"), "يلزم bash وunzip")
class TestWorkflowUnzipStep(unittest.TestCase):
    """يشغّل خطوة «فك حزمة المشروع» من ملف الـworkflow كما هي على مستودع يحوي ملفات zip فقط."""

    def setUp(self):
        import yaml
        self.tmp = Path(tempfile.mkdtemp(prefix="ds-ios-wf-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        doc = yaml.safe_load((ROOT / WF_REL).read_text(encoding="utf-8"))
        self.step = next(s for s in doc["jobs"]["ios"]["steps"] if s.get("name") == "فك حزمة المشروع")["run"]
        self.repo = self.tmp / "repo"
        self.repo.mkdir()
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        sh = self.bin / "shasum"
        sh.write_text('#!/bin/sh\nexec sha256sum "$3"\n')
        sh.chmod(0o755)

    def add_zip(self, name, with_script=True):
        with zipfile.ZipFile(self.repo / name, "w") as z:
            z.writestr("dar-alsalam/README.md", "x")
            if with_script:
                z.writestr("dar-alsalam/mobile/ci/ios-build.sh", "#!/bin/bash\n")

    def run_step(self, version="latest"):
        env_file, runner = self.tmp / "env", self.tmp / "runner"
        runner.mkdir(exist_ok=True)
        env = dict(os.environ, PATH="%s:%s" % (self.bin, os.environ["PATH"]), VERSION=version, RUNNER_TEMP=str(runner), GITHUB_ENV=str(env_file))
        r = subprocess.run([BASH, "-c", self.step], cwd=self.repo, env=env, capture_output=True, text=True)
        src = env_file.read_text().strip() if env_file.exists() else ""
        return r, src

    def test_latest_picks_highest_numeric_version_not_alphabetical(self):
        for n in ("dar-alsalam-v0.9.0.zip", "dar-alsalam-v0.10.0.zip", "dar-alsalam-v0.10.9.zip", "dar-alsalam-v0.10.10.zip", "dar-alsalam-v0.2.0.zip", "notes.zip"):
            self.add_zip(n)
        r, src = self.run_step()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("الحزمة: dar-alsalam-v0.10.10.zip", r.stdout)
        self.assertTrue(src.startswith("SRC=") and src.endswith("/src/dar-alsalam"))
        self.assertTrue((Path(src[4:]) / "mobile/ci/ios-build.sh").is_file())

    def test_explicit_version_with_or_without_v_prefix(self):
        self.add_zip("dar-alsalam-v0.10.1.zip")
        self.add_zip("dar-alsalam-v0.11.0.zip")
        for v in ("0.10.1", "v0.10.1"):
            r, _ = self.run_step(v)
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            self.assertIn("الحزمة: dar-alsalam-v0.10.1.zip", r.stdout)

    def test_missing_zip_and_old_package_give_clear_errors(self):
        r, _ = self.run_step()
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("::error::لم أجد حزمة", r.stdout)
        r, _ = self.run_step("9.9.9")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("::error::لم أجد حزمة", r.stdout)
        self.add_zip("dar-alsalam-v0.8.0.zip", with_script=False)
        r, _ = self.run_step()
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("قديمة", r.stdout)


ANDROID_WF = ".github/workflows/android-apk.yml"


@unittest.skipUnless(BASH, "يلزم bash")
class TestAndroidWorkflowShim(unittest.TestCase):
    """ملف أندرويد يعمل على مستودع فيه ملفات zip فقط (لا مجلدات المشروع)."""

    def setUp(self):
        import yaml
        self.doc = yaml.safe_load((ROOT / ANDROID_WF).read_text(encoding="utf-8"))
        self.steps = self.doc["jobs"]["apk"]["steps"]
        self.step = next(s for s in self.steps if s.get("name") == "فك حزمة المشروع")["run"]
        self.tmp = Path(tempfile.mkdtemp(prefix="ds-and-wf-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.repo = self.tmp / "repo"
        self.repo.mkdir()

    def add_zip(self, name, with_mobile=True):
        with zipfile.ZipFile(self.repo / name, "w") as z:
            z.writestr("dar-alsalam/README.md", "x")
            if with_mobile:
                z.writestr("dar-alsalam/mobile/scripts/prepare-www.js", "//")

    def run_step(self, version="latest"):
        env = dict(os.environ, VERSION=version)
        return subprocess.run([BASH, "-c", self.step], cwd=self.repo, env=env, capture_output=True, text=True)

    def test_shape_and_secret_scope(self):
        trig = self.doc.get("on", self.doc.get(True))
        self.assertEqual(list(trig), ["workflow_dispatch"])
        self.assertEqual(set(trig["workflow_dispatch"]["inputs"]), {"version", "api_base", "push"})
        self.assertEqual(self.doc["permissions"], {"contents": "read"})
        job = self.doc["jobs"]["apk"]
        self.assertNotIn("secrets.", json.dumps({k: v for k, v in job.items() if k != "steps"}))
        holders = [s["name"] for s in self.steps if "secrets." in json.dumps(s)]
        self.assertEqual(holders, ["تجهيز الواجهة من مجلد web", "ملف Firebase (للتنبيهات فقط)"])

    def test_every_path_points_inside_the_unpacked_project(self):
        base = "proj/dar-alsalam/mobile"
        for s in self.steps:
            wd = s.get("working-directory")
            if wd:
                self.assertTrue(wd == base or wd == base + "/android", s["name"])
        art = next(s for s in self.steps if s.get("uses", "").startswith("actions/upload-artifact"))
        self.assertTrue(art["with"]["path"].startswith(base + "/android/app/build/"))
        self.assertIn(base + "/android/app/google-services.json", next(s for s in self.steps if "Firebase" in s.get("name", ""))["run"])
        # لا خطوة تعمل على mobile/ مباشرة من جذر المستودع (غير موجود هناك)
        self.assertNotIn("working-directory: mobile\n", (ROOT / ANDROID_WF).read_text(encoding="utf-8"))

    def test_unpack_latest_numeric_and_explicit(self):
        for n in ("dar-alsalam-v0.9.0.zip", "dar-alsalam-v0.10.0.zip", "dar-alsalam-v0.10.10.zip", "dar-alsalam-v0.10.9.zip", "notes.zip"):
            self.add_zip(n)
        r = self.run_step()
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("الحزمة: dar-alsalam-v0.10.10.zip", r.stdout)
        self.assertTrue((self.repo / "proj/dar-alsalam/mobile/scripts/prepare-www.js").is_file())
        for v in ("0.10.9", "v0.10.9"):
            r = self.run_step(v)
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            self.assertIn("الحزمة: dar-alsalam-v0.10.9.zip", r.stdout)

    def test_unpack_errors_are_clear(self):
        r = self.run_step()
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("::error::لم أجد حزمة", r.stdout)
        self.add_zip("dar-alsalam-v0.1.0.zip", with_mobile=False)
        r = self.run_step()
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("لا تحوي مجلد mobile", r.stdout)


if __name__ == "__main__":
    unittest.main()
