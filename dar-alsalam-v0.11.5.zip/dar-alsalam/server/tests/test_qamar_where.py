"""قمر و«أين الطبيب؟» (0.11.1): يجيب عن فرع الطبيب ودوامه (الآن/اليوم/غداً/يوم محدد) من جدوله الفعلي، ولا يخترع شيئاً.
الوقت مثبَّت (الاثنين 23 نوفمبر 2026 الساعة 9:00 بتوقيت الرياض). ويفحص أيضاً أن ساعات الأطباء تصل للتطبيق في البيانات العامة."""
import unittest

from test_qamar_slots import SlotsBase, SHIFTS, ask, slots_of
from test_schedule import day

import qamar as qmod  # noqa: E402
import scheddb as sd  # noqa: E402


class WhereBase(SlotsBase):
    def setUp(self):
        super().setUp()
        docs = self.db.list_entities("doctors")
        self.doc = next(d for d in docs if d["id"] == self.dental[0])
        self.nm = self.doc["name"]
        self.B = [b["id"] for b in self.db.list_entities("branches")][1]
        self.bn = {b["id"]: (b.get("shortName") or b["name"]) for b in self.db.list_entities("branches")}

    def q(self, tail, **kw):
        return ask(self.e, "الدكتور %s %s" % (self.nm, tail), **kw)


class TestWhere(WhereBase):
    def test_present_now_and_today_hours(self):
        self.hours(self.doc["id"])
        r = self.q("في أي فرع الحين؟")
        self.assertIn("موجود الآن في " + self.bn[self.A], r["text"])
        self.assertIn("من 9:00 ص إلى 12:30 م، ومن 4:00 م إلى 10:00 م", r["text"])
        self.assertEqual(r["intent"], "doctor_where")
        self.assertEqual(r["source"], "kb")
        self.assertEqual(self.fake.calls, [])                                       # بلا نموذج لغوي
        self.assertEqual(slots_of(r), [])
        self.assertTrue(any(a["type"] == "book" and a.get("doctorId") == self.doc["id"] for a in r["actions"]))
        self.assertIn("ليس توفّراً للمواعيد", r["text"])

    def test_not_on_duty_now_but_later_today(self):
        self.hours(self.doc["id"], windows=[("16:00", "22:00")])
        r = self.q("موجود الان؟")
        self.assertIn("ما هو في الدوام الآن، لكن يداوم اليوم", r["text"])
        self.assertIn("من 4:00 م إلى 10:00 م", r["text"])
        self.assertNotIn("موجود الآن", r["text"])

    def test_tomorrow_and_named_day(self):
        self.hours(self.doc["id"])
        r = self.q("في أي فرع بكرة؟")
        self.assertIn("يداوم غداً " + self.bn[self.A], r["text"])
        r = self.q("متى دوامه يوم الخميس")
        self.assertIn("يداوم الخميس 26 " + self.bn[self.A], r["text"])

    def test_day_off_and_next_working_day(self):
        self.hours(self.doc["id"], days=[0, 1, 2, 3, 4])                              # الأحد–الخميس: بلا الجمعة والسبت
        r = self.q("هل هو موجود يوم الجمعة؟")
        self.assertIn("ما عنده دوام الجمعة 27", r["text"])
        self.assertIn("وأقرب دوام له الأحد 29 " + self.bn[self.A], r["text"])

    def test_vacation_is_respected(self):
        self.hours(self.doc["id"])
        rows, _ = self.db.sched_get(self.doc["id"])
        rows = [{k: r[k] for k in ("branch_id", "weekday", "start_min", "end_min", "slot_min")} for r in rows]
        self.db.sched_replace(self.doc["id"], rows, [{"branch_id": "", "day": day(1), "kind": "off", "start_min": None, "end_min": None, "slot_min": None, "note": ""}])
        r = self.q("في أي فرع بكرة؟")
        self.assertIn("ما عنده دوام غداً", r["text"])
        self.assertIn("وأقرب دوام له", r["text"])

    def test_two_branches_same_day_are_both_named(self):
        rows = [{"branch_id": self.A, "weekday": wd, "start_min": 9 * 60, "end_min": 12 * 60 + 30, "slot_min": 30} for wd in range(7)]
        rows += [{"branch_id": self.B, "weekday": wd, "start_min": 16 * 60, "end_min": 22 * 60, "slot_min": 30} for wd in range(7)]
        self.db.sched_replace(self.doc["id"], rows, [])
        r = self.q("في أي فرع اليوم؟")
        self.assertIn(self.bn[self.A], r["text"])
        self.assertIn(self.bn[self.B], r["text"])

    def test_24_hour_doctor(self):
        self.hours(self.doc["id"], windows=[("00:00", "24:00")])
        r = self.q("موجود الان؟")
        self.assertIn("على مدار 24 ساعة", r["text"])

    def test_unscheduled_doctor_is_not_invented(self):
        r = self.q("في أي فرع اليوم؟")                                               # لا ساعات لأحد
        self.assertIn("ما عندي جدول دوام مؤكد له حالياً", r["text"])
        self.assertNotIn("يداوم", r["text"])
        self.assertEqual(qmod.time_mentions(r["text"]), [])

    def test_text_only_states_times_from_the_schedule(self):
        self.hours(self.doc["id"], windows=[("10:15", "13:45")])
        r = self.q("وين يداوم بكرة؟")
        self.assertIn("من 10:15 ص إلى 1:45 م", r["text"])

    def test_booking_requests_still_go_to_slots(self):
        self.hours(self.doc["id"])
        r = ask(self.e, "ابي موعد عند الدكتور %s بكرة" % self.nm)
        self.assertTrue(slots_of(r))
        self.assertNotEqual(r["intent"], "doctor_where")

    def test_followup_uses_the_doctor_from_history(self):
        self.hours(self.doc["id"])
        hist = [{"role": "user", "content": "ابي اعرف عن الدكتور " + self.nm}, {"role": "assistant", "content": "تفضل"}]
        r = ask(self.e, "في أي فرع هو بكرة؟", hist=hist)
        self.assertEqual(r["intent"], "doctor_where")
        self.assertIn("يداوم غداً", r["text"])

    def test_no_doctor_named_falls_through(self):
        self.hours(self.doc["id"])
        r = ask(self.e, "وين الفروع؟")
        self.assertNotEqual(r["intent"], "doctor_where")

    def test_emergency_is_never_hijacked(self):
        self.hours(self.doc["id"])
        r = ask(self.e, "الدكتور %s وين موجود، عندي الم شديد في الصدر وصعوبة تنفس" % self.nm)
        self.assertNotEqual(r["intent"], "doctor_where")


class TestPublicHours(WhereBase):
    def meta(self):
        s, d, _ = self.e.req("GET", "/api/v1/clinic")
        self.assertEqual(s, 200)
        return d["meta"]

    def test_weekly_hours_reach_the_app_and_follow_changes(self):
        self.assertEqual(self.meta().get("hours"), {})
        self.hours(self.doc["id"], days=[0, 1])
        h = self.meta()["hours"]
        self.assertEqual(sorted(h), [self.doc["id"]])
        self.assertIn([self.A, 0, 9 * 60, 12 * 60 + 30], h[self.doc["id"]])
        self.assertIn([self.A, 1, 16 * 60, 22 * 60], h[self.doc["id"]])
        self.assertEqual(len(h[self.doc["id"]]), 4)
        self.hours(self.doc["id"], days=[0], windows=[("08:00", "14:00")], branch=self.B)
        self.assertEqual(self.meta()["hours"][self.doc["id"]], [[self.B, 0, 480, 840]])

    def test_only_active_public_doctors(self):
        self.hours(self.doc["id"])
        self.db.sched_replace("dr-ghost", [{"branch_id": self.A, "weekday": 0, "start_min": 540, "end_min": 600, "slot_min": 30}], [])
        self.assertEqual(sorted(self.meta()["hours"]), [self.doc["id"]])


if __name__ == "__main__":
    unittest.main()
