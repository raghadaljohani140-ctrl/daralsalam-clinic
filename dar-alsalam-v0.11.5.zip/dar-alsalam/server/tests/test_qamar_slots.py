"""قمر والمواعيد الفعلية: يفهم «بكرة الصبح» و«الخميس العصر» و«الساعة 5» ويعرض أزراراً من نظام المواعيد نفسه، ولا يخترع وقتاً أبداً.
الوقت مثبَّت (الاثنين 23 نوفمبر 2026 الساعة 9:00 بتوقيت الرياض)."""
import datetime as dt
import re
import unittest
from unittest import mock

from helpers import Env
from test_qamar_llm import FakeLLM
from test_schedule import NOW, TODAY, day, fake_now   # يضبط مسار الخادم (helpers) قبل استيراد وحداته

import qamar as qmod  # noqa: E402
import qamar_slots as qs  # noqa: E402
import scheddb as sd  # noqa: E402

SHIFTS = [("09:00", "12:30"), ("16:00", "22:00")]
DEV = "slots_dev_000000000000000"


def ask(e, msg, hist=None, dev=DEV):
    s, d, _ = e.req("POST", "/api/v1/qamar", {"deviceId": dev, "message": msg, "history": hist or []})
    assert s == 200, (s, d)
    return d["reply"]


def slots_of(r):
    return [a for a in r["actions"] if a["type"] == "slot"]


class TestParseWhen(unittest.TestCase):
    T = dt.date(2026, 11, 23)                      # الاثنين

    def w(self, s):
        return qs.parse_when(s, self.T)

    def test_days(self):
        self.assertEqual(self.w("بكرة الصبح"), {"day": dt.date(2026, 11, 24), "period": "am", "at": None})
        self.assertEqual(self.w("بعد بكرة العصر")["day"], dt.date(2026, 11, 25))
        self.assertEqual(self.w("يوم الخميس")["day"], dt.date(2026, 11, 26))
        self.assertEqual(self.w("الاثنين")["day"], dt.date(2026, 11, 30))              # اليوم نفسه ليس «القادم»
        self.assertEqual(self.w("الأحد")["day"], dt.date(2026, 11, 29))
        self.assertEqual(self.w("اليوم المغرب"), {"day": self.T, "period": "night", "at": None})
        self.assertEqual(self.w("الليلة"), {"day": self.T, "period": "night", "at": None})
        self.assertEqual(self.w("ابي كشف يوم الجمعة")["day"], dt.date(2026, 11, 27))

    def test_periods_and_greetings(self):
        self.assertIsNone(self.w("صباح الخير")["period"])                               # تحية لا فترة
        self.assertEqual(self.w("صباحاً")["period"], "am")
        self.assertEqual(self.w("بعد الظهر")["period"], "pm")
        self.assertEqual(self.w("بعد العصر")["period"], "asr")
        self.assertEqual(self.w("الخميس المساء")["period"], "eve")
        self.assertEqual(self.w("السلام عليكم"), {"day": None, "period": None, "at": None})
        self.assertIsNone(self.w("احد الاطباء")["day"])                                   # «أحد» ليست يوم الأحد

    def test_hours(self):
        self.assertEqual(self.w("الساعة 5")["at"], 17 * 60)                               # دون كلمة: ساعات الدوام المعتادة
        self.assertEqual(self.w("الساعة 10")["at"], 10 * 60)
        self.assertEqual(self.w("الساعة 5 العصر")["at"], 17 * 60)
        self.assertEqual(self.w("9:30 صباحاً")["at"], 9 * 60 + 30)
        self.assertEqual(self.w("الساعة ٩ مساء")["at"], 21 * 60)
        self.assertEqual(self.w("بكرة الساعة 4 مساء"), {"day": dt.date(2026, 11, 24), "period": "eve", "at": 16 * 60})
        self.assertIsNone(self.w("الساعة 12")["at"])                                      # ظهراً أم منتصف الليل؟ لا نخمّن
        self.assertIsNone(self.w("عمري 30 سنة")["at"])


class TestGuardTimes(unittest.TestCase):
    def test_time_mentions(self):
        for s in ("موعدك الساعة 5 مساء", "٩:٣٠ صباحاً", "عند 5 م", "الساعة الخامسة مساءً", "يفتح 9 صباحاً", "من 4:30 إلى 7:30"):
            self.assertTrue(qmod.time_mentions(s), s)
        for s in ("الطب العام على مدار 24 ساعة", "على مدار الساعة", "الرقم الموحد 920031134", "عيادة الأسنان", "بعد 3 أيام"):
            self.assertEqual(qmod.time_mentions(s), [], s)


class SlotsBase(unittest.TestCase):
    MODE = "llm"

    def setUp(self):
        self.fake = FakeLLM()
        self.e = Env({"QAMAR_PROVIDER": "anthropic", "QAMAR_API_KEY": "sk-test", "QAMAR_BASE_URL": self.fake.url,
                      "QAMAR_MODEL": "claude-haiku-5-5", "QAMAR_DEVICE_CAP": "50", "QAMAR_DAILY_CAP": "100"})
        self.db = self.e.app.db
        q = self.db.get_kv("qamar")
        q["mode"] = self.MODE
        self.db.set_kv("qamar", q)
        docs = self.db.list_entities("doctors")
        self.dental = [d["id"] for d in docs if "dental" in (d.get("specialtyIds") or [])]
        self.peds = [d["id"] for d in docs if "pediatrics" in (d.get("specialtyIds") or [])]
        self.A = [b["id"] for b in self.db.list_entities("branches")][0]
        self._ctx = fake_now()
        self._ctx.__enter__()
        self.addCleanup(self._ctx.__exit__, None, None, None)
        self.addCleanup(self.e.close)
        self.addCleanup(self.fake.close)

    def hours(self, doctor, windows=SHIFTS, days=range(7), slot=30, branch=None):
        rows = [{"branch_id": branch or self.A, "weekday": wd, "start_min": sd.parse_hhmm(a), "end_min": sd.parse_hhmm(b), "slot_min": slot}
                for wd in days for a, b in windows]
        self.db.sched_replace(doctor, rows, [])

    def free(self, doctor, n):
        s, d, _ = self.e.req("GET", "/api/v1/slots?doctorId=%s" % doctor)
        self.assertEqual(s, 200, d)
        return [x["start"] for x in d["days"][n]["slots"]]

    def bookings(self):
        return self.db.conn().execute("SELECT COUNT(*) FROM bookings").fetchone()[0]


class TestOffers(SlotsBase):
    def test_no_scheduled_doctors_means_nothing_changes(self):
        r = ask(self.e, "ابي موعد اسنان بكرة الصبح")
        self.assertEqual(slots_of(r), [])
        self.assertTrue(any(a["type"] == "book" for a in r["actions"]))            # مسار «طلب حجز» كما كان
        self.assertEqual(self.fake.calls, [])

    def test_booking_request_gets_real_slots(self):
        self.hours(self.dental[0])
        r = ask(self.e, "ابي موعد اسنان بكرة الصبح")
        sl = slots_of(r)
        self.assertTrue(sl)
        self.assertEqual({a["day"] for a in sl}, {day(1)})
        self.assertTrue(all(a["start"] < "12:00" and a["doctorId"] == self.dental[0] for a in sl), sl)
        self.assertIn("هذه أقرب المواعيد المتاحة غداً صباحاً فعلياً في النظام", r["text"])
        self.assertIn("«تأكيد الحجز»", r["text"])
        self.assertEqual(r["source"], "kb")
        self.assertEqual(self.fake.calls, [])                                     # بلا نموذج لغوي ولو كان الوضع «النموذج لأغلب الأسئلة»
        free = self.free(self.dental[0], 1)
        for a in sl:
            self.assertIn(a["start"], free)                                       # كل زر موعد فعلي متاح الآن
            self.assertRegex(a["day"], r"^\d{4}-\d{2}-\d{2}$")
            self.assertRegex(a["start"], r"^\d{2}:\d{2}$")
            self.assertTrue(a["label"].startswith("غداً "))
        self.assertTrue(any(a["type"] == "book" and a["label"] == "عرض كل المواعيد" for a in r["actions"]))

    def test_text_never_states_a_time_itself(self):
        self.hours(self.dental[0])
        for msg in ("ابي موعد اسنان بكرة الصبح", "ابغى احجز عند الاسنان الخميس العصر", "موعد اسنان"):
            r = ask(self.e, msg)
            self.assertTrue(slots_of(r), msg)
            self.assertEqual(qmod.time_mentions(r["text"]), [], r["text"])        # الأوقات في الأزرار فقط

    def test_missing_period_shifts_honestly(self):
        self.hours(self.dental[0], windows=[("16:00", "22:00")])                  # لا دوام صباحي
        r = ask(self.e, "ابي موعد اسنان بكرة الصبح")
        sl = slots_of(r)
        self.assertTrue(sl)
        self.assertIn("ما وجدت مواعيد متاحة غداً صباحاً، وهذه أقرب المواعيد المتاحة فعلياً", r["text"])
        self.assertTrue(all(a["day"] == day(1) and a["start"] >= "16:00" for a in sl), sl)

    def test_specific_hour_returns_nearby_times(self):
        self.hours(self.dental[0])
        r = ask(self.e, "ابي موعد اسنان بكرة الساعة 5 مساء")
        sl = slots_of(r)
        self.assertTrue(sl)
        starts = [a["start"] for a in sl]
        self.assertIn("17:00", starts)
        self.assertTrue(all("15:30" <= s <= "18:30" for s in starts), starts)
        self.assertEqual(starts, sorted(starts))
        self.assertIn("حوالي 5:00 م", r["text"])

    def test_hour_phrase_is_not_mistaken_for_opening_hours(self):
        self.hours(self.dental[0])
        r = ask(self.e, "عندي ألم في اسناني ابغى كشف بكرة الساعة 5")                  # المحرك وحده يفهم «الساعة» سؤالاً عن الدوام
        sl = slots_of(r)
        self.assertTrue(sl)
        self.assertNotIn("الدوام المعلن", r["text"])
        self.assertTrue(any(a["type"] == "book" for a in r["actions"]))
        self.assertEqual(slots_of(ask(self.e, "متى الدوام")), [])                      # وسؤال الدوام الحقيقي كما هو

    def test_asr_and_night_windows(self):
        self.hours(self.dental[0], windows=[("09:00", "12:30"), ("16:00", "22:00")])
        r = ask(self.e, "موعد اسنان بكرة العصر")
        self.assertTrue(all("15:00" <= a["start"] < "18:00" for a in slots_of(r)), slots_of(r))
        self.assertIn("عصراً", r["text"])
        r = ask(self.e, "موعد اسنان بكرة العشاء")
        self.assertTrue(all(a["start"] >= "18:00" for a in slots_of(r)), slots_of(r))

    def test_booking_without_a_clinic_asks_which_one_with_buttons(self):
        self.hours(self.dental[0])
        self.hours(self.peds[0])
        r = ask(self.e, "احجز لي موعد")
        self.assertEqual(slots_of(r), [])
        self.assertIn("أي عيادة", r["text"])
        self.assertEqual(sorted(r["chips"]), sorted(["موعد الأسنان", "موعد الأطفال"]))        # فقط العيادات التي لها مواعيد
        r2 = ask(self.e, "موعد الأسنان")                                              # الزر نفسه يعمل كرسالة
        self.assertTrue(slots_of(r2))
        self.assertTrue(all(a["doctorId"] == self.dental[0] for a in slots_of(r2)))
        self.assertEqual(self.fake.calls, [])

    def test_booked_slot_is_not_offered(self):
        self.hours(self.dental[0])
        body = {"deviceId": "other_device_00000000000", "name": "مراجع", "phone": "0577700010", "doctorId": self.dental[0], "branchId": self.A,
                "consent": True, "slot": {"day": day(1), "start": "09:00"}}
        s, d, _ = self.e.req("POST", "/api/v1/bookings", body)
        self.assertEqual(s, 201, d)
        r = ask(self.e, "ابي موعد اسنان بكرة الصبح")
        self.assertNotIn("09:00", [a["start"] for a in slots_of(r)])

    def test_qamar_never_creates_bookings(self):
        self.hours(self.dental[0])
        n = self.bookings()
        for m in ("ابي احجز اسنان بكرة", "احجز لي موعد", "ايوه احجز"):
            ask(self.e, m)
        self.assertEqual(self.bookings(), n)

    def test_follow_up_uses_context_and_no_llm(self):
        self.hours(self.dental[0])
        hist = [{"role": "user", "content": "عندي ألم في اسناني"},
                {"role": "assistant", "content": "من كلامك، العيادة الأقرب لما ذكرته هي «الأسنان». هذا توجيه إداري فقط. تبي أرتّب لك طلب حجز؟"},
                {"role": "user", "content": "بكرة الصبح"}]
        r = ask(self.e, "بكرة الصبح", hist=hist)
        sl = slots_of(r)
        self.assertTrue(sl)
        self.assertTrue(all(a["doctorId"] == self.dental[0] for a in sl))
        self.assertEqual(self.fake.calls, [])
        r2 = ask(self.e, "ايوه", hist=hist[:2] + [{"role": "user", "content": "ايوه"}])           # «تبي أرتّب؟» ← «ايوه»
        self.assertTrue(slots_of(r2), r2)

    def test_route_answer_drops_the_old_question(self):
        self.hours(self.dental[0])
        r = ask(self.e, "عندي ألم في اسناني ابغى كشف بكرة")
        self.assertTrue(slots_of(r))
        self.assertNotIn("تبي أرتّب لك طلب حجز", r["text"])
        self.assertIn("هذه أقرب المواعيد", r["text"])

    def test_named_doctor_only_that_doctor(self):
        self.hours(self.dental[0])
        self.hours(self.dental[1])
        name = self.db.get_entity("doctors", self.dental[0])["name"].split()[0]
        r = ask(self.e, "ابغى موعد مع دكتور %s بكرة" % name)
        sl = slots_of(r)
        if sl:                                                                      # الاسم الأول قد يطابق أكثر من طبيب؛ المهم ألا يظهر طبيب لم يُذكر
            ids = {a["doctorId"] for a in sl}
            kb = self.e.app.get_kb()
            self.assertTrue(ids <= {d for d in self.dental if name in kb.by_id[("doctors", d)]["name"]})

    def test_unscheduled_doctor_stays_on_request_flow(self):
        self.hours(self.dental[0])
        other = self.peds[0]                                                        # طبيب أطفال بلا جدول
        r = ask(self.e, "ابي موعد اطفال بكرة الصبح")
        self.assertEqual(slots_of(r), [])
        self.assertTrue(any(a["type"] == "book" for a in r["actions"]))
        self.assertNotIn(other, [a.get("doctorId") for a in r["actions"]])

    def test_several_doctors_each_labelled(self):
        for d in self.dental[:3]:
            self.hours(d)
        r = ask(self.e, "ابي موعد اسنان بكرة")
        sl = slots_of(r)
        self.assertGreaterEqual(len({a["doctorId"] for a in sl}), 2)
        self.assertTrue(all("· د. " in a["label"] for a in sl), [a["label"] for a in sl])
        self.assertLessEqual(len(sl), 4)

    def test_two_branches_are_named_in_labels(self):
        brs = [b["id"] for b in self.db.list_entities("branches")]
        self.hours(self.dental[0], branch=brs[0], days=range(0, 7), windows=[("09:00", "12:30")])
        self.hours(self.dental[1], branch=brs[1], days=range(0, 7), windows=[("09:30", "12:00")])
        r = ask(self.e, "ابي موعد اسنان بكرة الصبح")
        sl = slots_of(r)
        self.assertEqual({a["branchId"] for a in sl}, set(brs[:2]))
        self.assertTrue(all(" · فرع " in a["label"] or "·" in a["label"] for a in sl))

    def test_branch_named_in_message_is_respected(self):
        brs = [b["id"] for b in self.db.list_entities("branches")]
        if len(brs) < 2:
            self.skipTest("فرع واحد")
        self.hours(self.dental[0], branch=brs[0])
        r = ask(self.e, "ابي موعد اسنان بكرة فرع التلال")
        self.assertEqual([a for a in slots_of(r) if a["branchId"] != brs[1]], [])   # لا نعرض فرعاً آخر بصمت

    def test_emergency_never_gets_slots(self):
        self.hours(self.dental[0])
        r = ask(self.e, "عندي ألم شديد في الصدر وضيق نفس ابي موعد بكرة")
        self.assertEqual(slots_of(r), [])
        self.assertEqual(r["intent"], "emergency")

    def test_self_harm_never_gets_slots(self):
        self.hours(self.dental[0])
        r = ask(self.e, "ابغى انتحر ابي موعد بكرة")
        self.assertEqual(slots_of(r), [])
        self.assertIn("937", r["text"])
        self.assertEqual(self.fake.calls, [])

    def test_unrelated_questions_unchanged(self):
        self.hours(self.dental[0])
        for msg in ("وين الفروع", "وش خدماتكم اليوم", "ارقام التواصل", "كم سعر الكشف"):
            self.assertEqual(slots_of(ask(self.e, msg)), [], msg)

    def test_no_free_slots_message(self):
        self.hours(self.dental[0], days=[4])                                        # الخميس فقط
        self.db.set_kv("scheduling", {"horizonDays": 1})                            # والمهلة يوم واحد ← لا مواعيد
        r = ask(self.e, "عندي ألم في اسناني ابغى كشف بكرة")
        self.assertEqual(slots_of(r), [])
        self.assertIn("لا توجد مواعيد متاحة حالياً في الأيام القادمة", r["text"])

    def test_failure_in_slots_degrades_to_the_plain_reply(self):
        self.hours(self.dental[0])
        with mock.patch.object(qs, "offers", side_effect=RuntimeError("boom")):
            r = ask(self.e, "ابي موعد اسنان بكرة الصبح")
        self.assertEqual(slots_of(r), [])
        self.assertTrue(r["text"])
        self.assertTrue(any(a["type"] == "book" for a in r["actions"]))

    def test_general_doctor_is_available_at_night(self):
        gp = [d["id"] for d in self.db.list_entities("doctors") if "general" in (d.get("specialtyIds") or [])][0]
        self.hours(gp, windows=[("00:00", "24:00")])
        r = ask(self.e, "ابي موعد طبيب عام الليلة")
        sl = slots_of(r)
        self.assertTrue(sl)
        self.assertTrue(all(a["start"] >= "12:00" for a in sl) and any(a["start"] >= "22:00" for a in sl), [a["start"] for a in sl])


class TestKbOnlyMode(SlotsBase):
    """وضع «قاعدة المعرفة فقط»: المواعيد الفعلية تعمل بلا أي استدعاء للنموذج (لا تكلفة ولا مزوّد)."""
    MODE = "kb"

    def test_slots_without_any_provider_call(self):
        self.hours(self.dental[0])
        r = ask(self.e, "ابي موعد اسنان بكرة الصبح")
        self.assertTrue(slots_of(r))
        self.assertEqual(r["source"], "kb")
        self.assertEqual(self.fake.calls, [])

    def test_ask_mode_without_provider_call(self):
        self.hours(self.dental[0])
        r = ask(self.e, "ابي احجز موعد")
        self.assertIn("أي عيادة", r["text"])
        self.assertTrue(r["chips"])
        self.assertEqual(self.fake.calls, [])


class TestLLMStaysHonest(SlotsBase):
    MODE = "auto"

    def test_llm_time_claims_are_rejected(self):
        self.fake.reply = "الدكتور متاح بكرة الساعة 5 مساء، تفضل بالحضور."
        r = ask(self.e, "اريد اكل بيتزا")                                          # لا نية معروفة ← النموذج
        self.assertEqual(len(self.fake.calls), 1)
        self.assertEqual(r["source"], "kb-fallback")
        self.assertTrue(r["guard"].startswith("time:"), r)

    def test_llm_prompt_forbids_times_and_confirmations(self):
        ask(self.e, "اريد اكل بيتزا")
        system = self.fake.calls[0]["body"]["system"]
        self.assertIn("لا تذكر أي موعد أو وقت أو يوم", system)
        self.assertIn("ولا «رتبت لك موعداً»", system)

    def test_plain_llm_answers_still_pass(self):
        self.fake.reply = "الطب العام متاح على مدار 24 ساعة طوال الأسبوع حسب الموقع."
        r = ask(self.e, "اريد اكل بيتزا")
        self.assertEqual(r["source"], "llm")


if __name__ == "__main__":
    unittest.main()
