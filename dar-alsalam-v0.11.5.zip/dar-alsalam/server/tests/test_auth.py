import json
import unittest

from helpers import Env
from test_api import booking_body, DEV


def last_code(e, phone):
    lines = (e.tmp / "sms-test.log").read_text(encoding="utf-8").strip().splitlines()
    msg = [json.loads(x) for x in lines if json.loads(x)["phone"] == phone][-1]
    import re
    return re.search(r"(\d{6})", msg["text"]).group(1)


PROFILE = {"name": "أحمد الجهني", "gender": "male", "birthDate": "1989-07-25", "nationalId": ""}


class TestAuthOff(unittest.TestCase):
    def test_disabled_by_default_booking_still_works(self):
        e = Env()
        try:
            _, ds, _ = e.req("GET", "/api/v1/clinic")
            self.assertFalse(ds["meta"]["auth"]["enabled"])
            s, d, _ = e.req("POST", "/api/v1/auth/otp", {"phone": "0565551234"})
            self.assertEqual((s, d["error"]), (503, "auth_disabled"))
            s, _, _ = e.req("POST", "/api/v1/bookings", booking_body())
            self.assertEqual(s, 201)
        finally:
            e.close()


class TestAuthOn(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.e = Env({"DS_SMS_PROVIDER": "test"})

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def test_full_flow(self):
        e = self.e
        _, ds, _ = e.req("GET", "/api/v1/clinic")
        self.assertTrue(ds["meta"]["auth"]["enabled"])
        # الحجز بلا تسجيل مرفوض
        s, d, _ = e.req("POST", "/api/v1/bookings", booking_body())
        self.assertEqual((s, d["error"]), (401, "login_required"))
        # رقم غير صالح
        s, _, _ = e.req("POST", "/api/v1/auth/otp", {"phone": "123"})
        self.assertEqual(s, 422)
        s, d, _ = e.req("POST", "/api/v1/auth/otp", {"phone": "0565551234"})
        self.assertEqual((s, d["isNew"]), (200, True))
        # طلب ثانٍ فوراً مرفوض
        s, _, _ = e.req("POST", "/api/v1/auth/otp", {"phone": "0565551234"})
        self.assertEqual(s, 429)
        code = last_code(e, "966565551234")
        # رمز خاطئ
        s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0565551234", "code": "000000" if code != "000000" else "111111", "profile": PROFILE})
        self.assertEqual((s, d["error"]), (400, "otp_bad"))
        # مستخدم جديد بلا بيانات
        s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0565551234", "code": code})
        self.assertEqual((s, d["error"]), (422, "profile_needed"))
        self.assertIn("name", d["fields"])
        # هوية غير صحيحة
        s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0565551234", "code": code, "profile": dict(PROFILE, nationalId="123")})
        self.assertEqual(s, 422)
        s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0565551234", "code": code, "profile": dict(PROFILE, nationalId="1067995256")})
        self.assertEqual(s, 200, d)
        tok = d["token"]
        self.assertEqual(d["patient"]["phone"], "966565551234")
        self.assertTrue(d["patient"]["hasNationalId"])
        self.assertNotIn("1067995256", json.dumps(d))
        # الرمز يُستهلك
        s, _, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0565551234", "code": code})
        self.assertEqual(s, 400)
        H = {"Authorization": "Bearer " + tok}
        s, d, _ = e.req("GET", "/api/v1/auth/me", headers=H)
        self.assertEqual((s, d["patient"]["name"]), (200, "أحمد الجهني"))
        s, _, _ = e.req("GET", "/api/v1/auth/me", headers={"Authorization": "Bearer x.y"})
        self.assertEqual(s, 401)
        # الحجز: الاسم والجوال من الحساب لا من الطلب
        s, d, _ = e.req("POST", "/api/v1/bookings", booking_body(name="اسم مزوّر", phone="0500000000"), headers=H)
        self.assertEqual(s, 201, d)
        b = e.app.db.get_booking(d["booking"]["id"])
        self.assertEqual((b["name"], b["phone"]), ("أحمد الجهني", "966565551234"))
        # تعديل الملف
        s, d, _ = e.req("POST", "/api/v1/auth/me", dict(PROFILE, name="أحمد محمد"), headers=H)
        self.assertEqual((s, d["patient"]["name"]), (200, "أحمد محمد"))
        # تسجيل دخول لاحق (حساب موجود) لا يطلب بيانات
        import time
        e.app.db.otp_clear("966565551234")
        e.app.rl.h.clear()
        s, d, _ = e.req("POST", "/api/v1/auth/otp", {"phone": "+966565551234"})
        self.assertEqual((s, d["isNew"]), (200, False))
        s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0565551234", "code": last_code(e, "966565551234")})
        self.assertEqual(s, 200)
        # حذف الحساب يجهّل الطلبات ويبطل الدخول
        s, _, _ = e.req("POST", "/api/v1/auth/delete", {}, headers=H)
        self.assertEqual(s, 200)
        self.assertIsNone(e.app.db.patient_by_phone("966565551234"))
        b = e.app.db.get_booking(b["id"])
        self.assertEqual((b["name"], b["phone"]), ("(محذوف)", ""))
        s, _, _ = e.req("GET", "/api/v1/auth/me", headers=H)
        self.assertEqual(s, 401)

    def test_otp_attempts_limit(self):
        e = self.e
        e.app.rl.h.clear()
        e.req("POST", "/api/v1/auth/otp", {"phone": "0551112222"})
        code = last_code(e, "966551112222")
        bad = "000000" if code != "000000" else "111111"
        for _ in range(5):
            e.req("POST", "/api/v1/auth/verify", {"phone": "0551112222", "code": bad, "profile": PROFILE})
        s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0551112222", "code": code, "profile": PROFILE})
        self.assertEqual((s, d["error"]), (400, "otp_expired"))

    def test_patient_token_not_admin_token(self):
        e = self.e
        e.app.rl.h.clear()
        e.req("POST", "/api/v1/auth/otp", {"phone": "0553334444"})
        s, d, _ = e.req("POST", "/api/v1/auth/verify", {"phone": "0553334444", "code": last_code(e, "966553334444"), "profile": PROFILE})
        self.assertEqual(s, 200)
        s, _, _ = e.req("GET", "/api/admin/dataset", headers={"Authorization": "Bearer " + d["token"]})
        self.assertEqual(s, 401)


if __name__ == "__main__":
    unittest.main()
