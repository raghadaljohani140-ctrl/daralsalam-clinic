"""الدورة السريرية: حجز ← استقبال ← طبيب ← انتهاء ← مغادرة ← ما يراه المراجع. مع عزل الأطباء وقفل الزيارة المنتهية."""
import json
import threading
import unittest
from urllib.parse import quote, urlencode

from helpers import Env
from test_api import booking_body
from test_files import PDF, PROFILE, login as patient_login, raw_req
from test_staff import PW, PW2

SECRET_NOTE = "ملاحظة داخلية سرّية للطبيب"
DX = {"complaint": "ألم حلق منذ يومين", "diagnosis": "التهاب لوزتين حاد", "notes": SECRET_NOTE, "advice": "راحة وسوائل دافئة", "followUp": "بعد أسبوع",
      "rx": [{"drug": "أموكسيسيلين 500", "dose": "حبة", "freq": "3 مرات يومياً", "duration": "7 أيام", "note": "بعد الأكل"},
             {"drug": "باراسيتامول 500", "dose": "حبة", "freq": "عند اللزوم", "duration": "3 أيام", "note": ""}],
      "orders": [{"type": "lab", "name": "صورة دم كاملة", "note": ""}, {"type": "radiology", "name": "أشعة صدر", "note": "وضع أمامي"}]}


class Base(unittest.TestCase):
    ENV = None

    @classmethod
    def setUpClass(cls):
        cls.e = Env(cls.ENV)
        _, d, _ = cls.e.adm("GET", "/entities/branches")
        cls.br = [b["id"] for b in d["items"]]
        _, d, _ = cls.e.adm("GET", "/entities/doctors")
        cls.docs = [x["id"] for x in d["items"] if not x.get("branchIds") or cls.br[0] in x["branchIds"]][:16]   # لكل حساب طبيب سجله الخاص
        cls.names = {x["id"]: x["name"] for x in d["items"]}
        cls.n = 0
        cls.R = cls.ready("rec_main", "reception", cls.br[0])

    @classmethod
    def tearDownClass(cls):
        cls.e.close()

    def setUp(self):
        self.e.app.rl.h.clear()

    # --------------------------------------------------------------- أدوات
    @classmethod
    def ready(cls, username, role, branch="", doctor=None):
        body = {"username": username, "name": "موظف " + username, "role": role, "branchId": branch, "password": PW}
        if doctor:
            body["doctorId"] = doctor
        s, d, _ = cls.e.adm("POST", "/staff", body)
        assert s == 201, (s, d)
        s, d, _ = cls.e.req("POST", "/api/staff/login", {"username": username, "password": PW})
        assert s == 200, d
        s, d, _ = cls.e.req("POST", "/api/staff/password", {"old": PW, "new": PW2}, {"Authorization": "Bearer " + d["token"]})
        assert s == 200, d
        return {"Authorization": "Bearer " + d["token"]}

    def st(self, method, path, H, body=None):
        return self.e.req(method, "/api/staff" + path, body, H)

    @classmethod
    def uniq(cls):
        cls.n += 1
        return cls.n

    def newrec(self, name="مراجع الدورة", H=None, **kw):
        i = self.uniq()
        s, d, _ = self.st("POST", "/records", H or self.R, dict({"name": name, "phone": "05665%05d" % i, "nationalId": "10100%05d" % i, "birthDate": "1990-01-01", "gender": "male"}, **kw))
        self.assertIn(s, (200, 201), d)
        return d["record"]["mrn"]

    def checkin(self, doctor, name="مراجع الدورة", booking=None, reason="", H=None, mrn=None):
        mrn = mrn or self.newrec(name)
        body = {"mrn": mrn, "doctorId": doctor, "reason": reason}
        if booking:
            body["bookingId"] = booking
        s, d, _ = self.st("POST", "/visits", H or self.R, body)
        self.assertEqual(s, 201, d)
        return mrn, d["visit"]

    def call(self, D, vid, expect=200):
        s, d, _ = self.st("POST", "/clinic/visits/%s/call" % vid, D)
        self.assertEqual(s, expect, d)
        return d

    def save(self, D, vid, body, expect=200):
        s, d, _ = self.st("PUT", "/clinic/visits/%s/encounter" % vid, D, body)
        self.assertEqual(s, expect, d)
        return d

    def finish(self, D, vid, body=None, expect=200):
        s, d, _ = self.st("POST", "/clinic/visits/%s/finish" % vid, D, body or {})
        self.assertEqual(s, expect, d)
        return d

    def status(self, vid, st, H=None, expect=200):
        s, d, _ = self.st("POST", "/visits/%s/status" % vid, H or self.R, {"status": st})
        self.assertEqual(s, expect, d)
        return d

    def notifs(self, dev, headers=None):
        return self.e.req("GET", "/api/v1/notifications?deviceId=" + dev, headers=headers)[1]["notifications"]

    def audit(self, ref):
        return [r["action"] for r in self.e.app.db.conn().execute("SELECT action FROM audit WHERE ref=?", (ref,))]


class TestClinicCycle(Base):
    """الدورة كاملة في وضع التجربة (بلا SMS): المراجع يرى زيارته عبر جهاز الحجز."""

    def test_full_cycle(self):
        e = self.e
        dev = "cycle_device_0123456789ab"
        D = self.ready("doc_cycle", "doctor", self.br[0], self.docs[0])
        # 1) المراجع يحجز من التطبيق
        s, d, _ = e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev, branchId=self.br[0], phone="0565559001", name="مراجع الدورة"))
        self.assertEqual(s, 201, d)
        bid = d["booking"]["id"]
        # 2) الاستقبال يؤكد الموعد
        s, d, _ = self.st("PATCH", "/bookings/" + bid, self.R, {"status": "confirmed", "appointmentText": "اليوم 5 عصراً"})
        self.assertEqual(s, 200, d)
        # 3) يصل المراجع: الاستقبال يسجّل وصوله من الحجز
        mrn, v = self.checkin(self.docs[0], booking=bid, reason="ألم في الحلق")
        vid = v["id"]
        s, d, _ = e.req("GET", "/api/v1/bookings?deviceId=" + dev)
        card = d["bookings"][0]
        self.assertEqual((card["visit"]["status"], card["visit"]["queueNo"], card["visit"]["summary"]), ("waiting", v["queueNo"], False))
        self.assertEqual(card["visit"]["doctorName"], self.names[self.docs[0]])
        n = self.notifs(dev)
        self.assertTrue(any(x["kind"] == "visit" and x["title"] == "تم تسجيل وصولك" and str(v["queueNo"]) in x["body"] for x in n), n)
        # 4) الاستقبال يجهّزه للطبيب؛ الطبيب يراه في طابوره
        self.status(vid, "ready")
        s, q, _ = self.st("GET", "/clinic/queue", D)
        self.assertEqual(s, 200)
        mine = [x for x in q["visits"] if x["id"] == vid]
        self.assertEqual((len(mine), mine[0]["status"], mine[0]["reason"]), (1, "ready", "ألم في الحلق"))
        self.assertEqual(q["doctor"]["name"], self.names[self.docs[0]])
        s, det, _ = self.st("GET", "/clinic/visits/" + vid, D)
        self.assertEqual((s, det["encounter"], det["history"], det["busy"]), (200, None, [], ""))
        self.assertEqual(det["patient"]["mrn"], mrn)
        self.assertRegex(det["patient"]["nationalIdMasked"], r"^\*{6}\d{4}$")           # الهوية مخفية حتى على الطبيب
        # 5) الطبيب يستدعي المراجع
        d = self.call(D, vid)
        self.assertEqual(d["visit"]["status"], "with_doctor")
        self.assertTrue(any(x["title"] == "حان دورك" for x in self.notifs(dev)))
        self.call(D, vid)                                                                 # تكرار الاستدعاء لا يخرّب شيئاً
        self.assertEqual(sum(1 for x in self.notifs(dev) if x["title"] == "حان دورك"), 1)  # ولا يكرر الإشعار
        s, det, _ = self.st("GET", "/clinic/visits/" + vid, D)
        self.assertEqual(det["encounter"]["complaint"], "ألم في الحلق")                  # الشكوى تبدأ بسبب الزيارة
        # الاستقبال لا يقفل زيارة الطبيب وهو يكتبها
        d = self.status(vid, "done", expect=409)
        self.assertEqual(d["error"], "doctor_writing")
        # 6) الطبيب يكتب مسودة (حفظ جزئي) ثم يكملها
        self.save(D, vid, {"diagnosis": "مسودة", "rx": DX["rx"][:1]})
        d = self.save(D, vid, {k: v_ for k, v_ in DX.items()})
        self.assertEqual((d["encounter"]["diagnosis"], len(d["encounter"]["rx"]), len(d["encounter"]["orders"])), (DX["diagnosis"], 2, 2))
        self.assertEqual(self.st("GET", "/clinic/visits/" + vid, D)[1]["encounter"]["notes"], SECRET_NOTE)
        # المراجع لا يرى شيئاً قبل أن ينهي الطبيب
        self.assertEqual(e.req("GET", "/api/v1/visits?deviceId=" + dev)[1]["visits"], [])
        self.assertEqual(e.req("GET", "/api/v1/visits/%s?deviceId=%s" % (vid, dev))[0], 404)
        self.assertEqual(self.st("GET", "/visits/%s/summary" % vid, self.R)[0], 409)
        # 7) إنهاء الزيارة
        d = self.finish(D, vid)
        self.assertEqual((d["visit"]["status"], d["visit"]["rxCount"], d["visit"]["orderCount"], d["visit"]["hasSummary"]), ("done", 2, 2, True))
        self.assertEqual(self.finish(D, vid, expect=409)["error"], "locked")             # لا تعديل بعد الإنهاء
        self.assertEqual(self.save(D, vid, {"diagnosis": "تعديل"}, expect=409)["error"], "locked")
        self.call(D, vid, expect=409)
        # 8) المراجع يرى ملخصه (بلا الملاحظات الداخلية) ويصله إشعار
        s, d, _ = e.req("GET", "/api/v1/visits?deviceId=" + dev)
        self.assertEqual([(x["id"], x["diagnosis"], x["rxCount"], x["orderCount"]) for x in d["visits"]], [(vid, DX["diagnosis"], 2, 2)])
        s, d, _ = e.req("GET", "/api/v1/visits/%s?deviceId=%s" % (vid, dev))
        self.assertEqual(s, 200, d)
        v_ = d["visit"]
        self.assertEqual((v_["advice"], v_["followUp"], [r["drug"] for r in v_["rx"]], [o["name"] for o in v_["orders"]]),
                         (DX["advice"], DX["followUp"], ["أموكسيسيلين 500", "باراسيتامول 500"], ["صورة دم كاملة", "أشعة صدر"]))
        self.assertNotIn("سرّية", json.dumps(d, ensure_ascii=False))
        self.assertNotIn("notes", v_)
        self.assertTrue(any(x["title"] == "انتهت زيارتك" and x["ref"] == "#/visits/" + vid for x in self.notifs(dev)))
        self.assertNotIn("أموكسيسيلين", json.dumps(self.notifs(dev), ensure_ascii=False))    # الإشعار لا يحمل دواءً ولا تشخيصاً
        self.assertNotIn(DX["diagnosis"], json.dumps(self.notifs(dev), ensure_ascii=False))
        # جهاز آخر لا يرى شيئاً
        other = "other_device_0123456789a"
        self.assertEqual(e.req("GET", "/api/v1/visits?deviceId=" + other)[1]["visits"], [])
        self.assertEqual(e.req("GET", "/api/v1/visits/%s?deviceId=%s" % (vid, other))[0], 404)
        self.assertEqual(e.req("GET", "/api/v1/visits")[0], 401)
        # بطاقة الحجز تعرض «انتهت» مع إتاحة الملخص
        card = e.req("GET", "/api/v1/bookings?deviceId=" + dev)[1]["bookings"][0]
        self.assertEqual((card["visit"]["status"], card["visit"]["summary"]), ("done", True))
        # 9) الاستقبال يطبع الملخص ثم يسجّل المغادرة
        s, d, _ = self.st("GET", "/visits/%s/summary" % vid, self.R)
        self.assertEqual(s, 200, d)
        sm = d["summary"]
        self.assertEqual((sm["diagnosis"], sm["doctor"], sm["patient"]["mrn"], len(sm["rx"]), len(sm["orders"]), sm["followUp"]),
                         (DX["diagnosis"], self.names[self.docs[0]], mrn, 2, 2, "بعد أسبوع"))
        self.assertNotIn("سرّية", json.dumps(d, ensure_ascii=False))
        self.assertTrue(sm["clinic"])
        d = self.status(vid, "left")
        self.assertTrue(d["visit"]["leftAt"])
        self.assertEqual(self.status(vid, "ready", expect=409)["error"], "bad_transition")   # «غادر» نهائية
        self.assertEqual(self.st("GET", "/visits/%s/summary" % vid, self.R)[0], 200)           # والملخص يبقى متاحاً
        card = e.req("GET", "/api/v1/bookings?deviceId=" + dev)[1]["bookings"][0]
        self.assertEqual(card["visit"]["status"], "left")
        s, q, _ = self.st("GET", "/clinic/queue", D)
        self.assertEqual(next(x for x in q["visits"] if x["id"] == vid)["status"], "left")
        # بعد المغادرة يمكن تسجيل زيارة جديدة لنفس المراجع
        self.checkin(self.docs[0], mrn=mrn)
        # التدقيق: كل خطوة مسجّلة بلا نص طبي
        acts = self.audit(vid)
        for a in ("visit_create", "visit_ready", "clinical_view", "visit_call", "encounter_save", "encounter_finish", "summary_view", "visit_left"):
            self.assertIn(a, acts)
        blob = json.dumps([dict(r) for r in e.app.db.conn().execute("SELECT * FROM audit")], ensure_ascii=False)
        for secret in (DX["diagnosis"], "أموكسيسيلين", SECRET_NOTE, "ألم حلق"):
            self.assertNotIn(secret, blob)

    def test_reception_done_without_encounter_still_works(self):
        """طبيب لا يستعمل التطبيق: الاستقبال يكمل الدورة يدوياً كما في 0.7.0، ولا ملخص للمراجع."""
        dev = "manual_device_0123456789a"
        s, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev, branchId=self.br[0], phone="0565559002", name="يدوي"))
        _, v = self.checkin(self.docs[1], booking=d["booking"]["id"])
        for st in ("ready", "with_doctor", "done", "left"):
            self.status(v["id"], st)
        self.assertEqual(self.st("GET", "/visits/%s/summary" % v["id"], self.R)[0], 409)
        self.assertEqual(self.e.req("GET", "/api/v1/visits?deviceId=" + dev)[1]["visits"], [])

    def test_publish_off_hides_from_patient_but_prints_prescription(self):
        dev = "private_device_0123456789"
        s, d, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev, branchId=self.br[0], phone="0565559003", name="سرّي"))
        D = self.ready("doc_pub", "doctor", self.br[0], self.docs[2])
        _, v = self.checkin(self.docs[2], booking=d["booking"]["id"])
        self.call(D, v["id"])
        self.finish(D, v["id"], dict(DX, publish=False))
        self.assertEqual(self.e.req("GET", "/api/v1/visits?deviceId=" + dev)[1]["visits"], [])
        self.assertEqual(self.e.req("GET", "/api/v1/visits/%s?deviceId=%s" % (v["id"], dev))[0], 404)
        self.assertFalse(any(x["title"] == "انتهت زيارتك" for x in self.notifs(dev)))
        self.assertFalse(self.e.req("GET", "/api/v1/bookings?deviceId=" + dev)[1]["bookings"][0]["visit"]["summary"])
        s, d, _ = self.st("GET", "/visits/%s/summary" % v["id"], self.R)
        self.assertEqual((s, d["summary"]["diagnosis"], len(d["summary"]["rx"])), (200, "", 2))     # الوصفة تُطبع، والتشخيص لا

    def test_state_machine_left(self):
        D = self.ready("doc_sm", "doctor", self.br[0], self.docs[3])
        _, v = self.checkin(self.docs[3])
        vid = v["id"]
        self.assertEqual(self.status(vid, "left", expect=409)["error"], "bad_transition")         # لا مغادرة قبل الانتهاء
        self.call(D, vid)
        self.assertEqual(self.status(vid, "left", expect=409)["error"], "bad_transition")
        self.finish(D, vid, {"diagnosis": "فحص روتيني"})
        # الطبيب لا يغيّر حالات الزيارات من واجهة الاستقبال
        self.assertEqual(self.st("POST", "/visits/%s/status" % vid, D, {"status": "left"})[0], 403)
        self.assertEqual(self.st("POST", "/visits/%s/transfer" % vid, D, {"doctorId": self.docs[4]})[0], 403)
        self.status(vid, "left")

    def test_one_patient_at_a_time_and_concurrent_call(self):
        D = self.ready("doc_conc", "doctor", self.br[0], self.docs[4])
        _, v1 = self.checkin(self.docs[4], "مراجع أول")
        _, v2 = self.checkin(self.docs[4], "مراجع ثان")
        _, v3 = self.checkin(self.docs[4], "مراجع ثالث")
        out = []
        ts = [threading.Thread(target=lambda x=x: out.append(self.st("POST", "/clinic/visits/%s/call" % x, D))) for x in (v1["id"], v2["id"])]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(sorted(s for s, _, _ in out), [200, 409])                                  # دخل واحد فقط
        self.assertEqual([d["error"] for s, d, _ in out if s == 409], ["busy"])
        inside = v1["id"] if next(d for s, d, _ in out if s == 200)["visit"]["id"] == v1["id"] else v2["id"]
        waiting = v2["id"] if inside == v1["id"] else v1["id"]
        self.assertEqual(self.call(D, v3["id"], expect=409)["error"], "busy")
        s, det, _ = self.st("GET", "/clinic/visits/" + waiting, D)
        self.assertEqual(det["busy"], inside)                                                        # الواجهة تعرف من الداخل
        self.finish(D, inside, {"diagnosis": "تمام"})
        self.call(D, waiting)

    def test_save_validation_and_sanitising(self):
        D = self.ready("doc_val", "doctor", self.br[0], self.docs[5])
        _, v = self.checkin(self.docs[5])
        vid = v["id"]
        self.save(D, vid, {"diagnosis": "x"}, expect=409)                                           # قبل الاستدعاء
        self.call(D, vid)
        E = lambda body: self.save(D, vid, body, expect=422)
        self.assertIn("rx", E({"rx": [{"drug": "", "dose": "حبة"}]})["fields"])                      # دواء بلا اسم
        self.assertIn("rx", E({"rx": [{"drug": "د"}] * 25})["fields"])                               # أكثر من 20
        self.assertIn("rx", E({"rx": "نص"})["fields"])
        self.assertIn("orders", E({"orders": [{"type": "pharmacy", "name": "س"}]})["fields"])        # نوع غير معروف
        self.assertIn("orders", E({"orders": [{"type": "lab", "name": ""}, {"type": "lab", "note": "ملاحظة بلا اسم"}]})["fields"])
        self.assertIn("diagnosis", E({"diagnosis": "ا" * 800})["fields"])
        self.assertEqual(self.finish(D, vid, {"diagnosis": " "}, expect=422)["fields"]["diagnosis"], "اكتب التشخيص قبل إنهاء الزيارة")
        self.assertEqual(self.st("PUT", "/clinic/visits/%s/encounter" % vid, D, ["x"])[0], 400)      # جسم ليس كائناً
        # صفوف فارغة تماماً تُهمَل؛ والمحارف الخفية تُنظَّف؛ والنصوص تُقصّ
        d = self.save(D, vid, {"diagnosis": "\x00التهاب\x07  حاد  ", "rx": [{}, {"drug": "دواء", "dose": "x" * 200}], "orders": [{"type": "lab", "name": ""}], "notes": "سطر1\r\n\r\n\r\n\r\nسطر2"})
        enc = d["encounter"]
        self.assertEqual((enc["diagnosis"], len(enc["rx"]), len(enc["rx"][0]["dose"]), enc["orders"], enc["notes"]), ("التهاب حاد", 1, 60, [], "سطر1\n\nسطر2"))
        self.finish(D, vid)

    def test_doctor_isolation(self):
        DA = self.ready("doc_iso_a", "doctor", self.br[0], self.docs[6])
        DB = self.ready("doc_iso_b", "doctor", self.br[0], self.docs[7])
        mrn, va = self.checkin(self.docs[6], "مراجع الطبيب أ")
        _, vb = self.checkin(self.docs[7], "مراجع الطبيب ب")
        qa = [x["id"] for x in self.st("GET", "/clinic/queue", DA)[1]["visits"]]
        self.assertIn(va["id"], qa)
        self.assertNotIn(vb["id"], qa)
        # لا يفتح ولا يستدعي ولا يحفظ ولا يطبع زيارة زميله
        self.assertEqual(self.st("GET", "/clinic/visits/" + vb["id"], DA)[0], 404)
        self.assertEqual(self.st("POST", "/clinic/visits/%s/call" % vb["id"], DA)[0], 404)
        self.assertEqual(self.st("PUT", "/clinic/visits/%s/encounter" % vb["id"], DA, {"diagnosis": "x"})[0], 404)
        self.assertEqual(self.st("POST", "/clinic/visits/%s/finish" % vb["id"], DA, {})[0], 404)
        self.call(DB, vb["id"])
        self.finish(DB, vb["id"], {"diagnosis": "تشخيص الطبيب ب"})
        self.assertEqual(self.st("GET", "/visits/%s/summary" % vb["id"], DA)[0], 404)
        self.assertEqual(self.st("GET", "/visits/%s/summary" % vb["id"], DB)[0], 200)
        # لا يرى قائمة الزيارات العامة ولا يبحث في المراجعين ولا الحجوزات ولا التدقيق
        for path in ("/visits", "/records?q=" + quote("مراجع"), "/records/" + mrn, "/bookings", "/audit"):
            self.assertEqual(self.st("GET", path, DA)[0], 403, path)
        self.assertEqual(self.st("POST", "/visits", DA, {"mrn": mrn, "doctorId": self.docs[6]})[0], 403)
        self.assertEqual(self.st("POST", "/records", DA, {"name": "س", "phone": "0565550000"})[0], 403)
        # والاستقبال لا يدخل واجهات الطبيب
        for path in ("/clinic/queue", "/clinic/visits/" + va["id"]):
            self.assertEqual(self.st("GET", path, self.R)[0], 403, path)
        self.assertEqual(self.st("POST", "/clinic/visits/%s/call" % va["id"], self.R)[0], 403)
        self.assertEqual(self.st("PUT", "/clinic/visits/%s/encounter" % va["id"], self.R, {"diagnosis": "x"})[0], 403)

    def test_doctor_files_only_for_own_patients(self):
        DA = self.ready("doc_file_a", "doctor", self.br[0], self.docs[8])
        DB = self.ready("doc_file_b", "doctor", self.br[0], self.docs[9])
        mrn, va = self.checkin(self.docs[8], "صاحب الملف")
        hdr = {"Authorization": "Bearer " + self.e.admin_token(), "Content-Type": "application/pdf"}
        s, b, _ = raw_req(self.e, "POST", "/api/admin/files?" + urlencode({"mrn": mrn, "kind": "lab", "title": "تحليل سكر", "by": "سارة"}), PDF, hdr)
        self.assertEqual(s, 201, b)
        fid = json.loads(b)["file"]["id"]
        s, det, _ = self.st("GET", "/clinic/visits/" + va["id"], DA)
        self.assertEqual([f["id"] for f in det["files"]], [fid])
        s, body, h = self.st("GET", "/clinic/files/" + fid, DA)
        self.assertEqual((s, h["Content-Type"]), (200, "application/pdf"))
        self.assertTrue(body.startswith(b"%PDF"))
        self.assertEqual(self.st("GET", "/clinic/files/" + fid, DB)[0], 404)                      # طبيب لم يعالج هذا المراجع
        self.assertEqual(self.st("GET", "/clinic/files/" + fid, self.R)[0], 403)                  # والاستقبال لا يفتح ملفات سريرية
        self.assertEqual(self.st("GET", "/clinic/files/f-" + "0" * 32, DA)[0], 404)
        self.assertIn("file_view", [r["action"] for r in self.e.app.db.conn().execute("SELECT action FROM audit WHERE ref=?", (fid,))])

    def test_history_shows_previous_finished_visits_only(self):
        D = self.ready("doc_hist", "doctor", self.br[0], self.docs[10])
        mrn, v1 = self.checkin(self.docs[10], "صاحب التاريخ")
        self.call(D, v1["id"])
        self.finish(D, v1["id"], {"diagnosis": "زكام قديم", "rx": [{"drug": "دواء قديم"}]})
        self.status(v1["id"], "left")
        _, v2 = self.checkin(self.docs[10], mrn=mrn)
        s, det, _ = self.st("GET", "/clinic/visits/" + v2["id"], D)
        self.assertEqual([(h["visitId"], h["diagnosis"], len(h["rx"])) for h in det["history"]], [(v1["id"], "زكام قديم", 1)])
        # مسودة زيارة أخرى غير منتهية لا تظهر في التاريخ
        self.call(D, v2["id"])
        self.save(D, v2["id"], {"diagnosis": "مسودة لم تنتهِ"})
        _, v3 = self.checkin(self.docs[10], mrn=self.newrec("ثالث"))
        self.assertEqual(self.st("GET", "/clinic/visits/" + v3["id"], D)[1]["history"], [])

    def test_doctor_accounts_linking(self):
        s, d, _ = self.e.adm("POST", "/staff", {"username": "doc_nolink", "name": "طبيب بلا ربط", "role": "doctor", "password": PW})
        self.assertEqual((s, "doctorId" in d["fields"]), (422, True))
        s, d, _ = self.e.adm("POST", "/staff", {"username": "doc_nolink", "name": "طبيب", "role": "doctor", "doctorId": "no-such-doctor", "password": PW})
        self.assertEqual(s, 422)
        s, d, _ = self.e.adm("POST", "/staff", {"username": "doc_link1", "name": "طبيب أول", "role": "doctor", "doctorId": self.docs[11], "password": PW})
        self.assertEqual((s, d["staff"]["doctorId"]), (201, self.docs[11]))
        sid = d["staff"]["id"]
        # حساب فعّال واحد لكل طبيب
        s, d, _ = self.e.adm("POST", "/staff", {"username": "doc_link2", "name": "طبيب مكرر", "role": "doctor", "doctorId": self.docs[11], "password": PW})
        self.assertEqual(s, 422)
        self.assertIn("doctorId", d["fields"])
        # بعد إيقاف الأول يصح الثاني
        self.e.adm("PATCH", "/staff/" + sid, {"active": False})
        s, d, _ = self.e.adm("POST", "/staff", {"username": "doc_link2", "name": "طبيب مكرر", "role": "doctor", "doctorId": self.docs[11], "password": PW})
        self.assertEqual(s, 201)
        sid2 = d["staff"]["id"]
        # لا يمكن إعادة تفعيل الأول وهو مرتبط بحساب فعّال آخر
        self.assertEqual(self.e.adm("PATCH", "/staff/" + sid, {"active": True})[0], 422)
        # تغيير الدور إلى غير طبيب يفكّ الربط؛ وإلى طبيب يلزمه سجل
        s, d, _ = self.e.adm("PATCH", "/staff/" + sid2, {"role": "reception"})
        self.assertEqual((s, d["staff"]["doctorId"]), (200, ""))
        self.assertEqual(self.e.adm("PATCH", "/staff/" + sid2, {"role": "doctor"})[0], 422)
        s, d, _ = self.e.adm("PATCH", "/staff/" + sid2, {"role": "doctor", "doctorId": self.docs[12]})
        self.assertEqual((s, d["staff"]["doctorId"]), (200, self.docs[12]))
        self.assertEqual(self.e.adm("PATCH", "/staff/" + sid2, {"doctorId": "ghost"})[0], 422)
        # الأدوار الأخرى لا تقبل ربطاً
        s, d, _ = self.e.adm("POST", "/staff", {"username": "rec_nolink", "name": "استقبال", "role": "reception", "doctorId": self.docs[11], "password": PW})
        self.assertEqual((s, d["staff"]["doctorId"]), (201, ""))
        # /me يعيد الربط؛ حساب طبيب بلا سجل (حُذف الطبيب لاحقاً) يُرفض بوضوح
        H = self.ready("doc_me", "doctor", "", self.docs[13])
        self.assertEqual(self.st("GET", "/me", H)[1]["user"]["doctorId"], self.docs[13])
        db = self.e.app.db
        db.staff_update(db.staff_get(username="doc_me")["id"], doctor_id=None)
        self.assertEqual(self.st("GET", "/clinic/queue", H)[0], 403)


class TestClinicAccounts(Base):
    """وضع الإنتاج (SMS مفعّل): المراجع لا يرى زياراته إلا بحساب موثّق ومرتبط بملفه."""
    ENV = {"DS_SMS_PROVIDER": "test"}

    def test_account_visibility(self):
        e = self.e
        D = self.ready("doc_acc", "doctor", self.br[0], self.docs[0])
        P = patient_login(e, "0565557001")
        Q = patient_login(e, "0565557002")
        mrn = self.newrec("صاحب الحساب", nationalId="1020304050", phone="0565557001")
        self.assertEqual(e.req("POST", "/api/v1/records/link", {"nationalId": "1020304050"}, headers=P)[0], 200)
        dev = "account_device_0123456789"
        _, v = self.checkin(self.docs[0], mrn=mrn)
        self.call(D, v["id"])
        self.finish(D, v["id"], DX)
        # الجهاز وحده لا يكفي في وضع الإنتاج
        self.assertEqual(e.req("GET", "/api/v1/visits?deviceId=" + dev)[0], 401)
        self.assertEqual(e.req("GET", "/api/v1/visits/%s?deviceId=%s" % (v["id"], dev))[0], 401)
        # صاحب الحساب المرتبط يرى؛ حساب آخر غير مرتبط لا يرى ولا يستطيع جلب الزيارة بمعرّفها
        s, d, _ = e.req("GET", "/api/v1/visits", headers=P)
        self.assertEqual([x["id"] for x in d["visits"]], [v["id"]])
        self.assertEqual(e.req("GET", "/api/v1/visits/" + v["id"], headers=P)[1]["visit"]["rx"][0]["drug"], "أموكسيسيلين 500")
        self.assertEqual(e.req("GET", "/api/v1/visits", headers=Q)[1]["visits"], [])
        self.assertEqual(e.req("GET", "/api/v1/visits/" + v["id"], headers=Q)[0], 404)
        # فك الربط يسحب الصلاحية فوراً
        e.req("POST", "/api/v1/records/unlink", {"mrn": mrn}, headers=P)
        self.assertEqual(e.req("GET", "/api/v1/visits", headers=P)[1]["visits"], [])
        self.assertEqual(e.req("GET", "/api/v1/visits/" + v["id"], headers=P)[0], 404)
        e.req("POST", "/api/v1/records/link", {"nationalId": "1020304050"}, headers=P)
        # إشعار «انتهت زيارتك» للحساب المرتبط فقط، وليس لجهاز عشوائي
        pid = e.app.db.patients_of_mrn(mrn)
        self.assertEqual(len(pid), 1)
        n = e.app.db.list_notifications(dev, 0, 50, patient_id=pid[0])
        self.assertTrue(any(x["title"] == "انتهت زيارتك" and x["ref"] == "#/visits/" + v["id"] for x in n))
        n = e.app.db.list_notifications(dev, 0, 50, patient_id=None)
        self.assertFalse(any(x["kind"] == "visit" for x in n))
        # بطاقة الحجز في وضع الإنتاج لا تُلمّح لوجود ملخص عبر الجهاز
        s, d, _ = e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev, branchId=self.br[0], phone="0565557001", name="صاحب الحساب"), headers=P)
        self.assertEqual(s, 201, d)
        card = e.req("GET", "/api/v1/bookings?deviceId=" + dev, headers=P)[1]["bookings"][0]          # حجز الحساب يراه صاحبه فقط (حتى على جهاز مشترك)
        self.assertNotIn("visit", card)                                                           # لم تُربط زيارة بهذا الحجز

    def test_visit_stage_summary_flag_off_in_production(self):
        e = self.e
        D = self.ready("doc_acc2", "doctor", self.br[0], self.docs[1])
        P = patient_login(e, "0565557003")
        dev = "account_device_prod_012345"
        s, d, _ = e.req("POST", "/api/v1/bookings", booking_body(deviceId=dev, branchId=self.br[0], phone="0565557003", name="مراجع"), headers=P)
        self.assertEqual(s, 201, d)
        _, v = self.checkin(self.docs[1], booking=d["booking"]["id"])
        self.call(D, v["id"])
        self.finish(D, v["id"], DX)
        card = e.req("GET", "/api/v1/bookings?deviceId=" + dev, headers=P)[1]["bookings"][0]
        self.assertEqual((card["visit"]["status"], card["visit"]["summary"]), ("done", False))
        # لا إشعار طبي لجهاز الحجز في الإنتاج (يصل للحساب المرتبط فقط)
        self.assertFalse(any(x["title"] == "انتهت زيارتك" for x in self.notifs(dev)))
        # لكن «وصولك» و«حان دورك» (بلا معلومة طبية) تصل لصاحب الحجز: في صندوق حسابه، لا في صندوق الجهاز المشترك
        self.assertTrue(any(x["title"] == "تم تسجيل وصولك" for x in self.notifs(dev, P)))
        self.assertFalse(any(x["title"] == "تم تسجيل وصولك" for x in self.notifs(dev)))


class TestMigrationFrom070(unittest.TestCase):
    def test_old_database_gets_new_columns_and_keeps_data(self):
        import sqlite3
        import tempfile
        from pathlib import Path
        import db as dbmod
        tmp = Path(tempfile.mkdtemp(prefix="ds-mig-")) / "old.db"
        c = sqlite3.connect(str(tmp))
        c.executescript("""
CREATE TABLE staff(id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL, role TEXT NOT NULL, branch_id TEXT, pw TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 1, failed INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0,
  last_login TEXT, created_at TEXT NOT NULL, created_by TEXT);
CREATE TABLE visits(id TEXT PRIMARY KEY, day TEXT NOT NULL, branch_id TEXT, doctor_id TEXT NOT NULL, mrn TEXT NOT NULL, patient_name TEXT NOT NULL,
  booking_id TEXT, reason TEXT, status TEXT NOT NULL DEFAULT 'waiting', queue_no INTEGER NOT NULL,
  arrived_at TEXT NOT NULL, updated_at TEXT NOT NULL, called_at TEXT, finished_at TEXT, created_by TEXT NOT NULL, updated_by TEXT);
INSERT INTO staff(id,username,name,role,pw,created_at) VALUES('s-0000000001','old1','قديم','reception','{}','2026-01-01T00:00:00Z');
INSERT INTO visits(id,day,doctor_id,mrn,patient_name,queue_no,arrived_at,updated_at,created_by,status) VALUES('v-000000000001','2026-11-20','d1','M-1','قديم',1,'t','t','staff:old1','done');
""")
        c.commit()
        c.close()
        db = dbmod.DB(tmp)
        cols = lambda t: {r["name"] for r in db.conn().execute("PRAGMA table_info(%s)" % t)}
        self.assertIn("doctor_id", cols("staff"))
        self.assertIn("left_at", cols("visits"))
        self.assertIn("encounters", {r["name"] for r in db.conn().execute("SELECT name FROM sqlite_master WHERE type='table'")})
        self.assertEqual(db.visit_get("v-000000000001")["status"], "done")                       # البيانات القديمة سليمة
        self.assertEqual(db.staff_get("s-0000000001")["username"], "old1")
        db2 = dbmod.DB(tmp)                                                                       # إعادة الفتح آمنة (ترقية مكررة)
        self.assertIn("left_at", {r["name"] for r in db2.conn().execute("PRAGMA table_info(visits)")})
        v = db.visit_update("v-000000000001", "x", status="left", left_at="2026-11-20T10:00:00Z")
        self.assertEqual((v["status"], v["left_at"]), ("left", "2026-11-20T10:00:00Z"))


if __name__ == "__main__":
    unittest.main()


class TestDoctorSeesHealth(Base):
    """0.11.3: الحالة الصحية التي أدخلها المراجع في حسابه تظهر لطبيب زيارته فقط، بلا هوية ولا تأمين، وفتحها مسجَّل في التدقيق."""
    ENV = {"DS_PW_ITERS": "1000"}

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        s, d, _ = cls.e.adm("PUT", "/auth", {"mode": "password"})
        assert s == 200, d

    def _account_visit(self, phone, doctor):
        from test_accounts import reg_body
        s, d, _ = self.e.req("POST", "/api/v1/auth/register", reg_body(phone))
        self.assertEqual(s, 201, d)
        H = {"Authorization": "Bearer " + d["token"]}
        s, b, _ = self.e.req("POST", "/api/v1/bookings", booking_body(deviceId="health_dev_0123456789", branchId=self.br[0], phone=phone, name="سعد العتيبي"), headers=H)
        self.assertEqual(s, 201, b)
        _, v = self.checkin(doctor, booking=b["booking"]["id"])
        return v

    def test_doctor_sees_patient_entered_health(self):
        D = self.ready("doc_health1", "doctor", self.br[0], self.docs[0])
        v = self._account_visit("0551119001", self.docs[0])
        self.call(D, v["id"])
        s, d, _ = self.st("GET", "/clinic/visits/" + v["id"], D)
        self.assertEqual(s, 200, d)
        h = d["health"]
        self.assertTrue(h["available"])
        self.assertEqual(h["allergies"], {"known": True, "none": False, "text": "بنسلين"})
        self.assertEqual(h["chronic"]["items"], ["السكري", "ارتفاع ضغط الدم"])
        self.assertEqual((h["medications"]["text"], h["bloodType"], h["surgeries"]["none"]), ("ميتفورمين 500", "O+", True))
        blob = json.dumps(h, ensure_ascii=False)
        for secret in ("بوبا", "BP-12345", "فهد", "0551110002"):
            self.assertNotIn(secret, blob)                      # لا تأمين ولا جهة اتصال طوارئ
        self.assertIn("health_view", self.audit(v["id"]))

    def test_other_doctor_cannot_open_and_walkin_has_none(self):
        D1 = self.ready("doc_health2", "doctor", self.br[0], self.docs[1])
        D2 = self.ready("doc_health3", "doctor", self.br[0], self.docs[2])
        v = self._account_visit("0551119002", self.docs[1])
        self.assertEqual(self.st("GET", "/clinic/visits/" + v["id"], D2)[0], 404)       # زيارة طبيب آخر
        _, w = self.checkin(self.docs[1], name="بلا حساب")
        s, d, _ = self.st("GET", "/clinic/visits/" + w["id"], D1)
        self.assertEqual((s, d["health"]), (200, {"available": False, "reason": "account"}))
