#!/usr/bin/env python3
"""أوامر macOS/Capacitor وهمية لاختبار mobile/ci/ios-build.sh على Linux (npm وnpx وxcodebuild وplutil وshasum).

تُستدعى هكذا:  python3 ios_fake_tools.py <الأمر> [المعاملات...]
وتسجّل كل نداء كسطر JSON في الملف SHIM_LOG. وتُضبط حالاتها بمتغيرات:
  FAKE_ICON_ALPHA=1     يولّد «capacitor-assets» أيقونة فيها قناة شفافية
  FAKE_EXPORT_FAIL=نص    يفشل «xcodebuild -exportArchive» ويطبع هذا النص
  FAKE_FAIL_STEP=resolve|archive   يفشل الخطوة المذكورة
(تُستعمل أيضاً كوحدة: make_png لتوليد ملفات PNG صغيرة بأنواع ألوان مختلفة.)
"""
import json
import os
import plistlib
import struct
import subprocess
import sys
import zlib
from pathlib import Path


def _chunk(t, d):
    return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)


def make_png(path, kind="rgb"):
    """kind: rgb | rgba | palette | palette_trns"""
    w = h = 8
    plte = trns = None
    if kind == "rgb":
        ct, row = 2, bytes([10, 100, 180] * w)
    elif kind == "rgba":
        ct, row = 6, bytes([10, 100, 180, 255] * w)
    elif kind in ("palette", "palette_trns"):
        ct, row = 3, bytes([0] * w)
        plte = bytes([10, 100, 180, 255, 255, 255])
        trns = bytes([0, 255]) if kind == "palette_trns" else None
    else:
        raise ValueError(kind)
    raw = b"".join(b"\x00" + row for _ in range(h))
    out = b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, ct, 0, 0, 0))
    if plte:
        out += _chunk(b"PLTE", plte)
    if trns:
        out += _chunk(b"tRNS", trns)
    out += _chunk(b"IDAT", zlib.compress(raw)) + _chunk(b"IEND", b"")
    Path(path).write_bytes(out)


def _opt(args, name):
    return args[args.index(name) + 1] if name in args else None


def main(argv):
    tool, args = argv[0], argv[1:]
    rec = {"tool": tool, "args": args, "cwd": os.getcwd()}
    log = os.environ["SHIM_LOG"]

    def done(code=0):
        with open(log, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return code

    if tool == "npm":
        return done(0)

    if tool == "npx":
        if args[:3] == ["cap", "add", "ios"]:
            if not Path("www/index.html").is_file():
                print("error: www/index.html غير موجود (webDir)", file=sys.stderr)
                return done(1)
            cfg = json.loads(Path("capacitor.config.json").read_text(encoding="utf-8"))
            base = Path("ios/App")
            (base / "App.xcodeproj").mkdir(parents=True)
            (base / "App.xcodeproj/project.pbxproj").write_text("// وهمي\n")
            icons = base / "App/Assets.xcassets/AppIcon.appiconset"
            icons.mkdir(parents=True)
            make_png(icons / "AppIcon-512@2x.png", "rgb")
            with open(base / "App/Info.plist", "wb") as f:
                plistlib.dump({"CFBundleDisplayName": cfg["appName"], "CFBundleIdentifier": cfg["appId"]}, f)
            return done(0)
        if args[:2] == ["capacitor-assets", "generate"]:
            if not Path("ios/App/App/Assets.xcassets/AppIcon.appiconset").is_dir():
                return done(1)
            make_png("ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png", "rgba" if os.environ.get("FAKE_ICON_ALPHA") else "rgb")
            return done(0)
        if args[:2] == ["cap", "sync"] and not Path("ios").is_dir():
            return done(1)
        return done(0)

    if tool == "plutil":
        # plutil -replace KEY -bool YES|NO FILE
        if args[:1] == ["-replace"] and args[2] == "-bool":
            p = Path(args[4])
            d = plistlib.loads(p.read_bytes())
            d[args[1]] = args[3].upper() in ("YES", "TRUE")
            p.write_bytes(plistlib.dumps(d))
            return done(0)
        if args[:1] == ["-replace"] and args[2] == "-string":      # plutil -replace KEY -string TEXT FILE
            p = Path(args[4])
            d = plistlib.loads(p.read_bytes())
            d[args[1]] = args[3]
            p.write_bytes(plistlib.dumps(d))
            return done(0)
        return done(1)

    if tool == "shasum":
        r = subprocess.run(["sha256sum"] + args[2:], capture_output=True, text=True)
        sys.stdout.write(r.stdout)
        return done(r.returncode)

    if tool == "xcodebuild":
        if args[:1] == ["-version"]:
            print("Xcode 26.6\nBuild version 17E000")
            return done(0)
        step = os.environ.get("FAKE_FAIL_STEP", "")
        if args[:1] == ["-resolvePackageDependencies"]:
            if step == "resolve":
                print("error: could not resolve package dependencies")
                return done(65)
            return done(0)
        if args[:1] == ["archive"]:
            if "CODE_SIGNING_ALLOWED=NO" not in args:
                print("error: Communication with Apple failed. Your team has no devices from which to generate a provisioning profile.")
                return done(65)
            if step == "archive":
                print("error: Build failed")
                return done(65)
            ap = Path(_opt(args, "-archivePath"))
            (ap / "Products/Applications/App.app").mkdir(parents=True)
            return done(0)
        if args[:1] == ["-exportArchive"]:
            ap, ep, xp = Path(_opt(args, "-archivePath")), Path(_opt(args, "-exportOptionsPlist")), Path(_opt(args, "-exportPath"))
            key = Path(_opt(args, "-authenticationKeyPath") or "/nonexistent")
            opts = plistlib.loads(ep.read_bytes())
            rec["export"] = {
                "archive_exists": ap.is_dir(),
                "options": opts,
                "allowProvisioningUpdates": "-allowProvisioningUpdates" in args,
                "keyId": _opt(args, "-authenticationKeyID"),
                "issuerId": _opt(args, "-authenticationKeyIssuerID"),
                "keyPath": str(key),
                "keyExists": key.is_file(),
                "keyValid": key.is_file() and subprocess.run(["openssl", "pkey", "-in", str(key), "-noout"], capture_output=True).returncode == 0,
                "keyMode": (key.stat().st_mode & 0o777) if key.is_file() else None,
            }
            if os.environ.get("FAKE_EXPORT_FAIL"):
                print(os.environ["FAKE_EXPORT_FAIL"])
                return done(70)
            if opts.get("destination") == "export":
                xp.mkdir(parents=True, exist_ok=True)
                (xp / "App.ipa").write_bytes(b"PK-fake-ipa")
            print("** EXPORT SUCCEEDED **")
            return done(0)
        return done(0)

    print("أمر وهمي غير معروف: " + tool, file=sys.stderr)
    return done(127)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
