"""واجهات حسابات المراجعين بكلمة مرور: تسجيل جديد، دخول، تغيير كلمة المرور، الملف الشخصي والصحي، وإدارتها من لوحة الإدارة.

قواعد الأمان (تُفحص في الخادم):
- كلمة المرور تُخزَّن مُشتقّة (PBKDF2-SHA256 بدورات من الإعدادات) ولا تُعاد ولا تُسجَّل أبداً.
- رسالة الدخول الفاشل واحدة (جوال أو كلمة مرور غير صحيحة) سواء وُجد الحساب أم لا، مع تعادل زمن المقارنة لمنع كشف الأرقام المسجّلة.
- خمس محاولات فاشلة لنفس الرقم خلال 15 دقيقة توقف الدخول له (ويُفتح من لوحة الإدارة)، وحدّ آخر لكل عنوان.
- تغيير كلمة المرور أو إعادة تعيينها يبطل كل الجلسات السابقة (رقم إصدار كلمة المرور داخل الرمز).
- الجوال في هذا المسار غير موثّق (لا SMS): لذلك لا يُربط الحساب بملف المستوصف الطبي ولا بنتائجه ما لم يُوثَّق الجوال برمز SMS.
- الملف الصحي لا يظهر في القوائم، ولا يُقرأ في لوحة الإدارة إلا بطلب صريح يُسجَّل في التدقيق (بلا محتواه).
"""
import re
import sqlite3

import accounts as acc
import sms as smsmod
from util import AR_DIGITS, check_password, hash_password, norm_phone

NOSTORE = {"Cache-Control": "private, no-store"}
PID_RE = re.compile(r"(pt-[0-9a-f]{12})")
LOGIN_FAILS, LOGIN_WINDOW = 5, 900          # خمس محاولات فاشلة لكل رقم كل 15 دقيقة


class AccountsMixin:
    # ------------------------------------------------------------------ ما يُعاد للمراجع
    def acct_payload(self, pt):
        db = self.app.db
        prof = db.patient_profile_get(pt["id"])
        auth = db.patient_auth_get(pt["id"])
        return {"patient": self.public_patient(pt),
                "profile": prof["data"] if prof else None,
                "consent": {"at": prof["consent_at"], "version": prof["consent_ver"]} if prof and prof["consent_at"] else None,
                "mustChange": bool(auth and auth["must_change"]), "hasPassword": bool(auth)}

    # ------------------------------------------------------------------ تسجيل جديد
    def acct_register(self):
        app = self.app
        body = self.body_json()
        if body is None:
            return
        if not app.rl.allow("reg-ip:" + self.ip, 10, 3600):
            return self.err(429, "rate_limited", "محاولات كثيرة، جرّب لاحقاً")
        f = {}
        phone = norm_phone(body.get("phone"))
        if not phone or not phone.startswith("9665"):
            f["phone"] = "رقم الجوال غير صحيح (مثال: 05xxxxxxxx)"
        name, gender, bd, nid = self.clean_profile(body, f)
        pw = body.get("password")
        problem = acc.pw_problem(pw, phone or "", nid or "")
        if problem:
            f["password"] = problem
        elif body.get("password2") is not None and body.get("password2") != pw:
            f["password2"] = "كلمتا المرور غير متطابقتين"
        prof = acc.clean_profile(body.get("profile"), gender, f)
        acc.consent_problems(body.get("consent"), f)
        if f:
            return self.err(422, "validation", "تحقق من الحقول", f)
        if not app.rl.allow("reg-ph:" + phone, 5, 3600):
            return self.err(429, "rate_limited", "محاولات كثيرة لهذا الرقم، جرّب لاحقاً")
        try:
            pt = app.db.patient_register(phone, name, gender, bd, nid, hash_password(pw, iters=app.cfg.pw_iters), prof, acc.CONSENT_VER)
        except sqlite3.IntegrityError:
            return self.err(409, "phone_exists", "هذا الرقم مسجّل مسبقاً. سجّل دخولك بكلمة مرورك، أو تواصل مع المجمع إن نسيتها.", {"phone": "مسجّل مسبقاً"})
        app.db.audit("patient:" + pt["id"], "register", "patient", pt["id"], "")
        out = self.acct_payload(pt)
        out["token"] = app.make_patient_token(pt["id"])
        return self.json(201, out, NOSTORE)

    # ------------------------------------------------------------------ دخول
    def acct_login(self):
        app = self.app
        body = self.body_json()
        if body is None:
            return
        phone, pw = norm_phone(body.get("phone")), body.get("password")
        if not phone or not phone.startswith("9665") or not isinstance(pw, str) or not pw or len(pw) > 200:
            return self.err(422, "validation", "أدخل رقم الجوال وكلمة المرور", {"phone": "رقم الجوال غير صحيح (مثال: 05xxxxxxxx)"} if not phone else {"password": "أدخل كلمة المرور"})
        if not app.rl.allow("login-ip:" + self.ip, 40, 600):
            return self.err(429, "rate_limited", "محاولات كثيرة، انتظر بضع دقائق")
        kph = "login-ph:" + phone
        if not app.rl.peek(kph, LOGIN_FAILS, LOGIN_WINDOW):
            return self.err(429, "locked", "محاولات خاطئة كثيرة لهذا الرقم. انتظر 15 دقيقة ثم جرّب، أو تواصل مع المجمع لإعادة تعيين كلمة المرور.")
        pt = app.db.patient_by_phone(phone)
        auth = app.db.patient_auth_get(pt["id"]) if pt else None
        ok = check_password(pw, auth["pw"] if auth else app.dummy_pw())      # نفس الكلفة سواء وُجد الحساب أم لا
        if not (pt and auth and ok):
            app.rl.allow(kph, LOGIN_FAILS, LOGIN_WINDOW)                      # يُحسب فشلاً
            return self.err(401, "bad_credentials", "رقم الجوال أو كلمة المرور غير صحيحة")
        app.rl.reset(kph)
        app.db.patient_touch(pt["id"])
        out = self.acct_payload(pt)
        out["token"] = app.make_patient_token(pt["id"])
        return self.json(200, out, NOSTORE)

    # ------------------------------------------------------------------ تغيير كلمة المرور
    def acct_password(self, pt):
        app = self.app
        body = self.body_json()
        if body is None:
            return
        key = "pwchg:" + pt["id"]
        if not app.rl.peek(key, 5, LOGIN_WINDOW):
            return self.err(429, "locked", "محاولات كثيرة، انتظر 15 دقيقة")
        auth = app.db.patient_auth_get(pt["id"])
        if not auth:
            return self.err(409, "no_password", "هذا الحساب يدخل برمز التحقق ولا كلمة مرور له")
        cur, new = body.get("current"), body.get("new")
        if not isinstance(cur, str) or not check_password(cur, auth["pw"]):
            app.rl.allow(key, 5, LOGIN_WINDOW)
            return self.err(401, "bad_password", "كلمة المرور الحالية غير صحيحة", {"current": "غير صحيحة"})
        problem = acc.pw_problem(new, pt["phone"], pt["national_id"] or "")
        if not problem and new == cur:
            problem = "اختر كلمة مرور مختلفة عن الحالية"
        if problem:
            return self.err(422, "validation", problem, {"new": problem})
        app.db.patient_set_password(pt["id"], hash_password(new, iters=app.cfg.pw_iters), False)
        app.db.audit("patient:" + pt["id"], "password_change", "patient", pt["id"], "")
        return self.json(200, {"ok": True, "token": app.make_patient_token(pt["id"])}, NOSTORE)       # جلسة جديدة لهذا الجهاز؛ غيره يُطلب منه الدخول

    # ------------------------------------------------------------------ الملف الشخصي والصحي
    def acct_me_update(self, pt):
        app = self.app
        body = self.body_json()
        if body is None:
            return
        f = {}
        name, gender, bd, nid = self.clean_profile(body, f)
        prof = acc.clean_profile(body["profile"], gender, f) if isinstance(body.get("profile"), dict) else None
        existing = app.db.patient_profile_get(pt["id"])
        need_consent = prof is not None and not (existing and existing["consent_at"])
        if need_consent:
            acc.consent_problems(body.get("consent"), f)
        if f:
            return self.err(422, "validation", "تحقق من الحقول", f)
        pt2 = app.db.patient_update(pt["id"], name, gender, bd, nid or pt["national_id"])
        if prof is not None:
            app.db.patient_profile_put(pt["id"], prof, acc.CONSENT_VER if need_consent else None)
        app.db.audit("patient:" + pt["id"], "profile_update", "patient", pt["id"], "")
        return self.json(200, self.acct_payload(pt2), NOSTORE)

    # ------------------------------------------------------------------ لوحة الإدارة
    def acct_status(self):
        app = self.app
        mode = (app.db.get_kv("auth", {}) or {}).get("mode", "off")
        return {"mode": mode if mode in ("off", "password") else "off", "method": app.accounts_method(), "smsEnabled": smsmod.enabled(app.cfg),
                "counts": app.db.patients_count()}

    def acct_row(self, r):
        return {"id": r["id"], "name": r["name"], "phone": r["phone"], "gender": r["gender"] or "", "birthDate": r["birth_date"] or "",
                "createdAt": r["created_at"], "lastLogin": r["last_login"], "verified": bool(r["phone_verified"]),
                "hasPassword": bool(r.get("has_pw")), "mustChange": bool(r.get("must_change")), "hasProfile": bool(r.get("has_profile")),
                "locked": not self.app.rl.peek("login-ph:" + r["phone"], LOGIN_FAILS, LOGIN_WINDOW)}

    def admin_accounts_api(self, method, p):
        app, db = self.app, self.app.db
        if p == "/auth":
            if method == "GET":
                return self.json(200, self.acct_status())
            if method == "PUT":
                body = self.body_json()
                if body is None:
                    return
                mode = str(body.get("mode", ""))
                if mode not in ("off", "password"):
                    return self.err(422, "validation", "اختر وضعاً صحيحاً", {"mode": "اختر وضعاً صحيحاً"})
                db.set_kv("auth", {"mode": mode})
                db._bump()                                  # يتجدد ما يراه التطبيق (ds.meta.auth) فوراً
                db.audit("admin", "auth_mode", "settings", mode, "")
                return self.json(200, self.acct_status())
            return self.err(405, "method_not_allowed")
        if p == "/accounts":
            if method != "GET":
                return self.err(405, "method_not_allowed")
            q = (self.qs.get("q") or "").strip()[:60]
            qn = norm_phone(q)
            if qn:
                q = qn
            elif re.fullmatch(r"[0-9٠-٩]{3,}", q):
                q = q.translate(AR_DIGITS).lstrip("0")
            rows = db.patients_list(q or None, 200)
            return self.json(200, {"accounts": [self.acct_row(r) for r in rows], "counts": db.patients_count()}, NOSTORE)
        m = re.fullmatch(r"/accounts/" + PID_RE.pattern + r"(?:/(reset|unlock))?", p)
        if not m:
            return self.err(404, "not_found")
        pid, action = m.group(1), m.group(2)
        pt = db.patient_by_id(pid)
        if not pt:
            return self.err(404, "not_found", "الحساب غير موجود")
        if not action and method == "GET":
            row = next((r for r in db.patients_list(pt["phone"], 5) if r["id"] == pid), None)
            prof = db.patient_profile_get(pid)
            db.audit("admin", "account_view", "patient", pid, "")        # فتح الملف الصحي يُسجَّل (بلا محتواه)
            return self.json(200, {"account": self.acct_row(row), "nationalId": pt["national_id"] or "", "profile": prof["data"] if prof else None,
                                   "consent": {"at": prof["consent_at"], "version": prof["consent_ver"]} if prof and prof["consent_at"] else None,
                                   "lists": acc.public_lists()}, NOSTORE)
        if not action and method == "DELETE":
            db.patient_delete(pid)
            db.audit("admin", "account_delete", "patient", pid, "")
            return self.json(200, {"ok": True})
        if action == "reset" and method == "POST":
            pw = acc.temp_password()
            db.patient_set_password(pid, hash_password(pw, iters=app.cfg.pw_iters), True)
            app.rl.reset("login-ph:" + pt["phone"])
            db.audit("admin", "account_reset_pw", "patient", pid, "")
            return self.json(200, {"password": pw}, NOSTORE)              # تظهر مرة واحدة فقط ولا تُحفظ نصاً
        if action == "unlock" and method == "POST":
            app.rl.reset("login-ph:" + pt["phone"])
            db.audit("admin", "account_unlock", "patient", pid, "")
            return self.json(200, {"ok": True})
        return self.err(405, "method_not_allowed")
