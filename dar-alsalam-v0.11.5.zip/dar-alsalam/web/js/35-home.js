/* الرئيسية بأسلوب التطبيق + مركز «الخدمات».
   الرئيسية قصيرة عمداً: بانر بعرض الشاشة، شبكة إجراءات سريعة (صفحتان)، بطاقة قمر، شريط الخدمات الصغير،
   قسم «استكشف» (محتوى الإدارة فقط)، ثم صف العيادات.
   كل ما يُعرض هنا يأتي من بيانات لوحة الإدارة (خدمات، تخصصات، أطباء، لوحات إعلانية): لا أرقام ولا عروض مكتوبة في الكود. */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui;

  function qm() { return (D.ds && D.ds.qamar) || {}; }
  function qmOn() { return qm().enabled !== false; }
  function waHref() { var s = D.settings(); return s.whatsapp ? DS.waHref(DS.kbmod.e164(s.whatsapp)) : ''; }
  function siteUrl() { var s = D.settings(); return /^https:\/\//.test(s.website || '') ? s.website : ''; }
  function hasEmergency() { return !!D.service('emergency'); }

  /* ---------- بلاطة (أيقونة + عنوان): تُستعمل في شبكة الإجراءات وفي مركز الخدمات ---------- */
  function tile(it, cls) {
    var inner = '<span class="qi ' + (it.c || '') + '">' + ic(it.ico) + '</span><span class="ql">' + esc(it.t) + '</span>';
    if (it.soon) return '<button type="button" class="' + cls + ' soon" data-act="soon" data-t="' + esc(it.t) + '"><span class="qi">' + ic(it.ico) + '</span><span class="ql">' + esc(it.t) + '</span><span class="sn">قريباً</span></button>';
    if (it.act) return '<button type="button" class="' + cls + '" data-act="' + it.act + '">' + inner + '</button>';
    if (it.ext) return '<a class="' + cls + '" href="' + esc(it.href) + '" data-act="ext" data-url="' + esc(it.href) + '">' + inner + '</a>';
    return '<a class="' + cls + '" href="' + esc(it.href) + '">' + inner + '</a>';
  }
  DS.acts.soon = function (el) { DS.toast(el.getAttribute('data-t') + ': تتوفر هذه الخدمة قريباً'); return false; };
  function svcColor(x) { return x.type === 'emergency' || x.id === 'emergency' ? 'c5' : 'c2'; }

  /* ---------- البانر ---------- */
  function welcome(s, ph) {
    return '<div class="hb-slide welcome" role="group" aria-label="ترحيب"><span class="hb-hi">حياك الله في</span><h2>' + esc(s.name || '') + '</h2>' +
      (s.tagline ? '<p>' + esc(s.tagline) + '</p>' : '') +
      '<div class="hb-btns"><a class="btn light sm" href="#/book">' + ic('calendar-plus', 'sm') + 'احجز موعدك</a>' +
      (ph ? '<a class="btn glass sm" href="' + esc(DS.telHref(ph)) + '">' + ic('phone', 'sm') + 'اتصل بنا</a>' : '') + '</div></div>';
  }
  /* إن أضاف المجمع لوحات للشريط العلوي من لوحة الإدارة حلّت محل الترحيب؛ وإلا يظهر الترحيب الافتراضي.
     اللوحات المخصصة لقسم «استكشف» فقط لا تدخل هنا. */
  function banner(s, ph) {
    var list = U.banners('hero');
    var slides = list.length ? list.map(function (b) { return U.bannerSlide(b); }) : [welcome(s, ph)];
    return '<section class="hbn" aria-roledescription="carousel" aria-label="' + (list.length ? 'عروض وإعلانات' : 'ترحيب') + '"><div class="hb-track" id="bn-track">' + slides.join('') + '</div>' +
      (slides.length > 1 ? '<div class="dots" id="bn-dots" aria-hidden="true">' + slides.map(function (_, i) { return '<i' + (i === 0 ? ' class="on"' : '') + '></i>'; }).join('') + '</div>' : '') + '</section>';
  }

  /* ---------- شبكة الإجراءات السريعة (صفحتان بنقاط تنقّل) ---------- */
  function quickPages() {
    var s = D.settings(), ds = D.ds, ph = D.mainPhone(), wa = waHref(), p1 = [], p2 = [];
    p1.push({ t: 'احجز موعد', ico: 'calendar-plus', href: '#/book', c: 'pri' });
    p1.push({ t: 'الأطباء', ico: 'users', href: '#/doctors', c: 'c1' });
    p1.push({ t: 'التخصصات', ico: 'stethoscope', href: '#/specialties', c: 'c2' });
    p1.push({ t: 'الفروع', ico: 'map-pin', href: '#/branches', c: 'c3' });
    if (ph) p1.push({ t: 'اتصل بنا', ico: 'phone', href: DS.telHref(ph), c: 'c1' });
    if (wa) p1.push({ t: 'واتساب', ico: 'whatsapp', href: wa, ext: true, c: 'c4' });
    p1.push({ t: 'طلباتي', ico: 'calendar', href: '#/profile', c: 'c2' });
    var svcAll = { t: 'الخدمات', ico: 'activity', href: '#/services', c: 'c1' };
    if (hasEmergency()) p1.push({ t: 'الطوارئ', ico: 'alert', href: '#/service/emergency', c: 'c5' });
    else if (ds.services.length) p1.push(svcAll);
    p1 = p1.slice(0, 8);

    if (ds.services.length && p1.indexOf(svcAll) < 0) p2.push(svcAll);
    ds.services.filter(function (x) { return x.id !== 'emergency'; }).slice(0, 3).forEach(function (x) {
      p2.push({ t: x.name, ico: x.icon || 'activity', href: '#/service/' + encodeURIComponent(x.id), c: svcColor(x) });
    });
    p2.push({ t: 'التواصل', ico: 'mail', href: '#/contact', c: 'c3' });
    if (U.tipsList().length) p2.push({ t: 'نصائح صحية', ico: 'bulb', href: '#/tips', c: 'c3' });
    p2.push({ t: 'عن المجمعات', ico: 'info', href: '#/about', c: 'c1' });
    p2.push({ t: 'مشاركة التطبيق', ico: 'share', act: 'share', c: 'c2' });
    p2.push({ t: 'الإشعارات', ico: 'bell', href: '#/notifications', c: 'c1' });
    /* خدمات المراجع: المواعيد والتثقيف الصحي تعملان فعلاً؛ الباقي «قريباً» لأنها بيانات مرضى لا تتوفر قبل ربط التطبيق بنظام المجمع */
    var pt = [
      { t: 'المواعيد', ico: 'calendar', href: '#/profile', c: 'pt' }, { t: 'السجلات الطبية', ico: 'plus', soon: 1, kind: 'records' }, { t: 'نتائج المختبر', ico: 'flask', soon: 1, kind: 'lab' },
      { t: 'نتائج الأشعة', ico: 'lungs', soon: 1, kind: 'radiology' }, { t: 'الوصفات الطبية', ico: 'pill', soon: 1, kind: 'prescriptions' }, { t: 'الموافقات الطبية', ico: 'shield', soon: 1, kind: 'consents' },
      { t: 'الحساسية', ico: 'drop', soon: 1, kind: 'allergies' }, { t: 'الفواتير', ico: 'mail', soon: 1, kind: 'invoices' }, { t: 'إعادة صرف الأدوية', ico: 'refresh', soon: 1, kind: 'refills' },
      { t: 'الأعذار الطبية', ico: 'clock', soon: 1, kind: 'excuses' }, { t: 'النشاط الصحي', ico: 'heart', soon: 1, kind: 'activity' }
    ];
    if (U.tipsList().length) pt.push({ t: 'التثقيف الصحي', ico: 'bulb', href: '#/tips', c: 'pt' }); else pt.push({ t: 'التثقيف الصحي', ico: 'bulb', soon: 1 });
    /* حين تُفعَّل ملفات المراجعين (تسجيل برمز تحقق) تصير هذه البطاقات حيّة وتفتح ملفات المراجع من النوع المناسب */
    if (DS.files && DS.files.enabled()) pt.forEach(function (x) { if (x.kind) { x.soon = 0; x.href = '#/files/' + x.kind; x.c = 'pt'; } });
    /* نتائج المختبر والأشعة حيّة في الوضعين (حساب موثّق، أو جهاز الحجز في وضع التجربة): تعرض ما راجعه الطبيب ونشره. المعاينة بلا خادم تبقى «قريباً» */
    if (!DS.cfg.demo) pt.forEach(function (x) { if (x.kind === 'lab' || x.kind === 'radiology') { x.soon = 0; x.href = '#/results/' + x.kind; x.c = 'pt'; } });
    p2 = p2.filter(function (x) { return ['نصائح صحية', 'عن المجمعات'].indexOf(x.t) < 0; }).slice(0, 4);
    return [pt.slice(0, 6), pt.slice(6)];   // الأدوات الأخرى (حجز، أطباء، اتصال…) في «+» وتبويب «الخدمات»
  }
  function quickCard() {
    var pages = quickPages().filter(function (p) { return p.length; });
    return '<section class="qcard" aria-label="خدمات سريعة"><div class="qc-track" id="qc-track">' + pages.map(function (p, i) {
      return '<div class="qc-page" role="group" aria-label="الصفحة ' + (i + 1) + ' من ' + pages.length + '">' + p.map(function (it) { return tile(it, 'qt'); }).join('') + '</div>';
    }).join('') + '</div>' +
      (pages.length > 1 ? '<div class="dots" id="qc-dots" aria-hidden="true">' + pages.map(function (_, i) { return '<i' + (i === 0 ? ' class="on"' : '') + '></i>'; }).join('') + '</div>' : '') + '</section>';
  }

  /* اقتراحات قمر تتحرك ببطء تلقائياً (تتوقف عند اللمس 6 ثوانٍ، ولا تتحرك مع «تقليل الحركة») */
  function chipsDrift() {
    var el = document.querySelector('.qm-chips'); if (!el) return;
    try { if (root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches) return; } catch (e) { return; }
    var dir = 1, hold = 0;
    ['pointerdown', 'touchstart', 'wheel'].forEach(function (ev) { el.addEventListener(ev, function () { hold = Date.now() + 6000; }, { passive: true }); });
    var iv = setInterval(function () {
      if (!document.body.contains(el)) { clearInterval(iv); return; }
      if (document.hidden || Date.now() < hold) return;
      var b = el.scrollLeft; el.scrollLeft = b - dir;
      if (Math.abs(el.scrollLeft - b) < 0.5) dir = -dir;
    }, 35);
  }

  /* ---------- بطاقة قمر ---------- */
  function qamarCard() {
    var q = qm(), name = q.name || 'قمر';
    var chips = (q.quickReplies && q.quickReplies.length ? q.quickReplies : ['أبي أحجز موعد', 'وين الفروع؟', 'وش التخصصات؟', 'أي عيادة تناسبني؟']).slice(0, 5);
    return '<section class="qm-card" aria-label="' + esc(name) + '، المساعد الافتراضي">' +
      '<div class="qm-h"><span class="qm-moon">' + DS.moonSvg + '</span><div class="grow"><b>اسأل ' + esc(name) + '</b><span class="sm">مساعدك الافتراضي يوجّهك للعيادة المناسبة</span></div></div>' +
      '<button type="button" class="qm-in" data-act="qamar-open"><span class="grow">اكتب سؤالك هنا…</span><span class="send">' + ic('send', 'sm') + '</span></button>' +
      '<div class="qm-chips">' + chips.map(function (c) { return '<button type="button" data-act="qm-chip" data-q="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') + '</div>' +
      '<p class="qm-note">لا يقدّم تشخيصاً ولا يصف أدوية.</p></section>';
  }

  /* ---------- شريط الخدمات الصغير (فوق «استكشف») ----------
     يُولَّد من الخدمات المضافة والمفعّلة فقط: لا خدمات = لا شريط. خدمة واحدة = صف مختصر، وأكثر = أزرار صغيرة تُمرَّر أفقياً.
     الضغط على أي خدمة يفتح تفاصيلها (وفيها زر طلب الحجز). */
  function svcStrip() {
    var list = ((D.ds && D.ds.services) || []).filter(function (x) { return x.active !== false && x.name; });
    if (!list.length) return '';
    var one = list.length === 1;
    var items = list.map(function (x) {
      var em = x.type === 'emergency' || x.id === 'emergency';
      return '<a class="svp' + (em ? ' em' : '') + '" href="#/service/' + esc(x.id) + '"><span class="svp-i">' + ic(x.icon || 'activity') + '</span>' +
        '<span class="svp-w"><span class="svp-t">' + esc(x.name) + '</span>' + (one && x.hoursText ? '<span class="svp-h">' + esc(x.hoursText) + '</span>' : '') + '</span>' +
        (one ? ic('chevron-left', 'chev') : '') + '</a>';
    }).join('');
    return '<nav class="svs' + (one ? ' one' : '') + '" id="svs" aria-label="الخدمات الطبية"><div class="svs-track">' + items + '</div></nav>';
  }
  /* تلميح تمرير: تعتيم خفيف عند الحافة ما دام هناك المزيد خارج الشاشة */
  function svcStripHint() {
    var box = DS.$('#svs'), tr = box && box.querySelector('.svs-track');
    if (!tr || box.classList.contains('one')) return;
    function chk() { var max = tr.scrollWidth - tr.clientWidth; box.classList.toggle('more', max > 6 && Math.abs(tr.scrollLeft) < max - 6); }
    chk(); tr.addEventListener('scroll', chk, { passive: true });
  }

  /* ---------- «استكشف»: محتوى وعروض وإعلانات تعريفية تختارها الإدارة فقط ----------
     مستقل عن الخدمات: خدمة جديدة لا تظهر هنا أبداً. القسم كله يختفي إن لم تضف الإدارة شيئاً له. */
  function exploreSection() {
    var list = U.banners('explore');
    if (!list.length) return '';
    return '<section class="sec" id="explore" aria-label="استكشف">' + U.sec('استكشف') +
      '<div class="xr' + (list.length === 1 ? ' one' : '') + '">' + list.map(function (b) { return U.bannerSlide(b, 'xc'); }).join('') + '</div></section>';
  }

  /* ---------- الرئيسية ---------- */
  DS.route('/', function () {
    var s = D.settings(), ds = D.ds, ph = D.mainPhone(), h = '';
    h += banner(s, ph);
    h += quickCard();
    if (s.notice) h += '<div class="alert info home-notice">' + ic('info', 'sm') + '<div>' + DS.nl(s.notice) + '</div></div>';
    h += '<div id="home-bk">' + (DS.bk ? DS.bk.card() : '') + '</div>';
    h += svcStrip();
    h += exploreSection();
    if (ds.specialties.length) h += '<section class="sec">' + U.sec('العيادات', '#/specialties') + '<div class="hs">' + ds.specialties.map(U.specChip).join('') + '</div></section>';
    setTimeout(function () {
      U.pager('#bn-track', '#bn-dots', { auto: 5000 });
      U.pager('#qc-track', '#qc-dots');
      svcStripHint();
      if (DS.bk) DS.bk.refresh();
    }, 0);
    return h;
  }, { tab: 'home', home: true, fab: true });

  /* ---------- مركز «الخدمات»: مجموعات تُولَّد من البيانات (خدمة جديدة من لوحة الإدارة تظهر هنا تلقائياً) ---------- */
  DS.route('/hub', function () {
    var s = D.settings(), ds = D.ds, ph = D.mainPhone(), wa = waHref(), site = siteUrl(), groups = [];
    groups.push(['العيادات والأطباء', [
      { t: 'التخصصات', ico: 'stethoscope', href: '#/specialties', c: 'c2' },
      { t: 'الأطباء', ico: 'users', href: '#/doctors', c: 'c1' },
      { t: 'الفروع والمواقع', ico: 'map-pin', href: '#/branches', c: 'c3' }
    ]]);
    if (ds.services.length) groups.push(['الخدمات الطبية', ds.services.map(function (x) {
      return { t: x.name, ico: x.icon || 'activity', href: '#/service/' + encodeURIComponent(x.id), c: svcColor(x) };
    })]);
    var tools = [];
    if (qmOn()) tools.push({ t: 'اسأل ' + (qm().name || 'قمر'), ico: 'chat', act: 'qamar-open', c: 'c2' });
    if (U.tipsList().length) tools.push({ t: 'نصائح صحية', ico: 'bulb', href: '#/tips', c: 'c3' });
    tools.push({ t: 'طلباتي', ico: 'calendar', href: '#/profile', c: 'c1' });
    tools.push({ t: 'الإشعارات', ico: 'bell', href: '#/notifications', c: 'c1' });
    groups.push(['أدوات', tools]);
    var contact = [];
    if (ph) contact.push({ t: 'اتصل بنا', ico: 'phone', href: DS.telHref(ph), c: 'c1' });
    if (wa) contact.push({ t: 'واتساب', ico: 'whatsapp', href: wa, ext: true, c: 'c4' });
    contact.push({ t: 'أرقام التواصل', ico: 'mail', href: '#/contact', c: 'c3' });
    if (site) contact.push({ t: 'الموقع الإلكتروني', ico: 'globe', href: site, ext: true, c: 'c2' });
    groups.push(['تواصل معنا', contact]);
    groups.push(['عن المجمعات والتطبيق', [
      { t: 'عن المجمعات', ico: 'info', href: '#/about', c: 'c1' },
      { t: 'مشاركة التطبيق', ico: 'share', act: 'share', c: 'c2' },
      { t: 'سياسة الخصوصية', ico: 'shield', href: '#/privacy', c: 'c3' }
    ]]);
    return '<div class="hub-t"><h2>كل خدمات ' + esc(s.shortName || 'المجمع') + '</h2><p>اختر ما تحتاجه وننقلك إليه مباشرة.</p></div>' +
      '<a class="hub-cta" href="#/book"><span class="qi">' + ic('calendar-plus') + '</span><div class="grow"><b>اطلب حجزاً</b><span class="sm">اختر العيادة أو الطبيب ويتواصل معك المجمع لتأكيد الموعد.</span></div>' + ic('chevron-left', 'chev') + '</a>' +
      groups.map(function (g) {
        return '<section class="hg" aria-label="' + esc(g[0]) + '"><h3>' + esc(g[0]) + '</h3><div class="tg">' + g[1].map(function (it) { return tile(it, 'qt'); }).join('') + '</div></section>';
      }).join('');
  }, { tab: 'more', title: 'الخدمات', fab: true });

  /* ---------- «الملفات الطبية»: شبكة ثلاثية دائرية. لا تُعرض إلا الخدمات الموجودة فعلاً (لا بلاطات وهمية) ---------- */
  DS.route('/records', function () {
    var A = DS.auth, F = DS.files, items = [];
    if (F && F.enabled()) items.push({ t: 'السجلات الطبية', ico: 'file', href: '#/files' });
    items.push({ t: 'المواعيد', ico: 'calendar', href: '#/profile' });
    if (!DS.cfg.demo) {
      items.push({ t: 'نتائج المختبر', ico: 'flask', href: '#/results/lab' });
      items.push({ t: 'نتائج الأشعة', ico: 'scan', href: '#/results/radiology' });
      items.push({ t: 'خدمات الزيارات', ico: 'stethoscope', href: '#/visits' });
    }
    if (A && A.pw && A.pw()) items.push({ t: 'ملفي الصحي', ico: 'heart', href: '#/account' });
    if (U.tipsList().length) items.push({ t: 'التثقيف الصحي', ico: 'bulb', href: '#/tips' });
    return '<div class="rec-grid">' + items.map(function (it) {
      return '<a class="rec" href="' + esc(it.href) + '"><span class="rc">' + ic(it.ico) + '</span><span class="rl">' + esc(it.t) + '</span></a>';
    }).join('') + '</div>';
  }, { tab: 'records', title: 'الملفات الطبية', fab: true });
})(window);
