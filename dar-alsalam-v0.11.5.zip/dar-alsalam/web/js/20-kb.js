/* منفذ جافاسكربت لمحرك قمر القاعدي (server/kb.py). يعمل بدون إنترنت داخل التطبيق ومعاينة المتصفح.
   أي تعديل هنا يجب أن يطابق kb.py؛ يوجد اختبار مطابقة (tools/parity_test.js) يقارن النتائج على مجموعة أسئلة. */
(function (root) {
  'use strict';

  var AR_FIX = { 'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي', 'ة': 'ه', 'ؤ': 'و', 'ئ': 'ي', 'ک': 'ك', 'ی': 'ي', 'ۀ': 'ه' };
  '٠١٢٣٤٥٦٧٨٩'.split('').forEach(function (c, i) { AR_FIX[c] = String(i); });
  '۰۱۲۳۴۵۶۷۸۹'.split('').forEach(function (c, i) { AR_FIX[c] = String(i); });
  var DIAC = /[ؐ-ًؚ-ٰٟۖ-ۭـ]/g;
  var NONTOK = /[^a-z0-9ء-ي]+/g;
  var ARONLY = /^[ء-ي]+$/;
  var PREF = ['وبال', 'وال', 'بال', 'كال', 'فال', 'لل', 'ال'];
  var SUF1 = ['ها', 'هم', 'كم', 'نا', 'ه', 'ي'];
  var SUF2 = ['ات', 'ان', 'ين', 'ون', 'ت'];

  function normalize(s) {
    s = String(s == null ? '' : s).toLowerCase().split('x-ray').join('xray');
    s = s.replace(DIAC, '');
    var out = '';
    for (var i = 0; i < s.length; i++) { var ch = s[i]; out += (AR_FIX[ch] !== undefined ? AR_FIX[ch] : ch); }
    return out.replace(NONTOK, ' ').trim();
  }

  function startsWith(t, p) { return t.slice(0, p.length) === p; }
  function endsWith(t, p) { return t.length >= p.length && t.slice(t.length - p.length) === p; }

  function stem(t) {
    if (t.length < 4 || !ARONLY.test(t)) return t;
    var i, p, s;
    for (i = 0; i < PREF.length; i++) {
      p = PREF[i];
      if (startsWith(t, p) && t.length - p.length >= 3) { t = t.slice(p.length); break; }
    }
    if (endsWith(t, 'ء') && t.length >= 4) t = t.slice(0, -1);
    for (i = 0; i < SUF1.length; i++) {
      s = SUF1[i];
      if (endsWith(t, s) && t.length - s.length >= 3) { t = t.slice(0, t.length - s.length); break; }
    }
    for (i = 0; i < SUF2.length; i++) {
      s = SUF2[i];
      if (endsWith(t, s) && t.length - s.length >= 3) { t = t.slice(0, t.length - s.length); break; }
    }
    return t;
  }

  function e164(n) {
    var d = String(n || '').replace(/\D/g, '');
    if (startsWith(d, '00')) d = d.slice(2);
    if (startsWith(d, '05') && d.length === 10) d = '966' + d.slice(1);
    else if (startsWith(d, '5') && d.length === 9) d = '966' + d;
    return d;
  }

  function words(text) { return normalize(text).split(' ').filter(Boolean); }

  function Lexicon(raw) {
    this.raw = raw;
    this.syn = Object.create(null);
    var self = this;
    Object.keys(raw.synonyms || {}).forEach(function (canon) {
      var c = stem(normalize(canon));
      self.syn[c] = c;
      raw.synonyms[canon].forEach(function (a) {
        var n = normalize(a);
        if (n.indexOf(' ') >= 0) return;
        self.syn[stem(n)] = c;
      });
    });
    this.stop = new Set();
    (raw.stopwords || []).forEach(function (w) {
      var n = normalize(w);
      if (n && n.indexOf(' ') < 0) { var s = stem(n); self.stop.add(self.syn[s] !== undefined ? self.syn[s] : s); }
    });
  }
  Lexicon.prototype.canon = function (s) { return this.syn[s] !== undefined ? this.syn[s] : s; };
  Lexicon.prototype.analyze = function (text, vocab) {
    var out = [], ws = words(text);
    for (var i = 0; i < ws.length; i++) {
      var t = ws[i], s = stem(t);
      if (vocab && !vocab.has(s) && t.length >= 5 && t[0] === 'و' && ARONLY.test(t)) {
        var s2 = this.canon(stem(t.slice(1)));
        if (vocab.has(s2)) s = s2;
      }
      out.push(this.canon(s));
    }
    return out;
  };
  Lexicon.prototype.phrases = function (items) {
    var self = this;
    return (items || []).map(function (x) { return self.analyze(x); }).filter(function (p) { return p.length > 0; });
  };

  function containsPhrase(tokens, p) {
    var n = tokens.length, m = p.length;
    if (m === 0 || m > n) return false;
    for (var i = 0; i <= n - m; i++) {
      var ok = true;
      for (var j = 0; j < m; j++) { if (tokens[i + j] !== p[j]) { ok = false; break; } }
      if (ok) return true;
    }
    return false;
  }
  function fill(tpl, kw) {
    var out = tpl;
    Object.keys(kw).forEach(function (k) { out = out.split('{' + k + '}').join(String(kw[k])); });
    return out;
  }
  function active(items) { return (items || []).filter(function (e) { return e.active !== false; }); }
  function setOf(a) { return new Set(a); }
  function union(a, b) { b.forEach(function (x) { a.add(x); }); return a; }
  function cmpStr(a, b) { return a < b ? -1 : (a > b ? 1 : 0); }

  var VOCAB_SKIP = setOf(['id', 'photo', 'icon', 'category', 'lat', 'lng', 'mapQuery', 'sort', 'active', 'needsReview', 'specialtyIds', 'serviceIds',
    'branchIds', 'whatsapp', 'phone', 'linkType', 'linkRef']);

  function KB(data, lex) {
    var self = this;
    this.lex = lex; this.d = data; this.s = data.settings || {}; this.q = data.qamar || {};
    this.branches = active(data.branches); this.specs = active(data.specialties); this.services = active(data.services);
    this.doctors = active(data.doctors); this.faqs = active(data.faqs);
    this.byId = {};
    [['branches', this.branches], ['specialties', this.specs], ['services', this.services], ['doctors', this.doctors], ['faqs', this.faqs]].forEach(function (kv) {
      kv[1].forEach(function (e) { self.byId[kv[0] + ':' + e.id] = e; });
    });
    var phones = this.s.phones || [];
    var main = phones.filter(function (p) { return p.type === 'main'; })[0] || phones[0] || { number: '' };
    this.vars = {
      clinic: this.s.name || '', city: this.s.city || '', phone_main: main.number || '',
      emergency: this.s.emergencyNumber || '997', healthline: this.s.healthLine || '937',
      handoff: this.q.handoffText || 'ما عندي معلومة مؤكدة عن هذا الموضوع، والأفضل تتواصل مع المجمع مباشرة.'
    };
    this.T = lex.raw.templates;
    this.vocab = null;
    this._compileLexicon();
    this._buildFaqTokens();
    this._buildVocab();
  }
  var P = KB.prototype;
  P.get = function (kind, id) { return this.byId[kind + ':' + id]; };
  P.an = function (text) { return this.lex.analyze(text, this.vocab); };

  P._compileLexicon = function () {
    var L = this.lex, raw = L.raw, self = this;
    this.intentPhrases = {};
    Object.keys(raw.intents).forEach(function (k) { self.intentPhrases[k] = L.phrases(raw.intents[k]); });
    this.advicePhrases = L.phrases(raw.advice || []);
    this.selfHarmPhrases = L.phrases(raw.selfHarm || []);
    this.yesFollow = L.phrases(raw.yesFollowups || []);
    this.tipsTokens = new Set();
    (this.intentPhrases.tips || []).forEach(function (p) { p.forEach(function (t) { self.tipsTokens.add(t); }); });
    this.priority = raw.priority || [];
    this.emergencyRules = (raw.emergency || []).map(function (r) {
      return { id: r.id, hint: r.hint || '', any: L.phrases(r.any || []), all: (r.all || []).map(function (g) { return L.phrases(g); }) };
    });
    var sets = this.branches.map(function (b) {
      var ts = new Set();
      ['name', 'shortName', 'area', 'landmark', 'address'].forEach(function (f) {
        L.analyze(b[f] || '').forEach(function (t) { if (t.length >= 3 && !L.stop.has(t)) ts.add(t); });
      });
      return ts;
    });
    var common = new Set();
    if (sets.length > 1) {
      sets[0].forEach(function (t) { if (sets.every(function (s) { return s.has(t); })) common.add(t); });
    }
    var generic = setOf(['فرع', 'دار', 'سلام', 'طبي', 'مدينه', 'منور', 'مدين', 'مجمع']);
    this.branchTokens = sets.map(function (s) {
      var out = new Set(); s.forEach(function (t) { if (!common.has(t) && !generic.has(t)) out.add(t); }); return out;
    });
  };

  P._buildFaqTokens = function () {
    var L = this.lex, self = this;
    this.faqTokens = {};
    this.faqs.forEach(function (f) {
      var ts = new Set(L.analyze(f.question));
      (f.keywords || []).forEach(function (k) { L.analyze(k).forEach(function (t) { ts.add(t); }); });
      var out = new Set(); ts.forEach(function (t) { if (!L.stop.has(t)) out.add(t); });
      self.faqTokens[f.id] = out;
    });
  };

  P._buildVocab = function () {
    var L = this.lex, v = new Set(L.stop);
    Object.keys(L.syn).forEach(function (k) { v.add(k); v.add(L.syn[k]); });
    var self = this;
    Object.keys(this.intentPhrases).forEach(function (k) { self.intentPhrases[k].forEach(function (p) { p.forEach(function (t) { v.add(t); }); }); });
    [this.advicePhrases, this.selfHarmPhrases].forEach(function (g) { g.forEach(function (p) { p.forEach(function (t) { v.add(t); }); }); });
    var texts = ['name', 'legalName', 'city', 'about', 'mission', 'vision'].map(function (k) { return self.s[k] || ''; });
    (this.s.phones || []).forEach(function (p) { texts.push(p.label || ''); });
    [this.branches, this.specs, this.services, this.doctors, this.faqs].forEach(function (items) {
      items.forEach(function (e) {
        Object.keys(e).forEach(function (k) {
          if (VOCAB_SKIP.has(k)) return;
          var val = e[k];
          if (typeof val === 'string') texts.push(val);
          else if (Array.isArray(val)) val.forEach(function (x) { if (typeof x === 'string') texts.push(x); });
        });
      });
    });
    texts.forEach(function (t) { L.analyze(t).forEach(function (x) { v.add(x); }); });
    this.vocab = v;
  };

  P.docLabel = function (d) { return 'د. ' + d.name; };
  P._names = function (ids, kind) { var self = this; return (ids || []).map(function (i) { return self.get(kind, i); }).filter(Boolean).map(function (e) { return e.name; }); };

  P._emergency = function (toks) {
    for (var i = 0; i < this.emergencyRules.length; i++) {
      var r = this.emergencyRules[i];
      if (r.any.some(function (p) { return containsPhrase(toks, p); })) return r;
      if (r.all.length && r.all.every(function (g) { return g.some(function (p) { return containsPhrase(toks, p); }); })) return r;
    }
    return null;
  };
  P._selfHarm = function (toks) { return this.selfHarmPhrases.some(function (p) { return containsPhrase(toks, p); }); };

  P._intents = function (toks) {
    var found = new Set(), self = this;
    Object.keys(this.intentPhrases).forEach(function (name) {
      var phrases = self.intentPhrases[name];
      if ((name === 'yes' || name === 'no') && toks.length > 4) return;
      if (name === 'qamar') {
        if (phrases.some(function (p) { return containsPhrase(toks, p) && (p.length >= 2 || toks.length <= 2); })) found.add(name);
        return;
      }
      if (phrases.some(function (p) { return containsPhrase(toks, p); })) found.add(name);
    });
    if (this.advicePhrases.some(function (p) { return containsPhrase(toks, p); })) found.add('advice');
    return this.priority.filter(function (n) { return found.has(n); });
  };

  P._routeGroup = function (toks, items) {
    var L = this.lex, tset = new Set(toks), scored = [];
    items.forEach(function (it) {
      var sc = 0;
      (it.keywords || []).concat([it.name]).forEach(function (kw) {
        var kt = L.analyze(kw).filter(function (t) { return !L.stop.has(t); });
        if (kt.length && kt.every(function (t) { return tset.has(t); })) sc += kt.length;
      });
      if (sc) scored.push({ sc: sc, sort: it.sort || 0, id: it.id });
    });
    scored.sort(function (a, b) { return (b.sc - a.sc) || (a.sort - b.sort) || cmpStr(a.id, b.id); });
    return scored.map(function (x) { return [x.id, x.sc]; });
  };
  P.route = function (toks) { return this._routeGroup(toks, this.specs); };
  P.serviceMatch = function (toks) { return this._routeGroup(toks, this.services); };
  P.branchesIn = function (toks) {
    var tset = new Set(toks), out = [];
    for (var i = 0; i < this.branches.length; i++) {
      var hit = false; this.branchTokens[i].forEach(function (t) { if (tset.has(t)) hit = true; });
      if (hit) out.push(this.branches[i].id);
    }
    return out;
  };
  P.doctorsIn = function (toks) {
    var L = this.lex, tset = new Set(toks), hasTitle = tset.has('طبيب'), found = [];
    this.doctors.forEach(function (d) {
      var nt = L.analyze(d.name).filter(function (t) { return t.length >= 3 && !L.stop.has(t); });
      var m = nt.filter(function (t) { return tset.has(t); });
      if (!m.length) return;
      if (m.length >= 2 || m.some(function (t) { return t.length >= 4; }) || hasTitle) found.push(d.id);
    });
    return found;
  };

  P.faqMatch = function (toks, only, exclude, drop) {
    var L = this.lex, q = new Set();
    toks.forEach(function (t) { if (!L.stop.has(t) && !(drop && drop.has(t))) q.add(t); });
    if (!q.size) return null;
    var best = null;
    for (var idx = 0; idx < this.faqs.length; idx++) {
      var f = this.faqs[idx], cat = f.category || 'app';
      if (only && cat !== only) continue;
      if (exclude && cat === exclude) continue;
      var ft = this.faqTokens[f.id], nm = 0;
      q.forEach(function (t) { if (ft.has(t)) nm++; });
      if (!nm) continue;
      var cov = nm / q.size;
      if (!best || cov > best.cov || (cov === best.cov && nm > best.nm)) best = { f: f, nm: nm, cov: cov, nq: q.size };
    }
    return best ? { faq: best.f, matched: best.nm, coverage: best.cov, qsize: best.nq } : null;
  };

  P.T_ = function (key, kw) { var v = {}; Object.keys(this.vars).forEach(function (k) { v[k] = this.vars[k]; }, this); Object.keys(kw || {}).forEach(function (k) { v[k] = kw[k]; }); return fill(this.T[key], v); };
  P._faqAnswer = function (f) { return fill(f.answer, this.vars); };
  P._phonesText = function () { var self = this; return this.T_('contact_intro') + '\n' + (this.s.phones || []).map(function (p) { return self.T_('contact_line', { label: p.label, number: p.number }); }).join('\n'); };
  P._landmark = function (b) { return b.landmark ? ' (' + b.landmark + ')' : ''; };
  P._branchLine = function (b) { return this.T_('branch_line', { name: b.name, address: b.address || '', landmark: this._landmark(b) }); };
  P._branchOne = function (b) { return this.T_('branch_one', { name: b.name, address: b.address || '', landmark: this._landmark(b), phone: b.phone || '' }); };
  P._a = function (type, kw) { var d = { type: type }; Object.keys(kw || {}).forEach(function (k) { d[k] = kw[k]; }); return d; };
  P._callMain = function () { return this._a('call', { number: this.vars.phone_main, label: 'اتصال بالرقم الموحد' }); };
  P._waActions = function () {
    var self = this, acts = [];
    this.branches.forEach(function (b) { if (b.whatsapp) acts.push(self._a('whatsapp', { number: e164(b.whatsapp), label: 'واتساب ' + (b.shortName || b.name) })); });
    if (!acts.length && this.s.whatsapp) acts.push(this._a('whatsapp', { number: e164(this.s.whatsapp), label: 'واتساب' }));
    return acts;
  };
  P._bookAction = function (spec, doctor, branch) {
    var a = this._a('book', { label: 'ابدأ طلب الحجز' });
    if (spec) a.specialtyId = spec;
    if (doctor) a.doctorId = doctor;
    if (branch) a.branchId = branch;
    return a;
  };
  P.mentions = function (text) {
    var toks = this.an(text), L = this.lex, tset = new Set(toks), self = this;
    var ents = { branches: this.branchesIn(toks), doctors: this.doctorsIn(toks), specialties: [], services: [] };
    [[this.specs, 'specialties'], [this.services, 'services']].forEach(function (pair) {
      pair[0].forEach(function (it) {
        var nt = L.analyze(it.name).filter(function (t) { return !L.stop.has(t) && t.length >= 3; });
        if (nt.length && nt.every(function (t) { return tset.has(t); })) ents[pair[1]].push(it.id);
      });
    });
    return ents;
  };
  P.faqText = function (f) {
    var head = f.question, body = this._faqAnswer(f);
    if (f.category === 'tips') return this.T_('tips_intro') + '\n' + head + '\n' + body + '\n' + this.T_('tips_note');
    return head + '\n' + body;
  };

  P.answer = function (text, history) {
    var self = this, q = String(text || '').trim().slice(0, 600), toks = this.an(q);
    var res = { text: '', actions: [], intent: null, confident: true, emergency: false, direct: false, faq: null, routed: [], entities: {}, chips: [] };
    function set(o) { Object.keys(o).forEach(function (k) { res[k] = o[k]; }); return res; }
    var quick = this.q.quickReplies || [];

    var em = this._emergency(toks);
    if (em) {
      set({ intent: 'emergency', emergency: true, text: this.T_('emergency', { hint: em.hint }) });
      res.actions = [this._a('emergency', { number: this.vars.emergency, label: 'اتصال بالإسعاف ' + this.vars.emergency })];
      return res;
    }
    if (this._selfHarm(toks)) {
      set({ intent: 'self_harm', emergency: true, text: this.T_('self_harm') });
      res.actions = [this._a('emergency', { number: this.vars.emergency, label: 'اتصال بالإسعاف ' + this.vars.emergency }),
        this._a('call', { number: this.vars.healthline, label: 'خط وزارة الصحة ' + this.vars.healthline })];
      return res;
    }

    var ints = this._intents(toks), main = ints.length ? ints[0] : null;
    var routed = this.route(toks), svc = this.serviceMatch(toks);
    var ents = { branches: this.branchesIn(toks), doctors: this.doctorsIn(toks), specialties: routed.slice(0, 2).map(function (x) { return x[0]; }), services: svc.slice(0, 1).map(function (x) { return x[0]; }) };
    res.routed = routed.slice(0, 2).map(function (x) { return x[0]; });
    res.entities = ents;

    var faqDirect = this.q.answerFaqDirectly !== undefined ? this.q.answerFaqDirectly : true;
    if (faqDirect && [null, 'about', 'which_clinic', 'booking', 'cancel', 'hours', 'contact', 'qamar'].indexOf(main) >= 0) {
      var fm = this.faqMatch(toks, null, 'tips', null);
      if (fm) {
        var strict = ['booking', 'cancel', 'hours', 'contact', 'qamar'].indexOf(main) >= 0;
        var ok = strict ? (fm.matched >= 3 && fm.coverage >= 0.75) : (fm.coverage >= 0.6 && (fm.matched >= 2 || fm.qsize === 1));
        if (ok) {
          var f0 = fm.faq;
          set({ intent: 'faq', direct: true, faq: f0.id, text: this.faqText(f0) });
          if (f0.id === 'faq-book' || f0.id === 'faq-confirm') res.actions.push(this._bookAction());
          res.actions.push(this._callMain());
          return res;
        }
      }
    }

    if (main === 'tips') {
      var tm = this.faqMatch(toks, 'tips', null, this.tipsTokens);
      if (tm && tm.coverage >= 0.4) {
        set({ intent: 'tips', direct: true, faq: tm.faq.id, text: this.faqText(tm.faq) });
        res.actions = [this._callMain()];
        return res;
      }
      var tips = this.faqs.filter(function (f) { return f.category === 'tips'; });
      if (tips.length) {
        set({ intent: 'tips', text: this.T_('tips_list') + '\n' + tips.map(function (f) { return '• ' + f.question; }).join('\n'), chips: tips.map(function (f) { return f.question; }).slice(0, 4) });
        return res;
      }
      main = null;
    }

    if (main === 'yes') {
      var last = '';
      var h = history || [];
      for (var i = h.length - 1; i >= 0; i--) { if (h[i].role === 'assistant') { last = h[i].content || ''; break; } }
      var lt = this.an(last);
      if (this.yesFollow.some(function (p) { return containsPhrase(lt, p); })) {
        var prev = this.mentions(last);
        set({ intent: 'booking', text: this.T_('booking') });
        res.actions = [this._bookAction(prev.specialties[0] || null, prev.doctors.length === 1 ? prev.doctors[0] : null)];
        return res;
      }
      main = null;
    }

    if (main === 'booking') {
      var sp = ents.specialties[0] || null, dr = ents.doctors.length === 1 ? ents.doctors[0] : null, br = ents.branches.length === 1 ? ents.branches[0] : null;
      var t1;
      if (dr) t1 = this.T_('booking_for_doctor', { doctor: this.docLabel(this.get('doctors', dr)) });
      else if (sp) t1 = this.T_('booking_for_specialty', { specialty: this.get('specialties', sp).name });
      else t1 = this.T_('booking');
      set({ intent: 'booking', text: t1 });
      res.actions = [this._bookAction(sp, dr, br), this._callMain()];
      return res;
    }

    if (main === 'cancel') {
      set({ intent: 'cancel', text: this.T_('cancel') });
      res.actions = [this._a('nav', { to: 'profile', label: 'حجوزاتي' }), this._callMain()];
      return res;
    }
    if (main === 'contact') {
      set({ intent: 'contact', text: this._phonesText() });
      res.actions = [this._callMain()].concat(this._waActions());
      return res;
    }
    if (main === 'branches') {
      if (ents.branches.length) {
        var bs = ents.branches.map(function (i) { return self.get('branches', i); });
        set({ intent: 'branches', text: bs.map(function (b) { return self._branchOne(b); }).join('\n\n') });
        res.actions = bs.slice(0, 2).map(function (b) { return self._a('branch', { id: b.id, label: 'تفاصيل ' + (b.shortName || b.name) }); });
      } else {
        set({ intent: 'branches', text: this.T_('branches_intro') + '\n' + this.branches.map(function (b) { return self._branchLine(b); }).join('\n') });
        res.actions = this.branches.slice(0, 3).map(function (b) { return self._a('branch', { id: b.id, label: b.shortName || b.name }); });
      }
      return res;
    }
    if (main === 'hours') {
      var lines = this.services.concat(this.specs).filter(function (e) { return e.hoursText; }).map(function (e) { return self.T_('hours_line', { name: e.name, hours: e.hoursText }); });
      if (lines.length) set({ intent: 'hours', text: this.T_('hours_intro') + '\n' + lines.join('\n') + '\n' + this.T_('hours_note') });
      else set({ intent: 'hours', text: this.T_('hours_none'), confident: false });
      res.actions = [this._callMain()];
      return res;
    }
    if (main === 'insurance' || main === 'price') {
      set({ intent: main, text: this.T_(main), confident: false });
      res.actions = [this._callMain()].concat(this._waActions().slice(0, 1));
      return res;
    }
    if (main === 'advice') {
      set({ intent: 'advice', text: this.T_('advice') });
      if (routed.length) res.actions = [this._a('specialty', { id: routed[0][0], label: this.get('specialties', routed[0][0]).name }), this._bookAction(routed[0][0])];
      else res.actions = [this._a('nav', { to: 'specialties', label: 'عرض التخصصات' })];
      return res;
    }
    if (main === 'which_clinic' && !routed.length) {
      set({ intent: 'which_clinic', text: this.T_('which_clinic'), chips: ['أسنان', 'عظام', 'جلدية', 'أطفال', 'نساء وولادة'] });
      return res;
    }
    if (main === 'doctors' && !ents.doctors.length && !routed.length) {
      set({ intent: 'doctors', text: this.T_('doctors_intro') + '\n' + this.doctors.slice(0, 8).map(function (d) { return '• ' + self.docLabel(d); }).join('\n') });
      res.actions = [this._a('nav', { to: 'doctors', label: 'عرض كل الأطباء' })];
      return res;
    }
    if (main === 'specialties' && !routed.length) {
      set({ intent: 'specialties', text: this.T_('specialties_intro') + '\n' + this.specs.map(function (s) { return '• ' + s.name; }).join('\n') });
      res.actions = [this._a('nav', { to: 'specialties', label: 'عرض التخصصات' })];
      return res;
    }
    if (main === 'services' && !svc.length) {
      set({ intent: 'services', text: this.T_('services_intro') + '\n' + this.services.map(function (s) { return '• ' + s.name; }).join('\n') });
      res.actions = [this._a('nav', { to: 'services', label: 'عرض الخدمات' })];
      return res;
    }
    if (main === 'about') {
      set({ intent: 'about', text: this.T_('about', { about: this.s.about || '' }) });
      res.actions = [this._a('nav', { to: 'about', label: 'عن المجمعات' })];
      return res;
    }
    if (main === 'qamar') { set({ intent: 'qamar', text: this.T_('qamar'), chips: quick.slice() }); return res; }
    if (main === 'thanks' || main === 'greeting' || main === 'no') {
      set({ intent: main, text: this.T_(main), chips: main !== 'thanks' ? quick.slice() : [] });
      return res;
    }

    if (ents.doctors.length) {
      var ds = ents.doctors.slice(0, 3).map(function (i) { return self.get('doctors', i); });
      if (ds.length === 1) {
        var d = ds[0];
        var sps = this._names(d.specialtyIds, 'specialties').concat(this._names(d.serviceIds, 'services')).join('، ') || '—';
        set({ intent: 'doctor', text: this.T_('doctor_one', { doctor: this.docLabel(d), rank: d.rank ? ' — ' + d.rank : '', degree: d.degree ? ' — ' + d.degree : '', specialties: sps }) });
        res.actions = [this._a('doctor', { id: d.id, label: this.docLabel(d) }), this._bookAction(null, d.id)];
      } else {
        set({ intent: 'doctors', text: this.T_('doctors_intro') + '\n' + ds.map(function (x) { return '• ' + self.docLabel(x); }).join('\n') });
        res.actions = ds.map(function (x) { return self._a('doctor', { id: x.id, label: self.docLabel(x) }); });
      }
      return res;
    }

    if (routed.length && (!svc.length || routed[0][1] > svc[0][1])) {
      var sp0 = this.get('specialties', routed[0][0]), t2;
      if (routed.length > 1 && routed[1][1] >= routed[0][1]) {
        var sp2 = this.get('specialties', routed[1][0]);
        t2 = this.T_('route_two', { specialty: sp0.name, specialty2: sp2.name });
        res.actions = [this._a('specialty', { id: sp0.id, label: sp0.name }), this._a('specialty', { id: sp2.id, label: sp2.name }), this._bookAction(sp0.id)];
      } else {
        t2 = this.T_('route', { specialty: sp0.name });
        res.actions = [this._a('specialty', { id: sp0.id, label: sp0.name }), this._bookAction(sp0.id)];
      }
      if (sp0.id === 'chest') t2 = t2.split(' تبي أرتّب لك طلب حجز؟').join(this.T_('route_chest_note') + ' تبي أرتّب لك طلب حجز؟');
      set({ intent: 'route', text: t2 });
      return res;
    }

    if (svc.length) {
      var sv = this.get('services', svc[0][0]);
      var docs = this.doctors.filter(function (d2) { return (d2.serviceIds || []).indexOf(sv.id) >= 0; }).map(function (d2) { return self.docLabel(d2); });
      var t3 = sv.name + ': ' + (sv.description || '');
      if (sv.hoursText) t3 += '\nالدوام المعلن: ' + sv.hoursText;
      if (docs.length) t3 += '\nالأطباء: ' + docs.join('، ');
      set({ intent: 'service', text: t3 });
      res.actions = [this._a('service', { id: sv.id, label: sv.name }), this._callMain()];
      return res;
    }

    if (ents.branches.length) {
      var bs2 = ents.branches.map(function (i) { return self.get('branches', i); });
      set({ intent: 'branches', text: bs2.map(function (b) { return self._branchOne(b); }).join('\n\n') });
      res.actions = bs2.slice(0, 2).map(function (b) { return self._a('branch', { id: b.id, label: 'تفاصيل ' + (b.shortName || b.name) }); });
      return res;
    }

    var fm2 = this.faqMatch(toks, null, null, null);
    if (fm2 && fm2.coverage >= 0.75 && fm2.matched >= 2) {
      set({ intent: 'faq', direct: true, faq: fm2.faq.id, text: this.faqText(fm2.faq) });
      res.actions = [this._callMain()];
      return res;
    }

    set({ intent: 'unknown', confident: false, text: this.T_('unknown'), chips: quick.slice() });
    res.actions = [this._callMain()].concat(this._waActions().slice(0, 1));
    return res;
  };

  var api = { normalize: normalize, stem: stem, e164: e164, Lexicon: Lexicon, KB: KB, fill: fill };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.DS = root.DS || {}; root.DS.kbmod = api; }
})(typeof window !== 'undefined' ? window : globalThis);
