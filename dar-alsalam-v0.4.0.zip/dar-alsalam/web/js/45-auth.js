/* تسجيل المرضى: جوال + رمز تحقق SMS. التصفح حر؛ يُطلب التسجيل عند إرسال طلب حجز فقط.
   يعمل فقط إن فعّل الخادم مزوّد الرسائل (meta.auth.enabled)؛ وإلا يبقى الحجز بلا تسجيل كما كان. */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui;

  var A = DS.auth = {
    enabled: function () { return !DS.cfg.demo && !!(D.ds && D.ds.meta && D.ds.meta.auth && D.ds.meta.auth.enabled); },
    token: function () { return DS.store.get('ptoken', '') || ''; },
    patient: function () { return A.token() ? DS.store.get('patient', null) : null; },
    set: function (t, p) { DS.store.set('ptoken', t); DS.store.set('patient', p); },
    clear: function () { DS.store.del('ptoken'); DS.store.del('patient'); },
    /* true = أعدنا التوجيه لصفحة الدخول */
    gate: function (next) {
      if (!A.enabled() || A.token()) return false;
      setTimeout(function () { location.replace('#/login?next=' + encodeURIComponent(next || '#/')); }, 0);
      return true;
    },
    local: function (phone) { return phone && phone.slice(0, 3) === '966' ? '0' + phone.slice(3) : phone || ''; }
  };

  function fld(id, label, input, hint) {
    return '<div class="fld"><label for="' + id + '">' + label + '</label>' + input + (hint ? '<div class="xs muted" style="margin-top:4px">' + hint + '</div>' : '') + '<div class="err" data-err="' + id + '" hidden></div></div>';
  }
  function showErr(fields) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-err]'), function (e) { e.hidden = true; });
    Object.keys(fields || {}).forEach(function (k) {
      var e = DS.$('[data-err="a-' + k + '"]') || DS.$('[data-err="' + k + '"]'); if (e) { e.textContent = fields[k]; e.hidden = false; }
    });
  }

  DS.route('/login', function (p, q) {
    if (!A.enabled()) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    var next = q.next && q.next.charAt(0) === '#' ? q.next : '#/', st = { phone: '', isNew: false };
    var html = '<div id="au-root"><div class="card"><h2 style="font-weight:800;font-size:1.1rem">تسجيل الدخول</h2>' +
      '<p class="sm muted" style="margin:4px 0 12px">تصفّح التطبيق بحرية. التسجيل مطلوب فقط عند طلب الحجز أو الاستشارة.</p>' +
      '<form id="au-phone" class="form" novalidate>' + fld('a-phone', 'رقم الجوال', '<input class="in ltr" id="a-phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="05xxxxxxxx">') +
      '<div id="au-fail"></div><button class="btn pri blk" type="submit">إرسال رمز التحقق</button></form></div></div>';
    setTimeout(function () {
      var root_ = DS.$('#au-root');
      function fail(msg) { var f = DS.$('#au-fail'); if (f) f.innerHTML = msg ? '<div class="alert danger" style="margin-bottom:10px">' + ic('alert', 'sm') + '<div>' + esc(msg) + '</div></div>' : ''; }
      function codeStep() {
        root_.innerHTML = '<div class="card"><h2 style="font-weight:800;font-size:1.1rem">رمز التحقق</h2>' +
          '<p class="sm muted" style="margin:4px 0 12px">أرسلنا رمزاً من 6 أرقام إلى <span class="ltr">' + esc(A.local(st.phone)) + '</span>.</p>' +
          '<form id="au-code" class="form" novalidate>' + fld('a-code', 'الرمز', '<input class="in ltr" id="a-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000">') +
          (st.isNew ? '<h3 style="font-weight:800;margin:12px 0 4px">أكمل بياناتك</h3>' +
            fld('a-name', 'الاسم', '<input class="in" id="a-name" autocomplete="name" maxlength="60">') +
            fld('a-gender', 'الجنس', '<select class="in" id="a-gender"><option value="">اختر</option><option value="male">ذكر</option><option value="female">أنثى</option></select>') +
            fld('a-birthDate', 'تاريخ الميلاد', '<input class="in ltr" id="a-birthDate" type="date" max="' + DS.riyadhToday(0) + '">') +
            fld('a-nationalId', 'رقم الهوية / الإقامة <span class="muted">(اختياري)</span>', '<input class="in ltr" id="a-nationalId" inputmode="numeric" maxlength="10">', 'تساعد موظف المجمع على فتح ملفك أسرع. يمكنك تركه فارغاً.') : '') +
          '<p class="xs muted">بالمتابعة توافق على <a href="#/privacy">سياسة الخصوصية</a>.</p><div id="au-fail"></div>' +
          '<button class="btn pri blk" type="submit">' + (st.isNew ? 'إنشاء الحساب' : 'دخول') + '</button>' +
          '<button class="btn ghost blk" type="button" data-act="au-back" style="margin-top:8px">تغيير الرقم</button></form></div>';
        var f = DS.$('#au-code');
        f.addEventListener('submit', function (ev) {
          ev.preventDefault(); fail(''); showErr({});
          var body = { phone: st.phone, code: DS.$('#a-code').value.trim() };
          if (st.isNew) body.profile = { name: DS.$('#a-name').value, gender: DS.$('#a-gender').value, birthDate: DS.$('#a-birthDate').value, nationalId: DS.$('#a-nationalId').value };
          var btn = f.querySelector('button[type=submit]'); btn.disabled = true;
          DS.api.post('/auth/verify', body, { timeout: 15000 }).then(function (r) {
            A.set(r.data.token, r.data.patient);
            DS.store.set('profile', { name: r.data.patient.name, phone: A.local(r.data.patient.phone) });
            DS.toast('تم تسجيل الدخول'); location.replace(next);
          }).catch(function (e) {
            btn.disabled = false;
            if (e && e.fields && Object.keys(e.fields).length) showErr(e.fields);
            fail(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر التحقق الآن.');
          });
        });
      }
      DS.acts['au-back'] = function () { location.reload(); return false; };
      DS.$('#au-phone').addEventListener('submit', function (ev) {
        ev.preventDefault(); fail(''); showErr({});
        var ph = DS.normPhone(DS.$('#a-phone').value.trim());
        if (!ph || ph.slice(0, 4) !== '9665') { showErr({ 'a-phone': 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)' }); return; }
        var btn = ev.target.querySelector('button[type=submit]'); btn.disabled = true;
        DS.api.post('/auth/otp', { phone: ph, deviceId: DS.deviceId() }, { timeout: 15000 }).then(function (r) {
          st.phone = ph; st.isNew = !!r.data.isNew; codeStep();
        }).catch(function (e) {
          btn.disabled = false;
          fail(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر إرسال الرمز الآن.');
        });
      });
    }, 0);
    return html;
  }, { tab: 'none', title: 'تسجيل الدخول', back: true });

  /* بطاقة الحساب في «طلباتي وبياناتي» */
  A.card = function () {
    if (!A.enabled()) return '';
    var p = A.patient();
    if (!p) return '<div class="card row" style="margin-bottom:10px"><span class="ico-box">' + ic('user') + '</span><div class="grow"><b>حسابي</b><p class="sm muted">سجّل لتتمكن من إرسال طلبات الحجز.</p></div><a class="btn pri sm" href="#/login?next=' + encodeURIComponent('#/profile') + '">دخول</a></div>';
    return '<div class="card" style="margin-bottom:10px"><b>حسابي</b><p class="sm" style="margin:6px 0"><span>' + esc(p.name) + '</span> · <span class="ltr">' + esc(A.local(p.phone)) + '</span></p>' +
      '<div class="grid2"><button class="btn out sm" data-act="au-logout">تسجيل الخروج</button>' +
      '<button class="btn out sm" style="color:var(--danger);border-color:var(--danger)" data-act="au-delete">حذف حسابي</button></div></div>';
  };
  DS.acts['au-logout'] = function () { A.clear(); DS.toast('تم تسجيل الخروج'); DS.render(); return false; };
  DS.acts['au-delete'] = function () {
    if (!root.confirm('سيُحذف حسابك وتُزال بياناتك من طلباتك لدى المجمع، ولا يمكن التراجع. متابعة؟')) return false;
    DS.api.post('/auth/delete', {}).then(function () { A.clear(); DS.store.del('profile'); DS.store.del('myBookings'); DS.toast('تم حذف حسابك'); DS.render(); })
      .catch(function () { DS.toast('تعذر الحذف الآن، جرّب عند توفر الاتصال.'); });
    return false;
  };
})(window);
