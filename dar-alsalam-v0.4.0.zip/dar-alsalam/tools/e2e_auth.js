/* التسجيل برمز التحقق: خادم منفصل على :8091 بمزوّد test (يكتب الرمز في ملف بدل إرساله) */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const ROOT = require('path').resolve(__dirname, '..');
const DIR = '/tmp/ds-auth', BASE = 'http://127.0.0.1:8091';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  execSync('rm -rf ' + DIR + ' && mkdir -p ' + DIR);
  const env = Object.assign({}, process.env, { DS_DB: DIR + '/clinic.db', DS_PORT: '8091', DS_QUIET: '1', DS_SMS_PROVIDER: 'test' });
  execSync('python3 ' + ROOT + '/server/manage.py init --password devpass-12345', { env, stdio: 'ignore' });
  const srv = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  for (let i = 0; i < 30; i++) { try { const r = await fetch(BASE + '/api/v1/health'); if (r.ok) break; } catch (e) { /* انتظر */ } await sleep(300); }
  const code = () => { const l = fs.readFileSync(DIR + '/sms-test.log', 'utf8').trim().split('\n').pop(); return JSON.parse(l).text.match(/(\d{6})/)[1]; };
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar-SA' });
  const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  try {
    await page.goto(BASE + '/app/#/'); await page.waitForSelector('#view .qcard', { timeout: 8000 });
    await page.goto(BASE + '/app/#/doctors'); await sleep(500);
    ok(await page.locator('#view a[href^="#/doctor/"]').count() > 0, 'التصفح حر: صفحة الأطباء تعمل بلا تسجيل');
    await page.goto(BASE + '/app/#/book'); await page.waitForSelector('#a-phone', { timeout: 6000 });
    ok(page.url().includes('#/login') && page.url().includes('next='), 'فتح «احجز» بلا تسجيل يحوّل لصفحة الدخول مع العودة');
    await page.fill('#a-phone', '123'); await page.click('#au-phone button[type=submit]'); await sleep(300);
    ok(await page.locator('[data-err="a-phone"]:not([hidden])').count() === 1, 'رقم غير صحيح يُرفض برسالة');
    await page.fill('#a-phone', '0565551234'); await page.click('#au-phone button[type=submit]');
    await page.waitForSelector('#a-code', { timeout: 6000 });
    ok(await page.locator('#a-name').count() === 1, 'مستخدم جديد: تظهر حقول الاسم والجنس والميلاد');
    await page.fill('#a-code', code()); await page.click('#au-code button[type=submit]'); await sleep(600);
    ok(await page.locator('[data-err="a-name"]:not([hidden])').count() === 1, 'إكمال الحساب بلا بيانات يُرفض');
    await page.fill('#a-name', 'أحمد الجهني'); await page.selectOption('#a-gender', 'male'); await page.fill('#a-birthDate', '1989-07-25');
    await page.click('#au-code button[type=submit]');
    await page.waitForSelector('#f-name', { timeout: 8000 });
    ok(page.url().includes('#/book') && await page.inputValue('#f-name') === 'أحمد الجهني' && await page.inputValue('#f-phone') === '0565551234', 'بعد التسجيل يعود لصفحة الحجز والاسم والجوال معبّآن');
    ok(await page.evaluate(() => document.querySelector('#f-name').readOnly && document.querySelector('#f-phone').readOnly), 'الاسم والجوال للقراءة فقط (من الحساب)');
    await page.selectOption('#f-sel', { index: 1 });
    await page.locator('#f-consent').check().catch(() => {});
    await page.click('#f-submit'); await page.waitForSelector('.bk-id', { timeout: 8000 });
    ok(/^DS-[A-Z0-9]{6}$/.test((await page.locator('.bk-id').innerText()).trim()), 'إرسال الطلب بعد التسجيل ينجح ويظهر رقم الطلب');
    await page.goto(BASE + '/app/#/profile'); await sleep(600);
    ok(await page.locator('[data-act="au-logout"]').count() === 1, 'صفحة طلباتي فيها بطاقة الحساب مع تسجيل الخروج');
    await page.evaluate(() => document.querySelector('[data-act="au-logout"]').click()); await sleep(500);
    await page.goto(BASE + '/app/#/book'); await page.waitForSelector('#a-phone', { timeout: 6000 });
    ok(true, 'بعد الخروج يطلب الحجز التسجيل من جديد');
    ok(errs.length === 0, 'لا أخطاء جافاسكربت: ' + errs.join('|'));
  } catch (e) { fail++; console.log('CRASH', e.message); }
  await b.close(); srv.kill();
  console.log('النتيجة: ' + pass + ' ناجح، ' + fail + ' فاشل');
  process.exit(fail ? 1 : 0);
})();
