"""حسابات المراجعين بكلمة مرور: سياسة كلمة المرور والتحقق الصارم من الملف الشخصي والصحي.

دوال نقية (بلا خادم ولا قاعدة بيانات) لتُختبر منفردة. المبدأ: قائمة بيضاء؛ ما لم يُذكر هنا لا يُحفظ أبداً،
وكل نص يُنظَّف من المحارف الخفية ويُقيَّد طوله. البيانات الصحية لا تُرسل إلى «قمر» ولا إلى أي مزوّد خارجي.
"""
import re
import secrets

from util import AR_DIGITS, norm_phone

# إصدار نص الموافقة والخصوصية الذي وافق عليه المراجع (يُسجَّل مع وقت الموافقة؛ يُرفع عند تغيير النص جوهرياً)
CONSENT_VER = "2026-11"

BLOOD_TYPES = ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")
CHRONIC = (("diabetes", "السكري"), ("hypertension", "ارتفاع ضغط الدم"), ("heart", "أمراض القلب"), ("asthma", "الربو"),
           ("kidney", "أمراض الكلى"), ("thyroid", "الغدة الدرقية"), ("epilepsy", "الصرع"), ("cholesterol", "ارتفاع الدهون والكوليسترول"),
           ("anemia", "فقر الدم الوراثي (المنجلي / الثلاسيميا)"), ("g6pd", "نقص إنزيم G6PD (الفول)"))
CHRONIC_IDS = tuple(k for k, _ in CHRONIC)
RELATIONS = ("أب", "أم", "زوج/ة", "أخ/أخت", "ابن/ابنة", "قريب", "صديق", "أخرى")
PREGNANCY = (("no", "لا"), ("pregnant", "حامل"), ("breastfeeding", "مرضعة"))

_HIDDEN = re.compile(r"[\x00-\x1f\x7f​-‏‪-‮⁦-⁩﻿]")
_EMAIL = re.compile(r"[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s.]{2,}")
_INS_NO = re.compile(r"[A-Za-z0-9\-/ ]{3,30}")
_LETTERS = re.compile(r"[A-Za-zء-ي]")

# كلمات مرور شائعة تُرفض (بعد خفض الحروف). القائمة قصيرة عمداً: الغرض قطع أسهل التخمينات لا إرهاق المراجع.
WEAK = frozenset("""12345678 123456789 1234567890 11111111 00000000 87654321 987654321 12341234 123123123 11223344 12121212 0123456789
password password1 password12 password123 passw0rd p@ssw0rd qwertyui qwerty123 qwertyuiop abcd1234 abcdefgh abc12345 iloveyou
admin123 welcome1 letmein1 aaaaaaaa asdfghjk 1q2w3e4r 1qaz2wsx""".split())


def clean_text(v, maxlen):
    """نص مفرد السطر بلا محارف تحكّم أو اتجاه خفية؛ يُقتطع عند maxlen (يمرَّر hi+1 لكشف الزيادة)."""
    if v is None or isinstance(v, (dict, list, bool)):
        return ""
    return re.sub(r"\s+", " ", _HIDDEN.sub(" ", str(v))).strip()[:maxlen]


def _text(v, f, key, lo, hi, label, required=False):
    s = clean_text(v, hi + 1)
    if not s:
        if required:
            f[key] = "اكتب " + label
        return ""
    if len(s) < lo or len(s) > hi:
        f[key] = "%s: من %d إلى %d حرفاً" % (label, lo, hi)
        return ""
    return s


def _yesno(v, f, key, label, hi, required):
    """{"none": true} أو {"none": false, "text": "..."}؛ بلا إجابة صريحة → خطأ إن كان الحقل إلزامياً."""
    if not isinstance(v, dict) or not isinstance(v.get("none"), bool):
        if required:
            f[key] = "اختر «لا يوجد» أو اكتب %s" % label
        return {}
    if v["none"]:
        return {"none": True, "text": ""}
    text = _text(v.get("text"), f, key, 2, hi, label, required=True)
    return {"none": False, "text": text} if text else {}


def pw_problem(pw, phone="", national_id=""):
    """سبب رفض كلمة المرور بالعربية، أو "" إن كانت مقبولة."""
    if not isinstance(pw, str) or not pw:
        return "أدخل كلمة المرور"
    if len(pw) < 8:
        return "كلمة المرور 8 أحرف على الأقل"
    if len(pw) > 100:
        return "كلمة المرور طويلة (100 حرف كحد أقصى)"
    if pw != pw.strip():
        return "أزل المسافات من أول كلمة المرور وآخرها"
    if pw.isdigit():
        return "لا تجعل كلمة المرور أرقاماً فقط، أضف إليها حروفاً"
    low = pw.lower()
    if low in WEAK or len(set(low)) <= 2:
        return "كلمة المرور سهلة التخمين، اختر غيرها"
    digits = re.sub(r"\D", "", pw.translate(AR_DIGITS))
    local = phone[3:] if str(phone).startswith("966") else str(phone or "")
    if (local and len(local) >= 7 and local in digits) or (national_id and national_id in digits):
        return "لا تضع رقم جوالك أو هويتك في كلمة المرور"
    return ""


def temp_password():
    """كلمة مرور مؤقتة يصدرها المدير: 10 محارف بلا ما يلتبس (0/O/1/l/I)، وفيها حرف ورقم دائماً."""
    letters, nums = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ", "23456789"
    while True:
        pw = "".join(secrets.choice(letters + nums) for _ in range(10))
        if any(c in nums for c in pw) and any(c in letters for c in pw) and not pw_problem(pw):
            return pw


def clean_profile(raw, gender, f, required_health=True):
    """يعيد الملف الشخصي والصحي النظيف (بالحقول المسموحة فقط). الأخطاء تُضاف إلى f: مفتاح مسطّح → رسالة بالعربية.
    الإجابات الصريحة (لا يوجد / أكتب) إلزامية للحساسية والأمراض المزمنة والأدوية؛ وفصيلة الدم والعمليات والحمل اختيارية."""
    raw = raw if isinstance(raw, dict) else {}
    out = {"nationality": _text(raw.get("nationality"), f, "nationality", 2, 40, "الجنسية"),
           "city": _text(raw.get("city"), f, "city", 2, 40, "المدينة")}
    email = clean_text(raw.get("email"), 121).lower()
    if email and not (len(email) <= 120 and _EMAIL.fullmatch(email)):
        f["email"] = "البريد الإلكتروني غير صحيح"
        email = ""
    out["email"] = email

    em = raw.get("emergency") if isinstance(raw.get("emergency"), dict) else {}
    ename, erel, ephone_raw = clean_text(em.get("name"), 61), clean_text(em.get("relation"), 31), clean_text(em.get("phone"), 26)
    if ename or erel or ephone_raw:
        if not (2 <= len(ename) <= 60 and len(_LETTERS.findall(ename)) >= 2):
            f["emName"] = "اكتب اسم جهة الاتصال"
        ephone = norm_phone(ephone_raw)
        if not ephone or not ephone.startswith("9665"):
            f["emPhone"] = "رقم الجوال غير صحيح (مثال: 05xxxxxxxx)"
        if erel not in RELATIONS:
            f["emRelation"] = "اختر صلة القرابة"
        out["emergency"] = {"name": ename, "relation": erel, "phone": ephone or ""}
    else:
        out["emergency"] = {}

    h = raw.get("health") if isinstance(raw.get("health"), dict) else {}
    bt = clean_text(h.get("bloodType"), 8)
    if bt and bt not in BLOOD_TYPES and bt != "unknown":
        f["bloodType"] = "فصيلة الدم غير صحيحة"
    oh = {"bloodType": bt if bt in BLOOD_TYPES else ""}
    oh["allergies"] = _yesno(h.get("allergies"), f, "allergies", "الحساسية (دواء أو طعام أو غيره)", 200, required_health)
    c = h.get("chronic")
    if not isinstance(c, dict) or not isinstance(c.get("none"), bool):
        if required_health:
            f["chronic"] = "اختر «لا يوجد» أو حدّد الأمراض المزمنة"
        oh["chronic"] = {}
    elif c["none"]:
        oh["chronic"] = {"none": True, "items": [], "other": ""}
    else:
        items = c.get("items") if isinstance(c.get("items"), list) else []
        given = {str(x) for x in items[:40]}
        if given - set(CHRONIC_IDS):
            f["chronic"] = "اختيار غير صحيح في الأمراض المزمنة"
        other = _text(c.get("other"), f, "chronic", 2, 100, "أمراض أخرى")
        ok_items = [k for k in CHRONIC_IDS if k in given]
        if not ok_items and not other and "chronic" not in f:
            f["chronic"] = "حدّد مرضاً واحداً على الأقل، أو اختر «لا يوجد»"
        oh["chronic"] = {"none": False, "items": ok_items, "other": other}
    oh["medications"] = _yesno(h.get("medications"), f, "medications", "الأدوية التي تستخدمها حالياً", 300, required_health)
    oh["surgeries"] = _yesno(h.get("surgeries"), f, "surgeries", "العمليات السابقة", 300, False)
    pg = clean_text(h.get("pregnancy"), 15)
    if gender == "female":
        if pg and pg not in {k for k, _ in PREGNANCY}:
            f["pregnancy"] = "اختيار غير صحيح"
            pg = ""
    else:
        pg = ""
    oh["pregnancy"] = pg
    out["health"] = oh

    ins = raw.get("insurance") if isinstance(raw.get("insurance"), dict) else {}
    ic, inum = clean_text(ins.get("company"), 61), clean_text(ins.get("memberNo"), 31)
    if ic or inum:
        if not (2 <= len(ic) <= 60):
            f["insCompany"] = "اكتب اسم شركة التأمين"
        if inum and not _INS_NO.fullmatch(inum):
            f["insNo"] = "رقم العضوية: أحرف إنجليزية وأرقام فقط (3 إلى 30)"
        out["insurance"] = {"company": ic if 2 <= len(ic) <= 60 else "", "memberNo": inum if _INS_NO.fullmatch(inum or "") else ""}
    else:
        out["insurance"] = {}
    return out


def consent_problems(consent, f):
    """الموافقتان المطلوبتان عند إنشاء الحساب: سياسة الخصوصية + معالجة البيانات الصحية. تُضاف الأخطاء إلى f."""
    c = consent if isinstance(consent, dict) else {}
    if c.get("privacy") is not True:
        f["consentPrivacy"] = "يجب الموافقة على سياسة الخصوصية"
    if c.get("health") is not True:
        f["consentHealth"] = "يجب الموافقة على حفظ بياناتك الصحية لدى المجمع"


def public_lists():
    """القوائم التي يعرضها التطبيق في النماذج (من مصدر واحد مع المُتحقِّق حتى لا تختلف)."""
    return {"bloodTypes": list(BLOOD_TYPES), "chronic": [{"id": k, "label": l} for k, l in CHRONIC], "relations": list(RELATIONS),
            "pregnancy": [{"id": k, "label": l} for k, l in PREGNANCY]}

