/* «قمر»: المساعد الافتراضي — أيقونة عائمة + نافذة محادثة.
   يجيب محلياً من قاعدة المعرفة (بلا تكلفة وبلا إنترنت)، ولا يطلب الخادم إلا للأسئلة غير المفهومة أو إن فُعّل وضع النموذج. */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui;
  var Q = DS.qamar = { isOpen: false };
  var LLM_FULL = ['unknown', 'route', 'doctor', 'doctors', 'service', 'services', 'specialties', 'which_clinic', 'about'];
  var NEVER = ['emergency', 'self_harm', 'advice'];
  var NAV_OK = { profile: 1, specialties: 1, doctors: 1, services: 1, about: 1, branches: 1, contact: 1, notifications: 1 };
  var hist = [], busy = false, fab = null, root_ = null, sheet = null, msgs = null, qr = null, input = null, lastFocus = null;

  function cfg() { return (D.ds && D.ds.qamar) || {}; }
  function enabled() { return cfg().enabled !== false; }
  function emergencyNo() { return D.settings().emergencyNumber || '997'; }
  function save() { DS.store.set('qamarHistory', hist.slice(-24)); }
  function ctx() { return hist.slice(-8).map(function (m) { return { role: m.r === 'me' ? 'user' : 'assistant', content: String(m.t || '').slice(0, 500) }; }); }

  /* ---------- أزرار الإجراءات ---------- */
  function actHtml(a) {
    var lbl = esc(a.label || ''), id = esc(a.id || '');
    switch (a.type) {
      case 'book': return '<a class="act book" href="' + U.bookHref({ sp: a.specialtyId, dr: a.doctorId, br: a.branchId }) + '" data-act="qm-go">' + ic('calendar-plus', 'sm') + lbl + '</a>';
      case 'slot': return '<a class="act slot" href="' + U.bookHref({ sp: a.specialtyId, dr: a.doctorId, br: a.branchId, day: a.day, t: a.start }) + '" data-act="qm-go">' + ic('clock', 'sm') + lbl + '</a>';
      case 'call': return '<a class="act" href="' + DS.telHref(a.number) + '">' + ic('phone', 'sm') + lbl + '</a>';
      case 'emergency': return '<a class="act em" href="' + DS.telHref(a.number) + '">' + ic('phone', 'sm') + lbl + '</a>';
      case 'whatsapp': return '<a class="act wa" href="' + DS.waHref(a.number) + '" data-act="ext" data-url="' + DS.waHref(a.number) + '">' + ic('whatsapp', 'sm') + lbl + '</a>';
      case 'specialty': return '<a class="act" href="#/specialty/' + id + '" data-act="qm-go">' + ic('stethoscope', 'sm') + lbl + '</a>';
      case 'doctor': return '<a class="act" href="#/doctor/' + id + '" data-act="qm-go">' + ic('user', 'sm') + lbl + '</a>';
      case 'branch': return '<a class="act" href="#/branch/' + id + '" data-act="qm-go">' + ic('map-pin', 'sm') + lbl + '</a>';
      case 'service': return '<a class="act" href="#/service/' + id + '" data-act="qm-go">' + ic('activity', 'sm') + lbl + '</a>';
      case 'nav': return NAV_OK[a.to] ? '<a class="act" href="#/' + esc(a.to) + '" data-act="qm-go">' + lbl + '</a>' : '';
      default: return '';
    }
  }
  DS.acts['qm-go'] = function () { Q.close(true); return true; };

  function msgHtml(m) {
    if (m.r === 'me') return '<div class="m me">' + esc(m.t) + '</div>';
    var acts = (m.a || []).map(actHtml).filter(Boolean).join('');
    return '<div class="m bot">' + esc(m.t) + (m.s === 'llm' ? '<span class="src">رد آلي بالذكاء الاصطناعي — تأكد من المعلومات المهمة مع المجمع</span>' : '') +
      (acts ? '<div class="acts">' + acts + '</div>' : '') + '</div>';
  }
  function scrollEnd() { if (msgs) msgs.scrollTop = msgs.scrollHeight; }
  function add(m) { hist.push(m); save(); if (msgs) { var tp = DS.$('.typing', msgs); if (tp) tp.remove(); msgs.insertAdjacentHTML('beforeend', msgHtml(m)); scrollEnd(); } }
  function typing(on) {
    if (!msgs) return;
    var t = DS.$('.typing', msgs);
    if (on && !t) { msgs.insertAdjacentHTML('beforeend', '<div class="m bot typing" aria-label="قمر يكتب"><i></i><i></i><i></i></div>'); scrollEnd(); }
    if (!on && t) t.remove();
  }
  function chips(list) {
    if (!qr) return;
    qr.innerHTML = (list || []).slice(0, 6).map(function (c) { return '<button type="button" data-act="qm-chip" data-q="' + esc(c) + '">' + esc(c) + '</button>'; }).join('');
  }
  DS.acts['qm-chip'] = function (el) { Q.ask(el.getAttribute('data-q')); return false; };

  function greeting() {
    return cfg().greeting || 'هلا! أنا قمر، مساعد ' + (D.settings().name || 'المجمع') + '. أساعدك تعرف التخصص المناسب والأطباء والفروع، وأرتّب معك طلب الحجز. ما أقدّم تشخيصاً ولا أصف أدوية.';
  }
  function defaultChips() { return cfg().quickReplies && cfg().quickReplies.length ? cfg().quickReplies : ['أبي أحجز موعد', 'وين الفروع؟', 'وش التخصصات؟', 'أرقام التواصل']; }

  /* ---------- الإجابة ---------- */
  function localAnswer(text) {
    try {
      if (D.kb) { var r = D.kb.answer(text, ctx()); return { text: r.text, actions: r.actions || [], chips: r.chips || [], intent: r.intent, confident: r.confident !== false, emergency: !!r.emergency, source: 'kb' }; }
    } catch (e) { /* ننتقل للرد الاحتياطي */ }
    var ph = D.mainPhone();
    return { text: 'تعذر عليّ الرد الآن. يمكنك الاتصال بالمجمع مباشرة' + (ph ? ' على ' + ph : '') + '.', actions: ph ? [{ type: 'call', number: ph, label: 'اتصال بالمجمع' }] : [], chips: [], intent: 'unknown', confident: false, source: 'kb' };
  }
  function needsServer(r) {
    if (DS.cfg.demo || r.emergency || NEVER.indexOf(r.intent) >= 0) return false;
    if (!r.confident) return true;
    return cfg().mode === 'llm' && LLM_FULL.indexOf(r.intent) >= 0;
  }
  /* طلب موعد («بكرة الصبح»، «الخميس العصر»): الأوقات الفعلية في الخادم، فنسأله حتى في وضع قاعدة المعرفة (بلا نموذج لغوي ولا تكلفة).
     الفلتر هنا واسع عمداً؛ الخادم هو من يقرر هل يعرض مواعيد ولمن، وإن لم يكن طلب موعد يرجع الرد العادي نفسه. */
  var SLOT_INTENTS = ['unknown', 'booking', 'doctor', 'doctors', 'route', 'which_clinic', 'specialties', 'service', 'services', 'hours'];
  var WHEN_RE = /موعد|مواعيد|احجز|حجز|كشف|بكر|غدا|غداً|اليوم|الليل|صباح|صبح|مساء|عصر|مغرب|عشاء|الأحد|الاحد|الاثنين|الإثنين|الثلاثاء|الأربعاء|الاربعاء|الخميس|الجمعة|السبت|الساعة|\d\s*(?:ص|م)\b/;
  function wantsSlots(text, r) {
    if (DS.cfg.demo || r.emergency || !(DS.sched && DS.sched.any && DS.sched.any())) return false;
    return (!r.intent || SLOT_INTENTS.indexOf(r.intent) >= 0) && WHEN_RE.test(text);
  }
  function serverAsk(text) {
    return DS.api.post('/qamar', { message: text, deviceId: DS.deviceId(), history: ctx() }, { timeout: 14000 }).then(function (r) { return r.data && r.data.reply; });
  }

  function finish(r) {
    busy = false; var s = DS.$('.send', sheet); if (s) s.disabled = false;
    chips(r.emergency ? [] : (r.chips && r.chips.length ? r.chips : defaultChips()));   // قبل الإضافة حتى يبقى التمرير صحيحاً
    add({ r: 'bot', t: r.text, a: r.actions || [], s: r.source || 'kb' });
  }

  Q.ask = function (text) {
    text = String(text || '').trim().slice(0, 600);
    if (!text || busy) return;
    if (!Q.isOpen) Q.open();
    busy = true; var s = DS.$('.send', sheet); if (s) s.disabled = true;
    chips([]);
    var local = localAnswer(text);          // نحسب قبل إضافة سؤال المستخدم لأن السياق يعتمد على الرسائل السابقة
    add({ r: 'me', t: text });
    if (local.emergency) { finish(local); return; }
    typing(true);
    var slots = wantsSlots(text, local);
    if (!slots && !needsServer(local)) { setTimeout(function () { finish(local); }, 260); return; }
    var mode = cfg().mode || 'kb';
    if (mode === 'kb' && !slots) {          // وضع قاعدة المعرفة: الرد المحلي فوراً، والخادم لتسجيل السؤال فقط
      setTimeout(function () { finish(local); }, 260);
      serverAsk(text).catch(function () { /* لا يهم */ });
      return;
    }
    serverAsk(text).then(function (rep) {
      if (!rep || !rep.text) return finish(local);
      finish({ text: rep.text, actions: rep.actions || [], chips: rep.chips || [], source: rep.source === 'llm' ? 'llm' : 'kb' });
    }).catch(function (e) {
      if (e && e.status === 429 && e.message) return finish({ text: e.message, actions: local.actions, chips: [], source: 'kb' });
      finish(local);
    });
  };

  /* ---------- النافذة ---------- */
  function build() {
    if (root_) return;
    root_ = document.createElement('div'); root_.id = 'qroot';
    document.body.appendChild(root_);
    fab = document.createElement('button');
    fab.className = 'fab pulse'; fab.type = 'button'; fab.setAttribute('data-act', 'qamar-open'); fab.setAttribute('aria-label', 'اسأل قمر، المساعد الافتراضي');
    fab.innerHTML = '<span class="fl">اسأل قمر</span>';
    root_.appendChild(fab);
    D.onChange(function () { if (fab) fab.hidden = !enabled() || Q.isOpen; });
  }
  function fit() {
    var vv = root.visualViewport; if (!vv || !sheet) return;
    var kb = Math.max(0, root.innerHeight - vv.height - vv.offsetTop);
    sheet.style.bottom = kb + 'px';
    sheet.style.height = Math.min(vv.height * (kb > 60 ? 0.96 : 0.86), 720) + 'px';
  }
  /* الأيقونة العائمة تظهر في الرئيسية والتبويبات والقوائم (meta.fab)؛ تُخفى في صفحات التفاصيل والنماذج حتى لا تغطي الأزرار */
  Q.onRoute = function (cur) { if (fab) fab.classList.toggle('away', !(cur && cur.meta && cur.meta.fab === true)); };
  Q.init = function () {
    build();
    fab.hidden = !enabled();
    try { hist = DS.store.get('qamarHistory', []) || []; } catch (e) { hist = []; }
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && Q.isOpen) Q.close(); });
  };

  Q.open = function () {
    if (Q.isOpen || !enabled()) return;
    build(); Q.isOpen = true; lastFocus = document.activeElement;
    if (fab) fab.hidden = true;
    var scrim = document.createElement('div'); scrim.className = 'scrim'; scrim.id = 'qscrim'; scrim.setAttribute('data-act', 'qamar-close');
    sheet = document.createElement('section'); sheet.className = 'sheet'; sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-modal', 'true'); sheet.setAttribute('aria-label', 'محادثة ' + (cfg().name || 'قمر'));
    sheet.innerHTML = '<header><span class="moon">' + DS.moonSvg + '</span><div><b>' + esc(cfg().name || 'قمر') + '</b><small>المساعد الافتراضي لـ' + esc(D.settings().shortName || 'المجمع') + '</small></div>' +
      '<button class="x" type="button" data-act="qm-new" aria-label="محادثة جديدة" style="margin-inline-start:auto">' + ic('refresh', 'sm') + '</button>' +
      '<button class="x" type="button" data-act="qamar-close" aria-label="إغلاق" style="margin-inline-start:0">' + ic('x') + '</button></header>' +
      '<div class="msgs" role="log" aria-live="polite" id="qmsgs"></div><div class="qr" id="qqr"></div>' +
      '<div class="disc">مساعد آلي: لا يشخّص ولا يصف أدوية. للحالات الطارئة اتصل بالإسعاف ' + esc(emergencyNo()) + '</div>' +
      '<form class="composer" id="qform"><textarea id="qin" rows="1" maxlength="600" dir="auto" placeholder="اكتب سؤالك…" aria-label="اكتب سؤالك لقمر"></textarea>' +
      '<button class="send" type="submit" aria-label="إرسال">' + ic('send', 'sm') + '</button></form>';
    root_.appendChild(scrim); root_.appendChild(sheet);
    msgs = DS.$('#qmsgs', sheet); qr = DS.$('#qqr', sheet); input = DS.$('#qin', sheet);
    if (!hist.length) hist.push({ r: 'bot', t: greeting(), a: [], s: 'kb' });
    msgs.innerHTML = hist.map(msgHtml).join(''); scrollEnd();
    chips(defaultChips());
    DS.$('#qform', sheet).addEventListener('submit', function (e) { e.preventDefault(); var v = input.value; input.value = ''; input.style.height = ''; Q.ask(v); });
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); DS.$('#qform', sheet).requestSubmit ? DS.$('#qform', sheet).requestSubmit() : DS.$('#qform', sheet).dispatchEvent(new Event('submit', { cancelable: true })); } });
    input.addEventListener('input', function () { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 110) + 'px'; });
    if (root.visualViewport) { root.visualViewport.addEventListener('resize', fit); root.visualViewport.addEventListener('scroll', fit); }
    var coarse = root.matchMedia && root.matchMedia('(pointer:coarse)').matches;
    if (!coarse) input.focus(); else DS.$('.x[data-act="qamar-close"]', sheet).focus();
  };

  Q.close = function (keepFocus) {
    if (!Q.isOpen) return;
    Q.isOpen = false;
    if (root.visualViewport) { root.visualViewport.removeEventListener('resize', fit); root.visualViewport.removeEventListener('scroll', fit); }
    var sc = DS.$('#qscrim'); if (sc) sc.remove(); if (sheet) sheet.remove();
    sheet = msgs = qr = input = null; busy = false;
    if (fab) { fab.hidden = !enabled(); fab.classList.remove('pulse'); }
    if (keepFocus !== true && lastFocus && lastFocus.focus) { try { lastFocus.focus(); } catch (e) { /* تجاهل */ } }
  };
  DS.acts['qamar-close'] = function () { Q.close(); return false; };
  DS.acts['qm-new'] = function () {
    hist = [{ r: 'bot', t: greeting(), a: [], s: 'kb' }]; save(); busy = false;
    if (msgs) { msgs.innerHTML = hist.map(msgHtml).join(''); chips(defaultChips()); }
    return false;
  };
  DS.acts['qamar-open'] = function () { Q.open(); return false; };
})(window);
