/* تسجيل المرضى. التصفح حر؛ يُطلب التسجيل عند إرسال طلب حجز فقط. طريقتان يحدّدهما الخادم (meta.auth.method):
   «sms» جوال + رمز تحقق (يلزم مزوّد رسائل) · «password» جوال + كلمة مرور مع ملف صحي (تفعّلها الإدارة؛ آخر هذا الملف).
   وإن لم يفعّل الخادم أيّاً منهما (meta.auth.enabled=false) يبقى الحجز بلا تسجيل كما كان. */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui;

  var A = DS.auth = {
    enabled: function () { return !DS.cfg.demo && !!(D.ds && D.ds.meta && D.ds.meta.auth && D.ds.meta.auth.enabled); },
    method: function () { return A.enabled() ? (D.ds.meta.auth.method || '') : ''; },
    pw: function () { return A.method() === 'password'; },                       // حسابات كلمة المرور (الملف الصحي)
    lists: function () { return (D.ds && D.ds.meta && D.ds.meta.auth) || {}; },     // قوائم النماذج من الخادم (فصائل الدم، الأمراض المزمنة، صلات القرابة…)
    token: function () { return DS.store.get('ptoken', '') || ''; },
    patient: function () { return A.token() ? DS.store.get('patient', null) : null; },
    mustChange: function () { return !!A.token() && !!DS.store.get('mustChange', false); },   // كلمة مرور مؤقتة من المجمع: تُغيَّر قبل الحجز
    set: function (t, p) { DS.store.set('ptoken', t); DS.store.set('patient', p); },
    /* الخروج أو انتهاء الجلسة: لا نُبقي على الجهاز حجوزات ولا إشعارات صاحب الحساب السابق (قد يستعمله شخص آخر) */
    clear: function () { ['ptoken', 'patient', 'records', 'mustChange', 'myBookings', 'notifCache'].forEach(function (k) { DS.store.del(k); }); },
    /* true = أعدنا التوجيه لصفحة الدخول */
    gate: function (next) {
      if (!A.enabled() || A.token()) return false;
      setTimeout(function () { location.replace('#/login?next=' + encodeURIComponent(next || '#/')); }, 0);
      return true;
    },
    local: function (phone) { return phone && phone.slice(0, 3) === '966' ? '0' + phone.slice(3) : phone || ''; }
  };

  /* فتح صفحة ملفات أو زيارات مباشرة عند بدء التشغيل قبل وصول إعدادات الخادم: نحوّل لصفحة الدخول فور وصولها.
     صفحة الحجز ليست منها: يتصفحها المراجع بحرية ويُطلب الدخول عند «تأكيد الحجز» فقط (انظر 40-booking.js). */
  D.onChange(function () { if (A.enabled() && !A.token() && /^#\/(files|link|visits)/.test(location.hash)) A.gate(location.hash); });

  var fld = A.fld = function (id, label, input, hint) {
    return '<div class="fld"><label for="' + id + '">' + label + '</label>' + input + (hint ? '<div class="xs muted" style="margin-top:4px">' + hint + '</div>' : '') + '<div class="err" data-err="' + id + '" hidden></div></div>';
  };
  function showErr(fields) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-err]'), function (e) { e.hidden = true; });
    Object.keys(fields || {}).forEach(function (k) {
      var e = DS.$('[data-err="a-' + k + '"]') || DS.$('[data-err="' + k + '"]'); if (e) { e.textContent = fields[k]; e.hidden = false; }
    });
  }
  A.showErr = showErr;

  DS.route('/login', function (p, q) {
    if (!A.enabled()) {
      /* أول فتح قبل أن تصل إعدادات الخادم (النسخة المضمّنة فقط): ننتظرها قليلاً بدل أن نعيدك للرئيسية فوراً.
         حين تصل يُعاد رسم الصفحة تلقائياً: تظهر شاشة الدخول إن كان التسجيل مفعّلاً، وإلا نعود للرئيسية. */
      if (!DS.cfg.demo && D.source === 'seed' && !A.waited) {
        A.waited = true;
        setTimeout(function () { if (!A.enabled() && /^#\/login/.test(location.hash)) location.replace('#/'); }, 6000);
        return '<div class="card"><p class="sm muted">جارٍ التحميل…</p></div>';
      }
      setTimeout(function () { location.replace('#/'); }, 0); return '';
    }
    if (A.pw()) return A.pwLogin(q);
    var next = q.next && q.next.charAt(0) === '#' ? q.next : '#/', st = { phone: '', isNew: false };
    var toBook = next.indexOf('#/book') === 0, saved = toBook && DS.bkDraft ? DS.bkDraft.line() : '';
    var html = '<div id="au-root"><div class="card"><h2 style="font-weight:800;font-size:1.1rem">' + (toBook ? 'سجّل دخولك لتأكيد الحجز' : 'تسجيل الدخول') + '</h2>' +
      (saved ? '<div class="alert info" style="margin:8px 0 4px">' + ic('check', 'sm') + '<div><b>حجزك محفوظ:</b> ' + esc(saved) + '<div class="xs">بعد الدخول تعود إليه تلقائياً.</div></div></div>' : '') +
      '<p class="sm muted" style="margin:4px 0 12px">' + (toBook ? 'ندخلك برمز يصلك على جوالك، وإن لم يكن لديك حساب ننشئه لك في الخطوة التالية.' : 'تصفّح التطبيق بحرية. التسجيل مطلوب فقط عند طلب الحجز أو الاستشارة.') + '</p>' +
      '<form id="au-phone" class="form" novalidate>' + fld('a-phone', 'رقم الجوال', '<input class="in ltr" id="a-phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="05xxxxxxxx">') +
      '<div id="au-fail"></div><button class="btn pri blk" type="submit">إرسال رمز التحقق</button></form>' +
      (toBook ? '<a class="btn ghost blk" style="margin-top:8px" href="#/book?resume=1">العودة إلى الحجز</a>' : '') + '</div></div>';
    setTimeout(function () {
      var root_ = DS.$('#au-root');
      function fail(msg) { var f = DS.$('#au-fail'); if (f) f.innerHTML = msg ? '<div class="alert danger" style="margin-bottom:10px">' + ic('alert', 'sm') + '<div>' + esc(msg) + '</div></div>' : ''; }
      function codeStep() {
        root_.innerHTML = '<div class="card"><h2 style="font-weight:800;font-size:1.1rem">رمز التحقق</h2>' +
          '<p class="sm muted" style="margin:4px 0 12px">أرسلنا رمزاً من 6 أرقام إلى <span class="ltr">' + esc(A.local(st.phone)) + '</span>.</p>' +
          '<form id="au-code" class="form" novalidate>' + fld('a-code', 'الرمز', '<input class="in ltr" id="a-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000">') +
          (st.isNew ? '<h3 style="font-weight:800;margin:12px 0 4px">أكمل بياناتك</h3>' +
            fld('a-name', 'الاسم', '<input class="in" id="a-name" autocomplete="name" maxlength="60">') +
            fld('a-gender', 'الجنس', '<select class="in" id="a-gender"><option value="">اختر</option><option value="male">ذكر</option><option value="female">أنثى</option></select>') +
            fld('a-birthDate', 'تاريخ الميلاد', '<input class="in ltr" id="a-birthDate" type="date" max="' + DS.riyadhToday(0) + '">') +
            fld('a-nationalId', 'رقم الهوية / الإقامة <span class="muted">(اختياري)</span>', '<input class="in ltr" id="a-nationalId" inputmode="numeric" maxlength="10">', 'تساعد موظف المجمع على فتح ملفك أسرع. يمكنك تركه فارغاً.') : '') +
          '<p class="xs muted">بالمتابعة توافق على <a href="#/privacy">سياسة الخصوصية</a>.</p><div id="au-fail"></div>' +
          '<button class="btn pri blk" type="submit">' + (st.isNew ? 'إنشاء الحساب' : 'دخول') + '</button>' +
          '<button class="btn ghost blk" type="button" data-act="au-back" style="margin-top:8px">تغيير الرقم</button></form></div>';
        var f = DS.$('#au-code');
        f.addEventListener('submit', function (ev) {
          ev.preventDefault(); fail(''); showErr({});
          var body = { phone: st.phone, code: DS.$('#a-code').value.trim() };
          if (st.isNew) body.profile = { name: DS.$('#a-name').value, gender: DS.$('#a-gender').value, birthDate: DS.$('#a-birthDate').value, nationalId: DS.$('#a-nationalId').value };
          var btn = f.querySelector('button[type=submit]'); btn.disabled = true;
          DS.api.post('/auth/verify', body, { timeout: 15000 }).then(function (r) {
            A.set(r.data.token, r.data.patient);
            DS.store.set('profile', { name: r.data.patient.name, phone: A.local(r.data.patient.phone) });
            DS.toast('تم تسجيل الدخول'); if (DS.files && DS.files.refresh) DS.files.refresh(); location.replace(next);
          }).catch(function (e) {
            btn.disabled = false;
            if (e && e.fields && Object.keys(e.fields).length) showErr(e.fields);
            fail(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر التحقق الآن.');
          });
        });
      }
      DS.acts['au-back'] = function () { location.reload(); return false; };
      DS.$('#au-phone').addEventListener('submit', function (ev) {
        ev.preventDefault(); fail(''); showErr({});
        var ph = DS.normPhone(DS.$('#a-phone').value.trim());
        if (!ph || ph.slice(0, 4) !== '9665') { showErr({ 'a-phone': 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)' }); return; }
        var btn = ev.target.querySelector('button[type=submit]'); btn.disabled = true;
        DS.api.post('/auth/otp', { phone: ph, deviceId: DS.deviceId() }, { timeout: 15000 }).then(function (r) {
          st.phone = ph; st.isNew = !!r.data.isNew; codeStep();
        }).catch(function (e) {
          btn.disabled = false;
          fail(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر إرسال الرمز الآن.');
        });
      });
    }, 0);
    return html;
  }, { tab: 'none', title: 'تسجيل الدخول', back: true });

  /* بطاقة الحساب في «طلباتي وبياناتي» */
  A.card = function () {
    if (!A.enabled()) return '';
    if (A.pw()) return A.pwCard();
    var p = A.patient();
    if (!p) return '<div class="card row" style="margin-bottom:10px"><span class="ico-box">' + ic('user') + '</span><div class="grow"><b>حسابي</b><p class="sm muted">سجّل لتتمكن من إرسال طلبات الحجز.</p></div><a class="btn pri sm" href="#/login?next=' + encodeURIComponent('#/profile') + '">دخول</a></div>';
    return '<div class="card" style="margin-bottom:10px"><b>حسابي</b><p class="sm" style="margin:6px 0"><span>' + esc(p.name) + '</span> · <span class="ltr">' + esc(A.local(p.phone)) + '</span></p>' +
      '<div class="grid2"><button class="btn out sm" data-act="au-logout">تسجيل الخروج</button>' +
      '<button class="btn out sm" style="color:var(--danger);border-color:var(--danger)" data-act="au-delete">حذف حسابي</button></div></div>';
  };
  DS.acts['au-logout'] = function () { A.clear(); if (A.pw()) DS.store.del('profile'); DS.toast('تم تسجيل الخروج'); DS.render(); return false; };
  DS.acts['au-delete'] = function () {
    if (!root.confirm(A.pw() ? 'سيُحذف حسابك وملفك الصحي وبياناتك الشخصية من خادم المجمع، وتُزال بياناتك من طلباتك، ولا يمكن التراجع. قد تبقى سجلات زياراتك الطبية لدى المجمع وفق أنظمة حفظ السجلات الطبية. متابعة؟'
      : 'سيُحذف حسابك وتُزال بياناتك من طلباتك لدى المجمع، ولا يمكن التراجع. متابعة؟')) return false;
    DS.api.post('/auth/delete', {}).then(function () { A.clear(); DS.store.del('profile'); DS.store.del('myBookings'); DS.toast('تم حذف حسابك'); DS.render(); })
      .catch(function () { DS.toast('تعذر الحذف الآن، جرّب عند توفر الاتصال.'); });
    return false;
  };
})(window);

/* ملفات المراجع (PDF يرفعها موظفو المجمع): كل مراجع يرى ملفاته فقط، والخادم يتحقق من الهوية عند كل فتح أو تحميل */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui, A = DS.auth, fld = A.fld;

  var F = DS.files = {
    enabled: function () { return A.enabled() && !!(D.ds && D.ds.meta && D.ds.meta.files && D.ds.meta.files.enabled); },
    kinds: function () { return (D.ds && D.ds.meta && D.ds.meta.files && D.ds.meta.files.kinds) || []; },
    label: function (k) { var m = F.kinds().filter(function (x) { return x.id === k; })[0]; return m ? m.label : 'ملفات'; }
  };
  function fmtSize(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function fmtDate(iso) { try { return new Date(iso).toLocaleDateString('ar-SA-u-nu-latn-ca-gregory', { timeZone: 'Asia/Riyadh', day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return ''; } }

  /* الملف الطبي المرتبط بحساب المراجع (رقم الملف + بياناته) */
  F.records = function () { return A.token() ? DS.store.get('records', []) : []; };
  F.refresh = function () {
    if (!F.enabled() || !A.token()) return Promise.resolve([]);
    return DS.api.get('/records/mine', { timeout: 10000 }).then(function (r) {
      var l = (r.data && r.data.records) || []; DS.store.set('records', l); return l;
    }).catch(function (e) { if (e && e.status === 401) A.clear(); return F.records(); });
  };
  function fmtBirth(s) { return s ? fmtDate(s + 'T12:00:00+03:00') : ''; }
  function recCard(r) {
    return '<div class="card" style="margin-bottom:10px"><div class="row"><span class="ico-box">' + ic('user') + '</span><div class="grow"><b>' + esc(r.name) + '</b>' +
      '<div class="xs muted">رقم الملف: <span class="ltr">' + esc(r.mrn) + '</span></div>' +
      '<div class="xs muted">' + (r.birthDate ? 'الميلاد: ' + esc(fmtBirth(r.birthDate)) + ' · ' : '') + (r.gender ? (r.gender === 'male' ? 'ذكر' : 'أنثى') + ' · ' : '') + '<span class="ltr">' + esc(A.local(r.phone)) + '</span></div></div></div></div>';
  }
  /* بطاقة «ملفي الطبي» في صفحة بياناتي: تُرسم من النسخة المحفوظة ثم تتحدّث من الخادم */
  F.card = function () {
    if (!F.enabled() || !A.token()) return '';
    setTimeout(function () { F.refresh().then(function (l) { var b = DS.$('#mf-card'); if (b) b.innerHTML = cardBody(l); }); }, 0);
    return '<div id="mf-card">' + cardBody(F.records()) + '</div>';
  };
  function cardBody(l) {
    if (!l.length) return '<div class="card row" style="margin-bottom:10px"><span class="ico-box">' + ic('file') + '</span><div class="grow"><b>ملفي الطبي</b><p class="sm muted">اربط حسابك بملفك في المجمع لتظهر لك نتائجك ووثائقك هنا.</p></div><a class="btn pri sm" href="#/link?next=' + encodeURIComponent('#/files') + '">ربط الملف</a></div>';
    return '<div style="margin-bottom:10px"><div class="row" style="margin-bottom:6px"><b class="grow">ملفي الطبي</b><a class="sm" href="#/link?next=' + encodeURIComponent('#/profile') + '">ربط ملف آخر</a></div>' + l.map(recCard).join('') +
      '<a class="btn pri blk" href="#/files">' + ic('file', 'sm') + 'ملفاتي ونتائجي</a></div>';
  }

  DS.route('/link', function (p, q) {
    if (!F.enabled()) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    var next = q.next && q.next.charAt(0) === '#' ? q.next : '#/files';
    setTimeout(function () {
      var f = DS.$('#lk-form'); if (!f) return;
      f.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var nid = DS.$('#lk-nid').value.replace(/\D/g, ''), bd = DS.$('#lk-bd').value, fail = DS.$('#lk-fail'), btn = f.querySelector('button[type=submit]');
        fail.innerHTML = '';
        if (!nid && !bd) { fail.innerHTML = '<div class="alert danger" style="margin-bottom:10px">' + ic('alert', 'sm') + '<div>اكتب رقم الهوية/الإقامة أو تاريخ الميلاد.</div></div>'; return; }
        btn.disabled = true;
        DS.api.post('/records/link', nid ? { nationalId: nid } : { birthDate: bd }, { timeout: 15000 }).then(function (r) {
          DS.store.set('records', r.data.records || []); DS.toast('تم ربط ملفك الطبي'); location.replace(next);
        }).catch(function (e) {
          btn.disabled = false;
          if (e && e.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); return; }
          fail.innerHTML = '<div class="alert danger" style="margin-bottom:10px">' + ic('alert', 'sm') + '<div>' + esc(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر الربط الآن.') + '</div></div>';
        });
      });
    }, 0);
    return '<div class="card"><h2 style="font-weight:800;font-size:1.1rem">ربط ملفي الطبي</h2>' +
      '<p class="sm muted" style="margin:4px 0 12px">لحماية خصوصيتك نتأكد أنك صاحب الملف: أدخل رقم الهوية/الإقامة <b>أو</b> تاريخ الميلاد المسجّل في المجمع. يجب أن يكون جوالك هو الرقم المسجّل في ملفك لدى المجمع.</p>' +
      '<form id="lk-form" class="form" novalidate>' +
      fld('lk-nid', 'رقم الهوية / الإقامة', '<input class="in ltr" id="lk-nid" inputmode="numeric" maxlength="10" autocomplete="off">') +
      '<div class="xs muted" style="text-align:center;margin:-4px 0 8px">أو</div>' +
      fld('lk-bd', 'تاريخ الميلاد', '<input class="in ltr" id="lk-bd" type="date" max="' + DS.riyadhToday(0) + '">', 'لملف أحد أبنائك (برقم جوالك) استخدم تاريخ ميلاده.') +
      '<div id="lk-fail"></div><button class="btn pri blk" type="submit">ربط الملف</button></form></div>';
  }, { tab: 'none', title: 'ربط الملف الطبي', back: true });

  function noRecords() {
    return '<div class="card" style="text-align:center">' + ic('file') + '<p class="sm" style="margin:8px 0">لم تربط ملفك الطبي بعد، فلا توجد ملفات لعرضها.</p><a class="btn pri" href="#/link?next=' + encodeURIComponent(location.hash || '#/files') + '">ربط الملف الطبي</a></div>';
  }
  function fileCard(x, multi) {
    return '<div class="card fl" style="margin-bottom:10px"><div class="row"><span class="ico-box">' + ic('file') + '</span><div class="grow"><b>' + esc(x.title) + '</b>' +
      '<div class="xs muted">' + esc(x.kindLabel) + ' · ' + esc(fmtDate(x.uploadedAt)) + ' · ' + fmtSize(x.size) + '</div>' + (multi && x.recordName ? '<div class="xs muted">للمراجع: ' + esc(x.recordName) + '</div>' : '') +
      (x.note ? '<div class="sm" style="margin-top:4px">' + esc(x.note) + '</div>' : '') + '</div></div>' +
      '<div class="grid2" style="margin-top:10px"><button class="btn pri sm" data-act="fl-view" data-id="' + esc(x.id) + '">عرض</button><button class="btn out sm" data-act="fl-dl" data-id="' + esc(x.id) + '" data-title="' + esc(x.title) + '">تحميل</button></div></div>';
  }
  function loadFiles(kind, onDone) {
    return DS.api.get('/files' + (kind ? '?kind=' + encodeURIComponent(kind) : ''), { timeout: 12000 }).then(function (r) { onDone((r.data && r.data.files) || []); });
  }
  function onErr(box) {
    return function (e) {
      if (e && e.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); return; }
      box.innerHTML = '<div class="alert danger">' + ic('alert', 'sm') + '<div>تعذر تحميل الملفات الآن. تحقق من الاتصال وحاول لاحقاً.</div></div>';
    };
  }

  /* نظرة عامة: كل أنواع الملفات مع العدد، وملف/ملفات المراجع المرتبطة */
  DS.route('/files', function () {
    if (!F.enabled()) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    setTimeout(function () {
      var box = DS.$('#fl-box'); if (!box) return;
      F.refresh().then(function (recs) {
        if (!recs.length) { box.innerHTML = noRecords(); return; }
        return loadFiles('', function (l) {
          var cnt = {}; l.forEach(function (x) { cnt[x.kind] = (cnt[x.kind] || 0) + 1; });
          box.innerHTML = recs.map(recCard).join('') + '<section class="sec">' + U.sec('أنواع الملفات') + F.kinds().map(function (k) {
            return '<a class="item" href="#/files/' + esc(k.id) + '">' + U.icoBox('file') + '<div class="grow"><h3>' + esc(k.label) + '</h3></div>' + (cnt[k.id] ? '<span class="tag">' + cnt[k.id] + '</span>' : '') + ic('chevron-left', 'chev') + '</a>'; }).join('') + '</section>' +
            (l.length ? '<section class="sec">' + U.sec('الأحدث') + l.slice(0, 3).map(function (x) { return fileCard(x, recs.length > 1); }).join('') + '</section>' : '');
        });
      }).catch(onErr(box));
    }, 0);
    return '<div class="alert info" style="margin-bottom:10px">' + ic('shield', 'sm') + '<div>هذه ملفاتك أنت فقط. لا تشاركها مع أحد.</div></div><div id="fl-box"><div class="skel" style="height:110px"></div></div>';
  }, { tab: 'none', title: 'ملفاتي', back: true });

  DS.route('/files/:kind', function (p) {
    if (!F.enabled()) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    var kind = p.kind, label = F.label(kind);
    setTimeout(function () {
      var box = DS.$('#fl-box'); if (!box) return;
      F.refresh().then(function (recs) {
        if (!recs.length) { box.innerHTML = noRecords(); return; }
        return loadFiles(kind, function (l) {
          box.innerHTML = l.length ? l.map(function (x) { return fileCard(x, recs.length > 1); }).join('')
            : U.empty('لا توجد ملفات في «' + label + '» حالياً. تظهر هنا فور رفعها من موظفي المجمع إلى ملفك.', 'file');
        });
      }).catch(onErr(box));
    }, 0);
    return '<div class="alert info" style="margin-bottom:10px">' + ic('shield', 'sm') + '<div>هذه ملفاتك أنت فقط. لا تشاركها مع أحد.</div></div><div id="fl-box"><div class="skel" style="height:110px"></div></div>';
  }, { tab: 'none', title: 'ملفاتي', back: true });

  function fetchPdf(id, dl) {
    return fetch(DS.api.url('/files/' + encodeURIComponent(id) + (dl ? '?dl=1' : '')), { headers: { 'Authorization': 'Bearer ' + A.token() }, cache: 'no-store' }).then(function (r) {
      if (r.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); throw new Error('login'); }
      if (!r.ok) throw new Error('تعذر فتح الملف الآن');
      return r.blob();
    });
  }
  DS.acts['fl-view'] = function (el) {
    var w = root.open('', '_blank');   // نفتح النافذة فوراً (قيد المتصفح على النوافذ بعد الطلب)
    fetchPdf(el.getAttribute('data-id'), false).then(function (b) {
      var u = URL.createObjectURL(b); if (w) w.location = u; else location.href = u;
      setTimeout(function () { URL.revokeObjectURL(u); }, 120000);
    }).catch(function (e) { if (w) w.close(); if (e.message !== 'login') DS.toast(e.message || 'تعذر فتح الملف'); });
    return false;
  };
  DS.acts['fl-dl'] = function (el) {
    fetchPdf(el.getAttribute('data-id'), true).then(function (b) {
      var u = URL.createObjectURL(b), a = document.createElement('a');
      a.href = u; a.download = (el.getAttribute('data-title') || 'document') + '.pdf'; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
    }).catch(function (e) { if (e.message !== 'login') DS.toast(e.message || 'تعذر تحميل الملف'); });
    return false;
  };
})(window);

/* حسابات المراجعين بكلمة مرور (الإصدار 0.11): إنشاء حساب بملف صحي معتاد، دخول، تعديل الملف، تغيير كلمة المرور.
   تفعّلها الإدارة من لوحة الإدارة (وإن فُعّل مزوّد الرسائل SMS حلّت طريقة الرمز محلها).
   لا تُحفَظ كلمة المرور ولا البيانات الصحية على الجهاز: تبقى في ذاكرة الصفحة أثناء التعبئة فقط، وتُرسَل مرة واحدة إلى الخادم،
   وتُمسح من الذاكرة بعد النجاح أو بمغادرة الصفحة. الملف الصحي لا يُرسَل إلى «قمر» ولا إلى أي مزوّد خارجي. */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, A = DS.auth, fld = A.fld;

  var BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  var RELS = ['أب', 'أم', 'زوج/ة', 'أخ/أخت', 'ابن/ابنة', 'قريب', 'صديق', 'أخرى'];
  var TITLES = ['بياناتك الأساسية', 'ملفك الصحي', 'الطوارئ والموافقة'];
  var STEP_OF = { phone: 1, name: 1, gender: 1, birthDate: 1, password: 1, password2: 1, bloodType: 2, allergies: 2, chronic: 2, medications: 2, surgeries: 2, pregnancy: 2,
    nationalId: 3, nationality: 3, city: 3, email: 3, emName: 3, emPhone: 3, emRelation: 3, insCompany: 3, insNo: 3, consentPrivacy: 3, consentHealth: 3 };

  function L() { return A.lists(); }
  function nextOf(q, d) { return q && q.next && q.next.charAt(0) === '#' ? q.next : (d || '#/'); }
  function latin(s) {
    return String(s == null ? '' : s).replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); }).replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); });
  }
  function trim(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
  function letters(s) { return (String(s).match(/[A-Za-zء-ي]/g) || []).length; }
  function box(kind, icon, html) { return '<div class="alert ' + kind + '" style="margin-bottom:10px">' + ic(icon, 'sm') + '<div>' + html + '</div></div>'; }
  function netMsg(e, d) { return e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || d; }
  function failBox(msg) { var f = DS.$('#au-fail'); if (f) f.innerHTML = msg ? box('danger', 'alert', esc(msg)) : ''; }
  function clinicPhone() { return D.mainPhone ? D.mainPhone() : ''; }
  function fmtAt(iso) {
    try { return new Date(iso).toLocaleDateString('ar-SA-u-nu-latn-ca-gregory', { timeZone: 'Asia/Riyadh', day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return ''; }
  }

  function clearErrs() {
    DS.$$('[data-err]').forEach(function (e) { e.hidden = true; e.textContent = ''; });
    DS.$$('.in.bad').forEach(function (e) { e.classList.remove('bad'); });
  }
  /* يعرض أخطاء الحقول (مفتاح الحقل → رسالة) ويمرّر إلى أولها؛ يعيد true إن وُجد حقل معروض */
  function showErrs(map) {
    clearErrs();
    var first = null;
    Object.keys(map || {}).forEach(function (k) {
      var e = DS.$('[data-err="a-' + k + '"]'), i = DS.$('#a-' + k);
      if (e) { e.textContent = map[k]; e.hidden = false; if (!first) first = e; }
      if (i && i.classList) i.classList.add('bad');
    });
    if (first && first.scrollIntoView) first.scrollIntoView({ block: 'center', behavior: 'smooth' });
    return !!first;
  }

  /* ---------- مكوّنات الحقول ---------- */
  function txt(k, v, o) {
    o = o || {};
    return '<input class="in' + (o.ltr ? ' ltr' : '') + '" id="a-' + k + '" data-k="' + k + '" type="' + (o.type || 'text') + '"' + (o.im ? ' inputmode="' + o.im + '"' : '') +
      ' autocomplete="' + (o.ac || 'off') + '" maxlength="' + (o.max || 60) + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.maxd ? ' max="' + o.maxd + '"' : '') +
      ' value="' + esc(v || '') + '">';
  }
  function opts(list, cur, ph) {
    return '<option value="">' + esc(ph) + '</option>' + list.map(function (o) {
      var id = typeof o === 'string' ? o : o.id, lb = typeof o === 'string' ? o : o.label;
      return '<option value="' + esc(id) + '"' + (id === cur ? ' selected' : '') + '>' + esc(lb) + '</option>';
    }).join('');
  }
  function sel(k, v, list, ph) { return '<select class="in" id="a-' + k + '" data-k="' + k + '">' + opts(list, v, ph) + '</select>'; }
  function pwBox(k, ac, val) {
    return '<div class="pwrow"><input class="in ltr" id="a-' + k + '" data-k="' + k + '" type="password" autocomplete="' + ac + '" maxlength="100" autocapitalize="off" autocorrect="off" spellcheck="false" value="' + esc(val || '') + '">' +
      '<button type="button" class="btn ghost sm" data-act="au-eye" data-for="a-' + k + '">إظهار</button></div>';
  }
  DS.acts['au-eye'] = function (el) {
    var i = DS.$('#' + el.getAttribute('data-for')); if (!i) return false;
    var show = i.type === 'password'; i.type = show ? 'text' : 'password'; el.textContent = show ? 'إخفاء' : 'إظهار';
    return false;
  };
  /* مجموعة أسئلة (نص + أخطاؤها) */
  function grp(k, label, inner, hint) {
    return '<div class="fld" role="group" aria-labelledby="gl-' + k + '"><label id="gl-' + k + '">' + label + '</label>' + inner + (hint ? '<div class="xs muted" style="margin-top:4px">' + hint + '</div>' : '') +
      '<div class="err" data-err="a-' + k + '" hidden></div></div>';
  }
  /* «لا يوجد» أو «نعم» + نص يظهر عند «نعم» */
  function ynBlock(k, v, no, yes, ph, max) {
    var cur = v[k];
    return '<div class="seg" style="grid-template-columns:1fr 1fr">' +
      '<input type="radio" name="a-' + k + '" id="a-' + k + '-no" data-k="' + k + '" value="none"' + (cur === 'none' ? ' checked' : '') + '><label for="a-' + k + '-no">' + esc(no) + '</label>' +
      '<input type="radio" name="a-' + k + '" id="a-' + k + '-yes" data-k="' + k + '" value="yes"' + (cur === 'yes' ? ' checked' : '') + '><label for="a-' + k + '-yes">' + esc(yes) + '</label></div>' +
      '<div id="sub-' + k + '" style="margin-top:8px"' + (cur === 'yes' ? '' : ' hidden') + '>' + txt(k + 'Text', v[k + 'Text'], { max: max, ph: ph }) + '</div>';
  }
  function chronicBlock(v) {
    var items = L().chronic || [];
    return '<div class="seg" style="grid-template-columns:1fr 1fr">' +
      '<input type="radio" name="a-chronic" id="a-chronic-no" data-k="chronic" value="none"' + (v.chronic === 'none' ? ' checked' : '') + '><label for="a-chronic-no">لا يوجد</label>' +
      '<input type="radio" name="a-chronic" id="a-chronic-yes" data-k="chronic" value="yes"' + (v.chronic === 'yes' ? ' checked' : '') + '><label for="a-chronic-yes">نعم، أحدّدها</label></div>' +
      '<div id="sub-chronic" style="margin-top:8px"' + (v.chronic === 'yes' ? '' : ' hidden') + '>' +
      items.map(function (c) {
        return '<label class="check" style="margin:8px 0"><input type="checkbox" data-chr="' + esc(c.id) + '"' + (v.chronicItems.indexOf(c.id) >= 0 ? ' checked' : '') + '><span>' + esc(c.label) + '</span></label>';
      }).join('') + '<div style="margin-top:8px">' + txt('chronicOther', v.chronicOther, { max: 100, ph: 'أمراض أخرى (اختياري)' }) + '</div></div>';
  }

  /* ---------- أقسام النموذج (مشتركة بين التسجيل وتعديل الملف) ---------- */
  function secHealth(v) {
    return box('info', 'shield', 'هذه المعلومات تساعد طبيبك على سلامتك. تُحفظ لدى المجمع فقط، ولا تُرسَل إلى «قمر» ولا إلى أي جهة أخرى.') +
      fld('a-bloodType', 'فصيلة الدم <span class="muted">(اختياري)</span>', sel('bloodType', v.bloodType, L().bloodTypes || BLOOD, 'لا أعرف')) +
      grp('allergies', 'هل لديك حساسية؟ (دواء أو طعام أو غيره) <span class="muted">*</span>', ynBlock('allergies', v, 'لا يوجد', 'نعم', 'اكتب ما تتحسس منه، مثال: بنسلين', 200)) +
      grp('chronic', 'أمراض مزمنة <span class="muted">*</span>', chronicBlock(v)) +
      grp('medications', 'أدوية تستخدمها حالياً <span class="muted">*</span>', ynBlock('medications', v, 'لا أستخدم', 'نعم', 'اكتب أسماء الأدوية وجرعاتها', 300)) +
      grp('surgeries', 'عمليات جراحية سابقة <span class="muted">(اختياري)</span>', ynBlock('surgeries', v, 'لا يوجد', 'نعم', 'اكتب العملية وسنتها', 300)) +
      (v.gender === 'female' ? fld('a-pregnancy', 'الحمل أو الرضاعة <span class="muted">(اختياري)</span>', sel('pregnancy', v.pregnancy, L().pregnancy || [{ id: 'no', label: 'لا' }, { id: 'pregnant', label: 'حامل' }, { id: 'breastfeeding', label: 'مرضعة' }], 'لم أحدد')) : '');
  }
  function secExtra(v, nidHint) {
    return '<h3 class="sh">بيانات إضافية <span class="muted">(اختيارية)</span></h3>' +
      fld('a-nationalId', 'رقم الهوية / الإقامة', txt('nationalId', v.nationalId, { ltr: 1, im: 'numeric', max: 10 }), nidHint || 'يساعد موظف المجمع على فتح ملفك أسرع.') +
      fld('a-nationality', 'الجنسية', txt('nationality', v.nationality, { max: 40, ph: 'مثال: سعودي' })) +
      fld('a-city', 'المدينة', txt('city', v.city, { max: 40, ph: 'مثال: المدينة المنورة' })) +
      fld('a-email', 'البريد الإلكتروني', txt('email', v.email, { ltr: 1, type: 'email', im: 'email', ac: 'email', max: 120 }));
  }
  function secEmergency(v) {
    return '<h3 class="sh">جهة اتصال للطوارئ <span class="muted">(اختيارية، ننصح بها)</span></h3>' +
      fld('a-emName', 'الاسم', txt('emName', v.emName, { max: 60 })) +
      fld('a-emRelation', 'صلة القرابة', sel('emRelation', v.emRelation, L().relations || RELS, 'اختر')) +
      fld('a-emPhone', 'رقم جوالها', txt('emPhone', v.emPhone, { ltr: 1, type: 'tel', im: 'tel', max: 20, ph: '05xxxxxxxx' }));
  }
  function secInsurance(v) {
    return '<h3 class="sh">التأمين الصحي <span class="muted">(اختياري)</span></h3>' +
      fld('a-insCompany', 'شركة التأمين', txt('insCompany', v.insCompany, { max: 60 })) +
      fld('a-insNo', 'رقم العضوية', txt('insNo', v.insNo, { ltr: 1, max: 30 }));
  }
  function secConsent(v) {
    return '<h3 class="sh">الموافقة</h3>' +
      '<details class="card" style="margin-bottom:10px;padding:10px 14px"><summary style="font-weight:700;cursor:pointer">كيف نحفظ بياناتك؟</summary><p class="sm" style="margin-top:8px">' + esc(DS.privacyPw || '') + '</p></details>' +
      '<div class="fld"><label class="check" for="a-consentPrivacy"><input type="checkbox" id="a-consentPrivacy" data-k="consentPrivacy"' + (v.consentPrivacy ? ' checked' : '') + '><span>قرأت <a href="#/privacy">سياسة الخصوصية</a> وأوافق عليها.</span></label><div class="err" data-err="a-consentPrivacy" hidden></div></div>' +
      '<div class="fld"><label class="check" for="a-consentHealth"><input type="checkbox" id="a-consentHealth" data-k="consentHealth"' + (v.consentHealth ? ' checked' : '') + '><span>أوافق صراحةً على حفظ بياناتي الصحية لدى المجمع، واطلاع الكادر الطبي المخوَّل عليها لتجهيز زيارتي وسلامتي الطبية.</span></label><div class="err" data-err="a-consentHealth" hidden></div></div>';
  }

  /* ---------- القيم والتحقق وبناء الطلب ---------- */
  function blank() {
    return { name: '', phone: '', gender: '', birthDate: '', password: '', password2: '', nationalId: '', nationality: '', city: '', email: '', bloodType: '',
      allergies: '', allergiesText: '', chronic: '', chronicItems: [], chronicOther: '', medications: '', medicationsText: '', surgeries: '', surgeriesText: '', pregnancy: '',
      emName: '', emRelation: '', emPhone: '', insCompany: '', insNo: '', consentPrivacy: false, consentHealth: false };
  }
  function vFrom(pt, prof) {
    prof = prof || {};
    var h = prof.health || {}, em = prof.emergency || {}, ins = prof.insurance || {}, al = h.allergies || {}, ch = h.chronic || {}, md = h.medications || {}, su = h.surgeries || {};
    function ynv(o) { return o.none === true ? 'none' : (o.none === false ? 'yes' : ''); }
    var v = blank();
    v.name = pt.name || ''; v.phone = A.local(pt.phone); v.gender = pt.gender || ''; v.birthDate = pt.birthDate || '';
    v.nationality = prof.nationality || ''; v.city = prof.city || ''; v.email = prof.email || '';
    v.bloodType = h.bloodType || ''; v.allergies = ynv(al); v.allergiesText = al.text || '';
    v.chronic = ch.none === true ? 'none' : (ch.none === false ? 'yes' : ''); v.chronicItems = (ch.items || []).slice(); v.chronicOther = ch.other || '';
    v.medications = ynv(md); v.medicationsText = md.text || ''; v.surgeries = ynv(su); v.surgeriesText = su.text || ''; v.pregnancy = h.pregnancy || '';
    v.emName = em.name || ''; v.emRelation = em.relation || ''; v.emPhone = em.phone ? A.local(em.phone) : '';
    v.insCompany = ins.company || ''; v.insNo = ins.memberNo || '';
    return v;
  }
  function yn(v, k) { return v[k] === 'none' ? { none: true, text: '' } : (v[k] === 'yes' ? { none: false, text: trim(v[k + 'Text']) } : {}); }
  function profileOf(v) {
    var any = trim(v.emName) || v.emRelation || trim(v.emPhone), ins = trim(v.insCompany) || trim(v.insNo);
    return {
      nationality: trim(v.nationality), city: trim(v.city), email: trim(v.email),
      emergency: any ? { name: trim(v.emName), relation: v.emRelation, phone: latin(v.emPhone) } : {},
      health: {
        bloodType: v.bloodType, allergies: yn(v, 'allergies'), medications: yn(v, 'medications'), surgeries: yn(v, 'surgeries'),
        chronic: v.chronic === 'none' ? { none: true, items: [], other: '' } : (v.chronic === 'yes' ? { none: false, items: v.chronicItems.slice(), other: trim(v.chronicOther) } : {}),
        pregnancy: v.gender === 'female' ? v.pregnancy : ''
      },
      insurance: ins ? { company: trim(v.insCompany), memberNo: trim(v.insNo) } : {}
    };
  }
  function pwProblem(pw) {
    if (!pw) return 'أدخل كلمة المرور';
    if (pw.length < 8) return 'كلمة المرور 8 أحرف على الأقل';
    if (pw.length > 100) return 'كلمة المرور طويلة (100 حرف كحد أقصى)';
    if (pw !== pw.trim()) return 'أزل المسافات من أول كلمة المرور وآخرها';
    if (/^\d+$/.test(latin(pw))) return 'لا تجعل كلمة المرور أرقاماً فقط، أضف إليها حروفاً';
    return '';
  }
  function vPersonal(v) {
    var e = {}, nm = trim(v.name);
    if (nm.length < 2 || letters(nm) < 2) e.name = 'اكتب الاسم (حرفان على الأقل)';
    if (v.gender !== 'male' && v.gender !== 'female') e.gender = 'اختر الجنس';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v.birthDate) || v.birthDate > DS.riyadhToday(0) || v.birthDate < '1900-01-01') e.birthDate = 'تاريخ الميلاد غير صحيح';
    return e;
  }
  function v1(v) {
    var e = vPersonal(v), ph = DS.normPhone(v.phone);
    if (!ph || ph.slice(0, 4) !== '9665') e.phone = 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)';
    var pe = pwProblem(v.password);
    if (pe) e.password = pe; else if (v.password2 !== v.password) e.password2 = 'كلمتا المرور غير متطابقتين';
    return e;
  }
  function v2(v) {
    var e = {};
    if (!v.allergies) e.allergies = 'اختر «لا يوجد» أو «نعم» واكتب ما تتحسس منه';
    else if (v.allergies === 'yes' && trim(v.allergiesText).length < 2) e.allergies = 'اكتب ما تتحسس منه';
    if (!v.chronic) e.chronic = 'اختر «لا يوجد» أو حدّد الأمراض المزمنة';
    else if (v.chronic === 'yes' && !v.chronicItems.length && trim(v.chronicOther).length < 2) e.chronic = 'حدّد مرضاً واحداً على الأقل أو اكتبه';
    if (!v.medications) e.medications = 'اختر «لا أستخدم» أو «نعم» واكتب الأدوية';
    else if (v.medications === 'yes' && trim(v.medicationsText).length < 2) e.medications = 'اكتب أسماء الأدوية';
    if (v.surgeries === 'yes' && trim(v.surgeriesText).length < 2) e.surgeries = 'اكتب العملية أو اختر «لا يوجد»';
    return e;
  }
  function v3(v, needConsent) {
    var e = {}, nid = latin(v.nationalId).replace(/\D/g, ''), em = trim(v.email);
    if (nid && !/^[12]\d{9}$/.test(nid)) e.nationalId = 'رقم الهوية/الإقامة 10 أرقام يبدأ بـ 1 أو 2 (أو اتركه فارغاً)';
    if (em && !/^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s.]{2,}$/.test(em)) e.email = 'البريد الإلكتروني غير صحيح';
    if (trim(v.emName) || v.emRelation || trim(v.emPhone)) {
      if (trim(v.emName).length < 2 || letters(v.emName) < 2) e.emName = 'اكتب اسم جهة الاتصال';
      var ep = DS.normPhone(v.emPhone); if (!ep || ep.slice(0, 4) !== '9665') e.emPhone = 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)';
      if (!v.emRelation) e.emRelation = 'اختر صلة القرابة';
    }
    if (trim(v.insNo) || trim(v.insCompany)) {
      if (trim(v.insCompany).length < 2) e.insCompany = 'اكتب اسم شركة التأمين';
      if (trim(v.insNo) && !/^[A-Za-z0-9\-/ ]{3,30}$/.test(trim(v.insNo))) e.insNo = 'رقم العضوية: أحرف إنجليزية وأرقام فقط (3 إلى 30)';
    }
    if (needConsent) {
      if (!v.consentPrivacy) e.consentPrivacy = 'يجب الموافقة على سياسة الخصوصية';
      if (!v.consentHealth) e.consentHealth = 'يجب الموافقة على حفظ بياناتك الصحية لدى المجمع';
    }
    return e;
  }
  function firstStep(errs) {
    var s = 9; Object.keys(errs).forEach(function (k) { s = Math.min(s, STEP_OF[k] || 3); }); return s === 9 ? 1 : s;
  }

  /* ---------- محرّك النموذج: يحدّث قيم الحالة الحالية أولاً بأول (لا تُحفظ إلا في ذاكرة الصفحة) ---------- */
  var cur = null;       // الحالة التي تُحدَّث الآن: {v: القيم}
  function applyField(t) {
    var k = t.getAttribute('data-k'); if (!k || !cur) return;
    if (t.type === 'checkbox') cur.v[k] = t.checked; else if (t.type === 'radio') { if (t.checked) cur.v[k] = t.value; } else cur.v[k] = t.value;
  }
  function syncFromDom(scope) {
    DS.$$('[data-k]', scope).forEach(applyField);      // يلتقط ما ملأه التعبئة التلقائية بلا أحداث
    if (DS.$('[data-chr]', scope)) cur.v.chronicItems = DS.$$('[data-chr]', scope).filter(function (c) { return c.checked; }).map(function (c) { return c.getAttribute('data-chr'); });
  }
  function onField(ev) {
    var t = ev.target; if (!t || !t.getAttribute || !cur) return;
    var c = t.getAttribute('data-chr');
    if (c) { var a = cur.v.chronicItems, i = a.indexOf(c); if (t.checked && i < 0) a.push(c); else if (!t.checked && i >= 0) a.splice(i, 1); return; }
    var k = t.getAttribute('data-k'); if (!k) return;
    applyField(t);
    if (t.classList) t.classList.remove('bad');
    var er = DS.$('[data-err="a-' + k + '"]'); if (er) er.hidden = true;
    if (t.type === 'radio') { var sub = DS.$('#sub-' + k); if (sub) sub.hidden = t.value !== 'yes'; }
  }
  function bindForm(rootEl, state) {
    cur = state;
    if (rootEl.getAttribute('data-bound')) return;        // الصفحة نفسها قد تُعاد رسمتها: لا نكرّر المستمعين
    rootEl.setAttribute('data-bound', '1');
    rootEl.addEventListener('input', onField);
    rootEl.addEventListener('change', onField);
  }

  /* ---------- مرحلة ما بعد الدخول أو التسجيل ---------- */
  function afterAuth(d, next, msg) {
    A.set(d.token, d.patient);
    DS.store.set('profile', { name: d.patient.name, phone: A.local(d.patient.phone) });
    if (d.mustChange) DS.store.set('mustChange', true); else DS.store.del('mustChange');
    DS.store.del('myBookings'); DS.store.del('notifCache');      // لا نعرض بيانات مستخدم سابق ريثما تصل بيانات هذا الحساب
    DS.toast(msg);
    location.replace(d.mustChange ? '#/password?next=' + encodeURIComponent(next) : next);
  }
  function notReady(re) {
    if (!DS.cfg.demo && D.source === 'seed' && !A.waited2) {      // أول فتح قبل وصول إعدادات الخادم: ننتظرها قليلاً قبل العودة للرئيسية
      A.waited2 = true;
      setTimeout(function () { if (!A.pw() && re.test(location.hash)) location.replace('#/'); }, 6000);
      return '<div class="card"><p class="sm muted">جارٍ التحميل…</p></div>';
    }
    setTimeout(function () { location.replace('#/'); }, 0);
    return '';
  }
  function savedBanner(next) {
    var saved = next.indexOf('#/book') === 0 && DS.bkDraft ? DS.bkDraft.line() : '';
    return saved ? '<div class="alert info" style="margin:8px 0 10px">' + ic('check', 'sm') + '<div><b>حجزك محفوظ:</b> ' + esc(saved) + '<div class="xs">بعد الدخول أو إنشاء الحساب تعود إليه تلقائياً.</div></div></div>' : '';
  }

  /* ================= تسجيل الدخول ================= */
  A.pwLogin = function (q) {
    var next = nextOf(q), toBook = next.indexOf('#/book') === 0, ph = clinicPhone();
    var html = '<div id="au-root"><div class="card"><h2 style="font-weight:800;font-size:1.1rem">' + (toBook ? 'سجّل دخولك لتأكيد الحجز' : 'تسجيل الدخول') + '</h2>' + savedBanner(next) +
      '<p class="sm muted" style="margin:4px 0 12px">' + (toBook ? 'أدخل جوالك وكلمة المرور. وإن كانت أول مرة فأنشئ حساباً: نسجّل بياناتك الطبية لمرة واحدة فقط.' : 'تصفّح التطبيق بحرية. الحساب مطلوب عند طلب الحجز.') + '</p>' +
      '<form id="au-login" class="form" novalidate>' +
      fld('a-phone', 'رقم الجوال', '<input class="in ltr" id="a-phone" type="tel" inputmode="tel" autocomplete="username" maxlength="20" placeholder="05xxxxxxxx">') +
      fld('a-password', 'كلمة المرور', pwBox('password', 'current-password', '')) +
      '<div id="au-fail"></div><button class="btn pri blk" type="submit">دخول</button></form>' +
      '<button class="btn ghost blk" type="button" data-act="au-forgot" style="margin-top:8px">نسيت كلمة المرور؟</button>' +
      '<div id="au-forgot" hidden>' + box('info', 'info', 'لإعادة تعيين كلمة المرور تواصل مع المجمع' + (ph ? ' على <span class="ltr" style="display:inline-block">' + esc(ph) + '</span>' : '') +
        '. يُعطيك الموظف كلمة مرور مؤقتة، وتختار كلمتك الخاصة عند أول دخول.') + (ph ? '<a class="btn out blk" href="' + esc(DS.telHref(ph)) + '">' + ic('phone', 'sm') + 'اتصل بالمجمع</a>' : '') + '</div>' +
      '<div style="border-top:1px solid var(--line);margin:16px 0 12px"></div><p class="sm muted" style="margin-bottom:8px">ليس لديك حساب؟</p>' +
      '<a class="btn out blk" href="#/register?next=' + encodeURIComponent(next) + '">إنشاء حساب جديد</a>' +
      (toBook ? '<a class="btn ghost blk" style="margin-top:8px" href="#/book?resume=1">العودة إلى الحجز</a>' : '') + '</div></div>';
    setTimeout(function () {
      var f = DS.$('#au-login'); if (!f) return;
      f.addEventListener('submit', function (ev) {
        ev.preventDefault(); failBox(''); clearErrs();
        var phone = DS.normPhone(DS.$('#a-phone').value.trim()), pw = DS.$('#a-password').value, bad = {};
        if (!phone || phone.slice(0, 4) !== '9665') bad.phone = 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)';
        if (!pw) bad.password = 'أدخل كلمة المرور';
        if (showErrs(bad)) return;
        var btn = f.querySelector('button[type=submit]'); btn.disabled = true;
        DS.api.post('/auth/login', { phone: phone, password: pw }, { timeout: 15000 }).then(function (r) {
          afterAuth(r.data, next, 'تم تسجيل الدخول'); if (DS.files && DS.files.refresh) DS.files.refresh();
        }).catch(function (e) {
          btn.disabled = false;
          if (e && e.status === 422 && e.fields && showErrs(e.fields)) return;
          failBox(netMsg(e, 'تعذر تسجيل الدخول الآن.'));
        });
      });
    }, 0);
    return html;
  };
  DS.acts['au-forgot'] = function () { var b = DS.$('#au-forgot'); if (b) b.hidden = !b.hidden; return false; };

  /* ================= إنشاء حساب (3 خطوات) ================= */
  var R = null;     // حالة التسجيل في الذاكرة فقط: تبقى عند فتح «سياسة الخصوصية» والعودة، وتُمسح بمغادرة الصفحة أو بالنجاح
  root.addEventListener('hashchange', function () { if (R && !/^#\/(register|privacy)/.test(root.location.hash || '')) R = null; });

  function navHtml(s, next) {
    if (s === 1) return '<button class="btn pri blk" type="submit">التالي</button><p class="sm muted" style="text-align:center;margin-top:12px">لديك حساب؟ <a href="#/login?next=' + encodeURIComponent(next) + '">سجّل دخولك</a></p>';
    return '<div class="grid2" style="margin-top:6px"><button class="btn out" type="button" data-act="rg-prev">السابق</button>' +
      '<button class="btn pri" type="submit">' + (s === 3 ? 'إنشاء الحساب' : 'التالي') + '</button></div>';
  }
  function paintReg() {
    var body = DS.$('#rg-body'); if (!body || !R) return;
    var s = R.step, v = R.v, errs = R.errs || {};
    R.t = Date.now();
    DS.$$('#rg-steps i').forEach(function (i, n) { i.className = n < s ? 'on' : ''; });
    body.innerHTML = '<form id="rg-form" class="form" novalidate><h3 class="sh" style="margin:0">الخطوة ' + s + ' من 3 · ' + TITLES[s - 1] + '</h3>' +
      (R.exists ? box('warn', 'info', 'هذا الرقم مسجّل مسبقاً. <a href="#/login?next=' + encodeURIComponent(R.next) + '"><b>سجّل دخولك</b></a> بكلمة مرورك، أو تواصل مع المجمع إن نسيتها.') : '') +
      (s === 1 ? '<p class="sm muted" style="margin:0 0 12px">نسجّل بياناتك مرة واحدة، وبعدها تحجز بجوالك وكلمة المرور دون إعادة كتابتها.</p>' +
        fld('a-name', 'الاسم الكامل <span class="muted">*</span>', txt('name', v.name, { ac: 'name', max: 60 })) +
        fld('a-phone', 'رقم الجوال <span class="muted">*</span>', txt('phone', v.phone, { ltr: 1, type: 'tel', im: 'tel', ac: 'username', max: 20, ph: '05xxxxxxxx' }), 'هو اسم المستخدم لدخولك.') +
        fld('a-gender', 'الجنس <span class="muted">*</span>', sel('gender', v.gender, [{ id: 'male', label: 'ذكر' }, { id: 'female', label: 'أنثى' }], 'اختر')) +
        fld('a-birthDate', 'تاريخ الميلاد <span class="muted">*</span>', txt('birthDate', v.birthDate, { ltr: 1, type: 'date', maxd: DS.riyadhToday(0), ac: 'bday' })) +
        fld('a-password', 'كلمة المرور <span class="muted">*</span>', pwBox('password', 'new-password', v.password), '8 أحرف على الأقل، وليست أرقاماً فقط.') +
        fld('a-password2', 'تأكيد كلمة المرور <span class="muted">*</span>', pwBox('password2', 'new-password', v.password2))
        : s === 2 ? secHealth(v) : secExtra(v) + secEmergency(v) + secInsurance(v) + secConsent(v)) +
      '<div id="au-fail"></div>' + navHtml(s, R.next) + '</form>';
    if (Object.keys(errs).length) showErrs(errs);
    if (R.note) { failBox(R.note); R.note = ''; }
  }
  function goReg(step) { R.step = step; paintReg(); root.scrollTo(0, 0); }
  DS.acts['rg-prev'] = function () { if (R && R.step > 1) { syncFromDom(DS.$('#rg-form')); R.errs = {}; R.exists = false; goReg(R.step - 1); } return false; };

  function submitReg() {
    syncFromDom(DS.$('#rg-form'));
    var v = R.v;
    if (R.step < 3) {
      var e = R.step === 1 ? v1(v) : v2(v);
      R.exists = false;
      if (Object.keys(e).length) { R.errs = e; paintReg(); return; }
      R.errs = {}; goReg(R.step + 1); return;
    }
    var e3 = v3(v, true);
    if (Object.keys(e3).length) { R.errs = e3; paintReg(); return; }
    var all = {}; [v1(v), v2(v)].forEach(function (m) { Object.keys(m).forEach(function (k) { all[k] = m[k]; }); });
    if (Object.keys(all).length) { R.errs = all; goReg(firstStep(all)); return; }       // لا يحدث عادةً: كل خطوة فُحصت قبل التقدّم
    var btn = DS.$('#rg-form button[type=submit]'); if (btn) btn.disabled = true; failBox('');
    var body = { phone: DS.normPhone(v.phone), name: trim(v.name), gender: v.gender, birthDate: v.birthDate, nationalId: latin(v.nationalId).replace(/\D/g, ''),
      password: v.password, password2: v.password2, profile: profileOf(v), consent: { privacy: !!v.consentPrivacy, health: !!v.consentHealth } };
    DS.api.post('/auth/register', body, { timeout: 25000 }).then(function (r) {
      var next = R ? R.next : '#/'; R = null; cur = null;       // نمسح كلمة المرور والبيانات الصحية من ذاكرة الصفحة
      afterAuth(r.data, next, 'تم إنشاء حسابك');
    }).catch(function (e) {
      if (!R) return;                                            // غادر المراجع الصفحة أثناء الإرسال
      if (btn) btn.disabled = false;
      if (e && e.code === 'phone_exists') { R.exists = true; R.errs = { phone: 'مسجّل مسبقاً' }; goReg(1); return; }
      if (e && e.status === 422 && e.fields && Object.keys(e.fields).length) {
        var f = {}; Object.keys(e.fields).forEach(function (k) { f[k] = e.fields[k]; });
        R.errs = f; R.note = 'راجع الحقول المظلّلة وصحّحها.'; goReg(firstStep(f)); return;
      }
      failBox(netMsg(e, 'تعذر إنشاء الحساب الآن. لم يُحفظ شيء، حاول مرة أخرى.'));
    });
  }

  DS.route('/register', function (p, q) {
    if (!A.pw()) { if (A.enabled()) { setTimeout(function () { location.replace('#/login?next=' + encodeURIComponent(nextOf(q))); }, 0); return ''; } return notReady(/^#\/register/); }
    var next = nextOf(q);
    if (A.token()) { setTimeout(function () { location.replace(next); }, 0); return ''; }
    if (!R || Date.now() - R.t > 30 * 60000) R = { step: 1, v: blank(), errs: {}, t: Date.now() };
    R.next = next;
    setTimeout(function () {
      var rootEl = DS.$('#au-root'); if (!rootEl) return;
      bindForm(rootEl, R);
      rootEl.addEventListener('submit', function (ev) { ev.preventDefault(); if (R) submitReg(); });
      paintReg();
    }, 0);
    return '<div id="au-root"><div class="card"><h2 style="font-weight:800;font-size:1.1rem">إنشاء حساب جديد</h2>' + savedBanner(next) +
      '<div class="steps" id="rg-steps" style="margin-top:10px"><i></i><i></i><i></i></div><div id="rg-body"></div></div></div>';
  }, { tab: 'none', title: 'إنشاء حساب', back: true });

  /* ================= ملفي الصحي والشخصي (عرض وتعديل) ================= */
  var E = null;
  DS.route('/account', function () {
    if (!A.pw()) { setTimeout(function () { location.replace('#/profile'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    setTimeout(loadAccount, 0);
    return '<div id="au-root"><div class="skel" style="height:160px"></div></div>';
  }, { tab: 'none', title: 'ملفي الصحي والشخصي', back: true });

  function loadAccount() {
    var rootEl = DS.$('#au-root'); if (!rootEl) return;
    DS.api.get('/auth/me', { timeout: 12000 }).then(function (r) {
      var d = r.data; A.set(A.token(), d.patient);
      E = { v: vFrom(d.patient, d.profile), consent: d.consent, hasNid: !!d.patient.hasNationalId, phone: d.patient.phone };
      bindForm(rootEl, E);
      rootEl.addEventListener('submit', function (ev) { ev.preventDefault(); if (E) saveAccount(); });
      paintAccount();
    }).catch(function (e) {
      if (e && e.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent('#/account')); return; }
      rootEl.innerHTML = box('danger', 'alert', esc(netMsg(e, 'تعذر تحميل ملفك الآن. تحقق من الاتصال وحاول لاحقاً.')));
    });
  }
  function paintAccount(msg) {
    var rootEl = DS.$('#au-root'); if (!rootEl || !E) return;
    var v = E.v;
    rootEl.innerHTML = '<div class="card"><h2 style="font-weight:800;font-size:1.1rem">ملفي الصحي والشخصي</h2>' +
      '<p class="sm muted" style="margin:4px 0 4px">رقم الجوال: <span class="ltr" style="display:inline-block">' + esc(A.local(E.phone)) + '</span> — لا يُعدَّل من هنا، وللتغيير تواصل مع المجمع.</p>' +
      (E.consent ? '<p class="xs muted">وافقت على سياسة الخصوصية وحفظ بياناتك الصحية بتاريخ ' + esc(fmtAt(E.consent.at)) + '.</p>' : '') +
      (msg ? box('ok', 'check', esc(msg)) : '') +
      '<form id="ac-form" class="form" novalidate><h3 class="sh">البيانات الشخصية</h3>' +
      fld('a-name', 'الاسم الكامل', txt('name', v.name, { ac: 'name', max: 60 })) +
      fld('a-gender', 'الجنس', sel('gender', v.gender, [{ id: 'male', label: 'ذكر' }, { id: 'female', label: 'أنثى' }], 'اختر')) +
      fld('a-birthDate', 'تاريخ الميلاد', txt('birthDate', v.birthDate, { ltr: 1, type: 'date', maxd: DS.riyadhToday(0), ac: 'bday' })) +
      '<h3 class="sh">الملف الصحي</h3>' + secHealth(v) +
      secExtra(v, E.hasNid ? 'رقمك محفوظ لدينا. اتركه فارغاً للإبقاء عليه، أو اكتب رقماً جديداً لتغييره.' : '') + secEmergency(v) + secInsurance(v) +
      (E.consent ? '' : secConsent(v)) +
      '<div id="au-fail"></div><button class="btn pri blk" type="submit">حفظ التعديلات</button></form></div>' +
      '<p style="margin-top:12px"><a class="btn ghost blk" href="#/profile">رجوع إلى حسابي</a></p>';
  }
  function saveAccount() {
    syncFromDom(DS.$('#ac-form'));
    var v = E.v, e = vPersonal(v), e2 = v2(v), e3 = v3(v, !E.consent);
    [e2, e3].forEach(function (m) { Object.keys(m).forEach(function (k) { e[k] = m[k]; }); });
    failBox('');
    if (showErrs(e)) return;
    var btn = DS.$('#ac-form button[type=submit]'); if (btn) btn.disabled = true;
    var body = { name: trim(v.name), gender: v.gender, birthDate: v.birthDate, nationalId: latin(v.nationalId).replace(/\D/g, ''), profile: profileOf(v) };
    if (!E.consent) body.consent = { privacy: !!v.consentPrivacy, health: !!v.consentHealth };
    DS.api.post('/auth/me', body, { timeout: 20000 }).then(function (r) {
      var d = r.data; A.set(A.token(), d.patient); DS.store.set('profile', { name: d.patient.name, phone: A.local(d.patient.phone) });
      E = { v: vFrom(d.patient, d.profile), consent: d.consent, hasNid: !!d.patient.hasNationalId, phone: d.patient.phone };
      bindForm(DS.$('#au-root'), E);
      paintAccount('تم حفظ التعديلات.'); root.scrollTo(0, 0);
    }).catch(function (er) {
      if (btn) btn.disabled = false;
      if (er && er.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent('#/account')); return; }
      if (er && er.status === 422 && er.fields && showErrs(er.fields)) { failBox('راجع الحقول المظلّلة وصحّحها.'); return; }
      failBox(netMsg(er, 'تعذر حفظ التعديلات الآن، حاول مرة أخرى.'));
    });
  }

  /* ================= تغيير كلمة المرور ================= */
  DS.route('/password', function (p, q) {
    if (!A.pw()) { setTimeout(function () { location.replace('#/profile'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    var next = nextOf(q, '#/profile'), forced = A.mustChange();
    setTimeout(function () {
      var f = DS.$('#pw-form'); if (!f) return;
      f.addEventListener('submit', function (ev) {
        ev.preventDefault(); failBox(''); clearErrs();
        var cu = DS.$('#a-current').value, nw = DS.$('#a-new').value, n2 = DS.$('#a-new2').value, bad = {};
        if (!cu) bad.current = 'أدخل كلمة المرور الحالية';
        var pe = pwProblem(nw); if (pe) bad.new = pe; else if (nw === cu) bad.new = 'اختر كلمة مرور مختلفة عن الحالية'; else if (n2 !== nw) bad.new2 = 'كلمتا المرور غير متطابقتين';
        if (showErrs(bad)) return;
        var btn = f.querySelector('button[type=submit]'); btn.disabled = true;
        DS.api.post('/auth/password', { current: cu, new: nw }, { timeout: 20000 }).then(function (r) {
          A.set(r.data.token, A.patient()); DS.store.del('mustChange');
          DS.toast('تم تغيير كلمة المرور'); location.replace(next);
        }).catch(function (e) {
          btn.disabled = false;
          if (e && e.status === 401 && e.code !== 'bad_password') { A.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); return; }
          if (e && e.fields && showErrs(e.fields)) return;
          failBox(netMsg(e, 'تعذر تغيير كلمة المرور الآن.'));
        });
      });
    }, 0);
    return '<div id="au-root"><div class="card"><h2 style="font-weight:800;font-size:1.1rem">' + (forced ? 'اختر كلمة مرور جديدة' : 'تغيير كلمة المرور') + '</h2>' +
      (forced ? box('warn', 'info', 'كلمة مرورك الحالية مؤقتة أصدرها المجمع. اختر كلمة مرور خاصة بك لتتمكن من الحجز.') : '') +
      '<form id="pw-form" class="form" novalidate>' +
      fld('a-current', 'كلمة المرور ' + (forced ? 'المؤقتة' : 'الحالية'), pwBox('current', 'current-password', '')) +
      fld('a-new', 'كلمة المرور الجديدة', pwBox('new', 'new-password', ''), '8 أحرف على الأقل، وليست أرقاماً فقط.') +
      fld('a-new2', 'تأكيد كلمة المرور الجديدة', pwBox('new2', 'new-password', '')) +
      '<p class="xs muted">بعد التغيير تنتهي جلساتك على الأجهزة الأخرى ويلزم الدخول فيها من جديد.</p>' +
      '<div id="au-fail"></div><button class="btn pri blk" type="submit">حفظ كلمة المرور</button></form></div></div>';
  }, { tab: 'none', title: 'كلمة المرور', back: true });

  /* ================= بطاقة «حسابي» في صفحة طلباتي ================= */
  A.pwCard = function () {
    var p = A.patient();
    if (!p) return '<div class="card row" style="margin-bottom:10px"><span class="ico-box">' + ic('user') + '</span><div class="grow"><b>حسابي</b><p class="sm muted">سجّل دخولك أو أنشئ حساباً لتتمكن من إرسال طلبات الحجز.</p></div>' +
      '<a class="btn pri sm" href="#/login?next=' + encodeURIComponent('#/profile') + '">دخول</a></div>';
    return '<div class="card" style="margin-bottom:10px"><b>حسابي</b><p class="sm" style="margin:6px 0"><span>' + esc(p.name) + '</span> · <span class="ltr">' + esc(A.local(p.phone)) + '</span></p>' +
      (A.mustChange() ? box('warn', 'alert', 'كلمة مرورك مؤقتة. <a href="#/password?next=' + encodeURIComponent('#/profile') + '"><b>غيّرها الآن</b></a> لتتمكن من الحجز.') : '') +
      '<div class="grid2"><a class="btn out sm" href="#/account">ملفي الصحي</a><a class="btn out sm" href="#/password?next=' + encodeURIComponent('#/profile') + '">كلمة المرور</a></div>' +
      '<div class="grid2" style="margin-top:8px"><button class="btn out sm" data-act="au-logout">تسجيل الخروج</button>' +
      '<button class="btn out sm" style="color:var(--danger);border-color:var(--danger)" data-act="au-delete">حذف حسابي</button></div></div>';
  };
})(window);
