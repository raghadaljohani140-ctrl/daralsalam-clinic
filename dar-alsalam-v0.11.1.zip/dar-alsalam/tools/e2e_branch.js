/* اختبار «الفرع قبل الطبيب» وتنبيه الدوام وإجابة قمر عن فرع الطبيب (0.11.1) بمتصفح حقيقي وخادم مؤقت (:8096، لا يمسّ أي خادم آخر):
     دوام الأطباء بأمر الإدارة الحقيقي `manage.py sched-standard --yes` (كلهم فرع قباء) ثم تُنقل الإدارة طبيباً إلى فرع التلال وآخر يداوم في الفرعين
     ← صفحة الحجز: الفرع قبل الطبيب ← اختيار الفرع يُظهر أطباءه فقط ويُنبّه ← اختيار طبيب يُظهر فرعه وأيام عمله وساعاته
     ← فرع بلا أطباء للتخصص يُقال صراحة ← الطبيب العام «على مدار 24 ساعة» ← قمر يجيب عن فرع الطبيب من الجدول (لا يخترع)
   NODE_PATH=<playwright> node tools/e2e_branch.js     بيانات تجريبية فقط. اللقطات في qa/shots/b*.png */
const { chromium } = require('playwright');
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SHOTS = path.join(ROOT, 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
const PW = 'devpass-12345', PORT = 8096, base = 'http://127.0.0.1:' + PORT;
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function http(method, p, body, token) {
  const h = { Accept: 'application/json' };
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(base + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(() => ({})) };
}

(async () => {
  const dir = '/tmp/ds-branch';
  execSync('rm -rf ' + dir + ' && mkdir -p ' + dir);
  const env = Object.assign({}, process.env, { DS_DB: dir + '/clinic.db', DS_PORT: String(PORT), DS_QUIET: '1' });
  execSync('python3 ' + ROOT + '/server/manage.py init --password ' + PW, { env, stdio: 'ignore' });
  execSync('python3 ' + ROOT + '/server/manage.py sched-standard --yes', { env, stdio: 'ignore' });
  const proc = spawn('python3', [ROOT + '/server/app.py'], { env, stdio: 'ignore' });
  for (let i = 0; i < 40; i++) { try { const r = await fetch(base + '/api/v1/health'); if (r.ok) break; } catch (e) { /* انتظر */ } await sleep(300); }
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  try {
    const AT = (await http('POST', '/api/admin/login', { password: PW })).body.token;
    const ds = (await http('GET', '/api/v1/clinic')).body;
    const dental = ds.doctors.filter((d) => (d.specialtyIds || []).includes('dental')).map((d) => d.id);
    const gp = ds.doctors.find((d) => (d.specialtyIds || []).includes('general')).id;
    const name = (id) => ds.doctors.find((d) => d.id === id).name;
    const shifts = (br, days) => days.flatMap((w) => [{ branchId: br, weekday: w, start: '09:00', end: '12:30', slot: 30 }, { branchId: br, weekday: w, start: '16:00', end: '22:00', slot: 30 }]);
    const ALL = [0, 1, 2, 3, 4, 5, 6];
    ok(dental.length === 3 && ds.meta.hours && Object.keys(ds.meta.hours).length === 27, 'البيانات العامة تحمل ساعات الأطباء الـ27');
    // الطبيب الأول ينتقل إلى التلال، والثاني: صباحاً في قباء ومساءً في التلال
    ok((await http('PUT', '/api/admin/schedules/' + dental[0], { rows: shifts('talal', ALL), days: [] }, AT)).status === 200, 'الإدارة تنقل طبيباً إلى فرع التلال');
    const mixed = ALL.flatMap((w) => [{ branchId: 'quba', weekday: w, start: '09:00', end: '12:30', slot: 30 }, { branchId: 'talal', weekday: w, start: '16:00', end: '22:00', slot: 30 }]);
    ok((await http('PUT', '/api/admin/schedules/' + dental[1], { rows: mixed, days: [] }, AT)).status === 200, 'وطبيباً آخر يداوم في الفرعين');
    const ds2 = (await http('GET', '/api/v1/clinic')).body;
    ok(ds2.meta.hours[dental[0]].every((r) => r[0] === 'talal') && ds2.meta.hours[dental[1]].some((r) => r[0] === 'quba') && ds2.meta.hours[dental[1]].some((r) => r[0] === 'talal'), 'البيانات العامة تتحدث بعد تعديل الإدارة');

    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
    const page = await ctx.newPage();
    page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text()); });
    await page.goto(base + '/app/', { waitUntil: 'networkidle' });
    await page.waitForSelector('#view .hbn', { timeout: 8000 }); await sleep(500);
    await page.evaluate(() => { location.hash = '#/book'; });
    await page.waitForSelector('#bk-form', { timeout: 8000 }); await sleep(400);
    const opts = (sel) => page.locator(sel + ' option').evaluateAll((els) => els.map((e) => ({ v: e.value, t: e.textContent })));
    const info = async () => (await page.locator('#dr-info').innerText()).replace(/\s+/g, ' ').trim();

    ok((await page.evaluate(() => [...document.querySelectorAll('#bk-form select')].map((s) => s.id).join(','))) === 'f-sel,f-br,f-dr', 'ترتيب الحقول: التخصص ثم الفرع ثم الطبيب');
    await page.selectOption('#f-sel', 'sp:dental'); await sleep(200);
    ok((await opts('#f-dr')).length === 1 + 3, 'بلا فرع: كل أطباء الأسنان الثلاثة');
    ok((await info()) === '', 'بلا فرع ولا طبيب: لا تنبيه');

    await page.selectOption('#f-br', 'talal'); await sleep(250);
    let d = await opts('#f-dr');
    ok(d.length === 1 + 2 && d.some((x) => x.v === dental[0]) && d.some((x) => x.v === dental[1]) && !d.some((x) => x.v === dental[2]), 'فرع التلال: طبيبان فقط (من يداوم فيه)');
    let t = await info();
    ok(/تظهر في القائمة أطباء فرع التلال فقط \(2\)/.test(t), 'تنبيه: تظهر أطباء الفرع فقط (2): ' + t);
    await page.screenshot({ path: path.join(SHOTS, 'b01-branch-filter.png') });

    await page.selectOption('#f-br', 'quba'); await sleep(250);
    d = await opts('#f-dr');
    ok(d.length === 1 + 2 && !d.some((x) => x.v === dental[0]) && d.some((x) => x.v === dental[1]) && d.some((x) => x.v === dental[2]), 'فرع قباء: الثاني والثالث فقط (الأول انتقل للتلال)');

    await page.selectOption('#f-br', 'talal'); await sleep(200);
    await page.selectOption('#f-dr', dental[0]); await sleep(500);
    t = await info();
    ok(t.includes(name(dental[0])) && /يداوم في/.test(t) && /فرع التلال/.test(t) && /كل الأيام: 9:00 ص – 12:30 م و4:00 م – 10:00 م/.test(t) && !/فرع قباء/.test(t), 'طبيب التلال: فرعه وأيامه وساعاته: ' + t);
    ok((await opts('#f-br')).map((x) => x.v).join() === ',talal', 'قائمة الفروع تقتصر على فرع الطبيب');
    await page.waitForSelector('.sl-t', { timeout: 8000 });
    ok(await page.locator('.sl-t').count() > 0, 'والمواعيد المتاحة تظهر له');
    await page.screenshot({ path: path.join(SHOTS, 'b02-doctor-hours.png') });

    await page.selectOption('#f-dr', dental[1]); await sleep(500);
    t = await info();
    ok(/فرع قباء — كل الأيام: 9:00 ص – 12:30 م/.test(t) && /فرع التلال — كل الأيام: 4:00 م – 10:00 م/.test(t), 'طبيب في الفرعين: سطر لكل فرع: ' + t);
    ok((await opts('#f-br')).length === 3, 'وقائمة الفروع تشمل الفرعين');
    await page.screenshot({ path: path.join(SHOTS, 'b03-two-branches.png') });

    // تغيير الفرع مع طبيب مختار لا يبقي طبيباً لا يداوم فيه
    await page.selectOption('#f-dr', ''); await page.selectOption('#f-br', ''); await sleep(200);
    await page.selectOption('#f-dr', dental[2]); await sleep(300);
    ok((await opts('#f-br')).map((x) => x.v).join() === ',quba', 'طبيب قباء وحده: لا يعرض التلال');
    await page.selectOption('#f-dr', ''); await sleep(200);

    // تخصص بلا أطباء في الفرع
    await page.selectOption('#f-br', 'talal'); await page.selectOption('#f-sel', 'sp:pediatrics'); await sleep(300);
    t = await info();
    ok((await opts('#f-dr')).length === 1 && /لا يوجد في فرع التلال أطباء لهذا الاختيار/.test(t), 'فرع بلا أطباء للتخصص: يُقال صراحة: ' + t);
    await page.screenshot({ path: path.join(SHOTS, 'b04-no-doctors.png') });

    // الطبيب العام: 24 ساعة
    await page.selectOption('#f-br', ''); await page.selectOption('#f-sel', 'sp:general'); await sleep(300);
    await page.selectOption('#f-dr', gp); await sleep(500);
    t = await info();
    ok(/فرع قباء — كل الأيام: على مدار 24 ساعة/.test(t), 'الطبيب العام: على مدار 24 ساعة: ' + t);
    ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'لا تمرير أفقي');

    // رابط من قمر (طبيب + فرع) يفتح الصفحة بالاختيارين
    await page.evaluate((id) => { location.hash = '#/book?dr=' + id + '&br=talal'; }, dental[1]); await sleep(900);
    ok((await page.inputValue('#f-dr')) === dental[1] && (await page.inputValue('#f-br')) === 'talal', 'رابط الحجز بطبيب وفرع يعبّئ الاختيارين');

    /* =============== قمر: فرع الطبيب من الجدول =============== */
    const q = async (m, h) => (await http('POST', '/api/v1/qamar', { deviceId: 'dev_branch_check_000000000', message: m, history: h || [] })).body.reply;
    let r = await q('الدكتور ' + name(dental[0]) + ' في أي فرع بكرة؟');
    ok(/يداوم غداً فرع التلال من 9:00 ص إلى 12:30 م، ومن 4:00 م إلى 10:00 م/.test(r.text) && r.intent === 'doctor_where' && r.source === 'kb', 'قمر: طبيب التلال «غداً فرع التلال» بساعاته: ' + r.text.slice(0, 120));
    ok(!/فرع قباء/.test(r.text), 'ولا يذكر فرعاً لا يداوم فيه');
    r = await q('وين الدكتور ' + name(dental[1]) + ' اليوم');
    ok(/فرع قباء/.test(r.text) && /فرع التلال/.test(r.text), 'قمر: طبيب الفرعين يذكر الفرعين');
    r = await q('الدكتور ' + name(gp) + ' موجود الحين؟');
    ok(/موجود الآن في فرع قباء/.test(r.text) && /على مدار 24 ساعة/.test(r.text), 'قمر: الطبيب العام موجود الآن على مدار 24 ساعة');
    const other = ds.doctors.find((x) => !Object.keys(ds2.meta.hours).includes(x.id));
    ok(!other, 'كل الأطباء لهم جدول (اختبار «بلا جدول» في اختبارات الخادم)');
    // قمر داخل التطبيق: الرد يظهر في المحادثة
    await page.evaluate(() => { location.hash = '#/home'; }); await sleep(500);
    await page.evaluate(() => document.querySelector('.fab').click());
    await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
    const before = await page.locator('.sheet .m.bot:not(.typing)').count();
    await page.fill('#qin', 'الدكتور ' + name(dental[0]) + ' في أي فرع اليوم؟');
    await page.locator('.sheet .send').click();
    await page.waitForFunction((n) => document.querySelectorAll('.sheet .m.bot:not(.typing)').length > n, before, { timeout: 15000 });
    await sleep(300);
    const bot = await page.locator('.sheet .m.bot:not(.typing)').last().innerText();
    ok(/فرع التلال/.test(bot) && !/فرع قباء/.test(bot) && !/تم الحجز|حجزت لك/.test(bot), 'قمر في التطبيق يجيب بفرع الطبيب');
    await page.screenshot({ path: path.join(SHOTS, 'b05-qamar-where.png') });
    ok(errors.length === 0, 'لا أخطاء جافاسكربت ' + errors.join(' | ').slice(0, 300));
  } finally {
    await browser.close(); proc.kill();
  }
  console.log('=== ' + pass + ' PASS / ' + fail + ' FAIL ===');
  process.exit(fail ? 1 : 0);
})();
