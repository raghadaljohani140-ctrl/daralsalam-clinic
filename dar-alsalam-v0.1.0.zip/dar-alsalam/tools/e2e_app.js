/* اختبار شامل للتطبيق على شاشة جوال (Playwright + Chrome). التشغيل:
   NODE_PATH=<مسار playwright> node tools/e2e_app.js [BASE_URL] [ADMIN_PASSWORD]
   يلتقط لقطات في qa/shots ويطبع PASS/FAIL ويخرج برمز غير صفري عند أي فشل. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8090';
const ADMIN_PW = process.argv[3] || 'devpass-12345';
const SHOTS = path.join(__dirname, '..', 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
let fails = 0, passes = 0;
function ok(cond, msg) { if (cond) { passes++; console.log('PASS', msg); } else { fails++; console.log('FAIL', msg); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('dialog', (d) => d.dismiss());

  const shot = async (name, full) => { await sleep(350); await page.screenshot({ path: path.join(SHOTS, name + '.png'), fullPage: !!full }); };
  const go = async (hash) => { await page.evaluate((h) => { location.hash = h; }, hash); await sleep(250); };
  const text = async (sel) => (await page.locator(sel).first().innerText()).trim();

  /* ---------- التشغيل ---------- */
  await page.goto(BASE + '/app/', { waitUntil: 'networkidle' });
  await page.waitForSelector('#view .hero', { timeout: 8000 });
  ok(await page.locator('.tabs .tab').count() === 5, 'شريط التبويب فيه 5 عناصر');
  ok(await page.locator('.fab').isVisible(), 'أيقونة قمر العائمة ظاهرة');
  ok((await text('.hero h2')).includes('دار السلام'), 'الرئيسية تعرض اسم المجمع');
  ok(await page.locator('.ribbon').isVisible(), 'شريط «بيانات قيد المراجعة» ظاهر لأن dataStatus=draft');
  await shot('01-home', false);
  await shot('01-home-full', true);

  /* ---------- صفحات المعلومات ---------- */
  await go('#/specialties');
  ok(await page.locator('#list .tile').count() === 13, 'قائمة التخصصات: 13');
  await page.fill('#q', 'ركبة');
  await sleep(200);
  ok(await page.locator('#list .tile').count() >= 1, 'بحث «ركبة» يعيد تخصصاً');
  ok((await page.locator('#list').innerText()).includes('عظام'), 'بحث «ركبة» يقود إلى العظام');
  await page.fill('#q', '');
  await shot('02-specialties');

  await go('#/specialty/internal');
  ok((await text('.page-h h2')) === 'الباطنة', 'صفحة تخصص الباطنة');
  await shot('03-specialty');

  await go('#/doctors');
  ok(await page.locator('#list .item').count() === 27, 'قائمة الأطباء: 27');
  await page.locator('#chips .chip').nth(2).click();
  await sleep(200);
  ok(await page.locator('#list .item').count() < 27, 'التصفية بالتخصص تقلّص القائمة');
  await shot('04-doctors');
  await go('#/doctors');
  await page.locator('#list .item').first().click();
  await sleep(300);
  ok(location_hash_ok(await page.evaluate(() => location.hash), '#/doctor/'), 'فتح صفحة طبيب');
  ok(await page.locator('.sticky-cta .btn').isVisible(), 'زر «اطلب حجزاً» ظاهر في صفحة الطبيب');
  await shot('05-doctor');

  await go('#/services');
  ok(await page.locator('.item').count() === 3, 'الخدمات: 3');
  await go('#/service/emergency');
  ok((await page.locator('.sticky-cta').innerText()).includes('اتصل'), 'خدمة الطوارئ فيها اتصال');
  ok(!(await page.locator('.sticky-cta').innerText()).includes('اطلب حجزاً'), 'الطوارئ بدون زر حجز');
  await shot('06-service-emergency');

  await go('#/branches');
  ok(await page.locator('.card .ico-box').count() >= 2, 'قائمة الفروع');
  await shot('07-branches');
  await go('#/branch/quba');
  ok(await page.locator('.mapph').count() === 1, 'بلا إحداثيات: عنصر نائب + روابط الخرائط');
  ok((await page.locator('a[href*="google.com/maps"]').count()) === 1, 'رابط خرائط قوقل موجود');
  await shot('08-branch');
  await go('#/contact');
  ok((await page.locator('body').innerText()).includes('920031134'), 'صفحة التواصل تعرض الرقم الموحد');
  await shot('09-contact');
  await go('#/about');
  await shot('10-about');
  await go('#/privacy');
  ok((await page.locator('.prose').innerText()).includes('ما الذي نجمعه'), 'سياسة الخصوصية');
  ok(!(await page.locator('.prose').innerText()).includes('ذكاء اصطناعي خارجية'), 'الخصوصية: لا فقرة مزوّد خارجي ما دام معطّلاً');
  await page.evaluate(() => { DS.data.ds.qamar.externalAi = true; });
  await go('#/about'); await go('#/privacy');
  const privAi = await page.locator('.prose').innerText();
  ok(privAi.includes('ذكاء اصطناعي خارجية') && privAi.includes('خارج المملكة') && privAi.includes('وكذلك ما أُرسل منها للمزوّد الخارجي'), 'الخصوصية: تظهر فقرة المزوّد الخارجي حين يعلن الخادم تفعيله');
  await page.evaluate(() => { DS.data.ds.qamar.externalAi = false; });
  await go('#/about'); await go('#/privacy');
  ok(!(await page.locator('.prose').innerText()).includes('ذكاء اصطناعي خارجية'), 'الخصوصية: تختفي الفقرة حين يُعطَّل');

  /* ---------- الحجز ---------- */
  await go('#/book');
  await shot('11-book-empty');
  await page.locator('#f-submit').click();
  await sleep(250);
  ok(await page.locator('[data-err="sel"]:not([hidden])').count() === 1, 'خطأ: لم يُختر تخصص');
  ok(await page.locator('[data-err="name"]:not([hidden])').count() === 1, 'خطأ: الاسم');
  ok(await page.locator('[data-err="phone"]:not([hidden])').count() === 1, 'خطأ: الجوال');
  ok(await page.locator('[data-err="consent"]:not([hidden])').count() === 1, 'خطأ: الموافقة');
  await shot('12-book-errors');

  await go('#/book?sp=orthopedics&br=quba');
  await sleep(300);
  const selVal = await page.locator('#f-sel').inputValue();
  ok(selVal.startsWith('sp:'), 'تعبئة التخصص من الرابط: ' + selVal);
  await page.fill('#f-name', 'أحمد تجريبي');
  await page.fill('#f-phone', '٠٥٠١٢٣٤٥٦٧');
  await page.fill('#f-note', 'اختبار آلي — لا تتصلوا');
  await page.locator('#f-consent').check();
  await shot('13-book-filled');
  await page.locator('#f-submit').click();
  await page.waitForSelector('.okmark', { timeout: 8000 });
  const bid = await text('.bk-id');
  ok(/^DS-[A-Z0-9]{6}$/.test(bid), 'رقم الطلب: ' + bid);
  const body = await page.locator('#bkroot').innerText();
  ok(body.includes('ليس موعداً مؤكداً'), 'نص «ليس موعداً مؤكداً» ظاهر بعد الإرسال');
  ok(!body.includes('تم حجز موعدك') && !body.includes('تم تأكيد'), 'لا يوجد ادعاء بتأكيد الحجز');
  await shot('14-book-success');

  /* ---------- حسابي ---------- */
  await go('#/profile');
  await page.waitForSelector('.bk', { timeout: 6000 });
  ok((await text('.bk .status')) === 'تم الاستلام', 'حالة الطلب في حسابي: تم الاستلام');
  ok((await page.locator('.bk').innerText()).includes('ليس موعداً مؤكداً'), 'ملاحظة عدم التأكيد في بطاقة الطلب');
  await shot('15-profile');

  // الموظف يؤكد الطلب من لوحة الإدارة (واجهة API) → يظهر الموعد للمراجع
  const login = await (await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: ADMIN_PW }) })).json();
  const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + login.token };
  const lst = await (await fetch(BASE + '/api/admin/bookings', { headers: H })).json();
  ok(lst.bookings.some((b) => b.id === bid), 'الطلب وصل إلى لوحة الإدارة');
  let r = await fetch(BASE + '/api/admin/bookings/' + bid, { method: 'PATCH', headers: H, body: JSON.stringify({ status: 'confirmed' }) });
  ok(r.status === 422, 'الخادم يرفض «مؤكد» بدون نص الموعد (' + r.status + ')');
  r = await fetch(BASE + '/api/admin/bookings/' + bid, { method: 'PATCH', headers: H, body: JSON.stringify({ status: 'confirmed', appointmentText: 'الأحد 10 صباحاً — عيادة العظام' }) });
  ok(r.status === 200, 'الموظف يؤكد الطلب بنص موعد');
  await page.reload({ waitUntil: 'networkidle' });
  await go('#/profile');
  await page.waitForSelector('.bk .status', { timeout: 6000 });
  ok((await text('.bk .status')) === 'مؤكد', 'الحالة تتحول إلى «مؤكد» بعد تثبيت الموظف');
  ok((await page.locator('.bk').innerText()).includes('الأحد 10 صباحاً'), 'نص الموعد يظهر للمراجع');
  await shot('16-profile-confirmed');

  // الإشعارات
  await sleep(200);
  ok(await page.locator('#nbadge:not([hidden])').count() === 1, 'شارة الإشعارات تظهر');
  await go('#/notifications');
  await page.waitForSelector('.nt', { timeout: 6000 });
  ok(await page.locator('.nt').count() >= 1, 'إشعار بتأكيد الطلب');
  await shot('17-notifications');
  await sleep(300);
  ok(await page.locator('#nbadge:not([hidden])').count() === 0, 'الشارة تختفي بعد فتح الإشعارات');

  // طلب ثانٍ ثم إلغاؤه
  await go('#/book?sp=dental');
  await page.fill('#f-name', 'أحمد تجريبي');
  await page.fill('#f-phone', '0501234567');
  await page.locator('#f-consent').check();
  await page.locator('#f-submit').click();
  await page.waitForSelector('.okmark', { timeout: 8000 });
  await go('#/profile');
  await page.waitForSelector('.bk', { timeout: 6000 });
  const cancelBtn = page.locator('[data-act="bk-cancel"]').first();
  await cancelBtn.click();
  ok((await cancelBtn.innerText()).includes('مرة أخرى'), 'الإلغاء يحتاج ضغطتين');
  await cancelBtn.click();
  await sleep(600);
  ok((await page.locator('.bk .status.s-cancelled').count()) === 1, 'الطلب الملغي يظهر «ملغي»');
  // ننتظر زوال إشعار «أُلغي الطلب» العائم كي لا يظهر في لقطات قمر التالية
  await page.waitForSelector('#toast:not(.on)', { state: 'attached', timeout: 5000 });

  /* ---------- قمر ---------- */
  await go('#/');
  await page.locator('.fab').click();
  await page.waitForSelector('.sheet .m.bot', { timeout: 4000 });
  ok(await page.locator('.sheet').isVisible(), 'نافذة قمر تفتح');
  await shot('18-qamar-open');
  const ask = async (q) => {
    const before = await page.locator('.sheet .m.bot:not(.typing)').count();
    await page.fill('#qin', q);
    await page.locator('.sheet .send').click();
    await page.waitForFunction((n) => document.querySelectorAll('.sheet .m.bot:not(.typing)').length > n, before, { timeout: 15000 });
    await sleep(150);
    return (await page.locator('.sheet .m.bot:not(.typing)').last().innerText()).trim();
  };
  let a = await ask('عندي ألم في الركبة');
  ok(a.includes('عظام'), 'قمر يقترح العظام لألم الركبة');
  ok(await page.locator('.sheet .m.bot').last().locator('.act.book').count() === 1, 'يظهر زر «ابدأ طلب الحجز»');
  await shot('19-qamar-route');
  a = await ask('ألم شديد في الصدر وضيق نفس');
  ok(a.includes('997'), 'حالة طارئة: رد بالإسعاف 997');
  ok(await page.locator('.sheet .m.bot').last().locator('.act.em').count() >= 1, 'زر اتصال بالإسعاف');
  await shot('20-qamar-emergency');
  a = await ask('هل عندي سكر؟');
  ok(!/عندك سكر|مصاب/.test(a), 'قمر لا يشخّص');
  a = await ask('وين الفروع؟');
  ok(a.includes('قباء'), 'قمر يذكر الفروع');
  a = await ask('أبي أحجز مع طبيب عظام');
  await page.locator('.sheet .m.bot').last().locator('.act.book').first().click();
  await sleep(500);
  ok((await page.evaluate(() => location.hash)).startsWith('#/book'), 'زر الحجز في قمر ينقل لصفحة الحجز');
  ok(await page.locator('.sheet').count() === 0, 'النافذة تُغلق بعد الانتقال');
  ok((await page.locator('#f-sel').inputValue()).startsWith('sp:'), 'التخصص معبّأ من قمر');
  await shot('21-book-from-qamar');

  // بدون إنترنت: قمر يعمل محلياً
  await ctx.setOffline(true);
  await go('#/');
  await page.locator('.fab').click();
  a = await ask('كم رقم المجمع؟');
  ok(/920031134/.test(a), 'بدون إنترنت: قمر يجيب من القاعدة المحلية');
  await shot('22-qamar-offline');
  await page.locator('.sheet header [data-act="qamar-close"]').click();
  await ctx.setOffline(false);

  // حذف بياناتي
  await go('#/profile');
  const del = page.locator('[data-act="del-data"]');
  await del.click(); await del.click();
  await sleep(800);
  const left = await page.evaluate(() => Object.keys(localStorage).filter((k) => /ds\.(profile|myBookings)/.test(k)).length);
  ok(left === 0, 'حذف بياناتي يمسح التخزين المحلي');

  /* ---------- ملخص ---------- */
  const real = errors.filter((e) => !/Failed to load resource.*(404|503)/.test(e) && !/net::ERR_INTERNET_DISCONNECTED/.test(e) && !/ERR_FAILED/.test(e));
  ok(real.length === 0, 'لا أخطاء في وحدة التحكم' + (real.length ? ': ' + real.join(' | ') : ''));
  console.log('\nالنتيجة:', passes, 'ناجح،', fails, 'فاشل');
  await browser.close();
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });

function location_hash_ok(h, prefix) { return String(h).startsWith(prefix); }
