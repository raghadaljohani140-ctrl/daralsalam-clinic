#!/usr/bin/env python3
"""يبني نسخة التجربة: ملف HTML واحد يحوي التطبيق كاملاً (واجهة + بيانات + قمر) ويعمل بفتحه من الجوال أو الحاسوب بلا خادم.

  python3 tools/build_preview.py [--out dist/preview.html]

ضمانات النسخة التجريبية (تُفرض في المتصفح نفسه وليس بالنية فقط):
  • سياسة CSP تمنع أي اتصال بالشبكة (connect-src 'none') وإرسال النماذج (form-action 'none') وتحميل صور/خطوط خارجية.
  • وضع demo=true: الحجز يعرض «ما كان سيُرسل» ولا يرسل، والإشعارات أمثلة، وقمر يجيب محلياً من قاعدة المعرفة فقط.
  • البيانات هي نسخة seed.public.json المضمّنة (بيانات الموقع الرسمي قيد المراجعة).
"""
import argparse
import base64
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
ORDER = ["00-core.js", "20-kb.js", "10-data.js", "30-views.js", "40-booking.js", "50-qamar.js", "90-app.js"]
CSP = ("default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; "
       "frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'")


def js_json(obj):
    """JSON آمن للتضمين داخل وسم script."""
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    return s.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def data_uri(path, mime):
    return "data:%s;base64,%s" % (mime, base64.b64encode(Path(path).read_bytes()).decode())


def build(version):
    html = (WEB / "index.html").read_text(encoding="utf-8")
    css = (WEB / "css" / "app.css").read_text(encoding="utf-8")
    svg_uri = data_uri(WEB / "img" / "icon.svg", "image/svg+xml")
    png180 = data_uri(WEB / "img" / "icon-180.png", "image/png")

    # رأس الصفحة: CSP صارمة + التنسيقات + الأيقونات المضمّنة
    html = re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '<meta http-equiv="Content-Security-Policy" content="%s">' % CSP, html, count=1)
    html = html.replace('<link rel="manifest" href="manifest.webmanifest">\n', "")
    html = html.replace('<link rel="icon" href="img/icon.svg" type="image/svg+xml">', '<link rel="icon" href="%s" type="image/svg+xml">' % svg_uri)
    html = html.replace('<link rel="apple-touch-icon" href="img/icon-180.png">', '<link rel="apple-touch-icon" href="%s">' % png180)
    html = html.replace('<link rel="stylesheet" href="css/app.css">', "<style>\n%s\n</style>" % css.replace("</style", "<\\/style"))
    html = html.replace("<title>مجمعات دار السلام الطبية</title>", "<title>مجمعات دار السلام الطبية — نسخة تجريبية</title>")
    html = html.replace('src="img/icon.svg"', 'src="%s"' % svg_uri)

    # الإعدادات والبيانات المضمّنة
    seed = json.loads((WEB / "data" / "seed.public.json").read_text(encoding="utf-8"))
    lex = json.loads((WEB / "data" / "lexicon.json").read_text(encoding="utf-8"))
    cfg = {"apiBase": "", "demo": True, "version": version, "build": "preview"}
    head_js = "<script>window.DS_CONFIG=%s;window.DS_SEED=%s;window.DS_LEXICON=%s;</script>" % (js_json(cfg), js_json(seed), js_json(lex))
    html = html.replace('<script src="config.js"></script>', head_js)

    # السكربتات بالترتيب نفسه المعتمد في index.html
    for name in ORDER:
        tag = '<script src="js/%s"></script>' % name
        if tag not in html:
            sys.exit("لم أجد السكربت في index.html: " + name)
        src = (WEB / "js" / name).read_text(encoding="utf-8")
        src = src.replace("img/icon.svg", svg_uri).replace("</script", "<\\/script")
        html = html.replace(tag, "<script>\n%s\n</script>" % src)

    markup = re.sub(r"<(script|style)\b[^>]*>.*?</\1>", "", html, flags=re.S)        # نفحص الوسوم فقط لا نصوص الجافاسكربت
    leftovers = re.findall(r'(?:src|href)="(?!data:|#|tel:|https?:)[^"]+"', markup)
    if leftovers:
        sys.exit("بقيت مراجع خارجية في الملف: %s" % leftovers[:5])
    return html


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "dist" / "preview.html"))
    ap.add_argument("--version", default=None)
    a = ap.parse_args()
    version = a.version
    if not version:
        m = re.search(r'version:\s*"([^"]+)"', (WEB / "config.js").read_text(encoding="utf-8"))
        version = m.group(1) if m else "0.1.0"
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    html = build(version)
    out.write_text(html, encoding="utf-8")
    print("تم: %s  (%d KB)  sha256=%s" % (out, len(html.encode("utf-8")) // 1024, hashlib.sha256(html.encode("utf-8")).hexdigest()[:16]))


if __name__ == "__main__":
    main()
