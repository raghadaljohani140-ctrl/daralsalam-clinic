/* يولّد كل أيقونات التطبيق (PNG) من رسم SVG واحد.   NODE_PATH=<مجلد node_modules العام> node tools/make_icons.js
   مهم: الشعار هنا رسم مؤقت عام (بيت + صليب طبي + هلال) وليس شعار المجمع الرسمي. استبدله بالشعار الرسمي عند توفره:
   ضعه في mobile/assets/ (icon-only.png 1024، icon-foreground.png 1024 بخلفية شفافة، splash.png 2732) وفي web/img/. */
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const WEB = path.join(ROOT, 'web', 'img');
const ASSETS = path.join(ROOT, 'mobile', 'assets');
fs.mkdirSync(WEB, { recursive: true });
fs.mkdirSync(ASSETS, { recursive: true });

const TEAL = '#0E7C7B', DARK = '#0A5655', GOLD = '#C9A24B';
const GLYPH = '<path d="M256 118 120 232v152h272V232L256 118z" fill="#fff"/>' +
  '<rect x="228" y="226" width="56" height="150" rx="10" fill="' + TEAL + '"/><rect x="181" y="273" width="150" height="56" rx="10" fill="' + TEAL + '"/>' +
  '<path d="M396 96a52 52 0 1 0 38 88 42 42 0 1 1-38-88z" fill="' + GOLD + '" transform="translate(-6 -2) scale(.95)"/>';
const DEFS = '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + TEAL + '"/><stop offset="1" stop-color="' + DARK + '"/></linearGradient></defs>';

/* bg: 'round' | 'square' | 'solid' | 'none'؛ scale: حجم الرمز داخل الإطار (1 = كامل التصميم الأصلي) */
function svg(size, bg, scale) {
  const back = bg === 'round' ? '<rect width="512" height="512" rx="112" fill="url(#g)"/>'
    : bg === 'square' ? '<rect width="512" height="512" fill="url(#g)"/>'
      : bg === 'solid' ? '<rect width="512" height="512" fill="' + DARK + '"/>' : '';
  const g = '<g transform="translate(256 256) scale(' + scale + ') translate(-256 -240)">' + GLYPH + '</g>';
  return Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="' + size + '" height="' + size + '">' + DEFS + back + g + '</svg>');
}
async function out(file, size, bg, scale, opaque) {
  let img = sharp(svg(size, bg, scale), { density: 384 }).resize(size, size);
  if (opaque) img = img.flatten({ background: DARK });          // متجر آبل: بلا قناة شفافية
  await img.png({ compressionLevel: 9 }).toFile(file);
  const st = fs.statSync(file);
  console.log('✓', path.relative(ROOT, file), size + 'x' + size, Math.round(st.size / 1024) + 'KB');
}

(async () => {
  await out(path.join(WEB, 'icon-192.png'), 192, 'round', 1);
  await out(path.join(WEB, 'icon-512.png'), 512, 'round', 1);
  await out(path.join(WEB, 'icon-180.png'), 180, 'square', 1, true);              // apple-touch-icon (يقصّه iOS بنفسه)
  await out(path.join(WEB, 'icon-maskable-512.png'), 512, 'square', 0.72, true);  // المنطقة الآمنة للأيقونات القابلة للقص
  await out(path.join(ASSETS, 'icon-only.png'), 1024, 'square', 1, true);         // أيقونة المتجر 1024
  await out(path.join(ASSETS, 'icon-foreground.png'), 1024, 'none', 0.62);        // مقدّمة أيقونة أندرويد التكيفية
  await out(path.join(ASSETS, 'icon-background.png'), 1024, 'square', 0.0001, true);
  await out(path.join(ASSETS, 'splash.png'), 2732, 'solid', 0.3, true);
  await out(path.join(ASSETS, 'splash-dark.png'), 2732, 'solid', 0.3, true);
})().catch((e) => { console.error(e); process.exit(1); });
