"""مخطط الكيانات: يُستخدم للتحقق من البيانات وتُرسل نسخة منه إلى لوحة الإدارة لتبني النماذج تلقائياً.
إضافة حقل أو نوع كيان جديد = تعديل هذا الملف فقط؛ لا تغيير في قاعدة البيانات."""
import re
import secrets

ICONS = ["activity", "heart", "user", "smile", "bone", "ear", "scalpel", "plus", "drop", "eye", "sparkle", "lungs", "alert",
         "flask", "scan", "stethoscope", "baby", "pill", "shield", "calendar", "phone", "map-pin"]

ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,48}$")
PHONE_TYPES = [("main", "الرقم الموحد"), ("whatsapp", "واتساب"), ("other", "آخر")]

F = lambda key, label, typ="text", **kw: dict(key=key, label=label, type=typ, **kw)  # noqa: E731

COMMON = [
    F("sort", "الترتيب", "number", help="رقم أصغر يظهر أولاً"),
    F("active", "ظاهر في التطبيق", "bool", default=True),
]

KINDS = {
    "branches": {
        "label": "الفروع", "single": "فرع", "title": "name",
        "fields": [
            F("name", "اسم الفرع", required=True, max=80),
            F("shortName", "اسم مختصر", max=40, help="يظهر في الأزرار، مثل: فرع قباء"),
            F("area", "الحي / المنطقة", max=60),
            F("address", "العنوان", required=True, max=160),
            F("landmark", "معلم قريب", max=100),
            F("phone", "هاتف الفرع", "phone"),
            F("whatsapp", "واتساب الفرع", "phone"),
            F("hoursText", "ساعات العمل (نص)", max=160, help="اتركه فارغاً إن لم تكن مؤكدة"),
            F("lat", "خط العرض (lat)", "number", step="any", help="من خرائط قوقل: اضغط مطولاً على الموقع"),
            F("lng", "خط الطول (lng)", "number", step="any"),
            F("mapQuery", "عبارة البحث في الخرائط", max=160, help="تُستخدم إن لم توجد إحداثيات"),
            F("photo", "رابط صورة", "url"),
            F("needsReview", "يحتاج مراجعة", "bool", admin_only=True),
        ] + COMMON,
    },
    "specialties": {
        "label": "التخصصات", "single": "تخصص", "title": "name",
        "fields": [
            F("name", "اسم التخصص", required=True, max=80),
            F("description", "وصف مختصر", "textarea", max=400),
            F("keywords", "كلمات مفتاحية لقمر", "list", help="كلمة أو عبارة في كل سطر: أعراض وأسماء شائعة تدل على التخصص"),
            F("hoursText", "ساعات العمل (نص)", max=160),
            F("icon", "الأيقونة", "select", options=ICONS, default="stethoscope"),
            F("needsReview", "يحتاج مراجعة", "bool", admin_only=True),
        ] + COMMON,
    },
    "services": {
        "label": "الخدمات", "single": "خدمة", "title": "name",
        "fields": [
            F("name", "اسم الخدمة", required=True, max=80),
            F("description", "وصف مختصر", "textarea", max=400),
            F("keywords", "كلمات مفتاحية لقمر", "list"),
            F("hoursText", "ساعات العمل (نص)", max=160),
            F("icon", "الأيقونة", "select", options=ICONS, default="activity"),
            F("needsReview", "يحتاج مراجعة", "bool", admin_only=True),
        ] + COMMON,
    },
    "doctors": {
        "label": "الأطباء", "single": "طبيب", "title": "name",
        "fields": [
            F("name", "الاسم (بدون «د.»)", required=True, max=80),
            F("rank", "الدرجة", max=40, help="مثل: استشاري، أخصائي"),
            F("degree", "المؤهل", max=120),
            F("specialtyIds", "التخصصات", "multi", ref="specialties"),
            F("serviceIds", "الخدمات", "multi", ref="services"),
            F("branchIds", "الفروع", "multi", ref="branches", help="اتركه فارغاً إن كان يعمل في كل الفروع أو لم يتأكد"),
            F("photo", "رابط صورة", "url"),
            F("bio", "نبذة", "textarea", max=600),
            F("needsReview", "يحتاج مراجعة", "bool", admin_only=True),
        ] + COMMON,
    },
    "faqs": {
        "label": "الأسئلة الشائعة", "single": "سؤال", "title": "question",
        "fields": [
            F("category", "النوع", "select", options=["app", "tips"], default="app",
              labels={"app": "سؤال عن التطبيق/المجمع", "tips": "نصيحة صحية منشورة"}),
            F("question", "السؤال", required=True, max=200),
            F("answer", "الجواب", "textarea", required=True, max=900,
              help="يمكن استخدام {phone_main} للرقم الموحد و{emergency} لرقم الإسعاف"),
            F("keywords", "كلمات مفتاحية", "list"),
        ] + COMMON,
    },
    "banners": {
        "label": "اللوحات الإعلانية", "single": "لوحة", "title": "title",
        "fields": [
            F("title", "العنوان", required=True, max=80),
            F("text", "النص", "textarea", max=300),
            F("linkType", "الرابط إلى", "select", options=["none", "specialty", "doctor", "service", "branch", "url"], default="none",
              labels={"none": "بدون", "specialty": "تخصص", "doctor": "طبيب", "service": "خدمة", "branch": "فرع", "url": "رابط خارجي"}),
            F("linkRef", "المعرّف أو الرابط", max=200),
        ] + COMMON,
    },
}

SETTINGS_FIELDS = [
    F("name", "اسم المجمع", required=True, max=100),
    F("shortName", "اسم مختصر", max=40, help="يظهر في عنوان نافذة قمر وأسفل التطبيق"),
    F("legalName", "الاسم النظامي", max=120),
    F("city", "المدينة", max=60),
    F("tagline", "الشعار النصي", max=120),
    F("about", "نبذة", "textarea", max=900),
    F("mission", "الرسالة", "textarea", max=500),
    F("vision", "الرؤية", "textarea", max=500),
    F("values", "القيم", "list", help="قيمة في كل سطر"),
    F("founded", "سنة التأسيس", "number"),
    F("phones", "أرقام التواصل", "phones"),
    F("whatsapp", "واتساب الرئيسي", "phone"),
    F("email", "البريد الإلكتروني", max=120, help="لا يظهر في التطبيق إلا إذا تم إدخاله"),
    F("website", "رابط موقع المجمع", "url"),
    F("social.x", "رابط حساب X", "url"),
    F("social.instagram", "رابط انستغرام", "url"),
    F("social.tiktok", "رابط تيك توك", "url"),
    F("stats.patients", "عدد المراجعين (للعرض في الرئيسية)", "number"),
    F("stats.doctors", "عدد الأطباء (للعرض)", "number"),
    F("stats.clinics", "عدد العيادات (للعرض)", "number"),
    F("stats.services", "عدد الخدمات (للعرض)", "number"),
    F("emergencyNumber", "رقم الإسعاف", max=10, default="997"),
    F("healthLine", "خط وزارة الصحة", max=10, default="937"),
    F("booking.externalUrl", "رابط بوابة المريض للحجز السريع", "url",
      help="اتركه فارغاً الآن. عند وجود رابط حقيقي يظهر زر «فتح بوابة المريض» في صفحة الحجز، ويبقى نموذج الطلب متاحاً"),
    F("booking.externalLabel", "نص زر البوابة", max=60, default="الحجز عبر بوابة المريض"),
    F("notice", "إشعار أعلى الصفحة الرئيسية", "textarea", max=240, help="اتركه فارغاً لإخفائه"),
    F("dataStatus", "حالة البيانات", "select", options=["draft", "verified"], default="draft",
      labels={"draft": "مسودة (تظهر شارة «بيانات قيد المراجعة»)", "verified": "تمت مراجعتها"}),
]

QAMAR_FIELDS = [
    F("enabled", "تفعيل قمر", "bool", default=True),
    F("name", "الاسم", max=30, default="قمر"),
    F("greeting", "رسالة الترحيب", "textarea", max=300),
    F("quickReplies", "اقتراحات سريعة", "list"),
    F("handoffText", "نص التحويل للموظفين", "textarea", max=300),
    F("mode", "الوضع", "select", options=["kb", "auto", "llm"], default="kb",
      labels={"kb": "قاعدة المعرفة فقط (بدون تكلفة)", "auto": "تلقائي (النموذج للأسئلة غير المفهومة فقط)", "llm": "النموذج لأغلب الأسئلة"}),
    F("answerFaqDirectly", "الإجابة المباشرة من الأسئلة الشائعة", "bool", default=True),
    F("extraInstructions", "تعليمات إضافية للنموذج", "textarea", max=600,
      help="تُضاف بعد القواعد الثابتة ولا تلغيها"),
]


def new_id(kind):
    prefix = {"branches": "br", "specialties": "sp", "services": "sv", "doctors": "dr", "faqs": "fq", "banners": "bn"}[kind]
    return f"{prefix}-{secrets.token_hex(3)}"


def _str(v, max_len):
    v = "" if v is None else str(v).strip()
    return v[:max_len] if max_len else v


def clean_phone(v):
    d = re.sub(r"[^\d+]", "", str(v or ""))
    return d[:20]


def clean_list(v, max_items=60, max_len=60):
    if isinstance(v, str):
        v = re.split(r"[\n،,]+", v)
    out = []
    for x in v or []:
        x = _str(x, max_len)
        if x and x not in out:
            out.append(x)
    return out[:max_items]


def _field_value(f, raw, errors):
    t = f["type"]
    key = f["key"]
    if t in ("text", "textarea"):
        v = _str(raw, f.get("max", 400))
        if f.get("required") and not v:
            errors[key] = "مطلوب"
        return v
    if t == "phone":
        return clean_phone(raw)
    if t == "url":
        v = _str(raw, 300)
        if v and not re.match(r"^https://", v):
            errors[key] = "يجب أن يبدأ بـ https://"
            return ""
        return v
    if t == "number":
        if raw in (None, ""):
            return None
        try:
            n = float(raw)
        except (TypeError, ValueError):
            errors[key] = "رقم غير صحيح"
            return None
        return int(n) if n == int(n) and f.get("step") != "any" else n
    if t == "bool":
        return bool(raw) if not isinstance(raw, str) else raw.lower() in ("1", "true", "yes", "on")
    if t == "select":
        v = _str(raw, 40) or f.get("default", "")
        if v and v not in f.get("options", []):
            errors[key] = "قيمة غير مسموحة"
            return f.get("default", "")
        return v
    if t == "list":
        return clean_list(raw)
    if t == "multi":
        return [x for x in clean_list(raw, 80, 60)]
    if t == "phones":
        out = []
        for p in raw or []:
            number = clean_phone(p.get("number"))
            label = _str(p.get("label"), 60)
            typ = p.get("type") if p.get("type") in [x[0] for x in PHONE_TYPES] else "other"
            if number and label:
                item = {"label": label, "number": number, "type": typ}
                bid = _str(p.get("branchId"), 50)
                if bid:
                    item["branchId"] = bid
                out.append(item)
        return out[:10]
    return raw


def validate_entity(kind, data, existing=None, refs=None):
    """يعيد (البيانات المنظّفة، الأخطاء). existing: بيانات سابقة للدمج (تحديث جزئي)."""
    spec = KINDS[kind]
    errors = {}
    base = dict(existing or {})
    base.update({k: v for k, v in (data or {}).items() if k in {f["key"] for f in spec["fields"]} or k == "id"})
    out = {}
    for f in spec["fields"]:
        raw = base.get(f["key"], f.get("default"))
        if f["key"] in ("sort",):
            raw = base.get("sort", 100)
        val = _field_value(f, raw, errors)
        if f["key"] == "sort" and val is None:
            val = 100
        if f["key"] == "active" and "active" not in base:
            val = True
        out[f["key"]] = val
    eid = _str(base.get("id"), 50)
    if not eid:
        eid = new_id(kind)
    if not ID_RE.match(eid):
        errors["id"] = "معرّف غير صالح (حروف إنجليزية صغيرة وأرقام وشرطات)"
    out["id"] = eid
    if refs:
        for f in spec["fields"]:
            if f["type"] == "multi":
                allowed = refs.get(f["ref"], set())
                bad = [x for x in out[f["key"]] if x not in allowed]
                if bad:
                    errors[f["key"]] = "معرّفات غير موجودة: " + "، ".join(bad)
    if kind == "branches":
        for k in ("lat", "lng"):
            v = out.get(k)
            if v is not None and not isinstance(v, (int, float)):
                errors[k] = "رقم غير صحيح"
        if out.get("lat") is not None and not (-90 <= out["lat"] <= 90):
            errors["lat"] = "خارج النطاق"
        if out.get("lng") is not None and not (-180 <= out["lng"] <= 180):
            errors["lng"] = "خارج النطاق"
        if (out.get("lat") is None) != (out.get("lng") is None):
            errors["lat"] = "أدخل خط العرض والطول معاً"
    if kind == "banners" and out.get("linkType") == "url" and not str(out.get("linkRef", "")).startswith("https://"):
        errors["linkRef"] = "الرابط الخارجي يجب أن يبدأ بـ https://"
    return out, errors


def _get_path(d, path):
    cur = d
    for part in path.split("."):
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
    return cur


def _set_path(d, path, val):
    parts = path.split(".")
    cur = d
    for part in parts[:-1]:
        cur = cur.setdefault(part, {})
    cur[parts[-1]] = val


def validate_settings(data, existing=None):
    """تحديث جزئي آمن: القيم المركّبة (social/stats/booking) تُدمج على مستوى المفتاح الداخلي،
    وأي مفتاح غير معروف للمخطط (مثل reviewNotes أو periods) يبقى كما هو ولا يُحذف."""
    errors = {}
    base = dict(existing or {})
    for k, v in (data or {}).items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            m = dict(base[k])
            m.update(v)
            base[k] = m
        else:
            base[k] = v
    managed_roots = {f["key"].split(".")[0] for f in SETTINGS_FIELDS}
    out = {k: v for k, v in base.items() if k not in managed_roots}
    for g in ("social", "stats", "booking"):
        if isinstance(base.get(g), dict):
            out[g] = {k: v for k, v in base[g].items() if g + "." + k not in {f["key"] for f in SETTINGS_FIELDS}}
    for f in SETTINGS_FIELDS:
        key = f["key"]
        raw = _get_path(base, key)
        if raw is None:
            raw = f.get("default", "")
        val = _field_value(f, raw, errors)
        if "." in key:
            _set_path(out, key, val)
        else:
            out[key] = val
    if out.get("email") and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", out["email"]):
        errors["email"] = "بريد غير صحيح"
    b = out.setdefault("booking", {})
    b["mode"] = b.get("mode") if b.get("mode") in ("requests", "external", "contact") else "requests"
    b["externalLabel"] = b.get("externalLabel") or "الحجز عبر بوابة المريض"
    b["periods"] = b.get("periods") or [{"id": "morning", "label": "صباحاً"}, {"id": "evening", "label": "مساءً"}, {"id": "any", "label": "أي وقت"}]
    return out, errors


def validate_qamar(data, existing=None):
    errors = {}
    base = dict(existing or {})
    base.update(data or {})
    out = {}
    for f in QAMAR_FIELDS:
        out[f["key"]] = _field_value(f, base.get(f["key"], f.get("default", "")), errors)
    return out, errors


def public_schema():
    return {"kinds": KINDS, "settings": SETTINGS_FIELDS, "qamar": QAMAR_FIELDS, "icons": ICONS, "phoneTypes": PHONE_TYPES}
