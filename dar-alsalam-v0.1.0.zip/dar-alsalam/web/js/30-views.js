/* صفحات المعلومات: الرئيسية، التخصصات، الأطباء، الخدمات، الفروع، التواصل، عن المجمع */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui = {};

  /* ---------- مكوّنات صغيرة ---------- */
  U.icoBox = function (name, cls) { return '<span class="ico-box ' + (cls || '') + '">' + ic(name) + '</span>'; };
  U.sec = function (title, href, more) {
    return '<div class="sec-h"><h2>' + esc(title) + '</h2>' + (href ? '<a href="' + href + '">' + esc(more || 'عرض الكل') + ic('chevron-left', 'sm') + '</a>' : '') + '</div>';
  };
  U.empty = function (msg, icon) { return '<div class="empty">' + ic(icon || 'search') + '<p>' + esc(msg) + '</p></div>'; };
  U.call = function (num, label, cls) { return '<a class="btn ' + (cls || 'pri') + '" href="' + DS.telHref(num) + '">' + ic('phone', 'sm') + esc(label || 'اتصال') + '</a>'; };
  U.wa = function (num, label) { return '<a class="btn wa" href="' + DS.waHref(num) + '" data-act="ext" data-url="' + DS.waHref(num) + '">' + ic('whatsapp', 'sm') + esc(label || 'واتساب') + '</a>'; };
  U.bookHref = function (o) {
    var q = [];
    if (o && o.sp) q.push('sp=' + encodeURIComponent(o.sp));
    if (o && o.dr) q.push('dr=' + encodeURIComponent(o.dr));
    if (o && o.br) q.push('br=' + encodeURIComponent(o.br));
    if (o && o.sv) q.push('sv=' + encodeURIComponent(o.sv));
    return '#/book' + (q.length ? '?' + q.join('&') : '');
  };
  U.avatar = function (d, cls) {
    if (d.photo) return '<span class="avatar ' + (cls || '') + '"><img src="' + esc(d.photo) + '" alt="" loading="lazy" referrerpolicy="no-referrer"></span>';
    return '<span class="avatar ' + (cls || '') + '" aria-hidden="true">' + esc(DS.initials(d.name)) + '</span>';
  };
  U.specChip = function (s) {
    return '<a class="spec-chip" href="#/specialty/' + esc(s.id) + '">' + U.icoBox(s.icon || 'stethoscope') + '<span>' + esc(s.name) + '</span></a>';
  };
  U.docCard = function (d) {
    var sp = D.doctorSpecs(d).map(function (x) { return x.name; }).slice(0, 2).join('، ');
    return '<a class="doc-card" href="#/doctor/' + esc(d.id) + '">' + U.avatar(d) + '<h3 class="sm" style="font-weight:800;line-height:1.5">' + esc(D.docTitle(d)) + '</h3>' +
      '<p class="xs muted" style="margin-top:2px">' + esc(d.rank || '') + (d.rank && sp ? ' · ' : '') + esc(sp) + '</p></a>';
  };
  U.docItem = function (d) {
    var sp = D.doctorSpecs(d).map(function (x) { return x.name; }).join('، ');
    return '<a class="item" href="#/doctor/' + esc(d.id) + '">' + U.avatar(d, 'sm') + '<div class="grow"><h3>' + esc(D.docTitle(d)) + '</h3><p class="sm muted">' +
      esc([d.rank, sp].filter(Boolean).join(' · ')) + '</p></div>' + ic('chevron-left', 'chev') + '</a>';
  };
  U.branchCard = function (b) {
    var wa = b.whatsapp ? U.wa(DS.kbmod.e164(b.whatsapp), 'واتساب') : '';
    return '<div class="card"><a href="#/branch/' + esc(b.id) + '" class="row" style="color:inherit"><span class="ico-box">' + ic('map-pin') + '</span><div class="grow"><h3 style="font-weight:800;line-height:1.5">' + esc(b.name) + '</h3>' +
      '<p class="sm muted">' + esc(b.address || '') + (b.landmark ? ' — ' + esc(b.landmark) : '') + '</p></div>' + ic('chevron-left', 'chev') + '</a>' +
      '<div class="row" style="margin-top:12px;flex-wrap:wrap">' + (b.phone ? U.call(b.phone, 'اتصال', 'ghost sm') : '') + wa.replace('class="btn wa"', 'class="btn wa sm"') +
      '<a class="btn out sm" href="#/branch/' + esc(b.id) + '">' + ic('map-pin', 'sm') + 'الموقع</a></div></div>';
  };
  U.mapQuery = function (b) { return b.lat != null && b.lng != null ? b.lat + ',' + b.lng : (b.mapQuery || (b.name + ' ' + (b.address || ''))); };
  U.gmaps = function (b) { return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(U.mapQuery(b)); };
  U.amaps = function (b) {
    return 'https://maps.apple.com/?q=' + encodeURIComponent(b.name) + (b.lat != null && b.lng != null ? '&ll=' + b.lat + ',' + b.lng : '&address=' + encodeURIComponent(b.mapQuery || b.address || ''));
  };
  U.mapBlock = function (b) {
    var emb = '';
    if (b.lat != null && b.lng != null) {
      var d = 0.004, bbox = [b.lng - d * 1.4, b.lat - d, b.lng + d * 1.4, b.lat + d].map(function (x) { return x.toFixed(6); }).join('%2C');
      emb = '<iframe class="map" loading="lazy" referrerpolicy="no-referrer" title="خريطة ' + esc(b.name) + '" src="https://www.openstreetmap.org/export/embed.html?bbox=' + bbox + '&layer=mapnik&marker=' + b.lat + '%2C' + b.lng + '"></iframe>';
    } else {
      emb = '<div class="mapph">' + ic('map-pin', 'lg') + '<span>افتح الموقع في تطبيق الخرائط</span></div>';
    }
    return emb + '<div class="grid2" style="margin-top:10px"><a class="btn pri" href="' + U.gmaps(b) + '" data-act="ext" data-url="' + U.gmaps(b) + '">' + ic('map-pin', 'sm') + 'خرائط قوقل</a>' +
      '<a class="btn out" href="' + U.amaps(b) + '" data-act="ext" data-url="' + U.amaps(b) + '">' + ic('map-pin', 'sm') + 'خرائط آبل</a></div>';
  };
  DS.acts.ext = function (el) { DS.openExternal(el.getAttribute('data-url')); return false; };
  DS.acts.back = function () { DS.back(); return false; };

  /* ---------- الرئيسية ---------- */
  DS.route('/', function () {
    var s = D.settings(), ds = D.ds, h = '', ph = D.mainPhone();
    if (s.notice) h += '<div class="alert info">' + ic('info', 'sm') + '<div>' + DS.nl(s.notice) + '</div></div>';
    ds.banners.forEach(function (b) {
      var link = b.linkType === 'specialty' ? '#/specialty/' + b.linkRef : b.linkType === 'doctor' ? '#/doctor/' + b.linkRef : b.linkType === 'service' ? '#/service/' + b.linkRef : b.linkType === 'branch' ? '#/branch/' + b.linkRef : '';
      h += '<div class="alert info" style="margin-top:10px">' + ic('sparkle', 'sm') + '<div><b>' + esc(b.title) + '</b><br>' + esc(b.text || '') + (link ? ' <a href="' + esc(link) + '">التفاصيل</a>' : '') +
        (b.linkType === 'url' && /^https:\/\//.test(b.linkRef) ? ' <a href="' + esc(b.linkRef) + '" data-act="ext" data-url="' + esc(b.linkRef) + '">فتح الرابط</a>' : '') + '</div></div>';
    });
    h += '<section class="hero" style="margin-top:' + (h ? '12px' : '0') + '"><span class="crescent">' + DS.moonSvg + '</span><h2>حياك الله في<br>' + esc(s.name || '') + '</h2>' +
      '<p>' + esc(s.city ? 'رعاية صحية متكاملة في ' + s.city + (s.founded ? ' منذ ' + s.founded : '') : '') + '</p>' +
      '<div class="btns"><a class="btn gold" href="#/book">' + ic('calendar-plus', 'sm') + 'احجز موعدك</a>' + (ph ? '<a class="btn light" href="' + DS.telHref(ph) + '">' + ic('phone', 'sm') + 'اتصل بنا</a>' : '') + '</div></section>';
    if (s.dataStatus !== 'verified') h += '<div class="alert warn" style="margin-top:12px">' + ic('info', 'sm') + '<div>بعض معلومات التطبيق قيد المراجعة. للتأكد من المواعيد والأطباء اتصل بالمجمع' + (ph ? ': <b class="ltr" style="display:inline-block">' + esc(ph) + '</b>' : '.') + '</div></div>';
    var em = (ds.services || []).filter(function (x) { return x.id === 'emergency'; })[0];
    h += '<div class="emerg" style="margin-top:12px"><span class="ico">' + ic('alert') + '</span><div class="grow"><b>' + esc(em ? em.name : 'الطوارئ') + '</b><div class="sm">' + esc(em && em.hoursText ? em.hoursText : 'اتصل بنا للتأكد') + '</div></div>' +
      (ph ? '<a class="btn danger sm" href="' + DS.telHref(ph) + '">اتصال</a>' : '') + '</div>' +
      '<p class="xs muted" style="margin-top:6px;text-align:center">الحالات التي تهدد الحياة: اتصل بالإسعاف <a class="ltr" style="display:inline-block;font-weight:800" href="tel:' + esc(s.emergencyNumber || '997') + '">' + esc(s.emergencyNumber || '997') + '</a></p>';
    h += '<div class="grid3 sec">' + [['grid', 'التخصصات', '#/specialties'], ['users', 'الأطباء', '#/doctors'], ['activity', 'الخدمات', '#/services'],
      ['map-pin', 'الفروع', '#/branches'], ['phone', 'التواصل', '#/contact'], ['calendar', 'حجوزاتي', '#/profile']].map(function (t) {
      return '<a class="tile" href="' + t[2] + '"><span class="ico">' + ic(t[0]) + '</span>' + t[1] + '</a>';
    }).join('') + '</div>';
    h += '<section class="sec">' + U.sec('التخصصات', '#/specialties') + '<div class="hs">' + ds.specialties.map(U.specChip).join('') + '</div></section>';
    if (ds.services.length) h += '<section class="sec">' + U.sec('خدماتنا', '#/services') + ds.services.map(function (x) {
      return '<a class="item" href="#/service/' + esc(x.id) + '">' + U.icoBox(x.icon || 'activity') + '<div class="grow"><h3>' + esc(x.name) + '</h3><p class="sm muted">' + esc(x.hoursText || x.description || '') + '</p></div>' + ic('chevron-left', 'chev') + '</a>';
    }).join('') + '</section>';
    if (ds.doctors.length) h += '<section class="sec">' + U.sec('أطباؤنا', '#/doctors') + '<div class="hs">' + ds.doctors.slice(0, 10).map(U.docCard).join('') + '</div></section>';
    h += '<section class="sec">' + U.sec('فروعنا', '#/branches') + ds.branches.map(U.branchCard).join('') + '</section>';
    h += '<section class="sec"><div class="card row" style="background:linear-gradient(135deg,#fff,#EEF7F6)"><span class="ico-box" style="background:var(--teal);color:var(--gold)"><span style="width:26px;height:26px;display:block" class="moonw">' + DS.moonSvg.replace('<svg', '<svg fill="currentColor" stroke="none"') + '</span></span>' +
      '<div class="grow"><b>اسأل قمر</b><p class="sm muted">مساعدك الافتراضي: يرشدك للعيادة المناسبة ويجيب عن أسئلتك.</p></div><button class="btn pri sm" data-act="qamar-open">ابدأ</button></div></section>';
    var st = s.stats || {};
    if (st.patients || st.doctors) h += '<section class="sec"><div class="card stats">' + [[st.patients, 'مراجع', '+'], [st.doctors, 'طبيب', '+'], [st.clinics, 'عيادة', ''], [st.services, 'خدمة', '']].filter(function (x) { return x[0]; }).map(function (x) {
      return '<div><b>' + Number(x[0]).toLocaleString('en-US') + x[2] + '</b><span>' + x[1] + '</span></div>';
    }).join('') + '</div></section>';
    var tips = ds.faqs.filter(function (f) { return f.category === 'tips'; });
    if (tips.length) h += '<section class="sec">' + U.sec('نصائح صحية') + tips.map(function (f) {
      return '<details class="acc"><summary>' + ic('shield', 'sm') + esc(f.question) + '</summary><div class="body">' + DS.nl(f.answer) + '</div></details>';
    }).join('') + '<p class="xs muted" style="margin-top:6px">نصائح عامة منشورة من المجمع وليست تشخيصاً لحالتك.</p></section>';
    h += '<footer class="foot">' + U.socials(s) + '<div>' + esc(s.legalName || s.name || '') + '</div><a href="#/privacy">سياسة الخصوصية</a><div class="xs">الإصدار ' + esc(DS.cfg.version) + '</div></footer>';
    return h;
  }, { tab: 'home' });

  U.socials = function (s) {
    var soc = s.social || {}, h = '';
    [['x', 'x_social', 'إكس'], ['instagram', 'instagram', 'انستغرام'], ['tiktok', 'tiktok', 'تيك توك']].forEach(function (k) {
      if (soc[k[0]] && /^https:\/\//.test(soc[k[0]])) h += '<a href="' + esc(soc[k[0]]) + '" data-act="ext" data-url="' + esc(soc[k[0]]) + '" aria-label="' + k[2] + '">' + ic(k[1]) + '</a>';
    });
    return h ? '<div class="soc">' + h + '</div>' : '';
  };

  /* ---------- التخصصات ---------- */
  DS.route('/specialties', function () {
    var h = '<div class="search">' + ic('search') + '<input class="in" id="q" type="search" placeholder="ابحث عن تخصص أو عَرَض" aria-label="بحث في التخصصات" autocomplete="off"></div><div id="list" class="grid2"></div>';
    setTimeout(function () {
      var inp = DS.$('#q'), list = DS.$('#list');
      function draw() {
        var q = inp.value.trim(), kb = D.kb, items = D.ds.specialties;
        if (q && kb) {
          var toks = kb.an(q), ids = kb.route(toks).map(function (x) { return x[0]; });
          var qn = DS.kbmod.normalize(q);
          items = items.filter(function (s) { return ids.indexOf(s.id) >= 0 || DS.kbmod.normalize(s.name).indexOf(qn) >= 0; });
        }
        list.innerHTML = items.length ? items.map(function (s) {
          return '<a class="tile" href="#/specialty/' + esc(s.id) + '"><span class="ico">' + ic(s.icon || 'stethoscope') + '</span>' + esc(s.name) + '</a>';
        }).join('') : '<div style="grid-column:1/-1">' + U.empty('لا توجد نتيجة. جرّب كلمة أخرى أو اسأل قمر.') + '</div>';
      }
      inp.addEventListener('input', draw); draw();
    }, 0);
    return h;
  }, { tab: 'specialties', title: 'التخصصات' });

  DS.route('/specialty/:id', function (p) {
    var s = D.specialty(p.id);
    if (!s) return U.empty('التخصص غير موجود');
    var docs = D.doctorsOfSpecialty(s.id);
    return '<div class="page-h">' + U.icoBox(s.icon || 'stethoscope') + '<div><h2>' + esc(s.name) + '</h2>' + (s.hoursText ? '<span class="tag gold">' + ic('clock', 'sm') + esc(s.hoursText) + '</span>' : '') + '</div></div>' +
      (s.description ? '<div class="card"><p>' + DS.nl(s.description) + '</p></div>' : '') +
      '<section class="sec">' + U.sec('أطباء العيادة') + (docs.length ? docs.map(U.docItem).join('') : '<div class="card muted sm">لم تُنشر أسماء أطباء هذه العيادة بعد. للاستفسار اتصل بالمجمع.</div>') + '</section>' +
      '<div class="sticky-cta"><a class="btn pri blk" href="' + U.bookHref({ sp: s.id }) + '">' + ic('calendar-plus', 'sm') + 'اطلب حجزاً في ' + esc(s.name) + '</a></div>';
  }, { tab: 'specialties', title: 'التخصص', back: true });

  /* ---------- الأطباء ---------- */
  DS.route('/doctors', function (p, q) {
    var h = '<div class="search">' + ic('search') + '<input class="in" id="q" type="search" placeholder="ابحث باسم الطبيب" aria-label="بحث في الأطباء" autocomplete="off" value="' + esc(q.q || '') + '"></div>' +
      '<div class="chips" id="chips"><button class="chip on" data-sp="">الكل</button>' + D.ds.specialties.filter(function (s) { return D.doctorsOfSpecialty(s.id).length; }).map(function (s) {
        return '<button class="chip" data-sp="' + esc(s.id) + '">' + esc(s.name) + '</button>';
      }).join('') + '</div><div id="list"></div>';
    setTimeout(function () {
      var inp = DS.$('#q'), list = DS.$('#list'), sel = q.sp || '';
      function paint() { DS.$$('#chips .chip').forEach(function (c) { c.classList.toggle('on', c.getAttribute('data-sp') === sel); }); }
      function draw() {
        var v = DS.kbmod.normalize(inp.value);
        var items = D.ds.doctors.filter(function (d) {
          return (!sel || (d.specialtyIds || []).indexOf(sel) >= 0 || (d.serviceIds || []).indexOf(sel) >= 0) && (!v || DS.kbmod.normalize(d.name).indexOf(v) >= 0);
        });
        list.innerHTML = items.length ? items.map(U.docItem).join('') : U.empty('لا يوجد طبيب مطابق');
      }
      DS.$('#chips').addEventListener('click', function (e) { var b = e.target.closest('.chip'); if (b) { sel = b.getAttribute('data-sp'); paint(); draw(); } });
      inp.addEventListener('input', draw); paint(); draw();
    }, 0);
    return h;
  }, { tab: 'doctors', title: 'الأطباء' });

  DS.route('/doctor/:id', function (p) {
    var d = D.doctor(p.id);
    if (!d) return U.empty('الطبيب غير موجود');
    var sps = D.doctorSpecs(d), brs = (d.branchIds || []).map(D.branch).filter(Boolean);
    var first = (d.specialtyIds || [])[0];
    return '<div class="card" style="text-align:center">' + U.avatar(d, 'lg') + '<h2 style="font-size:1.3rem;font-weight:800">' + esc(D.docTitle(d)) + '</h2>' +
      '<div style="margin-top:6px;display:flex;gap:6px;justify-content:center;flex-wrap:wrap">' + (d.rank ? '<span class="tag gold">' + esc(d.rank) + '</span>' : '') + (d.degree ? '<span class="tag gray">' + esc(d.degree) + '</span>' : '') + '</div></div>' +
      (sps.length ? '<section class="sec">' + U.sec('التخصص') + '<div class="chips" style="flex-wrap:wrap;overflow:visible">' + sps.map(function (s) {
        var href = D.specialty(s.id) === s ? '#/specialty/' : '#/service/';
        return '<a class="chip" href="' + href + esc(s.id) + '">' + ic(s.icon || 'stethoscope', 'sm') + esc(s.name) + '</a>';
      }).join('') + '</div></section>' : '') +
      (d.bio ? '<section class="sec"><div class="card"><p>' + DS.nl(d.bio) + '</p></div></section>' : '') +
      (!brs.length ? '<p class="xs muted" style="margin-top:12px;text-align:center">لم يُحدَّد فرع الطبيب في بيانات الموقع؛ يؤكد لك المجمع الفرع والموعد عند التواصل.</p>' : '') +
      (brs.length ? '<section class="sec">' + U.sec('الفروع') + brs.map(function (b) { return '<a class="item" href="#/branch/' + esc(b.id) + '">' + U.icoBox('map-pin') + '<div class="grow"><h3>' + esc(b.name) + '</h3></div>' + ic('chevron-left', 'chev') + '</a>'; }).join('') + '</section>' : '') +
      '<div class="sticky-cta"><a class="btn pri blk" href="' + U.bookHref({ dr: d.id, sp: first }) + '">' + ic('calendar-plus', 'sm') + 'اطلب حجزاً مع ' + esc(D.docTitle(d)) + '</a></div>';
  }, { tab: 'doctors', title: 'الطبيب', back: true });

  /* ---------- الخدمات ---------- */
  DS.route('/services', function () {
    return U.sec('خدمات المجمع') + D.ds.services.map(function (x) {
      return '<a class="item" href="#/service/' + esc(x.id) + '">' + U.icoBox(x.icon || 'activity') + '<div class="grow"><h3>' + esc(x.name) + '</h3><p class="sm muted">' + esc(x.hoursText || x.description || '') + '</p></div>' + ic('chevron-left', 'chev') + '</a>';
    }).join('');
  }, { tab: 'home', title: 'الخدمات' });

  DS.route('/service/:id', function (p) {
    var x = D.service(p.id);
    if (!x) return U.empty('الخدمة غير موجودة');
    var docs = D.doctorsOfService(x.id), ph = D.mainPhone();
    return '<div class="page-h">' + U.icoBox(x.icon || 'activity') + '<div><h2>' + esc(x.name) + '</h2>' + (x.hoursText ? '<span class="tag gold">' + ic('clock', 'sm') + esc(x.hoursText) + '</span>' : '') + '</div></div>' +
      (x.description ? '<div class="card"><p>' + DS.nl(x.description) + '</p></div>' : '') +
      (docs.length ? '<section class="sec">' + U.sec('الأطباء') + docs.map(U.docItem).join('') + '</section>' : '') +
      '<div class="sticky-cta grid2">' + (ph ? U.call(ph, 'اتصل بالمجمع', x.id === 'emergency' ? 'danger' : 'out') : '') + (x.id === 'emergency' ? '' : '<a class="btn pri" href="' + U.bookHref({ sv: x.id }) + '">' + ic('calendar-plus', 'sm') + 'اطلب حجزاً</a>') + '</div>';
  }, { tab: 'home', title: 'الخدمة', back: true });

  /* ---------- الفروع ---------- */
  DS.route('/branches', function () { return U.sec('فروعنا في ' + (D.settings().city || '')) + D.ds.branches.map(U.branchCard).join(''); }, { tab: 'home', title: 'الفروع' });

  DS.route('/branch/:id', function (p) {
    var b = D.branch(p.id);
    if (!b) return U.empty('الفرع غير موجود');
    var wa = b.whatsapp ? U.wa(DS.kbmod.e164(b.whatsapp), 'واتساب الفرع') : '';
    return '<div class="card"><h2 style="font-size:1.2rem;font-weight:800;margin-bottom:10px">' + esc(b.name) + '</h2><div class="kv">' +
      '<div class="r">' + ic('map-pin', 'sm') + '<div>' + esc(b.address || '') + (b.landmark ? '<br><span class="muted sm">' + esc(b.landmark) + '</span>' : '') + '</div></div>' +
      (b.phone ? '<div class="r">' + ic('phone', 'sm') + '<div class="ltr">' + esc(b.phone) + '</div></div>' : '') +
      (b.hoursText ? '<div class="r">' + ic('clock', 'sm') + '<div>' + esc(b.hoursText) + '</div></div>' : '') + '</div></div>' +
      '<section class="sec">' + U.sec('الموقع') + '<div class="card">' + U.mapBlock(b) + '</div></section>' +
      '<div class="sticky-cta grid2">' + (b.phone ? U.call(b.phone, 'اتصال', 'out') : '') + '<a class="btn pri" href="' + U.bookHref({ br: b.id }) + '">' + ic('calendar-plus', 'sm') + 'اطلب حجزاً</a></div>' + (wa ? '<div style="margin-top:10px">' + wa.replace('class="btn wa"', 'class="btn wa blk"') + '</div>' : '');
  }, { tab: 'home', title: 'الفرع', back: true });

  /* ---------- التواصل ---------- */
  DS.route('/contact', function () {
    var s = D.settings(), h = U.sec('أرقام التواصل');
    (s.phones || []).forEach(function (p) {
      var isWa = p.type === 'whatsapp';
      h += '<div class="card row" style="margin-bottom:10px"><span class="ico-box">' + ic(isWa ? 'whatsapp' : 'phone') + '</span><div class="grow"><b>' + esc(p.label) + '</b><div class="ltr sm" style="text-align:start">' + esc(p.number) + '</div></div>' +
        (isWa ? U.wa(DS.kbmod.e164(p.number), 'واتساب').replace('class="btn wa"', 'class="btn wa sm"') : '') + U.call(p.number, 'اتصال', 'ghost sm') + '</div>';
    });
    if (s.email) h += '<a class="item" href="mailto:' + esc(s.email) + '">' + U.icoBox('mail') + '<div class="grow"><h3>البريد الإلكتروني</h3><p class="sm muted ltr" style="text-align:start">' + esc(s.email) + '</p></div></a>';
    h += '<div class="emerg" style="margin-top:12px"><span class="ico">' + ic('alert') + '</span><div class="grow"><b>الحالات الطارئة</b><div class="sm">الإسعاف ' + esc(s.emergencyNumber || '997') + ' · خط وزارة الصحة ' + esc(s.healthLine || '937') + '</div></div><a class="btn danger sm" href="tel:' + esc(s.emergencyNumber || '997') + '">اتصال</a></div>';
    h += '<section class="sec">' + U.sec('الفروع', '#/branches') + D.ds.branches.map(U.branchCard).join('') + '</section>' + U.socials(s);
    return h;
  }, { tab: 'home', title: 'التواصل' });

  /* ---------- عن المجمع ---------- */
  DS.route('/about', function () {
    var s = D.settings(), st = s.stats || {};
    return '<div class="card"><h2 style="font-size:1.2rem;font-weight:800;color:var(--teal-d)">' + esc(s.name || '') + '</h2>' + (s.legalName ? '<p class="sm muted">' + esc(s.legalName) + (s.founded ? ' · تأسست عام ' + esc(s.founded) : '') + '</p>' : '') +
      '<p style="margin-top:10px">' + DS.nl(s.about || '') + '</p></div>' +
      (s.mission ? '<div class="card"><h3 style="font-weight:800">رسالتنا</h3><p>' + DS.nl(s.mission) + '</p></div>' : '') +
      (s.vision ? '<div class="card"><h3 style="font-weight:800">رؤيتنا</h3><p>' + DS.nl(s.vision) + '</p></div>' : '') +
      ((s.values || []).length ? '<div class="card"><h3 style="font-weight:800;margin-bottom:8px">قيمنا</h3><div style="display:flex;flex-wrap:wrap;gap:8px">' + s.values.map(function (v) { return '<span class="tag">' + esc(typeof v === 'string' ? v : (v.title || v.name || '')) + '</span>'; }).join('') + '</div></div>' : '') +
      (st.patients ? '<div class="card stats">' + [[st.patients, 'مراجع', '+'], [st.doctors, 'طبيب', '+'], [st.clinics, 'عيادة', ''], [st.services, 'خدمة', '']].filter(function (x) { return x[0]; }).map(function (x) {
        return '<div><b>' + Number(x[0]).toLocaleString('en-US') + x[2] + '</b><span>' + x[1] + '</span></div>'; }).join('') + '</div>' : '') +
      '<p class="xs muted" style="margin-top:12px;text-align:center">المعلومات مأخوذة من الموقع الرسمي للمجمعات.</p>';
  }, { tab: 'home', title: 'عن المجمعات' });
})(window);
