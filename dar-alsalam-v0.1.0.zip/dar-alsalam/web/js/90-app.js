/* هيكل التطبيق: الشريط العلوي، التبويبات، التشغيل، التحديث الخلفي */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon;
  var TABS = [
    ['home', 'الرئيسية', '#/', 'home'],
    ['specialties', 'التخصصات', '#/specialties', 'grid'],
    ['book', 'احجز', '#/book', 'calendar-plus'],
    ['doctors', 'الأطباء', '#/doctors', 'users'],
    ['profile', 'حسابي', '#/profile', 'user']
  ];

  function shell() {
    DS.$('#app').innerHTML = '<header class="bar" id="bar"></header><div class="ribbon" id="ribbon" hidden></div><main id="view" tabindex="-1"></main>' +
      '<nav class="tabs" id="tabs" aria-label="التنقل الرئيسي">' + TABS.map(function (t) {
        return '<a class="tab' + (t[0] === 'book' ? ' cta' : '') + '" data-tab="' + t[0] + '" href="' + t[2] + '">' +
          (t[0] === 'book' ? '<span class="pill">' + ic(t[3]) + '</span>' : ic(t[3])) + '<span>' + t[1] + '</span></a>';
      }).join('') + '</nav>';
  }

  DS.onRoute = function (cur) {
    var m = cur.meta || {}, s = D.settings(), bar = DS.$('#bar');
    var title = m.title || s.name || 'دار السلام';
    if (!bar) return;
    bar.innerHTML = (m.back ? '<button class="ib" data-act="back" aria-label="رجوع">' + ic('back') + '</button>' : '<img class="logo-s" src="img/icon.svg" alt="">') +
      '<h1>' + esc(title) + '</h1><a class="ib" href="#/notifications" aria-label="الإشعارات">' + ic('bell') + '<span class="badge-dot" id="nbadge" hidden></span></a>';
    DS.notif.setBadge(DS.notif.unread);
    DS.$$('#tabs .tab').forEach(function (a) {
      var on = a.getAttribute('data-tab') === m.tab;
      a.classList.toggle('on', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    ribbon();
    DS.qamar.onRoute(cur);
    document.title = title + (m.title ? ' — ' + (s.shortName || s.name || '') : '') + (DS.cfg.demo ? ' (نسخة تجريبية)' : '');
    var v = DS.$('#view'); if (v && v.focus) { try { v.focus({ preventScroll: true }); } catch (e) { /* تجاهل */ } }
  };

  function ribbon() {
    var r = DS.$('#ribbon'), app = DS.$('#app'); if (!r) return;
    var draft = D.settings().dataStatus !== 'verified';
    r.hidden = !draft; app.classList.toggle('has-ribbon', draft);
    r.textContent = DS.cfg.demo ? 'نسخة تجريبية — بيانات قيد المراجعة ولا يُرسل شيء' : 'بيانات قيد المراجعة — للتأكد من المواعيد اتصل بالمجمع';
  }

  DS.acts.reload = function () { root.location.reload(); return false; };

  function fatal() {
    DS.$('#app').innerHTML = '<div class="splash"><div style="padding:24px"><h2 style="font-weight:800">تعذر تحميل التطبيق</h2><p class="muted" style="margin:8px 0 16px">تحقق من الاتصال ثم أعد المحاولة.</p>' +
      '<button class="btn pri" data-act="reload">إعادة المحاولة</button><p style="margin-top:16px">أو اتصل بالمجمع: <a class="ltr" style="display:inline-block" href="tel:920031134">920031134</a></p></div></div>';
  }

  function refreshView() {
    var cur = DS.current(); if (!cur || cur.path === '/book') return;   // لا نعيد رسم نموذج الحجز أثناء الكتابة
    var y = root.scrollY; DS.render(); root.scrollTo(0, y);
  }

  function start() {
    shell();
    DS.qamar.init();
    D.onChange(refreshView);
    DS.startRouter();
    if (!DS.cfg.demo) {
      D.refresh();
      DS.notif.refreshBadge();
      setInterval(function () { if (!document.hidden) { DS.notif.refreshBadge(); } }, 60000);
      document.addEventListener('visibilitychange', function () { if (!document.hidden) { D.refresh(); DS.notif.refreshBadge(); } });
      root.addEventListener('online', function () { D.refresh(); DS.notif.refreshBadge(); });
    }
    /* زر الرجوع في أندرويد (داخل التطبيق الأصلي فقط) */
    var A = DS.cap('App');
    if (A && A.addListener) {
      A.addListener('backButton', function () {
        if (DS.qamar.isOpen) { DS.qamar.close(); return; }
        var cur = DS.current();
        if (cur && cur.path !== '/') DS.back(); else if (A.exitApp) A.exitApp();
      });
    }
    /* التخزين المؤقت للتشغيل بدون إنترنت — في المتصفح فقط وليس داخل التطبيق الأصلي */
    if ('serviceWorker' in navigator && !DS.isNative() && !DS.cfg.demo && /^https?:$/.test(root.location.protocol)) {
      navigator.serviceWorker.register('sw.js').catch(function () { /* اختياري */ });
    }
  }

  DS.boot = function () {
    D.load().then(start).catch(function () { fatal(); });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', DS.boot); else DS.boot();
})(window);
