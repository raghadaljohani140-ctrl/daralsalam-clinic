/* عامل خدمة بسيط: يخزّن واجهة التطبيق للتشغيل السريع وبدون إنترنت. لا يخزّن طلبات الـ API. */
const VERSION = "ds-0.1.0-dev";
const SHELL = ["./", "index.html", "config.js", "css/app.css", "js/00-core.js", "js/20-kb.js", "js/10-data.js", "js/30-views.js", "js/40-booking.js",
  "js/50-qamar.js", "js/90-app.js", "data/seed.public.json", "data/lexicon.json", "img/icon.svg", "manifest.webmanifest"];
self.addEventListener("install", e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== location.origin || u.pathname.includes("/api/")) return;
  e.respondWith(caches.match(r).then(hit => {
    const net = fetch(r).then(res => { if (res.ok) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(r, copy)); } return res; }).catch(() => hit);
    return hit || net;
  }));
});
