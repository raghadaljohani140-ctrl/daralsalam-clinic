#!/usr/bin/env bash
# تثبيت خادم دار السلام على Linux (Ubuntu/Debian). يُنفَّذ مرة واحدة وآمن لإعادة التنفيذ عند الترقية:
#   sudo ./install.sh
# على خادم يشغّل مشاريع أخرى: اختر منفذاً حراً، ودع الخادم يثق برأس الوسيط (Caddy/nginx) لأنه سيقف أمامه:
#   sudo DS_PORT=8431 DS_TRUST_PROXY=1 ./install.sh
# يلمس فقط: مجلد التطبيق (APP_DIR)، ومستخدم النظام (SVC_USER)، ووحدات systemd الثلاث: daralsalam وdaralsalam-backup (خدمة ومؤقّت).
# لا يلمس Caddy ولا nginx ولا أي خدمة أخرى، ولا يشتري شيئاً ولا يفتح حسابات.
# متغيرات اختيارية:
#   APP_DIR (الافتراضي /opt/daralsalam)   SVC_USER (الافتراضي daralsalam)
#   DS_PORT (الافتراضي 8080)             DS_TRUST_PROXY=1  — يُكتبان في .env الجديد فقط (لا يُعدَّل .env موجود)
#   NO_SYSTEMD=1  ينسخ الملفات ويجهّز القاعدة فقط، دون مستخدم نظام ولا systemd (للتجربة).
#   UNIT_DIR (الافتراضي /etc/systemd/system) — لاختبار التثبيت دون لمس النظام.
# جُرّب بوضع NO_SYSTEMD=1 وبمحاكاة أوامر النظام (useradd/systemctl/sudo/chown) في بيئة البناء؛ لم يُجرَّب على خادم حقيقي. راجعه قبل التنفيذ.
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/daralsalam}"
SVC_USER="${SVC_USER:-daralsalam}"
UNIT_DIR="${UNIT_DIR:-/etc/systemd/system}"
PORT="${DS_PORT:-8080}"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || true)"
NO_SYSTEMD="${NO_SYSTEMD:-0}"

[ -n "$PY" ] || { echo "python3 غير مثبّت. ثبّته أولاً (sudo apt install python3)."; exit 1; }
case "$PORT" in ''|*[!0-9]*) echo "DS_PORT يجب أن يكون رقماً بين 1024 و65535 (المعطى: $PORT)"; exit 1;; esac
if [ "$PORT" -lt 1024 ] || [ "$PORT" -gt 65535 ]; then echo "DS_PORT يجب أن يكون بين 1024 و65535 (المعطى: $PORT)"; exit 1; fi
if [ "$NO_SYSTEMD" != "1" ] && [ "$(id -u)" -ne 0 ]; then
  echo "نفّذ السكربت بصلاحية root:  sudo ./install.sh"; exit 1
fi

# هل المنفذ مشغول على 127.0.0.1؟ (نجرّب ربطه فعلاً، وهذا هو بالضبط ما سيفعله الخادم عند البدء)
port_busy() {
  "$PY" - "$1" <<'PYEOF'
import socket, sys
s = socket.socket()
try:
    s.bind(("127.0.0.1", int(sys.argv[1])))
except OSError:
    sys.exit(0)   # مشغول
sys.exit(1)       # حرّ
PYEOF
}

if [ "$NO_SYSTEMD" != "1" ]; then
  UPGRADE=0
  if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet daralsalam 2>/dev/null; then UPGRADE=1; fi
  if [ "$UPGRADE" = "0" ] && port_busy "$PORT"; then
    echo "المنفذ $PORT مشغول بخدمة أخرى على هذا الخادم، ولن أكتب فوقها. اختر منفذاً حراً ثم أعد التنفيذ، مثلاً:"
    echo "    sudo DS_PORT=8431 DS_TRUST_PROXY=1 ./install.sh"
    exit 1
  fi
fi

echo "== 1/5 نسخ الملفات التشغيلية إلى $APP_DIR (بلا أدوات التطوير ولا مجلد الجوال)"
mkdir -p "$APP_DIR/data"
for d in server web admin widget deploy; do
  rm -rf "${APP_DIR:?}/$d"
  cp -a "$SRC_DIR/$d" "$APP_DIR/$d"
done
find "$APP_DIR" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
rm -rf "$APP_DIR/server/tests"
chmod +x "$APP_DIR/deploy/backup.sh"   # قد تضيع صلاحية التنفيذ عند الرفع عبر المتصفح أو zip
cp -f "$SRC_DIR/data/seed.json" "$SRC_DIR/data/lexicon.json" "$APP_DIR/data/"
cp -f "$SRC_DIR/.env.example" "$APP_DIR/.env.example"

echo "== 2/5 ملف الإعدادات"
if [ ! -f "$APP_DIR/.env" ]; then
  cp "$SRC_DIR/.env.example" "$APP_DIR/.env"
  if [ "$PORT" != "8080" ]; then echo "DS_PORT=$PORT" >> "$APP_DIR/.env"; fi
  if [ "${DS_TRUST_PROXY:-0}" = "1" ]; then echo "DS_TRUST_PROXY=1" >> "$APP_DIR/.env"; fi
  echo "   أُنشئ $APP_DIR/.env (الباقي افتراضي). عدّله عند الحاجة: مفاتيح قمر إن وافقت عليها."
  if [ "${DS_TRUST_PROXY:-0}" != "1" ]; then
    echo "   لم يُفعَّل DS_TRUST_PROXY. إن وضعت Caddy/nginx أمام الخدمة أضف سطراً مستقلاً DS_TRUST_PROXY=1 في .env (انظر docs/DEPLOY.md)."
  fi
else
  echo "   $APP_DIR/.env موجود، لم يُمسّ (ما في الملف هو المعتمد: المنفذ وغيره)."
fi
chmod 600 "$APP_DIR/.env"
# المنفذ الفعلي كما في .env (آخر سطر DS_PORT=)، وإلا 8080
EP="$(grep -E '^DS_PORT=' "$APP_DIR/.env" | tail -n1 | cut -d= -f2- | tr -d '[:space:]"' || true)"
EP="${EP:-8080}"

if [ "$NO_SYSTEMD" != "1" ]; then
  echo "== 3/5 مستخدم الخدمة وصلاحياته"
  id "$SVC_USER" >/dev/null 2>&1 || useradd --system --home-dir "$APP_DIR" --shell /usr/sbin/nologin "$SVC_USER"
  chown -R "$SVC_USER":"$SVC_USER" "$APP_DIR/data" "$APP_DIR/.env"
  RUN=(sudo -u "$SVC_USER")
else
  echo "== 3/5 (تخطّي مستخدم الخدمة: NO_SYSTEMD=1)"
  RUN=()
fi

echo "== 4/5 تهيئة قاعدة البيانات وكلمة مرور الإدارة"
"${RUN[@]}" "$PY" "$APP_DIR/server/manage.py" init

if [ "$NO_SYSTEMD" != "1" ]; then
  echo "== 5/5 تشغيل الخدمة والنسخ الاحتياطي اليومي"
  mkdir -p "$UNIT_DIR"
  for u in daralsalam.service daralsalam-backup.service daralsalam-backup.timer; do
    sed -e "s#/opt/daralsalam#$APP_DIR#g" -e "s#^User=.*#User=$SVC_USER#" -e "s#^Group=.*#Group=$SVC_USER#" \
        -e "s#^ExecStart=/usr/bin/python3#ExecStart=$PY#" "$SRC_DIR/deploy/$u" > "$UNIT_DIR/$u"
  done
  # إصدار سابق من هذا السكربت كان يستخدم cron؛ نزيله كي لا تتكرر النسخ
  rm -f /etc/cron.d/daralsalam-backup
  systemctl daemon-reload
  systemctl enable --now daralsalam
  systemctl enable --now daralsalam-backup.timer
  echo "   نسخة احتياطية يومية (مؤقّت systemd، 03:17 بتوقيت الخادم) إلى $APP_DIR/data/backups — انقل نسخاً منها خارج الخادم."
  ok=0
  for _ in 1 2 3 4 5 6 7 8; do
    if "$PY" -c "import sys,urllib.request; sys.exit(0 if b'\"ok\"' in urllib.request.urlopen('http://127.0.0.1:$EP/api/v1/health', timeout=2).read() else 1)" 2>/dev/null; then ok=1; break; fi
    sleep 1
  done
  if [ "$ok" = "1" ]; then
    echo "   الخدمة تعمل وتردّ على 127.0.0.1:$EP."
  else
    echo "   تحذير: لم تردّ الخدمة على 127.0.0.1:$EP بعد. راجع:  journalctl -u daralsalam -n 50 --no-pager"
  fi
else
  echo "== 5/5 (تخطّي systemd: NO_SYSTEMD=1). للتشغيل:  python3 $APP_DIR/server/app.py"
fi
echo "تم. الخطوة التالية: ضع Caddy أو nginx أمام 127.0.0.1:$EP (docs/GO-LIVE-ar.md) ثم افتح /admin/ بكلمة المرور المعروضة أعلاه."
