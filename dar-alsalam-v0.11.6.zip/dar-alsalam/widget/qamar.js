/* ويدجت «قمر» لموقع المجمع — ملف واحد مستقل، بلا مكتبات ولا خدمات خارجية.

   الإضافة إلى أي صفحة بسطر واحد:
       <script src="https://HOST/widget/qamar.js" defer></script>

   خيارات اختيارية على وسم script نفسه:
       data-api="https://HOST/api/v1"   عنوان الخادم                        (الافتراضي: مصدر هذا الملف + /api/v1)
       data-app="https://HOST/app/"     عنوان التطبيق لصفحات الحجز والتفاصيل (الافتراضي: مصدر هذا الملف + /app/)
       data-side="left|right"           مكان الأيقونة                        (الافتراضي: left)

   • يعمل داخل Shadow DOM: لا يتأثر بتنسيقات الموقع ولا يغيّرها.
   • لا كوكيز ولا تتبع. المحادثة تُحفظ في sessionStorage فقط (تُمسح بإغلاق التبويب).
   • إن تعذّر الوصول للخادم، أو عُطّل قمر من لوحة الإدارة: لا يظهر شيء في الصفحة.
   • كل نصوص الخادم تُعرض كنص خام (textContent) — لا HTML قادم من الخادم يُنفَّذ أبداً.
   • واجهة صغيرة: window.DSQamar.open() / close() / ask("نص")                                         */
(function (w, d) {
  'use strict';
  if (w.DSQamar) return;                                  // منع التحميل المزدوج

  var VERSION = '0.11.6';
  var me = d.currentScript;
  if (!me) {
    var all = d.getElementsByTagName('script');
    for (var i = all.length - 1; i >= 0; i--) { if (/qamar(\.min)?\.js(\?|#|$)/.test(all[i].src || '')) { me = all[i]; break; } }
  }
  var origin;
  try { origin = new URL(me.src, w.location.href).origin; } catch (e) { return; }
  function attr(n, dflt) { var v = me && me.getAttribute('data-' + n); return v ? String(v).trim() : dflt; }
  function httpUrl(u, dflt) { return /^https?:\/\//i.test(u) ? u : dflt; }
  var API = httpUrl(attr('api', ''), origin + '/api/v1').replace(/\/+$/, '');
  var APP = httpUrl(attr('app', ''), origin + '/app/'); if (!/\/$/.test(APP)) APP += '/';
  var SIDE = attr('side', 'left') === 'right' ? 'right' : 'left';

  /* ---------- تخزين مؤقت للجلسة فقط ---------- */
  var mem = {};
  function sget(k) { try { return w.sessionStorage.getItem(k); } catch (e) { return mem[k] || null; } }
  function sset(k, v) { try { w.sessionStorage.setItem(k, v); } catch (e) { mem[k] = v; } }
  function rnd(n) {
    var s = '', j;
    try { var a = new Uint8Array(n / 2); w.crypto.getRandomValues(a); for (j = 0; j < a.length; j++) s += ('0' + a[j].toString(16)).slice(-2); return s; }
    catch (e) { s = ''; for (j = 0; j < n; j++) s += Math.floor(Math.random() * 16).toString(16); return s; }
  }
  function deviceId() {
    var v = sget('dsq_did');
    if (!v || !/^web_[a-f0-9]{24}$/.test(v)) { v = 'web_' + rnd(24); sset('dsq_did', v); }
    return v;
  }

  /* ---------- أيقونات (ثوابت داخلية فقط) ---------- */
  var P = {
    moon: '<path d="M20.2 14.2A8.6 8.6 0 1 1 9.8 3.8a7.1 7.1 0 0 0 10.4 10.4z"/><path d="M18 3.2l.7 1.8 1.8.7-1.8.7L18 8.2l-.7-1.8-1.8-.7 1.8-.7z"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    send: '<path d="M21 3L10 14"/><path d="M21 3l-7 18-4-7-7-4 18-7z"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    cal: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4M12 13v5M9.5 15.5h5"/>',
    pin: '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/>',
    steth: '<path d="M6 3v6a4 4 0 0 0 8 0V3"/><path d="M10 13v2a4 4 0 0 0 8 0v-1"/><circle cx="18" cy="12" r="2"/>',
    act: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    wa: '<path d="M4 20l1.3-4.2A8 8 0 1 1 8.4 18.8L4 20z"/><path d="M9.3 8.9c.3 2.3 2.7 4.7 5.1 5.1l1.2-1.2-2-1-.9.6a4.4 4.4 0 0 1-1.9-1.9l.6-.9-1-2-1.1 1.3z"/>'
  };
  function ico(n, fill) { return '<svg class="ic' + (fill ? ' fill' : '') + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (P[n] || '') + '</svg>'; }

  var CSS = [
    ':host{all:initial}',
    '*{box-sizing:border-box}',
    '[hidden]{display:none!important}',
    '.wrap{position:fixed;bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:2147483000;direction:rtl;text-align:right;',
    'font-family:system-ui,-apple-system,"Segoe UI",Tahoma,"Noto Sans Arabic","Noto Naskh Arabic",Arial,sans-serif;font-size:15px;line-height:1.7;color:#1B2B36;-webkit-text-size-adjust:100%}',
    '.wrap.left{left:16px}.wrap.right{right:16px}',
    'button,textarea{font:inherit;color:inherit}button{cursor:pointer}',
    '.ic{width:18px;height:18px;flex:none;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.ic.fill{fill:currentColor;stroke:none}',
    '.fab{position:relative;display:flex;align-items:center;gap:8px;height:54px;padding:0 18px 0 14px;border:0;border-radius:27px;background:linear-gradient(135deg,#0A67B0,#064A85);color:#fff;font-weight:700;box-shadow:0 8px 24px rgba(6,74,133,.35);transition:transform .15s}',
    '.fab:hover{transform:translateY(-2px)}.fab:focus-visible,.x:focus-visible,.send:focus-visible,.act:focus-visible,.qr button:focus-visible{outline:3px solid #0396C4;outline-offset:2px}',
    '.fab .moon{width:28px;height:28px;color:#F2C14E;display:flex}.fab .moon .ic{width:100%;height:100%}',
    '.fab.pulse::after{content:"";position:absolute;inset:0;border-radius:inherit;box-shadow:0 0 0 0 rgba(10,103,176,.55);animation:pulse 2s ease-out 3;pointer-events:none}',
    '@keyframes pulse{to{box-shadow:0 0 0 16px rgba(10,103,176,0)}}',
    '.panel{position:absolute;bottom:0;width:372px;max-width:calc(100vw - 32px);height:min(580px,calc(100vh - 32px));display:flex;flex-direction:column;background:#fff;border-radius:20px;overflow:hidden;border:1px solid rgba(10,103,176,.18);box-shadow:0 18px 50px rgba(6,74,133,.28)}',
    '.wrap.left .panel{left:0}.wrap.right .panel{right:0}',
    'header{display:flex;align-items:center;gap:10px;padding:12px 14px;background:linear-gradient(135deg,#0A67B0,#064A85);color:#fff}',
    'header .moon{width:38px;height:38px;border-radius:50%;background:rgba(242,193,78,.2);color:#F2C14E;display:flex;align-items:center;justify-content:center}header .moon .ic{width:24px;height:24px}',
    'header b{display:block;font-size:16px;line-height:1.3}header small{display:block;opacity:.85;font-size:12px;line-height:1.3}',
    '.hb{margin-inline-start:auto;display:flex;gap:2px}.x{width:36px;height:36px;border:0;border-radius:10px;background:transparent;color:#fff;display:flex;align-items:center;justify-content:center}.x:hover{background:rgba(255,255,255,.14)}',
    '.msgs{flex:1;overflow-y:auto;overscroll-behavior:contain;padding:14px 12px;background:#F2F6FA;display:flex;flex-direction:column;gap:10px}',
    '.m{max-width:88%;padding:9px 13px;border-radius:16px;word-wrap:break-word;overflow-wrap:anywhere}',
    '.m .t{white-space:pre-wrap}',
    '.m.bot{align-self:flex-start;background:#fff;border:1px solid #DFE7EF;border-top-right-radius:4px}',
    '.m.me{align-self:flex-end;background:#0A67B0;color:#fff;border-top-left-radius:4px;white-space:pre-wrap}',
    '.src{display:block;margin-top:6px;font-size:11px;color:#586977}',
    '.acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}',
    '.act{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:999px;border:1.5px solid #0A67B0;color:#064A85;background:#fff;font-size:13px;font-weight:600;text-decoration:none}',
    '.act:hover{background:#E7F1FA}.act.book{background:#0A67B0;color:#fff}.act.book:hover{background:#064A85}',
    '.act.em{border-color:#C0392B;color:#fff;background:#C0392B}.act.wa{border-color:#1E9E5A;color:#0F6B3B}',
    '.typing{display:flex;gap:4px;align-items:center;padding:12px 14px}.typing i{width:7px;height:7px;border-radius:50%;background:#8DA9C2;animation:bl 1.1s infinite ease-in-out}.typing i:nth-child(2){animation-delay:.15s}.typing i:nth-child(3){animation-delay:.3s}',
    '@keyframes bl{0%,80%,100%{opacity:.25;transform:translateY(0)}40%{opacity:1;transform:translateY(-3px)}}',
    '.qr{display:flex;gap:6px;padding:8px 10px 2px;overflow-x:auto;background:#F2F6FA;scrollbar-width:none}.qr:empty{display:none}.qr::-webkit-scrollbar{display:none}',
    '.qr button{flex:none;border:1.5px solid #BFD8EE;background:#fff;color:#064A85;border-radius:999px;padding:5px 12px;font-size:13px;white-space:nowrap}.qr button:hover{background:#E7F1FA}',
    '.disc{padding:5px 14px 7px;background:#F2F6FA;font-size:11px;line-height:1.5;color:#586977;display:flex;gap:8px;justify-content:space-between;flex-wrap:wrap}.disc a{color:#064A85}',
    '.composer{display:flex;gap:8px;align-items:flex-end;padding:10px 12px;border-top:1px solid #DFE7EF;background:#fff}',
    'textarea{flex:1;resize:none;border:1.5px solid #C9D8E6;border-radius:14px;padding:9px 12px;max-height:110px;min-height:42px;background:#fff;outline:none;direction:rtl}textarea:focus{border-color:#0A67B0}',
    '.send{width:42px;height:42px;border:0;border-radius:50%;background:#0A67B0;color:#fff;display:flex;align-items:center;justify-content:center;flex:none}.send:disabled{opacity:.5;cursor:default}.send .ic{transform:scaleX(-1)}',
    '@media (max-width:520px){.panel{position:fixed;left:0;right:0;bottom:0;width:auto;max-width:none;height:86vh;border-radius:20px 20px 0 0}textarea{font-size:16px}}',
    '@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}'
  ].join('');

  /* ---------- الحالة ---------- */
  var cfg = null, hist = [], busy = false, isOpen = false, built = false, wantOpen = false;
  var host, sh, wrap, fab, panel, msgs, qr, input, form, sendBtn, lastFocus = null;
  try { hist = JSON.parse(sget('dsq_hist') || '[]'); if (!Array.isArray(hist)) hist = []; } catch (e) { hist = []; }
  function persist() { sset('dsq_hist', JSON.stringify(hist.slice(-24))); }
  function ctx() { return hist.slice(-8).map(function (m) { return { role: m.r === 'me' ? 'user' : 'assistant', content: String(m.t || '').slice(0, 500) }; }); }
  function el(tag, cls, text) { var e = d.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function name() { return (cfg && cfg.name) || 'قمر'; }
  function emNo() { return (cfg && cfg.emergencyNumber) || '997'; }
  function greeting() { return (cfg && cfg.greeting) || 'هلا! أنا قمر، المساعد الافتراضي. أساعدك تعرف التخصص المناسب والأطباء والفروع. ما أقدّم تشخيصاً ولا أصف أدوية.'; }
  function defaultChips() { return cfg && cfg.quickReplies && cfg.quickReplies.length ? cfg.quickReplies : ['أبي أحجز موعد', 'وين الفروع؟', 'وش التخصصات؟', 'أرقام التواصل']; }

  /* ---------- أزرار الإجراءات: روابط تُبنى من قوالب ثابتة + قيم مُرمَّزة فقط ---------- */
  var NAV = { specialties: 1, doctors: 1, services: 1, about: 1, branches: 1, contact: 1 };
  function enc(s) { return encodeURIComponent(String(s == null ? '' : s).slice(0, 80)); }
  function digits(s) { return String(s || '').replace(/[^\d+]/g, '').slice(0, 20); }
  function validPhone(n) { return /^\+?\d{3,16}$/.test(n); }
  function link(href, cls, icon, label, ext) {
    var a = el('a', 'act' + (cls ? ' ' + cls : ''));
    a.href = href;
    a.insertAdjacentHTML('afterbegin', ico(icon));
    a.appendChild(d.createTextNode(label));
    if (ext) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
    return a;
  }
  function actNode(a) {
    if (!a || typeof a !== 'object') return null;
    var label = String(a.label || '').slice(0, 60); if (!label) return null;
    var id = a.id ? enc(a.id) : '';
    switch (a.type) {
      case 'book':
        var q = [];
        if (a.specialtyId) q.push('sp=' + enc(a.specialtyId));
        if (a.doctorId) q.push('dr=' + enc(a.doctorId));
        if (a.branchId) q.push('br=' + enc(a.branchId));
        return link(APP + '#/book' + (q.length ? '?' + q.join('&') : ''), 'book', 'cal', label, true);
      case 'slot':        // موعد رتّبه قمر من نظام المواعيد: يفتح صفحة الحجز في التطبيق معبّأً، والمراجع هو من يؤكد
        if (!a.doctorId || !/^\d{4}-\d{2}-\d{2}$/.test(String(a.day || '')) || !/^\d{2}:\d{2}$/.test(String(a.start || ''))) return null;
        var sq = [];
        if (a.specialtyId) sq.push('sp=' + enc(a.specialtyId));
        sq.push('dr=' + enc(a.doctorId));
        if (a.branchId) sq.push('br=' + enc(a.branchId));
        sq.push('day=' + a.day, 't=' + enc(a.start));
        return link(APP + '#/book?' + sq.join('&'), 'slot', 'cal', label, true);
      case 'call': var n = digits(a.number); return validPhone(n) ? link('tel:' + n, '', 'phone', label) : null;
      case 'emergency': var e = digits(a.number); return validPhone(e) ? link('tel:' + e, 'em', 'phone', label) : null;
      case 'whatsapp': var wn = String(a.number || '').replace(/\D/g, '').slice(0, 15); return wn.length >= 8 ? link('https://wa.me/' + wn, 'wa', 'wa', label, true) : null;
      case 'specialty': return id ? link(APP + '#/specialty/' + id, '', 'steth', label, true) : null;
      case 'doctor': return id ? link(APP + '#/doctor/' + id, '', 'user', label, true) : null;
      case 'branch': return id ? link(APP + '#/branch/' + id, '', 'pin', label, true) : null;
      case 'service': return id ? link(APP + '#/service/' + id, '', 'act', label, true) : null;
      case 'nav': return NAV[a.to] === 1 ? link(APP + '#/' + a.to, '', 'act', label, true) : null;
      default: return null;
    }
  }

  /* ---------- الرسائل ---------- */
  function renderMsg(m) {
    var b = el('div', 'm ' + (m.r === 'me' ? 'me' : 'bot'));
    if (m.r === 'me') { b.textContent = String(m.t || ''); return b; }
    b.appendChild(el('span', 't', String(m.t || '')));
    if (m.s === 'llm') b.appendChild(el('span', 'src', 'رد آلي بالذكاء الاصطناعي — تأكد من المعلومات المهمة مع المجمع'));
    var nodes = (Array.isArray(m.a) ? m.a : []).map(actNode).filter(Boolean).slice(0, 6);
    if (nodes.length) { var box = el('div', 'acts'); nodes.forEach(function (n) { box.appendChild(n); }); b.appendChild(box); }
    return b;
  }
  function scrollEnd() { if (msgs) msgs.scrollTop = msgs.scrollHeight; }
  function typing(on) {
    if (!msgs) return;
    var t = msgs.querySelector('.typing');
    if (on && !t) { t = el('div', 'm bot typing'); t.setAttribute('aria-label', name() + ' يكتب'); t.innerHTML = '<i></i><i></i><i></i>'; msgs.appendChild(t); scrollEnd(); }
    if (!on && t) t.remove();
  }
  function add(m) { hist.push(m); persist(); if (msgs) { typing(false); msgs.appendChild(renderMsg(m)); scrollEnd(); } }
  function chips(list) {
    if (!qr) return;
    qr.textContent = '';
    (list || []).slice(0, 6).forEach(function (c) {
      var b = el('button', '', String(c).slice(0, 60)); b.type = 'button';
      b.addEventListener('click', function () { ask(c); });
      qr.appendChild(b);
    });
  }
  function finish(r) {
    busy = false; if (sendBtn) sendBtn.disabled = false;
    chips(r.emergency ? [] : (r.chips && r.chips.length ? r.chips : defaultChips()));   // قبل الإضافة حتى يبقى التمرير صحيحاً
    add({ r: 'bot', t: r.text, a: r.actions || [], s: r.source || 'kb' });
  }
  function fallback(msg) {
    var acts = [];
    if (cfg && cfg.mainPhone) acts.push({ type: 'call', number: cfg.mainPhone, label: 'اتصال بالمجمع ' + cfg.mainPhone });
    return { text: (msg || 'تعذّر الاتصال بالمساعد الآن.') + ' تقدر تتصل بالمجمع مباشرة' + (cfg && cfg.mainPhone ? ' على ' + cfg.mainPhone : '') + '. وإن كانت حالة طارئة فاتصل بالإسعاف ' + emNo() + ' فوراً.', actions: acts, chips: [], source: 'kb' };
  }

  /* ---------- الاتصال بالخادم ---------- */
  function post(path, body, ms) {
    var ctl = w.AbortController ? new AbortController() : null;
    var timer = ctl ? setTimeout(function () { ctl.abort(); }, ms || 15000) : null;
    return fetch(API + path, { method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer',
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctl ? ctl.signal : undefined })
      .then(function (r) { if (timer) clearTimeout(timer); return r.json().catch(function () { return {}; }).then(function (j) { return { status: r.status, json: j }; }); },
        function (e) { if (timer) clearTimeout(timer); throw e; });
  }
  function ask(text) {
    text = String(text || '').trim().slice(0, 600);
    if (!built || !text || busy) return;
    open();
    busy = true; if (sendBtn) sendBtn.disabled = true;
    chips([]);
    var history = ctx();                       // قبل إضافة سؤال المستخدم: الخادم يضيفه بنفسه
    add({ r: 'me', t: text });
    typing(true);
    post('/qamar', { message: text, deviceId: deviceId(), history: history }).then(function (res) {
      var rep = res.json && res.json.reply;
      if (res.status === 200 && rep && typeof rep.text === 'string' && rep.text) {
        return finish({ text: rep.text, actions: rep.actions, chips: rep.chips, emergency: rep.intent === 'emergency' || rep.intent === 'self_harm', source: rep.source === 'llm' ? 'llm' : 'kb' });
      }
      if (res.status === 429 && res.json && res.json.message) return finish(fallback(String(res.json.message)));
      finish(fallback());
    }).catch(function () { finish(fallback()); });
  }

  /* ---------- الواجهة ---------- */
  function fit() {
    var vv = w.visualViewport;
    if (!vv || !panel) return;
    if (!(w.matchMedia && w.matchMedia('(max-width:520px)').matches)) { panel.style.bottom = ''; panel.style.height = ''; return; }
    var kb = Math.max(0, w.innerHeight - vv.height - vv.offsetTop);
    panel.style.bottom = kb + 'px';
    panel.style.height = Math.min(vv.height * (kb > 60 ? 0.96 : 0.86), 720) + 'px';
  }
  function build() {
    if (built) return; built = true;
    host = d.createElement('ds-qamar'); host.id = 'ds-qamar-root';      // وسم مخصّص: لا تطابقه قواعد الموقع العامة مثل div{…}
    host.style.setProperty('all', 'initial', 'important');            // وتبقى أي قاعدة أخرى للموقع على العنصر المضيف بلا أثر
    sh = host.attachShadow ? host.attachShadow({ mode: 'open' }) : null;
    if (!sh) { built = false; return; }
    var st = d.createElement('style'); st.textContent = CSS; sh.appendChild(st);
    wrap = el('div', 'wrap ' + SIDE); wrap.setAttribute('lang', 'ar'); wrap.setAttribute('dir', 'rtl'); sh.appendChild(wrap);

    fab = el('button', 'fab pulse'); fab.type = 'button'; fab.setAttribute('aria-haspopup', 'dialog'); fab.setAttribute('aria-expanded', 'false');
    fab.setAttribute('aria-label', 'اسأل ' + name() + '، المساعد الافتراضي');
    fab.innerHTML = '<span class="moon">' + ico('moon', true) + '</span>';
    fab.appendChild(el('span', '', 'اسأل ' + name()));
    fab.addEventListener('click', function () { open(); });
    wrap.appendChild(fab);

    panel = el('section', 'panel'); panel.hidden = true; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'محادثة ' + name());
    var head = el('header');
    var mo = el('span', 'moon'); mo.innerHTML = ico('moon', true); head.appendChild(mo);
    var tt = el('div'); tt.appendChild(el('b', '', name()));
    tt.appendChild(el('small', '', 'المساعد الافتراضي' + (cfg && cfg.shortName ? ' لـ' + cfg.shortName : ''))); head.appendChild(tt);
    var hb = el('div', 'hb');
    var nb = el('button', 'x'); nb.type = 'button'; nb.setAttribute('aria-label', 'محادثة جديدة'); nb.innerHTML = ico('refresh'); nb.addEventListener('click', reset);
    var cb = el('button', 'x'); cb.type = 'button'; cb.setAttribute('aria-label', 'إغلاق'); cb.innerHTML = ico('x'); cb.addEventListener('click', function () { close(); });
    hb.appendChild(nb); hb.appendChild(cb); head.appendChild(hb); panel.appendChild(head);

    msgs = el('div', 'msgs'); msgs.setAttribute('role', 'log'); msgs.setAttribute('aria-live', 'polite'); panel.appendChild(msgs);
    qr = el('div', 'qr'); panel.appendChild(qr);
    var disc = el('div', 'disc');
    disc.appendChild(el('span', '', 'مساعد آلي: لا يشخّص ولا يصف أدوية. للحالات الطارئة اتصل بالإسعاف ' + emNo()));
    var pv = el('a', '', 'الخصوصية'); pv.href = origin + '/privacy'; pv.target = '_blank'; pv.rel = 'noopener noreferrer'; disc.appendChild(pv);
    panel.appendChild(disc);
    form = el('form', 'composer');
    input = el('textarea'); input.rows = 1; input.maxLength = 600; input.setAttribute('dir', 'auto'); input.placeholder = 'اكتب سؤالك…'; input.setAttribute('aria-label', 'اكتب سؤالك لـ' + name());
    sendBtn = el('button', 'send'); sendBtn.type = 'submit'; sendBtn.setAttribute('aria-label', 'إرسال'); sendBtn.innerHTML = ico('send');
    form.appendChild(input); form.appendChild(sendBtn); panel.appendChild(form);
    wrap.appendChild(panel);

    form.addEventListener('submit', function (e) { e.preventDefault(); var v = input.value; input.value = ''; input.style.height = ''; ask(v); });
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event('submit', { cancelable: true })); } });
    input.addEventListener('input', function () { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 110) + 'px'; });
    panel.addEventListener('keydown', function (e) { if (e.key === 'Escape') { e.stopPropagation(); close(); } });
    d.body.appendChild(host);
  }
  function fill() {
    if (!hist.length) { hist.push({ r: 'bot', t: greeting(), a: [], s: 'kb' }); persist(); }
    msgs.textContent = '';
    hist.forEach(function (m) { msgs.appendChild(renderMsg(m)); });
    chips(defaultChips()); scrollEnd();
  }
  function reset() { hist = []; busy = false; if (sendBtn) sendBtn.disabled = false; persist(); if (msgs) fill(); }
  function open() {
    if (!built || isOpen) return;
    isOpen = true; lastFocus = d.activeElement;
    fab.hidden = true; fab.setAttribute('aria-expanded', 'true'); panel.hidden = false;
    fill(); fit();
    if (w.visualViewport) { w.visualViewport.addEventListener('resize', fit); w.visualViewport.addEventListener('scroll', fit); }
    var coarse = w.matchMedia && w.matchMedia('(pointer:coarse)').matches;
    if (!coarse) input.focus();
  }
  function close() {
    if (!isOpen) return;
    isOpen = false; panel.hidden = true; fab.hidden = false; fab.classList.remove('pulse'); fab.setAttribute('aria-expanded', 'false');
    if (w.visualViewport) { w.visualViewport.removeEventListener('resize', fit); w.visualViewport.removeEventListener('scroll', fit); }
    try { fab.focus(); } catch (e) { /* تجاهل */ }
  }

  /* ---------- الإقلاع: لا يظهر شيء إلا بعد نجاح جلب الإعدادات وكون قمر مفعّلاً ---------- */
  function boot() {
    fetch(API + '/qamar/config', { mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (c) {
        if (!c || c.enabled === false) return;
        cfg = c; build();
        if (wantOpen) { wantOpen = false; open(); }
      })
      .catch(function () { /* الخادم غير متاح: لا نعرض شيئاً */ });
  }
  w.DSQamar = {
    version: VERSION,
    open: function () { if (built) open(); else wantOpen = true; },     // قبل اكتمال التحميل: يُفتح فور جاهزيته
    close: function () { wantOpen = false; close(); },
    ask: function (t) { ask(t); }
  };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})(window, document);
