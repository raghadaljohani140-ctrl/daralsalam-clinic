#!/usr/bin/env node
/* تطبيق الموظفين يحمّل صفحة الموظفين من الخادم الحي (server.url)، فلا واجهة محلية. هذا السكربت:
   1) يثبّت عنوان الخادم في capacitor.config.json (من --api)،  2) ينشئ www/index.html بسيطاً (يطلبه Capacitor ولا يُعرض عادةً).
   node scripts/prepare-www.js --api https://dar.example.com [--build 42]  */
const fs = require('fs'), path = require('path');
const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf('--' + n); return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : d; };
const fail = (m) => { console.error('خطأ: ' + m); process.exit(1); };
const api = (opt('api', '') || '').trim();
if (!api) fail('مطلوب --api');
let u; try { u = new URL(api); } catch (e) { fail('عنوان الخادم غير صالح: ' + api); }
if (u.protocol !== 'https:' || u.pathname !== '/' || u.search || u.hash || /\/$/.test(api)) fail('أعطِ أصل الخادم https فقط بلا مسار ولا / في آخره: ' + api);
const root = path.join(__dirname, '..');
const f = path.join(root, 'capacitor.config.json');
const c = JSON.parse(fs.readFileSync(f, 'utf8'));
c.server = Object.assign({}, c.server, { url: u.origin + '/staff/start.html', allowNavigation: [u.hostname], cleartext: false });
fs.writeFileSync(f, JSON.stringify(c, null, 2) + '\n');
const out = path.resolve(process.cwd(), opt('out', 'www'));
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=' + u.origin + '/staff/start.html"><title>دار السلام للموظفين</title><body style="font-family:sans-serif;text-align:center;padding:40px">جارٍ الفتح…</body></html>\n');
console.log('تم تجهيز تطبيق الموظفين · الخادم: ' + u.origin);
