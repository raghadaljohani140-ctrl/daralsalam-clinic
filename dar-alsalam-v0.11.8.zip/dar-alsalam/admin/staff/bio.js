/* الدخول ببصمة الوجه لبوابة الموظفين ولوحة الإدارة داخل تطبيق «دار السلام للموظفين» (iOS) فقط.
   الاسم وكلمة المرور يُحفظان في مخزن النظام المحمي (Keychain) عبر إضافة NativeBiometric، ولا يُقرآن إلا بعد نجاح التحقق بالوجه.
   كلمة المرور تبقى الطريقة البديلة دائماً. في المتصفح العادي لا يظهر شيء. kind = 'staff' أو 'admin' (حساب مستقل لكل منهما). */
(function () {
  var C = window.Capacitor;
  function plug() {
    try {
      if (!C || !(C.isNativePlatform && C.isNativePlatform())) return null;
      return (C.Plugins && C.Plugins.NativeBiometric) || (C.registerPlugin ? C.registerPlugin('NativeBiometric') : null);
    } catch (e) { return null; }
  }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { /* تجاهل */ } return null; }
  function srv(k) { return 'daralsalam-' + k; }
  var B = window.DSBio = {
    plug: plug,
    on: function (k) { return !!plug() && ls('ds.bio.' + k) === '1'; },
    avail: function () { var P = plug(); if (!P || !P.isAvailable) return Promise.resolve(false); return Promise.resolve().then(function () { return P.isAvailable(); }).then(function (r) { return !!(r && r.isAvailable); }).catch(function () { return false; }); },
    save: function (k, user, pw) { var P = plug(); return Promise.resolve().then(function () { return P.setCredentials({ username: user, password: pw, server: srv(k) }); }).then(function () { ls('ds.bio.' + k, '1'); return true; }).catch(function () { return false; }); },
    off: function (k) { var P = plug(); ls('ds.bio.' + k, null); if (P && P.deleteCredentials) { try { P.deleteCredentials({ server: srv(k) }); } catch (e) { /* لا شيء */ } } },
    /* بعد دخول ناجح بكلمة المرور: عرض التفعيل مرة واحدة (ولا يتكرر إن رُفض) */
    offer: function (k, user, pw) {
      if (!plug() || B.on(k) || ls('ds.bioNo.' + k) === '1') return Promise.resolve();
      return B.avail().then(function (ok) {
        if (!ok) return;
        if (window.confirm('هل تريد الدخول ببصمة الوجه في المرات القادمة؟')) return B.save(k, user, pw);
        ls('ds.bioNo.' + k, '1');
      }).catch(function () { /* اختياري: لا نُعطّل الدخول */ });
    },
    /* تحقق بالوجه ثم يعيد {username,password}؛ الإلغاء يرفض الوعد بلا رسالة */
    creds: function (k) {
      var P = plug(); if (!P) return Promise.reject(new Error('no-plugin'));
      return Promise.resolve().then(function () { return P.verifyIdentity({ reason: 'تسجيل الدخول إلى دار السلام', title: 'الدخول ببصمة الوجه' }); })
        .then(function () { return P.getCredentials({ server: srv(k) }); });
    },
    btn: function (k) { return B.on(k) ? '<button class="btn out" type="button" data-a="bio-login" style="margin-top:8px;width:100%">الدخول ببصمة الوجه</button>' : ''; }
  };
})();
