/* داخل تطبيق «دار السلام للموظفين» فقط (غلاف Capacitor): زر عائم صغير للعودة إلى شاشة الاختيار بين الإدارة والاستقبال. في المتصفح العادي لا يفعل شيئاً. */
(function () {
  if (!window.Capacitor || !document.body) return;
  var a = document.createElement('a');
  a.href = '/staff/start.html';
  a.textContent = 'الرئيسية';
  a.setAttribute('style', 'position:fixed;bottom:max(12px,env(safe-area-inset-bottom));left:12px;z-index:9999;background:#064A85;color:#fff;padding:8px 14px;border-radius:20px;font:600 13px/1 sans-serif;text-decoration:none;opacity:.85');
  document.body.appendChild(a);
})();
