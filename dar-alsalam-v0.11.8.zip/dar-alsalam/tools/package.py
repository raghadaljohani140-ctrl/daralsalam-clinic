#!/usr/bin/env python3
"""يغلّف المشروع في ملف zip قابل للتكرار (نفس المدخلات ← نفس الملف بالبايت) مع بصمة sha256.

  python3 tools/package.py [--out dist] [--list]

ما يُستبعد دائماً: الأسرار وبيانات التشغيل (.env، قواعد البيانات، .secret، مفاتيح Apple/Google/Firebase)، ومولَّدات البناء
(node_modules، mobile/www|android|ios، __pycache__)، واللقطات الخام qa/shots (تُعاد بتشغيل اختبارات المتصفح)، وdist (عدا preview.html).
قبل التغليف يفحص الملفات المشمولة بحثاً عن أسرار ظاهرة ويرفض المتابعة إن وجدها.
المخرجات: dist/dar-alsalam-v<الإصدار>.zip و.zip.sha256. الملفات الحاوية للسكربتات (#!) تُحفظ بصلاحية تنفيذ.
"""
import argparse
import hashlib
import json
import os
import re
import sys
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOP = "dar-alsalam"

EXCLUDE_DIRS = {"node_modules", "__pycache__", ".git", "backups", ".pytest_cache"}
EXCLUDE_PREFIXES = ("mobile/www/", "mobile/android/", "mobile/ios/", "mobile-staff/www/", "mobile-staff/ios/", "mobile-staff/android/", "qa/shots/", "dist/")
KEEP_EXACT = {"dist/preview.html"}  # استثناء من استبعاد dist
EXCLUDE_NAMES = {".env", ".secret", ".DS_Store", "google-services.json", "GoogleService-Info.plist", "clinic.db"}
EXCLUDE_SUFFIXES = (".pyc", ".p8", ".keystore", ".jks", ".db", ".db-wal", ".db-shm", ".zip", ".sha256")

# أنماط أسرار ظاهرة (احتياط أخير؛ ليست بديلاً عن المراجعة)
SECRET_PATTERNS = [
    (re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----"), "مفتاح خاص"),
    (re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}"), "مفتاح Anthropic"),
    (re.compile(r"\bsk-[A-Za-z0-9]{32,}\b"), "مفتاح بنمط OpenAI"),
    (re.compile(r"AIza[0-9A-Za-z_\-]{35}"), "مفتاح Google API"),
    (re.compile(r"\bghp_[A-Za-z0-9]{30,}\b|\bgithub_pat_[A-Za-z0-9_]{30,}\b"), "رمز GitHub"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "مفتاح AWS"),
    (re.compile(r"\b\d{8,10}:[A-Za-z0-9_\-]{35}\b"), "رمز بوت تيليجرام"),
]
TEXT_SUFFIXES = {".py", ".js", ".json", ".md", ".html", ".css", ".yml", ".yaml", ".sh", ".txt", ".service", ".timer", ".example", ".gitignore", ".svg", ".xml", ".cfg", ".toml"}


def included(rel):
    """هل يُشمل هذا المسار النسبي (بفواصل /)؟"""
    if rel in KEEP_EXACT:
        return True
    parts = rel.split("/")
    if any(p in EXCLUDE_DIRS for p in parts[:-1]):
        return False
    if any(rel.startswith(p) for p in EXCLUDE_PREFIXES):
        return False
    name = parts[-1]
    if name in EXCLUDE_NAMES:
        return False
    if name.endswith(EXCLUDE_SUFFIXES):
        return False
    return True


def collect():
    files = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = sorted(d for d in dirnames if d not in EXCLUDE_DIRS)
        for fn in sorted(filenames):
            full = Path(dirpath) / fn
            rel = full.relative_to(ROOT).as_posix()
            if full.is_symlink() or not full.is_file():
                continue
            if included(rel):
                files.append(rel)
    return sorted(files)


def scan_secrets(files):
    hits = []
    for rel in files:
        p = ROOT / rel
        if p.suffix.lower() not in TEXT_SUFFIXES and p.name not in {".gitignore", ".env.example"}:
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for rx, label in SECRET_PATTERNS:
            if rx.search(text):
                hits.append(f"{rel}: يبدو أنه يحوي {label}")
    return hits


def version():
    try:
        return json.loads((ROOT / "mobile" / "package.json").read_text(encoding="utf-8"))["version"]
    except Exception:
        return "0.0.0"


def main():
    ap = argparse.ArgumentParser(description="تغليف المشروع في zip قابل للتكرار")
    ap.add_argument("--out", default=str(ROOT / "dist"), help="مجلد المخرجات (الافتراضي dist)")
    ap.add_argument("--list", action="store_true", help="اطبع قائمة الملفات المشمولة فقط دون إنشاء zip")
    a = ap.parse_args()

    files = collect()
    if a.list:
        print("\n".join(files))
        print(f"-- {len(files)} ملفاً", file=sys.stderr)
        return 0

    hits = scan_secrets(files)
    if hits:
        print("توقّف: وُجدت أنماط تشبه أسراراً في ملفات ستُغلَّف. راجعها ثم أعد التشغيل:", file=sys.stderr)
        print("\n".join("  - " + h for h in hits), file=sys.stderr)
        return 1

    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    name = f"dar-alsalam-v{version()}.zip"
    zpath = out_dir / name
    epoch = int(os.environ.get("SOURCE_DATE_EPOCH", "1795305600"))  # 2026-11-22 00:00:00 UTC
    ts = time.gmtime(max(epoch, 315532800))[:6]

    total = 0
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in files:
            data = (ROOT / rel).read_bytes()
            total += len(data)
            zi = zipfile.ZipInfo(f"{TOP}/{rel}", date_time=ts)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.create_system = 3  # Unix
            zi.external_attr = ((0o755 if data.startswith(b"#!") else 0o644) << 16)
            z.writestr(zi, data, compresslevel=9)

    with zipfile.ZipFile(zpath) as z:
        bad = z.testzip()
        if bad:
            print("zip تالف عند: " + bad, file=sys.stderr)
            return 1
        names = set(z.namelist())
    for must in ("install.sh", "server/app.py", "web/index.html", "admin/index.html", "docs/GO-LIVE-ar.md", "data/seed.json", ".github/workflows/android-apk.yml", ".github/workflows/ios-testflight.yml", "mobile/ci/ios-build.sh", "docs/TESTFLIGHT-ar.md"):
        if f"{TOP}/{must}" not in names:
            print("ملف أساسي ناقص في الحزمة: " + must, file=sys.stderr)
            return 1

    digest = hashlib.sha256(zpath.read_bytes()).hexdigest()
    (out_dir / (name + ".sha256")).write_text(f"{digest}  {name}\n", encoding="utf-8")
    print(f"{zpath}  ({zpath.stat().st_size:,} بايت، {len(files)} ملفاً، {total:,} بايت قبل الضغط)")
    print(f"sha256: {digest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
