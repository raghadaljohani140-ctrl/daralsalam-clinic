/* الدخول ببصمة الوجه في بوابة الموظفين ولوحة الإدارة (إضافة NativeBiometric وهمية). المنفذ 8101. */
const { chromium } = require('playwright'); const { spawn, execSync } = require('child_process');
const base = 'http://127.0.0.1:8101'; let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS ' + m); } else { fail++; console.log('FAIL ' + m); } };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
(async () => {
  execSync('rm -rf /tmp/ds-sb && mkdir -p /tmp/ds-sb');
  const env = Object.assign({}, process.env, { DS_DB: '/tmp/ds-sb/clinic.db', DS_PORT: '8101', DS_QUIET: '1', DS_PW_ITERS: '1000' });
  execSync('python3 server/manage.py init --password devpass-12345', { env, stdio: 'ignore' });
  const proc = spawn('python3', ['server/app.py'], { env, stdio: 'ignore' }); await sleep(2500);
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 } });
  await ctx.addInitScript(() => {
    const raw = localStorage.getItem('mk.bio'); const store = new Proxy(raw ? JSON.parse(raw) : {}, { set(t, k, v) { t[k] = v; localStorage.setItem('mk.bio', JSON.stringify(t)); return true; }, deleteProperty(t, k) { delete t[k]; localStorage.setItem('mk.bio', JSON.stringify(t)); return true; } }); let verified = parseInt(localStorage.getItem('mk.v') || '0', 10);
    window.__bio = { store, get verified() { return verified; } };
    window.Capacitor = { isNativePlatform: () => true, Plugins: { NativeBiometric: {
      isAvailable: async () => ({ isAvailable: true }),
      verifyIdentity: async () => { verified++; localStorage.setItem('mk.v', String(verified)); },
      setCredentials: async (o) => { store[o.server] = { username: o.username, password: o.password }; },
      getCredentials: async (o) => { if (!store[o.server]) throw new Error('none'); return store[o.server]; },
      deleteCredentials: async (o) => { delete store[o.server]; } } } };
    window.confirm = () => true;
  });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  // الإدارة
  await p.goto(base + '/admin/', { waitUntil: 'load' }); await p.waitForSelector('#pw');
  ok(await p.$('[data-a="bio-login"]') === null, 'الإدارة: لا زر بصمة قبل التفعيل');
  await p.fill('#pw', 'devpass-12345'); await p.click('button[type=submit]');
  await p.waitForSelector('.page-h, nav, #nav, .side', { timeout: 8000 }).catch(() => {}); await sleep(800);
  ok(await p.evaluate(() => !!window.__bio.store['daralsalam-admin']), 'الإدارة: حُفظت البيانات في المخزن بعد الموافقة');
  await p.evaluate(() => sessionStorage.clear()); await p.reload({ waitUntil: 'load' }); await p.waitForSelector('#pw');
  ok(await p.$('[data-a="bio-login"]') !== null, 'الإدارة: يظهر زر البصمة');
  await p.click('[data-a="bio-login"]'); await sleep(1500);
  ok(await p.$('#pw') === null && await p.evaluate(() => window.__bio.verified) >= 1, 'الإدارة: الدخول بالبصمة ينجح');
  // الموظفون: حساب استقبال عبر API
  const t = (await (await fetch(base + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: 'devpass-12345' }) })).json()).token;
  const roles = await (await fetch(base + '/api/admin/roles', { headers: { Authorization: 'Bearer ' + t } })).json();
  const br = await (await fetch(base + '/api/admin/branches', { headers: { Authorization: 'Bearer ' + t } })).json().catch(() => null);
  const role = (roles.roles || roles || []).find(r => /reception/i.test(r.id || r.key || '')) || (roles.roles || roles)[0];
  const rid = role.id || role.key;
  const bid = (br && (br.branches || br)[0] || {}).id || '';
  const cr = await fetch(base + '/api/admin/staff', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t }, body: JSON.stringify({ name: 'اختبار', username: 'rec1', role: rid, branchId: bid, password: 'Temp-pass-12345', doctorId: '' }) });
  const cj = await cr.json(); ok(cr.ok, 'إنشاء موظف اختبار (' + cr.status + ')');
  // نغيّر كلمة المرور المؤقتة لتجاوز mustChange
  const lg = await (await fetch(base + '/api/staff/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'rec1', password: 'Temp-pass-12345' }) })).json();
  await fetch(base + '/api/staff/password', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + lg.token }, body: JSON.stringify({ old: 'Temp-pass-12345', new: 'Final-pass-12345' }) });
  await p.goto(base + '/staff/', { waitUntil: 'load' }); await p.waitForSelector('#lg-user');
  ok(await p.$('[data-a="bio-login"]') === null, 'الموظفون: لا زر قبل التفعيل');
  await p.fill('#lg-user', 'rec1'); await p.fill('#lg-pw', 'Final-pass-12345'); await p.click('button[type=submit]'); await sleep(1500);
  ok(await p.evaluate(() => !!window.__bio.store['daralsalam-staff']), 'الموظفون: حُفظت البيانات بعد الموافقة');
  await p.evaluate(() => sessionStorage.clear()); await p.reload({ waitUntil: 'load' }); await p.waitForSelector('#lg-user');
  ok(await p.$('[data-a="bio-login"]') !== null, 'الموظفون: يظهر زر البصمة');
  await p.click('[data-a="bio-login"]'); await sleep(1500);
  ok(await p.$('#lg-user') === null, 'الموظفون: الدخول بالبصمة ينجح');
  // بيانات قديمة: تُمسح وتُطلب كلمة المرور
  await p.evaluate(() => { sessionStorage.clear(); const o = JSON.parse(localStorage.getItem('mk.bio')); o['daralsalam-staff'].password = 'wrong-password-1'; localStorage.setItem('mk.bio', JSON.stringify(o)); });
  await p.reload({ waitUntil: 'load' }); await p.waitForSelector('#lg-user'); await p.click('[data-a="bio-login"]'); await sleep(1200);
  ok(await p.$('[data-a="bio-login"]') === null && await p.$('#lg-err:not([hidden])') !== null, 'بيانات قديمة: تُلغى البصمة ويظهر تنبيه');
  ok(errs.length === 0, 'لا أخطاء جافاسكربت ' + errs.join('|'));
  console.log('\n=== ' + pass + ' PASS / ' + fail + ' FAIL ==='); await b.close(); proc.kill(); process.exit(fail ? 1 : 0);
})();
