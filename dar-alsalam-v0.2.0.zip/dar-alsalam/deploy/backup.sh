#!/usr/bin/env bash
# نسخة احتياطية متسقة لقاعدة البيانات (تستخدم واجهة النسخ في SQLite، فلا تنسخ الملف يدوياً أثناء عمل الخادم).
# الاستخدام: deploy/backup.sh          (نسخة جديدة)
#            KEEP_DAYS=30 deploy/backup.sh   (ونحذف نسخ هذا المسار الأقدم من 30 يوماً؛ بلا KEEP_DAYS لا يُحذف شيء)
# تنبيه: النسخ تحوي أسماء وجوالات المراجعين. تُنشأ بصلاحية المالك فقط؛ انقلها خارج الخادم بمكان مقيّد.
set -euo pipefail
umask 077
APP_DIR="${APP_DIR:-/opt/daralsalam}"
BACKUP_DIR="${BACKUP_DIR:-$APP_DIR/data/backups}"
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
OUT="$BACKUP_DIR/clinic-$(date +%Y%m%d-%H%M%S).db"
python3 "$APP_DIR/server/manage.py" backup --out "$OUT"
if [ -n "${KEEP_DAYS:-}" ]; then
  find "$BACKUP_DIR" -maxdepth 1 -name 'clinic-*.db' -mtime +"$KEEP_DAYS" -print -delete
fi
