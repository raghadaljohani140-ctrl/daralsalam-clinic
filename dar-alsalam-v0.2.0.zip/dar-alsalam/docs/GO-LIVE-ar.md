# التشغيل على DigitalOcean + GitHub + daralsalamclinic.duckdns.org

> اخترتَ هذه الثلاثة، وهذا الملف خطواتها بالترتيب. **لم أنفّذ شيئاً منها**: بيئتي لا تصل إلى خادمك ولا إلى حساباتك في GitHub وDuckDNS، ولا أفتح حسابات ولا أشتري. الأوامر جاهزة للصق في **Web Console** (زر Web Console في صفحة الـDroplet) أو في SSH، وتنفّذها بنفسك.
> **ما جرّبته:** سكربت التثبيت `install.sh` بمحاكاة أوامر النظام (منفذ مشغول → يرفض ولا يكتب شيئاً؛ تثبيت جديد؛ ترقية لا تمسّ `.env`)، وسكربت الترقية `deploy/upgrade.sh` بالمحاكاة نفسها (نجاح مع بقاء البيانات؛ تراجع تلقائي إذا لم تعمل الخدمة الجديدة أو نقصت البيانات؛ رفض قبل أي تغيير إذا كانت الحزمة معطوبة)، وفحص وحدات systemd، وسكربت النسخ الاحتياطي.
> **ما لم أجرّبه:** أي شيء على خادم حقيقي، وCaddy وnginx، وDuckDNS، وGitHub. إن تعثّرت خطوة فالصق لي ناتج الأمر (أو لقطة شاشة) وأكمل معك.

## ما الذي سيحدث على الخادم (وما الذي لن يحدث)

- **يُنشأ فقط:** مجلد `/opt/daralsalam`، ومستخدم نظام `daralsalam` بلا دخول، وخدمة `daralsalam`، ومؤقّت نسخ احتياطي `daralsalam-backup.timer`، وقاعدة بيانات مستقلة (`/opt/daralsalam/data/clinic.db`)، ومنفذ داخلي `127.0.0.1:8431` لا يُفتح للخارج.
- **لا يُلمس:** أي مشروع آخر على الخادم. الوحيد الذي تعدّله بيدك هو إعداد الوسيط (Caddy/nginx) بإضافة كتلة جديدة في الخطوة 5، بعد أخذ نسخة من الملف.
- **الذاكرة:** الخدمة ≈ 30 ميغابايت (قياس في الاختبارات الآلية). في لقطتك الذاكرة المستخدمة 58.6%، فالمتبقي يكفيها.

## 1) فحص سريع قبل البدء (دقيقتان)

الصق في Web Console:

```bash
ss -ltnp | grep -E ':80 |:443 |:8431 '; echo "---"
systemctl is-active caddy nginx 2>/dev/null
python3 --version; free -m; df -h / | tail -1
```

- السطور الأولى تقول من يستمع على 80/443: `caddy` أم `nginx`؟ وإن ظهر `:8431` فالمنفذ مشغول، فاختر رقماً آخر (مثل 8432) وبدّله في كل خطوة أدناه.
- يلزم Python 3 (على Debian 13 هو 3.13، وعليه جرّبتُ الكود).
- إن لم يظهر أي وسيط (لا Caddy ولا nginx) فاذهب لملحق «تثبيت Caddy» آخر الملف.

## 2) النطاق (DuckDNS)

من لوحة duckdns.org اجعل `daralsalamclinic` يشير إلى عنوان IPv4 العام للـDroplet (يظهر في صفحته). ثم تحقق من الخادم:

```bash
getent hosts daralsalamclinic.duckdns.org
```

يجب أن يظهر عنوان الـDroplet نفسه. الشهادة تُصدر تلقائياً لاحقاً، لكن **بعد أن يشير النطاق للخادم** (انتظر دقيقة بعد تعديل DuckDNS).

## 3) GitHub

1. أنشئ مستودعاً **خاصاً** (مثلاً `daralsalam-clinic`) في حساب GitHub الذي تريده، وارفع إليه **محتويات** مجلد المشروع (لا ملف zip). الملف `.gitignore` يمنع رفع الأسرار إن استخدمت git؛ وإن رفعتَ من المتصفح فلا تُضِف `.env` ولا `clinic.db` (غير موجودين في الحزمة أصلاً).
2. مفتاح **قراءة فقط** يمكّن الخادم من سحب الكود من المستودع الخاص. على الخادم:

```bash
ssh-keygen -t ed25519 -N "" -f /root/.ssh/daralsalam_deploy -C "daralsalam-droplet"
cat /root/.ssh/daralsalam_deploy.pub
```

انسخ السطر الظاهر ← GitHub ← المستودع ← **Settings ← Deploy keys ← Add deploy key** ← الصقه واتركْ «Allow write access» **غير محدّد**.

3. سحب الكود (استبدل `OWNER` باسم حسابك):

```bash
apt-get install -y git
GIT_SSH_COMMAND="ssh -i /root/.ssh/daralsalam_deploy -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new" git clone git@github.com:OWNER/daralsalam-clinic.git /root/daralsalam-src
git -C /root/daralsalam-src config core.sshCommand "ssh -i /root/.ssh/daralsalam_deploy -o IdentitiesOnly=yes"
```

## 4) التثبيت

```bash
cd /root/daralsalam-src
DS_PORT=8431 DS_TRUST_PROXY=1 bash install.sh
```

- يطبع **كلمة مرور لوحة الإدارة مرة واحدة فقط**: احفظها في مدير كلمات المرور (وغيّرها لاحقاً من «الأمان والنسخ»).
- يجب أن ينتهي بسطر «الخدمة تعمل وتردّ على 127.0.0.1:8431». وإلا فشغّل `journalctl -u daralsalam -n 50 --no-pager` وأرسل لي الناتج.
- `DS_TRUST_PROXY=1` آمن هنا لأن الخدمة تستمع على 127.0.0.1 فقط ولا يصلها إلا الوسيط.
- إن رفض السكربت لأن المنفذ مشغول فاختر منفذاً آخر وأعد الأمر.

## 5) الوسيط أمام الخدمة

### إن كان عندك Caddy (الأرجح)

هذا **يضيف** كتلة في نهاية الملف ولا يستبدله:

```bash
cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak-$(date +%F)
cat >> /etc/caddy/Caddyfile <<'EOF'

daralsalamclinic.duckdns.org {
    encode zstd gzip
    reverse_proxy 127.0.0.1:8431
}
EOF
caddy validate --config /etc/caddy/Caddyfile && systemctl reload caddy
```

إن فشل `validate` فلا تُعد التحميل: استرجع النسخة `.bak-…` (`cp` فوق الأصل) وأرسل لي رسالة الخطأ. إعادة التحميل (`reload`) لا تقطع مواقعك الأخرى.

### إن كان عندك nginx (وصفة غير مجرَّبة)

```bash
apt-get install -y certbot python3-certbot-nginx
cat > /etc/nginx/conf.d/daralsalamclinic.conf <<'EOF'
server {
    listen 80;
    server_name daralsalamclinic.duckdns.org;
    client_max_body_size 1m;
    location / {
        proxy_pass http://127.0.0.1:8431;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOF
nginx -t && systemctl reload nginx
certbot --nginx -d daralsalamclinic.duckdns.org
```

**مهم:** `X-Forwarded-For $remote_addr` وليس `$proxy_add_x_forwarded_for`، وإلا يستطيع الزائر تزوير عنوانه وتجاوز حدود الاستخدام.

## 6) التحقق

```bash
curl -s https://daralsalamclinic.duckdns.org/api/v1/health
```

يجب أن يعيد `{"ok": true, …}`. ثم من الجوال: `/app/` التطبيق · `/admin/` الإدارة · `/privacy` سياسة الخصوصية. جرّب طلب حجز من التطبيق، ثم ثبّته من الإدارة وتأكد أن إشعار التأكيد يصل داخل التطبيق.

## 7) بعد التشغيل مباشرة

1. غيّر كلمة مرور الإدارة (الإدارة ← الأمان والنسخ).
2. جدار الحماية من لوحة DigitalOcean (Cloud Firewall): افتح 22 و80 و443 فقط.
3. **النسخ الاحتياطي** تلقائي يومياً على الخادم نفسه، وهذا **لا يكفي** وحده (ضياع القرص يضيّعه معه). نزّل نسخة دورياً من الإدارة ← الأمان والنسخ. خيار Backups المدفوع في DigitalOcean لم أفعّله ولم أتحقق من سعره.
4. بيانات المجمع «مسودة»: يظهر للمراجع شريط «بيانات قيد المراجعة» حتى تراجعها مع الإدارة وتغيّر **معلومات المجمع ← حالة البيانات**.
5. **ويدجت قمر لموقع المجمع** (لا تضفه للموقع الحي إلا بموافقتك وبعلم شركة التطوير): `<script src="https://daralsalamclinic.duckdns.org/widget/qamar.js" defer></script>`. جرّبه أولاً على `https://daralsalamclinic.duckdns.org/widget/demo.html`.

## 8) بناء التطبيق من GitHub

- **أندرويد (تجربة):** GitHub ← Actions ← «Android — APK تجريبي» ← Run workflow. خانة عنوان الخادم معبّأة مسبقاً بـ `https://daralsalamclinic.duckdns.org`. نزّل الملف من نتيجة التشغيل وثبّته على جوال أندرويد.
- **آيفون (TestFlight):** يحتاج في المستودع أسرار Apple (`APPLE_TEAM_ID` و`ASC_KEY_ID` و`ASC_ISSUER_ID` و`ASC_KEY_P8`) وتطبيقاً منشأً في App Store Connect بمعرّف الحزمة نفسه، كما في بناءاتك السابقة. التفاصيل في `STORE_RELEASE.md`، وكلفة دقائق macOS في `COSTS.md`.
- **لا يُنشر شيء في أي متجر قبل موافقتك.** مسارات البناء لم تُجرَّب بعد (لا macOS هنا)، فتوقّع تعديلات بسيطة عند أول تشغيل.

## 9) الترقية لاحقاً (أمر واحد، بنسخة احتياطية وتراجع تلقائي)

الترقية تتم بسكربت واحد `deploy/upgrade.sh` من داخل **الحزمة الجديدة** (لا من `/opt/daralsalam`). بالترتيب يفعل:

1. **يفحص** التثبيت القائم والحزمة (ملفات ناقصة، أخطاء صياغة). إن وجد خللاً توقّف **قبل أي تغيير**.
2. **ينسخ احتياطياً** قاعدة البيانات (واجهة النسخ في SQLite) ويتأكد من سلامتها، ويأخذ **لقطة** من الكود الحالي إلى `/opt/daralsalam-prev-<التاريخ>`.
3. **يثبّت** الإصدار الجديد بـ `install.sh` (لا يمسّ `.env` ولا القاعدة ولا وحدات systemd التي عدّلتَها) ويعيد تشغيل الخدمة (انقطاع لثوانٍ).
4. **يفحص**: أن الخدمة ترد، وأنها تقدّم رقم الإصدار الجديد، وأن أعداد الأطباء والفروع والتخصصات والخدمات وطلبات الحجز **لم تنقص**. إن فشل أي فحص **يتراجع تلقائياً** إلى الكود السابق ويعيد تشغيل الخدمة.

لا يحذف شيئاً: اللقطة والنسخة الاحتياطية تبقيان لتحذفهما أنت بعد التأكد. لا يلمس Caddy ولا أي مشروع آخر.

**الحزمة الجديدة عبر git** (إن سحبتَ الكود في الخطوة 3):

```bash
cd /root/daralsalam-src && git pull && bash deploy/upgrade.sh
```

**أو من ملف zip في مستودع خاص** (الطريقة المستعملة على خادم Aqar، انظر الملحق أدناه):

```bash
mkdir -p /root/ds-upgrade && cd /root/ds-upgrade && rm -rf dar-alsalam ./*.zip
read -rsp 'الصق مفتاح GitHub ثم Enter (اتركه فارغاً إن كان المستودع عاماً): ' T; echo
{ [ -z "$T" ] || printf 'header = "Authorization: Bearer %s"\n' "$T"; } | curl -fsS -K - \
  -H 'Accept: application/vnd.github.raw+json' -o dar-alsalam-NEW.zip \
  'https://api.github.com/repos/OWNER/REPO/contents/dar-alsalam-NEW.zip'
unset T
echo "البصمة_من_ملف_sha256  dar-alsalam-NEW.zip" | sha256sum -c -
python3 -m zipfile -e dar-alsalam-NEW.zip .
bash dar-alsalam/deploy/upgrade.sh
```

(استبدل `OWNER/REPO` و`NEW` ببيانات مستودعك ورقم الإصدار. المفتاح يُلصق **في الخادم فقط**، لا يُرسل لأحد ولا يُحفظ في ملف.)

إن انقطع الاتصال أثناء التنفيذ فأعد الأمر نفسه: السكربت قابل لإعادة التشغيل. بعد النجاح تحقق: `curl -s https://daralsalamclinic.duckdns.org/app/config.js` يجب أن يظهر فيه رقم الإصدار الجديد، وافتح `/admin/` و`/app/` من الجوال.

**تراجع يدوي** (إن لزم بعد انتهاء السكربت): يطبعه السكربت في آخر مخرجاته بمسار اللقطة الصحيح؛ وهو إيقاف الخدمة ثم نسخ المجلدات `server web admin widget deploy` من اللقطة فوق `/opt/daralsalam` ثم تشغيل الخدمة. في هذا الإصدار (0.2.0) لا يتغيّر مخطط قاعدة البيانات، فلا تحتاج استرجاعاً: الكود القديم يتجاهل بيانات «اللوحات الإعلانية» الجديدة. (إصدار مستقبلي يغيّر المخطط سيُنبَّه عليه بسكربت ترحيل.)

## 10) أمور تقرّرها (لا أعتمدها عنك)

1. **النطاق يُثبَّت داخل التطبيق عند بنائه.** DuckDNS مناسب للتجربة، لكن لو نُشر التطبيق به ثم تغيّر النطاق فالنسخ المثبّتة تبقى تتصل بالقديم حتى تُحدَّث. فإن نويت نطاقاً رسمياً (مثل نطاق فرعي من نطاق المجمع، ويضيف سجله مالك النطاق) فاحسمه **قبل** أول تقديم لمتجر، أو أبقِ الاسمين يعملان معاً (كتلتان في الوسيط). وDuckDNS خدمة مجانية لم أتحقق من أي ضمان لاستمرارها: لو تعطلت تعطّل الوصول.
2. **بيانات المراجعين على هذا الخادم**: مشترك مع مشاريعك الأخرى وفي ألمانيا (FRA1) وبحساب شخصي. مقبول للتجربة؛ قبل أن تدخله بيانات مراجعين حقيقية يُفضَّل نقله إلى خادم مستقل **باسم المجمع** (النسخ والاستعادة مجرَّبان، `DEPLOY.md`)، مع مراجعة قانونية لنظام حماية البيانات الشخصية ولنقل البيانات خارج المملكة.

## التراجع الكامل (دون المساس بمشاريعك الأخرى)

**انسخ النسخ الاحتياطية من `/opt/daralsalam/data/backups` أولاً إن أردت الاحتفاظ بالبيانات.** ثم:

```bash
systemctl disable --now daralsalam daralsalam-backup.timer
rm -f /etc/systemd/system/daralsalam.service /etc/systemd/system/daralsalam-backup.service /etc/systemd/system/daralsalam-backup.timer
systemctl daemon-reload
rm -rf /opt/daralsalam
userdel daralsalam
```

وأخيراً احذف كتلة `daralsalamclinic.duckdns.org` من إعداد الوسيط وأعد تحميله.

## ملحق: تثبيت Caddy (فقط إن لم يكن عندك وسيط)

الأوامر من وثائق Caddy الرسمية (بتاريخ 2026-11-22؛ راجع الصفحة قبل التنفيذ):

```bash
apt install --yes debian-keyring debian-archive-keyring apt-transport-https curl
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
chmod o+r /usr/share/keyrings/caddy-stable-archive-keyring.gpg /etc/apt/sources.list.d/caddy-stable.list
apt update
apt install caddy
```

ثم ضع كتلة الخطوة 5 في `/etc/caddy/Caddyfile` (استبدل محتواه الافتراضي) ونفّذ `systemctl reload caddy`. تأكد أن المنفذين 80 و443 مفتوحان في جدار الحماية.

## ملحق: إعداد خادم Aqar كما ثُبّت فعلاً (للمرجع)

هذا ما ضُبط في جلسات التثبيت، وهو ما يعتمد عليه سكربت الترقية في اكتشاف العنوان والمنفذ:

- **الخدمة** تستمع على `172.18.0.1:8431` (بوابة شبكة docker على المضيف) لا على `127.0.0.1`، لأن Caddy يعمل داخل Docker (الحاوية `aqar-caddy-1`) ولا يرى `127.0.0.1` الخاص بالمضيف. القيمة مضبوطة في `/opt/daralsalam/.env` بسطر `DS_HOST=172.18.0.1`، ومعها `DS_PORT=8431` و`DS_TRUST_PROXY=1` (تحقق بـ `cat /opt/daralsalam/.env`).
- **جدار الحماية (UFW)**: أُضيفت قاعدة تسمح لشبكة docker بالوصول إلى منفذ الخدمة. لا تحذفها وإلا انقطع Caddy عن الخدمة (راجع `ufw status numbered`).
- **Caddy**: كتلة النطاق `daralsalamclinic.duckdns.org` داخل ملف Caddyfile الخاص بمشروع Aqar (`/opt/aqar-property-management/deploy/Caddyfile`) بين سطري `# >>> daralsalamclinic` و`# <<< daralsalamclinic`، ولها نسخة احتياطية بامتداد `.bak-<رقم>`. إعادة التحميل: `docker exec aqar-caddy-1 caddy reload --config /etc/caddy/Caddyfile`. **سكربت الترقية لا يلمس Caddy**.
- **تنزيل الحزمة**: ملف zip في مستودع GitHub خاص ينزَّل بمفتاح قراءة فقط يُلصق في الكونسول (الخطوة 9). بعد انتهاء الاستعمال: ألغِ المفتاح من GitHub، واحذف مجلد التحميل `rm -rf /root/ds-upgrade`.
