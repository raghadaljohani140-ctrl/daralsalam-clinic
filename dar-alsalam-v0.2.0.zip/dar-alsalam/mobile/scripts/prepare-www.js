#!/usr/bin/env node
/* يجهّز مجلد www (واجهة التطبيق) للتغليف بـ Capacitor من المصدر الوحيد ../web مع كتابة config.js بعنوان الخادم.

   node scripts/prepare-www.js --api https://dar.example.com [--build 42] [--out www] [--dev] [--push]

   • --api  عنوان الخادم (أصل فقط بلا مسار ولا / في آخره). يجب أن يكون https، ويُسمح بـ http لعناوين التطوير المحلية فقط مع --dev.
   • --push يُظهر زر «تنبيهات الجوال» في حسابي. لا تستعمله إلا إذا جهّزت Firebase (أندرويد) أو إذن Push وAPNs (iOS)؛ وإلا يبقى مخفياً.
   • لا يُنسخ sw.js ولا manifest (التطبيق الأصلي لا يحتاجهما).
   • يتحقق من وجود الملفات الأساسية بعد النسخ ويفشل برمز غير صفري عند أي خلل.                                     */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const SRC = path.join(ROOT, 'web');
const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf('--' + n); return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : d; };
const flag = (n) => args.includes('--' + n);
const fail = (m) => { console.error('خطأ: ' + m); process.exit(1); };

const api = (opt('api', '') || '').trim();
const out = path.resolve(process.cwd(), opt('out', 'www'));
const build = String(opt('build', 'local')).replace(/[^\w.-]/g, '').slice(0, 24) || 'local';
const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));

if (!api) fail('مطلوب --api (عنوان الخادم، مثال: https://dar.example.com)');
let u;
try { u = new URL(api); } catch (e) { fail('عنوان الخادم غير صالح: ' + api); }
if (u.pathname !== '/' || u.search || u.hash || u.username || u.password || /\/$/.test(api)) fail('أعطِ أصل الخادم فقط بلا مسار ولا / في آخره: ' + u.origin);
const local = ['localhost', '127.0.0.1', '10.0.2.2'].includes(u.hostname);
if (u.protocol !== 'https:' && !(flag('dev') && local && u.protocol === 'http:')) fail('يجب أن يكون العنوان https (يُسمح بـ http لعناوين التطوير المحلية فقط مع --dev): ' + api);
if (out === SRC || out === ROOT || SRC.startsWith(out + path.sep)) fail('مجلد الإخراج غير آمن: ' + out);

fs.rmSync(out, { recursive: true, force: true });
const SKIP = new Set(['sw.js', 'manifest.webmanifest', 'config.js']);
(function copy(dir, rel) {
  fs.mkdirSync(path.join(out, rel), { recursive: true });
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const r = path.join(rel, e.name);
    if (e.isDirectory()) copy(path.join(dir, e.name), r);
    else if (!(rel === '' && SKIP.has(e.name))) fs.copyFileSync(path.join(dir, e.name), path.join(out, r));
  }
})(SRC, '');

/* index.html يشير إلى manifest الذي لم يُنسخ: نزيل الوسم حتى لا يظهر خطأ 404 في سجل الجهاز */
const idx = path.join(out, 'index.html');
fs.writeFileSync(idx, fs.readFileSync(idx, 'utf8').replace(/<link rel="manifest"[^>]*>\n?/, ''));

const cfg = { apiBase: u.origin, demo: false, version: pkg.version, build, push: flag('push') };
fs.writeFileSync(path.join(out, 'config.js'), '/* مولَّد تلقائياً بواسطة mobile/scripts/prepare-www.js — لا تعدّله يدوياً */\nwindow.DS_CONFIG = ' + JSON.stringify(cfg) + ';\n');

for (const must of ['index.html', 'config.js', 'js/00-core.js', 'js/20-kb.js', 'js/10-data.js', 'js/30-views.js', 'js/40-booking.js', 'js/50-qamar.js', 'js/90-app.js', 'css/app.css', 'data/seed.public.json', 'data/lexicon.json', 'img/icon.svg', 'img/mark.svg', 'img/mark-white.svg', 'img/wordmark.svg', 'img/splash-mark.svg']) {
  if (!fs.existsSync(path.join(out, must))) fail('ملف أساسي مفقود بعد النسخ: ' + must);
}
const n = (function count(d) { return fs.readdirSync(d, { withFileTypes: true }).reduce((a, e) => a + (e.isDirectory() ? count(path.join(d, e.name)) : 1), 0); })(out);
console.log('تم تجهيز ' + path.relative(process.cwd(), out) + ' (' + n + ' ملفاً) · الخادم: ' + u.origin + ' · الإصدار ' + pkg.version + ' (' + build + ')' + (flag('push') ? ' · التنبيهات: مفعّلة' : ' · التنبيهات: مخفية'));
