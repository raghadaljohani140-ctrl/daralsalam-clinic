/* اختبار لوحة الإدارة بمتصفح حقيقي: NODE_PATH=<playwright> node tools/e2e_admin.js [BASE_URL] [ADMIN_PASSWORD] */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8090';
const PW = process.argv[3] || 'devpass-12345';
const SHOTS = path.join(__dirname, '..', 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
let fails = 0, passes = 0;
function ok(c, m) { if (c) { passes++; console.log('PASS', m); } else { fails++; console.log('FAIL', m); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pub = async (p, opt) => { const r = await fetch(BASE + '/api/v1' + p, opt); return { status: r.status, body: await r.json().catch(() => ({})) }; };
const post = (p, body) => pub(p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 820 }, locale: 'ar-SA', timezoneId: 'Asia/Riyadh', acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  const shot = async (n) => { await sleep(300); await page.screenshot({ path: path.join(SHOTS, n + '.png') }); };
  const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await sleep(400); };

  /* ---------- الدخول ---------- */
  await page.goto(BASE + '/admin/', { waitUntil: 'networkidle' });
  ok(await page.locator('#pw').isVisible(), 'شاشة الدخول');
  ok(await page.evaluate(() => { const i = document.querySelector('.login img'); return !!i && i.complete && i.naturalWidth > 0; }), 'شعار شاشة الدخول يُحمَّل');
  await shot('a01-login');
  await page.fill('#pw', 'wrong-password-xx');
  await page.click('button[type=submit]');
  await page.waitForSelector('#login-err:not([hidden])');
  ok(true, 'كلمة مرور خاطئة تُرفض: ' + (await page.locator('#login-err').innerText()));
  await page.fill('#pw', PW);
  await page.click('button[type=submit]');
  await page.waitForSelector('#nav', { timeout: 8000 });
  ok(await page.locator('#nav a').count() >= 10, 'تظهر القائمة بعد الدخول');
  ok(await page.evaluate(() => { const i = document.querySelector('.side .brand img'); return !!i && i.complete && i.naturalWidth > 0; }), 'شعار الشريط الجانبي (الأقواس البيضاء) يُحمَّل');
  ok((await page.locator('#main').innerText()).includes('مسودة'), 'التنبيه: بيانات التطبيق «مسودة»');
  ok((await page.locator('#main').innerText()).includes('ملاحظات المراجعة'), 'ملاحظات المراجعة ظاهرة');
  await shot('a02-dashboard');

  /* ---------- الحجوزات ---------- */
  const dev = 'dev_admin_e2e_000000000001';
  const bk = await post('/bookings', { deviceId: dev, name: 'مراجع للاختبار', phone: '0555550101', consent: true, specialtyId: 'internal', period: 'evening', note: 'اختبار لوحة الإدارة' });
  ok(bk.status === 201, 'إنشاء طلب من التطبيق: ' + (bk.body.booking && bk.body.booking.id));
  const bid = bk.body.booking.id;
  await go('#/bookings');
  await page.waitForSelector('tr[data-a="bk-open"]');
  ok((await page.locator('#bk-box').innerText()).includes(bid), 'الطلب يظهر في اللوحة');
  await shot('a03-bookings');
  await page.locator('tr[data-a="bk-open"]', { hasText: bid }).click();
  await page.waitForSelector('#modal');
  await shot('a04-booking-modal');
  await page.selectOption('#bk-status', 'confirmed');
  await page.click('form[data-submit="bk-save"] button[type=submit]');
  await sleep(300);
  ok(await page.locator('#modal [data-err="appointmentText"]:not([hidden])').count() === 1, 'اللوحة تمنع «مؤكد» بدون تفاصيل الموعد');
  await page.selectOption('#bk-status', 'contacted');
  await page.fill('#bk-note', 'اتصلنا بالمراجع');
  await page.click('form[data-submit="bk-save"] button[type=submit]');
  await sleep(600);
  let list = await pub('/bookings?deviceId=' + dev);
  ok(list.body.bookings[0].status === 'contacted', 'الحالة «تم التواصل» وصلت للمراجع');
  let nt = await pub('/notifications?deviceId=' + dev);
  ok(nt.body.notifications.some((n) => n.title.includes('تواصل')), 'إشعار «تواصل معك المجمع» وصل للمراجع');
  await page.locator('tr[data-a="bk-open"]', { hasText: bid }).click();
  await page.waitForSelector('#modal');
  await page.selectOption('#bk-status', 'confirmed');
  await page.fill('#bk-appt', 'الخميس 6:00 مساءً — عيادة الباطنة');
  await page.click('form[data-submit="bk-save"] button[type=submit]');
  await sleep(600);
  list = await pub('/bookings?deviceId=' + dev);
  ok(list.body.bookings[0].status === 'confirmed' && list.body.bookings[0].appointmentText.includes('الخميس'), 'التأكيد مع نص الموعد يصل للمراجع');

  /* ---------- الأطباء: إضافة/تعديل/إخفاء/حذف نهائي ---------- */
  await go('#/list/doctors');
  await page.waitForSelector('#ls-body tr');
  ok(await page.locator('#ls-body tr').count() === 27, 'قائمة الأطباء 27');
  await shot('a05-doctors');
  await go('#/edit/doctors/new');
  await page.waitForSelector('#f_name');
  await page.fill('#new-id', 'dr-e2e-test');
  await page.fill('#f_name', 'طبيب الاختبار الآلي');
  await page.fill('#f_rank', 'أخصائي');
  await page.check('input[data-k="specialtyIds"][value="internal"]');
  await page.check('input[data-k="branchIds"][value="quba"]');
  await shot('a06-doctor-form');
  await page.click('form[data-submit="save-entity"] button[type=submit]');
  await sleep(700);
  let ds = (await pub('/clinic')).body;
  const d = ds.doctors.find((x) => x.id === 'dr-e2e-test');
  ok(!!d && d.specialtyIds.includes('internal') && d.branchIds.includes('quba'), 'الطبيب الجديد ظهر في بيانات التطبيق العامة');
  // تحقق الأخطاء: معرّف مكرر
  await go('#/edit/doctors/new');
  await page.fill('#new-id', 'dr-e2e-test'); await page.fill('#f_name', 'مكرر');
  await page.click('form[data-submit="save-entity"] button[type=submit]');
  await sleep(500);
  ok(await page.locator('.form-err:not([hidden])').count() === 1, 'معرّف مكرر يُرفض برسالة');
  // إخفاء
  await go('#/list/doctors'); await page.waitForSelector('#ls-body tr');
  await page.fill('#ls-q', 'dr-e2e-test'); await sleep(200);
  await page.locator('#ls-body [data-a="toggle"]').first().click();
  await sleep(700);
  ds = (await pub('/clinic')).body;
  ok(!ds.doctors.find((x) => x.id === 'dr-e2e-test'), 'إخفاء الطبيب يزيله من التطبيق');
  // حذف نهائي
  await go('#/edit/doctors/dr-e2e-test');
  await page.waitForSelector('[data-a="hard-delete"]');
  await page.click('[data-a="hard-delete"]');
  await page.fill('#del-confirm', 'خطأ');
  await page.click('[data-a="hard-delete-go"]');
  await sleep(300);
  ok(await page.locator('#modal').count() === 1, 'الحذف النهائي لا يتم بمعرّف خاطئ');
  await page.fill('#del-confirm', 'dr-e2e-test');
  await page.click('[data-a="hard-delete-go"]');
  await sleep(800);
  const adm = await (await fetch(BASE + '/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: PW }) })).json();
  const full = await (await fetch(BASE + '/api/admin/dataset', { headers: { Authorization: 'Bearer ' + adm.token } })).json();
  ok(!full.doctors.find((x) => x.id === 'dr-e2e-test'), 'الحذف النهائي بالتأكيد ينجح');

  /* ---------- فرع ثالث ---------- */
  await go('#/edit/branches/new');
  await page.waitForSelector('#f_name');
  await page.fill('#new-id', 'e2e-branch'); await page.fill('#f_name', 'فرع الاختبار'); await page.fill('#f_address', 'عنوان تجريبي');
  await page.fill('#f_lat', '24.4672'); await page.fill('#f_lng', '39.6111');
  await page.click('form[data-submit="save-entity"] button[type=submit]');
  await sleep(700);
  ds = (await pub('/clinic')).body;
  ok(ds.branches.length === 3 && ds.branches.find((b) => b.id === 'e2e-branch').lat === 24.4672, 'فرع ثالث بإحداثيات يظهر في التطبيق');
  await fetch(BASE + '/api/admin/entities/branches/e2e-branch?hard=1&confirm=e2e-branch', { method: 'DELETE', headers: { Authorization: 'Bearer ' + adm.token } });

  /* ---------- اللوحات الإعلانية (شرائح العروض في الرئيسية) ---------- */
  await go('#/edit/banners/new');
  await page.waitForSelector('#f_title');
  await page.fill('#new-id', 'bn-e2e-test');
  await page.fill('#f_title', 'عرض اختبار آلي');
  await page.fill('#f_text', 'نص توضيحي للاختبار');
  await page.fill('#f_buttonLabel', 'تفاصيل');
  await page.selectOption('#f_theme', 'sky');
  await page.selectOption('#f_linkType', 'doctor');
  await page.fill('#f_linkRef', 'dr-لا-يوجد');
  await page.click('form[data-submit="save-entity"] button[type=submit]');
  await sleep(600);
  const bnErr = await page.locator('[data-err="linkRef"]:not([hidden])').innerText().catch(() => '');
  ok(bnErr.includes('لا يوجد طبيب'), 'لوحة تشير إلى طبيب غير موجود تُرفض برسالة عربية: ' + bnErr);
  await page.fill('#f_linkRef', 'dr-ayman-almamour');
  await page.click('form[data-submit="save-entity"] button[type=submit]');
  await sleep(800);
  ds = (await pub('/clinic')).body;
  const bn = (ds.banners || []).find((x) => x.id === 'bn-e2e-test');
  ok(!!bn && bn.theme === 'sky' && bn.linkType === 'doctor' && bn.linkRef === 'dr-ayman-almamour', 'اللوحة الجديدة تظهر في بيانات التطبيق العامة');
  await go('#/list/banners');
  await page.waitForSelector('#ls-body tr');
  const bnRow = (await page.locator('#ls-body tr', { hasText: 'عرض اختبار آلي' }).innerText()).replace(/\s+/g, ' ');
  ok(bnRow.includes('سماوي') && bnRow.includes('طبيب') && !/\bsky\b|\bdoctor\b/.test(bnRow), 'قائمة اللوحات تعرض اللون والوجهة بالعربية: ' + bnRow);
  await shot('a13-banners');
  await page.fill('#ls-q', 'عرض اختبار'); await sleep(200);
  await page.locator('#ls-body [data-a="toggle"]').first().click();
  await sleep(700);
  ds = (await pub('/clinic')).body;
  ok(!(ds.banners || []).some((x) => x.id === 'bn-e2e-test'), 'إخفاء اللوحة يزيلها من التطبيق');
  await fetch(BASE + '/api/admin/entities/banners/bn-e2e-test?hard=1&confirm=bn-e2e-test', { method: 'DELETE', headers: { Authorization: 'Bearer ' + adm.token } });

  /* ---------- الإعدادات ---------- */
  await go('#/settings');
  await page.waitForSelector('#f_notice');
  await shot('a07-settings');
  await page.fill('#f_notice', 'إشعار اختبار آلي');
  await page.click('form[data-submit="save-settings"] button[type=submit]');
  await sleep(700);
  ds = (await pub('/clinic')).body;
  ok(ds.settings.notice === 'إشعار اختبار آلي', 'تعديل إشعار الرئيسية يصل للتطبيق');
  ok(ds.settings.shortName === 'دار السلام' && ds.settings.social.x && ds.settings.stats.patients === 500000, 'حفظ الإعدادات لم يفقد الاسم المختصر ولا الحسابات ولا الأرقام');
  await page.fill('#f_notice', '');
  await page.fill('#f_booking_externalUrl', 'http://not-https.example');
  await page.click('form[data-submit="save-settings"] button[type=submit]');
  await sleep(600);
  ok(await page.locator('[data-err="booking.externalUrl"]:not([hidden])').count() === 1, 'رابط البوابة غير https يُرفض');
  await page.fill('#f_booking_externalUrl', '');
  await page.click('form[data-submit="save-settings"] button[type=submit]');
  await sleep(600);
  ds = (await pub('/clinic')).body;
  ok(ds.settings.notice === '', 'إزالة الإشعار');

  /* ---------- قمر: من سؤال غير مفهوم إلى سؤال شائع ---------- */
  const Q = 'هل يوجد موقف سيارات';
  const r1 = await post('/qamar', { message: Q, deviceId: dev, history: [] });
  ok(r1.status === 200 && r1.body.reply, 'سؤال خارج المعرفة يُسجَّل: intent=' + (r1.body.reply && r1.body.reply.intent));
  await go('#/qamar');
  await page.waitForSelector('#qlog');
  await sleep(600);
  await shot('a08-qamar');
  const hasLog = (await page.locator('#qlog').innerText()).includes('موقف');
  ok(hasLog, 'السؤال غير المفهوم يظهر في سجل قمر');
  if (hasLog) {
    await page.locator('[data-a="log-faq"]').first().click();
    await page.waitForSelector('#f_answer');
    ok((await page.inputValue('#f_question')).includes('موقف'), 'نموذج السؤال الشائع معبّأ بنص السؤال');
    await page.fill('#f_answer', 'إجابة اختبار آلي — اتصل بالمجمع على {phone_main} للتأكد.');
    await page.fill('#f_keywords', 'موقف\nمواقف\nسيارات');
    await page.fill('#new-id', 'faq-e2e-test');
    await page.click('form[data-submit="save-entity"] button[type=submit]');
    await sleep(800);
    const r2 = await post('/qamar', { message: Q, deviceId: dev, history: [] });
    ok(r2.body.reply.confident !== false && r2.body.reply.text.includes('920031134'), 'بعد إضافة السؤال الشائع يجيب قمر عنه مباشرة: ' + r2.body.reply.text.slice(0, 60));
    await fetch(BASE + '/api/admin/entities/faqs/faq-e2e-test?hard=1&confirm=faq-e2e-test', { method: 'DELETE', headers: { Authorization: 'Bearer ' + adm.token } });
  }
  await go('#/qamar');
  await page.waitForSelector('[data-submit="save-qamar"]');
  await page.click('form[data-submit="save-qamar"] button[type=submit]');
  await sleep(500);
  ok((await pub('/clinic')).body.qamar.enabled === true, 'حفظ إعدادات قمر');

  /* ---------- الإشعارات ---------- */
  await go('#/notify');
  await page.waitForSelector('#n-title');
  page.once('dialog', (dl) => dl.accept());
  await page.fill('#n-title', 'إعلان اختبار'); await page.fill('#n-body', 'نص إشعار الاختبار الآلي');
  await page.click('form[data-submit="send-notify"] button[type=submit]');
  await sleep(700);
  nt = await pub('/notifications?deviceId=' + dev);
  ok(nt.body.notifications.some((n) => n.title === 'إعلان اختبار'), 'الإشعار العام وصل للتطبيق');
  await shot('a09-notify');

  /* ---------- الأمان والتصدير ---------- */
  await go('#/security');
  await page.waitForSelector('[data-a="export"]');
  const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 6000 }), page.click('[data-a="export"]')]);
  ok(/dar-alsalam-export-.*\.json$/.test(dl.suggestedFilename()), 'تنزيل النسخة الاحتياطية: ' + dl.suggestedFilename());
  await shot('a10-security');

  /* ---------- جوال ---------- */
  await page.setViewportSize({ width: 390, height: 844 });
  await go('#/bookings'); await page.waitForSelector('tr[data-a="bk-open"]'); await shot('a11-mobile-bookings');
  await go('#/edit/doctors/dr-ayman-almamour'); await page.waitForSelector('#f_name'); await shot('a12-mobile-form');
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
  ok(!overflow, 'لا تمرير أفقي في نسخة الجوال');

  /* ---------- الخروج ---------- */
  await page.setViewportSize({ width: 1280, height: 820 });
  await page.click('[data-a="logout"]');
  await page.waitForSelector('#pw');
  ok(true, 'تسجيل الخروج يعيد لشاشة الدخول');
  await page.reload({ waitUntil: 'networkidle' });
  ok(await page.locator('#pw').isVisible(), 'بعد إعادة التحميل تبقى الجلسة مغلقة');

  const real = errors.filter((e) => !/Failed to load resource.*(401|404|422|409|429)/.test(e));
  ok(real.length === 0, 'لا أخطاء في وحدة التحكم' + (real.length ? ': ' + real.join(' | ') : ''));
  console.log('\nالنتيجة:', passes, 'ناجح،', fails, 'فاشل');
  await browser.close();
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
