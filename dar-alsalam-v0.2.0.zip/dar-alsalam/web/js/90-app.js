/* هيكل التطبيق: الشريط العلوي، التبويبات، الإجراءات السريعة، شاشة البداية، التشغيل، التحديث الخلفي */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon;
  var TABS = [
    ['home', 'الرئيسية', '#/', 'home'],
    ['specialties', 'التخصصات', '#/specialties', 'grid'],
    ['quick', 'إجراءات', '', 'add'],          // الزر المركزي: يفتح «إجراءات سريعة» ولا يمثّل صفحة
    ['doctors', 'الأطباء', '#/doctors', 'users'],
    ['more', 'المزيد', '#/more', 'more']
  ];

  function shell() {
    DS.$('#app').innerHTML = '<header class="bar" id="bar"></header><div class="ribbon" id="ribbon" hidden></div><main id="view" tabindex="-1"></main>' +
      '<nav class="tabs" id="tabs" aria-label="التنقل الرئيسي">' + TABS.map(function (t) {
        if (t[0] === 'quick') {
          return '<button class="tab cta" type="button" data-tab="quick" data-act="qa-open" aria-haspopup="dialog" aria-label="إجراءات سريعة"><span class="pill">' + ic(t[3]) + '</span><span>' + t[1] + '</span></button>';
        }
        return '<a class="tab" data-tab="' + t[0] + '" href="' + t[2] + '">' + ic(t[3]) + '<span>' + t[1] + '</span></a>';
      }).join('') + '</nav>';
  }

  DS.onRoute = function (cur) {
    var m = cur.meta || {}, s = D.settings(), bar = DS.$('#bar');
    var title = m.title || s.name || 'دار السلام';
    if (!bar) return;
    if (DS.quick) DS.quick.close(true);
    bar.innerHTML = (m.back ? '<button class="ib" data-act="back" aria-label="رجوع">' + ic('back') + '</button>' : '<img class="logo-s" src="img/mark-white.svg" alt="">') +
      '<h1>' + esc(title) + '</h1><a class="ib" href="#/notifications" aria-label="الإشعارات">' + ic('bell') + '<span class="badge-dot" id="nbadge" hidden></span></a>';
    DS.notif.setBadge(DS.notif.unread);
    DS.$$('#tabs .tab').forEach(function (a) {
      var on = a.getAttribute('data-tab') === m.tab;
      a.classList.toggle('on', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    ribbon();
    DS.qamar.onRoute(cur);
    document.title = title + (m.title ? ' — ' + (s.shortName || s.name || '') : '') + (DS.cfg.demo ? ' (نسخة تجريبية)' : '');
    var v = DS.$('#view'); if (v && v.focus) { try { v.focus({ preventScroll: true }); } catch (e) { /* تجاهل */ } }
  };

  function ribbon() {
    var r = DS.$('#ribbon'), app = DS.$('#app'); if (!r) return;
    var draft = D.settings().dataStatus !== 'verified';
    r.hidden = !draft; app.classList.toggle('has-ribbon', draft);
    r.textContent = DS.cfg.demo ? 'نسخة تجريبية — بيانات قيد المراجعة ولا يُرسل شيء' : 'بيانات قيد المراجعة — للتأكد من المواعيد اتصل بالمجمع';
  }

  /* ---------- الإجراءات السريعة (الزر المركزي «+») ---------- */
  var QA = DS.quick = { isOpen: false }, qaEl = null, qaLast = null;
  function qaItems() {
    var s = D.settings(), ph = D.mainPhone(), wa = s.whatsapp, qm = (D.ds && D.ds.qamar) || {}, out = [];
    out.push({ ico: 'calendar-plus', t: 'طلب حجز', href: '#/book' });
    if (qm.enabled !== false) out.push({ ico: 'chat', t: 'اسأل ' + (qm.name || 'قمر'), act: 'qa-qamar' });
    if (ph) out.push({ ico: 'phone', t: 'اتصال بالمجمع', href: DS.telHref(ph) });
    if (wa) out.push({ ico: 'whatsapp', t: 'واتساب', href: DS.waHref(DS.kbmod.e164(wa)), ext: true });
    out.push({ ico: 'map-pin', t: 'الفروع والمواقع', href: '#/branches' });
    out.push({ ico: 'calendar', t: 'طلباتي', href: '#/profile' });
    return out;
  }
  function qaItemHtml(it) {
    var inner = '<span class="ico">' + ic(it.ico) + '</span><span>' + esc(it.t) + '</span>';
    if (it.act) return '<button type="button" class="qa-i" data-act="' + it.act + '">' + inner + '</button>';
    if (it.ext) return '<a class="qa-i" href="' + esc(it.href) + '" data-act="qa-ext" data-url="' + esc(it.href) + '">' + inner + '</a>';
    return '<a class="qa-i" href="' + esc(it.href) + '" data-act="qa-go">' + inner + '</a>';
  }
  function qaKey(e) {
    if (!QA.isOpen) return;
    if (e.key === 'Escape') { QA.close(); return; }
    if (e.key !== 'Tab' || !qaEl) return;
    var f = DS.$$('a[href],button', DS.$('.sheet', qaEl));
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  QA.open = function () {
    if (QA.isOpen) return;
    if (DS.qamar && DS.qamar.isOpen) DS.qamar.close(true);
    QA.isOpen = true; qaLast = document.activeElement;
    var em = D.settings().emergencyNumber || '997';
    qaEl = document.createElement('div'); qaEl.id = 'qaroot';
    qaEl.innerHTML = '<div class="scrim" data-act="qa-close"></div>' +
      '<section class="sheet qa" role="dialog" aria-modal="true" aria-labelledby="qa-t"><div class="grab" aria-hidden="true"></div>' +
      '<header><h2 id="qa-t">إجراءات سريعة</h2><button class="x" type="button" data-act="qa-close" aria-label="إغلاق">' + ic('x') + '</button></header>' +
      '<p class="qa-sub">اختر ما تريد وننقلك إليه مباشرة.</p>' +
      '<div class="qa-grid">' + qaItems().map(qaItemHtml).join('') + '</div>' +
      '<a class="qa-em" href="' + esc(DS.telHref(em)) + '" data-act="qa-go"><span class="ico">' + ic('alert') + '</span><div><b>الطوارئ: اتصل بالإسعاف ' + esc(em) + '</b><span class="sm">للحالات التي تهدد الحياة</span></div></a></section>';
    document.body.appendChild(qaEl);
    var x = DS.$('.x', qaEl); if (x) x.focus();
    document.addEventListener('keydown', qaKey);
  };
  QA.close = function (keepFocus) {
    if (!QA.isOpen) return;
    QA.isOpen = false;
    document.removeEventListener('keydown', qaKey);
    if (qaEl) qaEl.remove();
    qaEl = null;
    if (keepFocus !== true && qaLast && qaLast.focus) { try { qaLast.focus(); } catch (e) { /* تجاهل */ } }
  };
  DS.acts['qa-open'] = function () { QA.open(); return false; };
  DS.acts['qa-close'] = function () { QA.close(); return false; };
  DS.acts['qa-go'] = function () { QA.close(true); return true; };
  DS.acts['qa-ext'] = function (el) { var u = el.getAttribute('data-url'); QA.close(true); DS.openExternal(u); return false; };
  DS.acts['qa-qamar'] = function () { QA.close(true); if (DS.qamar) DS.qamar.open(); return false; };

  DS.acts.reload = function () { root.location.reload(); return false; };

  function fatal() {
    DS.$('#app').innerHTML = '<div class="splash"><div style="padding:24px"><h2 style="font-weight:800">تعذر تحميل التطبيق</h2><p class="muted" style="margin:8px 0 16px">تحقق من الاتصال ثم أعد المحاولة.</p>' +
      '<button class="btn pri" data-act="reload">إعادة المحاولة</button><p style="margin-top:16px">أو اتصل بالمجمع: <a class="ltr" style="display:inline-block" href="tel:920031134">920031134</a></p></div></div>';
  }

  function refreshView() {
    var cur = DS.current(); if (!cur || cur.path === '/book') return;   // لا نعيد رسم نموذج الحجز أثناء الكتابة
    var y = root.scrollY; DS.render(); root.scrollTo(0, y);
  }

  function start() {
    shell();
    DS.qamar.init();
    D.onChange(refreshView);
    DS.startRouter();
    if (!DS.cfg.demo) {
      D.refresh();
      DS.notif.refreshBadge();
      setInterval(function () { if (!document.hidden) { DS.notif.refreshBadge(); } }, 60000);
      document.addEventListener('visibilitychange', function () { if (!document.hidden) { D.refresh(); DS.notif.refreshBadge(); } });
      root.addEventListener('online', function () { D.refresh(); DS.notif.refreshBadge(); });
    }
    /* زر الرجوع في أندرويد (داخل التطبيق الأصلي فقط) */
    var A = DS.cap('App');
    if (A && A.addListener) {
      A.addListener('backButton', function () {
        if (QA.isOpen) { QA.close(); return; }
        if (DS.qamar.isOpen) { DS.qamar.close(); return; }
        var cur = DS.current();
        if (cur && cur.path !== '/') DS.back(); else if (A.exitApp) A.exitApp();
      });
    }
    /* التخزين المؤقت للتشغيل بدون إنترنت — في المتصفح فقط وليس داخل التطبيق الأصلي */
    if ('serviceWorker' in navigator && !DS.isNative() && !DS.cfg.demo && /^https?:$/.test(root.location.protocol)) {
      navigator.serviceWorker.register('sw.js').catch(function () { /* اختياري */ });
    }
  }

  /* شاشة البداية المتحركة تُعرض مدة قصيرة ثابتة داخل التطبيق المثبّت وفي النسخة التجريبية؛ أما في تبويب المتصفح العادي
     فلا نؤخّر أحداً: تزول بمجرد تحميل البيانات. وإن فضّل المستخدم تقليل الحركة نقصّر المدة. */
  function splashHold() {
    var standalone = false, reduce = false;
    try {
      standalone = DS.cfg.demo || DS.isNative() || (root.matchMedia && root.matchMedia('(display-mode: standalone)').matches) || root.navigator.standalone === true;
      reduce = !!(root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches);
    } catch (e) { /* تجاهل */ }
    return standalone ? (reduce ? 500 : 1800) : 0;
  }

  DS.boot = function () {
    var t0 = Date.now(), hold = splashHold();
    D.load().then(function () {
      var wait = hold - (Date.now() - t0);
      return wait > 0 ? new Promise(function (r) { setTimeout(r, wait); }) : null;
    }).then(function () {
      var sp = hold ? DS.$('#app .splash') : null;
      if (!sp) return null;
      sp.classList.add('out');
      return new Promise(function (r) { setTimeout(r, 280); });
    }).then(start).catch(function () { fatal(); });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', DS.boot); else DS.boot();
})(window);
