/* النواة: أدوات عامة، أيقونات، تخزين محلي، عميل API، موجّه صفحات */
(function (root) {
  'use strict';
  var DS = root.DS = root.DS || {};
  DS.cfg = Object.assign({ apiBase: '', demo: false, version: '0.2.0', build: 'dev', push: false }, root.DS_CONFIG || {});

  DS.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  };
  DS.nl = function (s) { return DS.esc(s).replace(/\n/g, '<br>'); };
  DS.$ = function (sel, el) { return (el || document).querySelector(sel); };
  DS.$$ = function (sel, el) { return Array.prototype.slice.call((el || document).querySelectorAll(sel)); };

  /* ---------- أيقونات (24×24، خط) ---------- */
  var P = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.8"/><rect x="14" y="3" width="7" height="7" rx="1.8"/><rect x="3" y="14" width="7" height="7" rx="1.8"/><rect x="14" y="14" width="7" height="7" rx="1.8"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M17 14.2c2.4 0 4.2 1.8 4.2 4"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    'calendar-plus': '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4M12 13v5M9.5 15.5h5"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    'map-pin': '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
    chat: '<path d="M4 5h16v11H9l-5 4V5z"/>',
    bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15L6 16z"/><path d="M10 21h4"/>',
    back: '<path d="M9 5l7 7-7 7"/>', 'chevron-left': '<path d="M15 5l-7 7 7 7"/>', 'chevron-right': '<path d="M9 5l7 7-7 7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    send: '<path d="M21 3L10 14"/><path d="M21 3l-7 18-4-7-7-4 18-7z"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    whatsapp: '<path d="M4 20l1.3-4.2A8 8 0 1 1 8.4 18.8L4 20z"/><path d="M9.3 8.9c.3 2.3 2.7 4.7 5.1 5.1l1.2-1.2-2-1-.9.6a4.4 4.4 0 0 1-1.9-1.9l.6-.9-1-2-1.1 1.3z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5H5V6h5"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.5"/>',
    alert: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.5"/>',
    activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    heart: '<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z"/>',
    smile: '<path d="M7 4c-2 0-3.5 1.6-3.5 4 0 2 1 3.4 1.5 5.2.5 2 .7 6.8 2.6 6.8 1.5 0 1.4-4 3.4-4s1.9 4 3.4 4c1.9 0 2.1-4.8 2.6-6.8.5-1.8 1.5-3.2 1.5-5.2 0-2.4-1.5-4-3.5-4-1.7 0-2.4.9-4 .9S8.7 4 7 4z"/>',
    bone: '<path d="M8.5 8.5l7 7"/><circle cx="6.5" cy="8" r="2.2"/><circle cx="8" cy="6.5" r="2.2"/><circle cx="17.5" cy="16" r="2.2"/><circle cx="16" cy="17.5" r="2.2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-2 3.5-2 6a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
    scalpel: '<path d="M3 21l10-10"/><path d="M13 11l6-6a2.2 2.2 0 0 1 3 3l-6 6-3-3z"/>',
    plus: '<rect x="3.5" y="3.5" width="17" height="17" rx="4.5"/><path d="M12 8v8M8 12h8"/>',
    drop: '<path d="M12 3s6 6.2 6 10.5A6 6 0 0 1 6 13.5C6 9.2 12 3 12 3z"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3z"/><path d="M19 17v4M17 19h4"/>',
    lungs: '<path d="M12 4v8"/><path d="M12 8C9 8 5 12 5 17c0 2 1.5 3 3 3s3-1 3-3V9"/><path d="M12 8c3 0 7 4 7 9 0 2-1.5 3-3 3s-3-1-3-3V9"/>',
    flask: '<path d="M9 3h6M10 3v6l-5.5 9.5A2 2 0 0 0 6.2 21h11.6a2 2 0 0 0 1.7-2.5L14 9V3"/><path d="M7.5 15h9"/>',
    scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M8 12h8"/>',
    stethoscope: '<path d="M6 3v6a4 4 0 0 0 8 0V3"/><path d="M10 13v2a4 4 0 0 0 8 0v-1"/><circle cx="18" cy="12" r="2"/>',
    baby: '<circle cx="12" cy="12" r="8"/><path d="M9 11v.5M15 11v.5M9.5 15c1.5 1 3.5 1 5 0M12 4c1 0 2 .5 2 1.5"/>',
    pill: '<rect x="3" y="8.5" width="18" height="7" rx="3.5" transform="rotate(-35 12 12)"/><path d="M9.6 9.6l4.8 4.8"/>',
    shield: '<path d="M12 3l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/>',
    x_social: '<path d="M5 4l14 16M19 4L5 20"/>',
    instagram: '<rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="3.5"/><circle cx="17" cy="7" r=".8"/>',
    tiktok: '<path d="M14 4v10.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 4c.5 2.5 2.2 4 5 4"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    add: '<path d="M12 5v14M5 12h14"/>',
    more: '<circle cx="5.5" cy="12" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="18.5" cy="12" r="1.4"/>',
    share: '<circle cx="18" cy="5.5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="18.5" r="2.5"/><path d="M8.2 10.8l7.6-4.1M8.2 13.2l7.6 4.1"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/>'
  };
  DS.icon = function (name, cls) {
    return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + (P[name] || P.plus) + '</svg>';
  };
  DS.moonSvg = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.2 14.2A8.6 8.6 0 1 1 9.8 3.8a7.1 7.1 0 0 0 10.4 10.4z"/><path d="M18 3.2l.7 1.8 1.8.7-1.8.7L18 8.2l-.7-1.8-1.8-.7 1.8-.7z"/></svg>';

  /* ---------- تخزين محلي آمن ---------- */
  var mem = {};
  DS.store = {
    get: function (k, d) { try { var v = root.localStorage.getItem('ds.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return k in mem ? mem[k] : d; } },
    set: function (k, v) { try { root.localStorage.setItem('ds.' + k, JSON.stringify(v)); } catch (e) { mem[k] = v; } },
    del: function (k) { try { root.localStorage.removeItem('ds.' + k); } catch (e) { delete mem[k]; } }
  };
  DS.uuid = function () {
    var a = new Uint8Array(12);
    (root.crypto || root.msCrypto).getRandomValues(a);
    return 'dev_' + Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  };
  DS.deviceId = function () {
    var id = DS.store.get('deviceId');
    if (!id || !/^[A-Za-z0-9_-]{16,64}$/.test(id)) { id = DS.uuid(); DS.store.set('deviceId', id); }
    return id;
  };

  /* ---------- API ---------- */
  function ApiError(status, body) { this.status = status; this.code = (body && body.error) || 'network'; this.message = (body && body.message) || ''; this.fields = (body && body.fields) || {}; }
  DS.api = {
    url: function (p) { return (DS.cfg.apiBase || '') + '/api/v1' + p; },
    req: function (method, path, body, opts) {
      opts = opts || {};
      if (DS.cfg.demo) return Promise.reject(new ApiError(0, { error: 'demo' }));
      var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var to = setTimeout(function () { if (ctl) ctl.abort(); }, opts.timeout || 10000);
      var headers = { 'Accept': 'application/json' };
      if (body !== undefined) headers['Content-Type'] = 'application/json';
      if (opts.etag) headers['If-None-Match'] = opts.etag;
      return fetch(DS.api.url(path), { method: method, headers: headers, body: body === undefined ? undefined : JSON.stringify(body), signal: ctl ? ctl.signal : undefined, cache: 'no-store' })
        .then(function (r) {
          clearTimeout(to);
          if (r.status === 304) return { status: 304, data: null, etag: opts.etag };
          return r.json().catch(function () { return {}; }).then(function (j) {
            if (!r.ok) throw new ApiError(r.status, j);
            return { status: r.status, data: j, etag: r.headers.get('ETag') };
          });
        }, function () { clearTimeout(to); throw new ApiError(0, { error: 'network' }); });
    },
    get: function (p, o) { return DS.api.req('GET', p, undefined, o); },
    post: function (p, b, o) { return DS.api.req('POST', p, b || {}, o); },
    del: function (p, o) { return DS.api.req('DELETE', p, undefined, o); }
  };

  /* ---------- أدوات واجهة ---------- */
  var toastT;
  DS.toast = function (msg) {
    var t = DS.$('#toast'); if (!t) return;
    t.textContent = msg; t.classList.add('on'); clearTimeout(toastT);
    toastT = setTimeout(function () { t.classList.remove('on'); }, 2800);
  };
  /* وصول آمن لإضافات Capacitor الأصلية (يعيد null خارج التطبيق الأصلي) */
  DS.cap = function (name) {
    var C = root.Capacitor;
    if (!C || !(C.isNativePlatform && C.isNativePlatform())) return null;
    try { return (C.Plugins && C.Plugins[name]) || (C.registerPlugin ? C.registerPlugin(name) : null); } catch (e) { return null; }
  };
  DS.openExternal = function (url) {
    var B = DS.cap('Browser');
    if (B && B.open) { try { B.open({ url: url }); return; } catch (e) { /* نكمل بالفتح العادي */ } }
    root.open(url, '_blank', 'noopener');
  };
  DS.isNative = function () { return !!(root.Capacitor && root.Capacitor.isNativePlatform && root.Capacitor.isNativePlatform()); };
  DS.fmtDate = function (iso) {
    if (!iso) return '';
    try { return new Date(iso.length === 10 ? iso + 'T12:00:00' : iso).toLocaleDateString('ar-SA-u-nu-latn-ca-gregory', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return iso; }
  };
  DS.fmtDateTime = function (iso) {
    try { return new Date(iso).toLocaleString('ar-SA-u-nu-latn-ca-gregory', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch (e) { return iso; }
  };
  DS.riyadhToday = function (plusDays) {
    var d = new Date(Date.now() + 3 * 3600 * 1000 + (plusDays || 0) * 86400000);
    return d.toISOString().slice(0, 10);
  };
  DS.initials = function (name) {
    var p = String(name || '').trim().split(/\s+/).filter(Boolean);
    return (p[0] ? p[0][0] : '') + (p[1] ? p[1][0] : '');
  };
  DS.telHref = function (n) { return 'tel:' + String(n || '').replace(/[^\d+]/g, ''); };
  DS.waHref = function (n, text) { return 'https://wa.me/' + String(n || '').replace(/\D/g, '') + (text ? '?text=' + encodeURIComponent(text) : ''); };

  /* ---------- موجّه الصفحات (hash) ---------- */
  var routes = [], current = null, stack = [];
  DS.route = function (pattern, handler, meta) {
    var keys = [], re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, function (_, k) { keys.push(k); return '([^/?]+)'; }) + '$');
    routes.push({ re: re, keys: keys, handler: handler, meta: meta || {} });
  };
  DS.parseHash = function () {
    var h = (root.location.hash || '#/').slice(1) || '/';
    var i = h.indexOf('?'), path = i < 0 ? h : h.slice(0, i), qs = {};
    if (i >= 0) h.slice(i + 1).split('&').forEach(function (kv) { if (!kv) return; var p = kv.split('='); qs[decodeURIComponent(p[0])] = decodeURIComponent((p[1] || '').replace(/\+/g, ' ')); });
    return { path: path || '/', query: qs };
  };
  DS.go = function (path) { if (root.location.hash === '#' + path) DS.render(); else root.location.hash = '#' + path; };
  DS.canGoBack = function () { return stack.length > 1; };
  DS.back = function () { if (DS.canGoBack()) root.history.back(); else DS.go('/'); };
  DS.render = function () {
    var loc = DS.parseHash(), r = null, params = {};
    for (var i = 0; i < routes.length; i++) {
      var m = routes[i].re.exec(loc.path);
      if (m) { r = routes[i]; routes[i].keys.forEach(function (k, j) { params[k] = decodeURIComponent(m[j + 1]); }); break; }
    }
    if (!r) { r = routes[0]; loc = { path: '/', query: {} }; }
    current = { path: loc.path, query: loc.query, params: params, meta: r.meta };
    var view = DS.$('#view');
    view.classList.remove('view-in');
    var out = r.handler(params, loc.query, view);
    if (typeof out === 'string') view.innerHTML = out;
    void view.offsetWidth; view.classList.add('view-in');
    if (!(r.meta && r.meta.keepScroll)) root.scrollTo(0, 0);
    if (DS.onRoute) DS.onRoute(current);
  };
  DS.current = function () { return current; };
  DS.startRouter = function () {
    stack = [root.location.hash || '#/'];
    root.addEventListener('hashchange', function () {
      var h = root.location.hash || '#/';
      if (stack.length >= 2 && stack[stack.length - 2] === h) stack.pop(); else { stack.push(h); if (stack.length > 60) stack.shift(); }
      DS.render();
    });
    DS.render();
  };
  DS.resetStack = function () { stack = [root.location.hash || '#/']; };

  /* ---------- أحداث بالتفويض: data-act ---------- */
  DS.acts = {};
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el) return;
    var fn = DS.acts[el.getAttribute('data-act')];
    if (fn) { var r = fn(el, e); if (r !== true) e.preventDefault(); }
  });
})(typeof window !== 'undefined' ? window : globalThis);
