#!/usr/bin/env python3
"""يبني نسخة التجربة: ملف HTML واحد يحوي التطبيق كاملاً (واجهة + بيانات + قمر) ويعمل بفتحه من الجوال أو الحاسوب بلا خادم.

  python3 tools/build_preview.py [--out dist/preview.html]

ضمانات النسخة التجريبية (تُفرض في المتصفح نفسه وليس بالنية فقط):
  • سياسة CSP تمنع أي اتصال بالشبكة (connect-src 'none') وإرسال النماذج (form-action 'none') وتحميل صور/خطوط خارجية.
  • وضع demo=true: الحجز يعرض «ما كان سيُرسل» ولا يرسل، والإشعارات أمثلة، وقمر يجيب محلياً من قاعدة المعرفة فقط.
  • البيانات هي نسخة seed.public.json المضمّنة (بيانات الموقع الرسمي قيد المراجعة).
  • شريحتان توضيحيتان تحملان عبارة «مثال توضيحي» تُضافان إلى النسخة التجريبية وحدها لتُرى تجربة العروض؛ لا تُضافان إلى بيانات الخادم أبداً.
"""
import argparse
import base64
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
ORDER = ["00-core.js", "20-kb.js", "10-data.js", "30-views.js", "35-home.js", "45-auth.js", "40-booking.js", "50-qamar.js", "90-app.js"]
SVGS = ["icon", "mark", "mark-white", "wordmark", "logo", "splash-mark"]
# شريحتا عرض توضيحيتان للمعاينة فقط (ليستا عرضاً حقيقياً): الأولى تفتح طلب الحجز والثانية تفتح قمر
DEMO_BANNERS = [
    {"id": "bn-demo-1", "title": "مثال توضيحي: بطاقة عرض", "text": "هكذا تظهر العروض والإعلانات التي يضيفها المجمع من لوحة الإدارة. هذا مثال للشكل فقط وليس عرضاً حقيقياً.",
     "buttonLabel": "اطلب حجزاً", "theme": "blue", "linkType": "book", "linkRef": "", "image": "", "active": True, "sort": 1},
    {"id": "bn-demo-2", "title": "مثال توضيحي: اسأل قمر", "text": "مثال لبطاقة تفتح محادثة المساعد الافتراضي. يمكن للمجمع تغيير نصها ولونها ووجهتها.",
     "buttonLabel": "ابدأ المحادثة", "theme": "sky", "linkType": "qamar", "linkRef": "", "image": "", "active": True, "sort": 2},
]
CSP = ("default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; "
       "frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'")


def js_json(obj):
    """JSON آمن للتضمين داخل وسم script."""
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    return s.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def data_uri(path, mime):
    return "data:%s;base64,%s" % (mime, base64.b64encode(Path(path).read_bytes()).decode())


def build(version):
    html = (WEB / "index.html").read_text(encoding="utf-8")
    css = (WEB / "css" / "app.css").read_text(encoding="utf-8")
    uris = {n: data_uri(WEB / "img" / (n + ".svg"), "image/svg+xml") for n in SVGS}
    png180 = data_uri(WEB / "img" / "icon-180.png", "image/png")

    def tokens(text):
        """كل مرجع img/NAME.svg (في HTML أو JS أو CSS بصيغة ../img/) يصير رمزاً مؤقتاً يُستبدل بالبيانات في الآخر."""
        def one(m):
            if m.group(1) not in uris:
                sys.exit("صورة غير مضمّنة في أداة المعاينة: img/%s.svg" % m.group(1))
            return "@@IMG:%s@@" % m.group(1)
        return re.sub(r"(?:\.\./)?img/([\w-]+)\.svg", one, text)

    # رأس الصفحة: CSP صارمة + التنسيقات + الأيقونات المضمّنة
    html = re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '<meta http-equiv="Content-Security-Policy" content="%s">' % CSP, html, count=1)
    html = html.replace('<link rel="manifest" href="manifest.webmanifest">\n', "")
    html = html.replace('<link rel="apple-touch-icon" href="img/icon-180.png">', '<link rel="apple-touch-icon" href="%s">' % png180)
    html = html.replace('<link rel="stylesheet" href="css/app.css">', "<style>\n%s\n</style>" % tokens(css).replace("</style", "<\\/style"))
    html = html.replace("<title>مجمعات دار السلام الطبية</title>", "<title>مجمعات دار السلام الطبية — نسخة تجريبية</title>")
    html = tokens(html)

    # الإعدادات والبيانات المضمّنة
    seed = json.loads((WEB / "data" / "seed.public.json").read_text(encoding="utf-8"))
    if not seed.get("banners"):
        seed["banners"] = DEMO_BANNERS
    lex = json.loads((WEB / "data" / "lexicon.json").read_text(encoding="utf-8"))
    cfg = {"apiBase": "", "demo": True, "version": version, "build": "preview"}
    head_js = "<script>window.DS_CONFIG=%s;window.DS_SEED=%s;window.DS_LEXICON=%s;</script>" % (js_json(cfg), js_json(seed), js_json(lex))
    html = html.replace('<script src="config.js"></script>', head_js)

    # السكربتات بالترتيب نفسه المعتمد في index.html
    for name in ORDER:
        tag = '<script src="js/%s"></script>' % name
        if tag not in html:
            sys.exit("لم أجد السكربت في index.html: " + name)
        src = (WEB / "js" / name).read_text(encoding="utf-8")
        src = tokens(src).replace("</script", "<\\/script")
        html = html.replace(tag, "<script>\n%s\n</script>" % src)

    markup = re.sub(r"<(script|style)\b[^>]*>.*?</\1>", "", html, flags=re.S)        # نفحص الوسوم فقط لا نصوص الجافاسكربت
    leftovers = re.findall(r'(?:src|href)="(?!data:|@@IMG:|#|tel:|https?:)[^"]+"', markup)
    if leftovers:
        sys.exit("بقيت مراجع خارجية في الملف: %s" % leftovers[:5])
    # أي صورة أو خط أو رابط ملف محلي متبقٍّ داخل الجافاسكربت/CSS يعني صورة ستفشل تحت CSP (img-src data:)
    stray = re.findall(r"""(?:\.\./)?(?:img|fonts|css|js)/[\w./-]+\.(?:svg|png|jpg|jpeg|webp|gif|woff2?|ttf)""", html)
    if stray:
        sys.exit("بقيت مراجع ملفات محلية: %s" % sorted(set(stray))[:5])
    for n, u in uris.items():                                                         # الاستبدال النهائي بعد فحص البقايا
        html = html.replace("@@IMG:%s@@" % n, u)
    if "@@IMG:" in html:
        sys.exit("رمز صورة لم يُستبدل")
    return html


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "dist" / "preview.html"))
    ap.add_argument("--version", default=None)
    a = ap.parse_args()
    version = a.version
    if not version:
        m = re.search(r'version:\s*"([^"]+)"', (WEB / "config.js").read_text(encoding="utf-8"))
        version = m.group(1) if m else "0.6.0"
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    html = build(version)
    out.write_text(html, encoding="utf-8")
    print("تم: %s  (%d KB)  sha256=%s" % (out, len(html.encode("utf-8")) // 1024, hashlib.sha256(html.encode("utf-8")).hexdigest()[:16]))


if __name__ == "__main__":
    main()
