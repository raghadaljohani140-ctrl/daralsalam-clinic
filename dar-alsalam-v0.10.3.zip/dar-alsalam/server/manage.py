#!/usr/bin/env python3
"""أدوات إدارة من سطر الأوامر: تهيئة، كلمة المرور، نسخ احتياطي، تصدير/استيراد."""
import argparse
import getpass
import json
import secrets
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import app as appmod  # noqa: E402


def cmd_init(a, app):
    if app.admin_record() and not a.reset:
        print("كلمة مرور الإدارة مضبوطة مسبقاً. لإعادة ضبطها: set-password")
        return 0
    pw = a.password or secrets.token_urlsafe(12)
    app.set_admin_password(pw)
    print("تم إنشاء قاعدة البيانات وتحميل البيانات الأولية.")
    if not a.password:
        print("كلمة مرور لوحة الإدارة (تُعرض مرة واحدة فقط، احفظها الآن): " + pw)
    return 0


def cmd_set_password(a, app):
    pw = a.password or getpass.getpass("كلمة المرور الجديدة: ")
    if len(pw) < 10:
        print("قصيرة: 10 أحرف على الأقل")
        return 1
    app.set_admin_password(pw)
    print("تم تغيير كلمة المرور.")
    return 0


def cmd_backup(a, app):
    dest = a.out or str(app.cfg.db_path.parent / "backups" / ("clinic-%s.db" % time.strftime("%Y%m%d-%H%M%S")))
    print("نسخة احتياطية:", app.db.backup_to(dest))
    return 0


def cmd_export(a, app):
    Path(a.out).write_text(json.dumps(app.db.export_all(), ensure_ascii=False, indent=1), encoding="utf-8")
    print("تم التصدير إلى", a.out)
    return 0


def cmd_import(a, app):
    data = json.loads(Path(a.file).read_text(encoding="utf-8"))
    if not a.yes:
        print("الاستيراد يكتب فوق بيانات الكيانات والإعدادات الحالية. أضف --yes للتأكيد (يُنصح بتنفيذ backup أولاً).")
        return 1
    n = 0
    for kind in appmod.dbmod.KINDS:
        for e in data.get(kind, []):
            app.db.upsert_entity(kind, e, "import")
            n += 1
    if "settings" in data:
        app.db.set_kv("settings", data["settings"])
    if "qamar" in data:
        app.db.set_kv("qamar", data["qamar"])
    app.db._bump()
    print("تم استيراد %d عنصراً" % n)
    return 0


def cmd_stats(a, app):
    print(json.dumps({"bookings": app.db.booking_stats(), "dataVersion": app._data_version(), "qamarToday": app.db.usage_get("qamar:msgs"),
                      "llmToday": app.db.usage_get("llm")}, ensure_ascii=False, indent=1))
    return 0


def main():
    ap = argparse.ArgumentParser(description="إدارة تطبيق دار السلام")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init", help="إنشاء قاعدة البيانات وكلمة مرور الإدارة")
    p.add_argument("--password")
    p.add_argument("--reset", action="store_true")
    p.set_defaults(fn=cmd_init)
    p = sub.add_parser("set-password")
    p.add_argument("--password")
    p.set_defaults(fn=cmd_set_password)
    p = sub.add_parser("backup")
    p.add_argument("--out")
    p.set_defaults(fn=cmd_backup)
    p = sub.add_parser("export")
    p.add_argument("out")
    p.set_defaults(fn=cmd_export)
    p = sub.add_parser("import")
    p.add_argument("file")
    p.add_argument("--yes", action="store_true")
    p.set_defaults(fn=cmd_import)
    p = sub.add_parser("stats")
    p.set_defaults(fn=cmd_stats)
    a = ap.parse_args()
    return a.fn(a, appmod.App())


if __name__ == "__main__":
    sys.exit(main())
