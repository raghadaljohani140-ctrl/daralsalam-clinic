import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from helpers import Env, ROOT  # noqa: F401
import qamar as qmod
import push as pushmod


class FakeLLM:
    def __init__(self):
        outer = self
        self.calls = []
        self.reply = "الأقرب لك عيادة الأسنان، وتقدر ترسل طلب حجز من التطبيق."
        self.status = 200

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get("Content-Length", "0"))
                body = json.loads(self.rfile.read(n))
                outer.calls.append({"path": self.path, "headers": {k.lower(): v for k, v in self.headers.items()}, "body": body})
                if outer.status != 200:
                    self.send_response(outer.status)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                if self.path.endswith("/messages"):
                    out = {"content": [{"type": "text", "text": outer.reply}]}
                else:
                    out = {"choices": [{"message": {"content": outer.reply}}]}
                raw = json.dumps(out).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def log_message(self, *a):
                pass

        self.srv = HTTPServer(("127.0.0.1", 0), H)
        self.url = "http://127.0.0.1:%d" % self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def close(self):
        self.srv.shutdown()
        self.srv.server_close()


OFF = ["اريد اكل بيتزا", "كيف حال الطقس اليوم", "من فاز بالمباراة", "ما هو افضل فيلم", "اقترح لي كتاب للقراءة"]


def ask(e, msg, dev="dev_llm_00000000000000", hist=None):
    s, d, _ = e.req("POST", "/api/v1/qamar", {"deviceId": dev, "message": msg, "history": hist or []})
    assert s == 200, (s, d)
    return d["reply"]


class TestLLM(unittest.TestCase):
    def setUp(self):
        self.fake = FakeLLM()
        self.e = Env({"QAMAR_PROVIDER": "anthropic", "QAMAR_API_KEY": "sk-test", "QAMAR_BASE_URL": self.fake.url,
                      "QAMAR_MODEL": "claude-haiku-5-5", "QAMAR_DEVICE_CAP": "3", "QAMAR_DAILY_CAP": "50"})
        q = self.e.app.db.get_kv("qamar")
        q["mode"] = "auto"
        q["extraInstructions"] = "اذكر أن الحجز أونلاين متاح قريباً"
        self.e.app.db.set_kv("qamar", q)

    def tearDown(self):
        self.e.close()
        self.fake.close()

    def test_default_mode_never_calls_llm(self):
        e = Env({"QAMAR_PROVIDER": "anthropic", "QAMAR_API_KEY": "sk", "QAMAR_BASE_URL": self.fake.url, "QAMAR_MODEL": "m"})
        try:
            q = e.app.db.get_kv("qamar")
            q["mode"] = "kb"
            e.app.db.set_kv("qamar", q)
            r = ask(e, "اريد اكل بيتزا")
            self.assertEqual(r["source"], "kb")
            self.assertEqual(self.fake.calls, [])
        finally:
            e.close()

    def test_llm_used_only_for_unknown_in_auto(self):
        r = ask(self.e, "اريد اكل بيتزا")  # unknown -> LLM
        self.assertEqual(r["source"], "llm")
        self.assertEqual(len(self.fake.calls), 1)
        n = len(self.fake.calls)
        ask(self.e, "وين الفروع")        # بيانات مؤكدة -> قواعد
        ask(self.e, "عندي ألم في الاسنان")  # توجيه بالقواعد
        self.assertEqual(len(self.fake.calls), n)

    def test_request_shape_and_system_prompt(self):
        ask(self.e, "اريد اكل بيتزا", hist=[{"role": "assistant", "content": "هلا"}, {"role": "user", "content": "مرحبا"}, {"role": "assistant", "content": "تفضل"}])
        c = self.fake.calls[0]
        self.assertTrue(c["path"].endswith("/v1/messages"))
        self.assertEqual(c["headers"].get("x-api-key"), "sk-test")
        self.assertEqual(c["headers"].get("anthropic-version"), "2023-06-01")
        b = c["body"]
        self.assertEqual(b["model"], "claude-haiku-5-5")
        self.assertLessEqual(b["max_tokens"], 500)
        self.assertIn("لا تشخّص", b["system"])
        self.assertIn("لا تؤكد حجزاً", b["system"])
        self.assertIn("920031134", b["system"])             # بيانات المجمع
        self.assertIn("اذكر أن الحجز أونلاين", b["system"])  # تعليمات الإدارة تُضاف ولا تلغي القواعد
        self.assertEqual(b["messages"][0]["role"], "user")
        self.assertEqual(b["messages"][-1], {"role": "user", "content": "اريد اكل بيتزا"})
        roles = [m["role"] for m in b["messages"]]
        self.assertTrue(all(a != b2 for a, b2 in zip(roles, roles[1:])))
        self.assertNotIn("اريد اكل بيتزا", b["system"])      # رسالة المستخدم لا تدخل في system

    def test_emergency_and_advice_never_reach_llm(self):
        self.e.app.db.set_kv("qamar", {**self.e.app.db.get_kv("qamar"), "mode": "llm"})
        for m in ("عندي ألم شديد في الصدر", "وش الدواء المناسب للصداع", "ابغى انتحر"):
            r = ask(self.e, m)
            self.assertEqual(r["source"], "kb", m)
        self.assertEqual(self.fake.calls, [])

    def test_guard_blocks_invented_phone(self):
        self.fake.reply = "تقدر تتصل على 0551234567 وتحجز."
        r = ask(self.e, "اريد اكل بيتزا")
        self.assertEqual(r["source"], "kb-fallback")
        self.assertTrue(r["guard"].startswith("number"))
        self.assertIn("920031134", r["text"])

    def test_guard_allows_real_phone(self):
        self.fake.reply = "تقدر تتصل بالرقم الموحد 920031134 للاستفسار."
        self.assertEqual(ask(self.e, "اريد اكل بيتزا")["source"], "llm")

    def test_guard_blocks_booking_confirmation(self):
        for i, bad in enumerate(("تم حجز موعدك يوم الثلاثاء.", "أكدت حجزك مع الطبيب.", "موعدك مؤكد.")):
            self.fake.reply = bad
            self.assertEqual(ask(self.e, OFF[i], dev="dev_g%d_00000000000000000" % i)["source"], "kb-fallback", bad)

    def test_guard_blocks_unknown_doctor(self):
        self.fake.reply = "أنصحك بمراجعة د. سالم الفلاني في عيادة الأسنان."
        r = ask(self.e, "اريد اكل بيتزا")
        self.assertEqual(r["source"], "kb-fallback")
        self.assertTrue(r["guard"].startswith("unknown_doctor"))

    def test_guard_allows_known_doctor_and_builds_cards(self):
        self.fake.reply = "تقدر تراجع د. أيمن في الطب العام، وأرتب لك طلب حجز لو تبي."
        r = ask(self.e, "اريد اكل بيتزا")
        self.assertEqual(r["source"], "llm")
        types = [a["type"] for a in r["actions"]]
        self.assertIn("doctor", types)
        self.assertIn("book", types)

    def test_guard_blocks_medication_and_urls(self):
        for i, bad in enumerate(("خذ جرعة 500 ملغ كل ست ساعات.", "زر الموقع https://evil.example.com", "عندك التهاب في الحلق.")):
            self.fake.reply = bad
            self.assertEqual(ask(self.e, OFF[i], dev="dev_m%d_00000000000000000" % i)["source"], "kb-fallback", bad)

    def test_provider_error_falls_back_silently(self):
        self.fake.status = 500
        r = ask(self.e, "اريد اكل بيتزا")
        self.assertEqual(r["source"], "kb-fallback")
        self.assertIn("920031134", r["text"])

    def test_device_cap(self):
        for i in range(3):
            ask(self.e, OFF[i], dev="dev_cap_0000000000000000")
        self.assertEqual(len(self.fake.calls), 3)
        r = ask(self.e, OFF[3], dev="dev_cap_0000000000000000")
        self.assertEqual(len(self.fake.calls), 3)
        self.assertEqual(r["source"], "kb")
        r = ask(self.e, OFF[4], dev="dev_cap_other_0000000000")
        self.assertEqual(r["source"], "llm")

    def test_daily_cap(self):
        e = Env({"QAMAR_PROVIDER": "anthropic", "QAMAR_API_KEY": "sk", "QAMAR_BASE_URL": self.fake.url, "QAMAR_MODEL": "m", "QAMAR_DAILY_CAP": "2", "QAMAR_DEVICE_CAP": "50"})
        try:
            q = e.app.db.get_kv("qamar")
            q["mode"] = "auto"
            e.app.db.set_kv("qamar", q)
            for i in range(4):
                ask(e, OFF[i], dev="dev_d%d_0000000000000000" % i)
            self.assertEqual(len([c for c in self.fake.calls]), 2)
        finally:
            e.close()

    def test_cache_for_single_turn(self):
        ask(self.e, "اريد اكل بيتزا", dev="dev_c1_0000000000000000")
        ask(self.e, "اريد اكل بيتزا", dev="dev_c2_0000000000000000")
        self.assertEqual(len(self.fake.calls), 1)

    def test_personal_data_is_scrubbed_before_reaching_provider(self):
        # المراجع قد يكتب جواله أو بريده داخل المحادثة: لا يجوز أن يصل للمزوّد الخارجي كما هو
        ask(self.e, "اريد اكل بيتزا واتصلوا علي 0565551234 او على a@b.com",
            hist=[{"role": "user", "content": "جوالي ٠٥٠١٢٣٤٥٦٧ وهويتي 1012345678"}, {"role": "assistant", "content": "تمام"}])
        self.assertEqual(len(self.fake.calls), 1)
        sent = json.dumps(self.fake.calls[0]["body"], ensure_ascii=False)
        for secret in ("0565551234", "a@b.com", "0501234567", "1012345678", "٠٥٠١٢٣٤٥٦٧"):
            self.assertNotIn(secret, sent, secret)
        self.assertIn("اريد اكل بيتزا", sent)

    def test_privacy_page_describes_provider_only_when_enabled(self):
        s, body, _ = self.e.req("GET", "/privacy", raw=True)
        self.assertEqual(s, 200)
        self.assertIn("ذكاء اصطناعي خارجية", body.decode("utf-8"))
        self.assertIn("خارج المملكة", body.decode("utf-8"))
        off = Env({})
        try:
            s2, body2, _ = off.req("GET", "/privacy", raw=True)
            self.assertEqual(s2, 200)
            self.assertNotIn("ذكاء اصطناعي خارجية", body2.decode("utf-8"))
        finally:
            off.close()

    def test_log_is_redacted(self):
        ask(self.e, "اتصلوا علي 0565551234 او على a@b.com بخصوص بيتزا")
        log = self.e.app.db.recent_qamar_log(5)
        self.assertTrue(log)
        q = log[0]["question"]
        self.assertNotIn("0565551234", q)
        self.assertNotIn("a@b.com", q)

    def test_openai_compatible_provider(self):
        e = Env({"QAMAR_PROVIDER": "openai", "QAMAR_API_KEY": "sk-oa", "QAMAR_BASE_URL": self.fake.url, "QAMAR_MODEL": "some-model", "QAMAR_TOKENS_PARAM": "max_completion_tokens"})
        try:
            q = e.app.db.get_kv("qamar")
            q["mode"] = "auto"
            e.app.db.set_kv("qamar", q)
            r = ask(e, "اريد اكل بيتزا")
            self.assertEqual(r["source"], "llm")
            c = self.fake.calls[-1]
            self.assertTrue(c["path"].endswith("/chat/completions"))
            self.assertEqual(c["headers"].get("authorization"), "Bearer sk-oa")
            self.assertIn("max_completion_tokens", c["body"])
            self.assertEqual(c["body"]["messages"][0]["role"], "system")
        finally:
            e.close()

    def test_disabled_qamar_returns_503(self):
        q = self.e.app.db.get_kv("qamar")
        q["enabled"] = False
        self.e.app.db.set_kv("qamar", q)
        s, d, _ = self.e.req("POST", "/api/v1/qamar", {"deviceId": "dev_x_00000000000000000", "message": "مرحبا"})
        self.assertEqual(s, 503)


class TestRedactAndPush(unittest.TestCase):
    def test_redact(self):
        self.assertEqual(qmod.redact("رقمي 0565551234 وايميلي x@y.com"), "رقمي # وايميلي @")
        self.assertEqual(qmod.redact("رقمي ٠٥٦٥٥٥١٢٣٤"), "رقمي #")

    def test_jwt_signature_verifies_with_openssl(self):
        import base64
        import os
        import subprocess
        import tempfile
        d = tempfile.mkdtemp()
        key, pub = os.path.join(d, "k.pem"), os.path.join(d, "p.pem")
        subprocess.run(["openssl", "genrsa", "-out", key, "2048"], check=True, capture_output=True)
        subprocess.run(["openssl", "rsa", "-in", key, "-pubout", "-out", pub], check=True, capture_output=True)
        sa = {"client_email": "svc@proj.iam.gserviceaccount.com", "private_key": open(key).read()}
        jwt = pushmod.make_jwt(sa, now=1_700_000_000)
        h, c, s = jwt.split(".")
        claims = json.loads(base64.urlsafe_b64decode(c + "=="))
        self.assertEqual(claims["iss"], sa["client_email"])
        self.assertEqual(claims["exp"] - claims["iat"], 3600)
        self.assertIn("firebase.messaging", claims["scope"])
        sig = os.path.join(d, "sig")
        open(sig, "wb").write(base64.urlsafe_b64decode(s + "=="))
        r = subprocess.run(["openssl", "dgst", "-sha256", "-verify", pub, "-signature", sig], input=(h + "." + c).encode(), capture_output=True)
        self.assertIn(b"Verified OK", r.stdout)

    def test_push_disabled_is_safe(self):
        e = Env()
        try:
            self.assertFalse(e.app.push.fcm_enabled)
            self.assertEqual(e.app.push.send(["tok"], "t", "b"), (0, 0))
            self.assertFalse(e.app.push.staff_alert("x"))
        finally:
            e.close()


if __name__ == "__main__":
    unittest.main()
