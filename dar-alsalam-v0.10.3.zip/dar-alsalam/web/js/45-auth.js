/* تسجيل المرضى: جوال + رمز تحقق SMS. التصفح حر؛ يُطلب التسجيل عند إرسال طلب حجز فقط.
   يعمل فقط إن فعّل الخادم مزوّد الرسائل (meta.auth.enabled)؛ وإلا يبقى الحجز بلا تسجيل كما كان. */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui;

  var A = DS.auth = {
    enabled: function () { return !DS.cfg.demo && !!(D.ds && D.ds.meta && D.ds.meta.auth && D.ds.meta.auth.enabled); },
    token: function () { return DS.store.get('ptoken', '') || ''; },
    patient: function () { return A.token() ? DS.store.get('patient', null) : null; },
    set: function (t, p) { DS.store.set('ptoken', t); DS.store.set('patient', p); },
    clear: function () { DS.store.del('ptoken'); DS.store.del('patient'); DS.store.del('records'); },
    /* true = أعدنا التوجيه لصفحة الدخول */
    gate: function (next) {
      if (!A.enabled() || A.token()) return false;
      setTimeout(function () { location.replace('#/login?next=' + encodeURIComponent(next || '#/')); }, 0);
      return true;
    },
    local: function (phone) { return phone && phone.slice(0, 3) === '966' ? '0' + phone.slice(3) : phone || ''; }
  };

  /* فتح صفحة ملفات أو زيارات مباشرة عند بدء التشغيل قبل وصول إعدادات الخادم: نحوّل لصفحة الدخول فور وصولها.
     صفحة الحجز ليست منها: يتصفحها المراجع بحرية ويُطلب الدخول عند «تأكيد الحجز» فقط (انظر 40-booking.js). */
  D.onChange(function () { if (A.enabled() && !A.token() && /^#\/(files|link|visits)/.test(location.hash)) A.gate(location.hash); });

  var fld = A.fld = function (id, label, input, hint) {
    return '<div class="fld"><label for="' + id + '">' + label + '</label>' + input + (hint ? '<div class="xs muted" style="margin-top:4px">' + hint + '</div>' : '') + '<div class="err" data-err="' + id + '" hidden></div></div>';
  };
  function showErr(fields) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-err]'), function (e) { e.hidden = true; });
    Object.keys(fields || {}).forEach(function (k) {
      var e = DS.$('[data-err="a-' + k + '"]') || DS.$('[data-err="' + k + '"]'); if (e) { e.textContent = fields[k]; e.hidden = false; }
    });
  }

  DS.route('/login', function (p, q) {
    if (!A.enabled()) {
      /* أول فتح قبل أن تصل إعدادات الخادم (النسخة المضمّنة فقط): ننتظرها قليلاً بدل أن نعيدك للرئيسية فوراً.
         حين تصل يُعاد رسم الصفحة تلقائياً: تظهر شاشة الدخول إن كان التسجيل مفعّلاً، وإلا نعود للرئيسية. */
      if (!DS.cfg.demo && D.source === 'seed' && !A.waited) {
        A.waited = true;
        setTimeout(function () { if (!A.enabled() && /^#\/login/.test(location.hash)) location.replace('#/'); }, 6000);
        return '<div class="card"><p class="sm muted">جارٍ التحميل…</p></div>';
      }
      setTimeout(function () { location.replace('#/'); }, 0); return '';
    }
    var next = q.next && q.next.charAt(0) === '#' ? q.next : '#/', st = { phone: '', isNew: false };
    var toBook = next.indexOf('#/book') === 0, saved = toBook && DS.bkDraft ? DS.bkDraft.line() : '';
    var html = '<div id="au-root"><div class="card"><h2 style="font-weight:800;font-size:1.1rem">' + (toBook ? 'سجّل دخولك لتأكيد الحجز' : 'تسجيل الدخول') + '</h2>' +
      (saved ? '<div class="alert info" style="margin:8px 0 4px">' + ic('check', 'sm') + '<div><b>حجزك محفوظ:</b> ' + esc(saved) + '<div class="xs">بعد الدخول تعود إليه تلقائياً.</div></div></div>' : '') +
      '<p class="sm muted" style="margin:4px 0 12px">' + (toBook ? 'ندخلك برمز يصلك على جوالك، وإن لم يكن لديك حساب ننشئه لك في الخطوة التالية.' : 'تصفّح التطبيق بحرية. التسجيل مطلوب فقط عند طلب الحجز أو الاستشارة.') + '</p>' +
      '<form id="au-phone" class="form" novalidate>' + fld('a-phone', 'رقم الجوال', '<input class="in ltr" id="a-phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="05xxxxxxxx">') +
      '<div id="au-fail"></div><button class="btn pri blk" type="submit">إرسال رمز التحقق</button></form>' +
      (toBook ? '<a class="btn ghost blk" style="margin-top:8px" href="#/book?resume=1">العودة إلى الحجز</a>' : '') + '</div></div>';
    setTimeout(function () {
      var root_ = DS.$('#au-root');
      function fail(msg) { var f = DS.$('#au-fail'); if (f) f.innerHTML = msg ? '<div class="alert danger" style="margin-bottom:10px">' + ic('alert', 'sm') + '<div>' + esc(msg) + '</div></div>' : ''; }
      function codeStep() {
        root_.innerHTML = '<div class="card"><h2 style="font-weight:800;font-size:1.1rem">رمز التحقق</h2>' +
          '<p class="sm muted" style="margin:4px 0 12px">أرسلنا رمزاً من 6 أرقام إلى <span class="ltr">' + esc(A.local(st.phone)) + '</span>.</p>' +
          '<form id="au-code" class="form" novalidate>' + fld('a-code', 'الرمز', '<input class="in ltr" id="a-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000">') +
          (st.isNew ? '<h3 style="font-weight:800;margin:12px 0 4px">أكمل بياناتك</h3>' +
            fld('a-name', 'الاسم', '<input class="in" id="a-name" autocomplete="name" maxlength="60">') +
            fld('a-gender', 'الجنس', '<select class="in" id="a-gender"><option value="">اختر</option><option value="male">ذكر</option><option value="female">أنثى</option></select>') +
            fld('a-birthDate', 'تاريخ الميلاد', '<input class="in ltr" id="a-birthDate" type="date" max="' + DS.riyadhToday(0) + '">') +
            fld('a-nationalId', 'رقم الهوية / الإقامة <span class="muted">(اختياري)</span>', '<input class="in ltr" id="a-nationalId" inputmode="numeric" maxlength="10">', 'تساعد موظف المجمع على فتح ملفك أسرع. يمكنك تركه فارغاً.') : '') +
          '<p class="xs muted">بالمتابعة توافق على <a href="#/privacy">سياسة الخصوصية</a>.</p><div id="au-fail"></div>' +
          '<button class="btn pri blk" type="submit">' + (st.isNew ? 'إنشاء الحساب' : 'دخول') + '</button>' +
          '<button class="btn ghost blk" type="button" data-act="au-back" style="margin-top:8px">تغيير الرقم</button></form></div>';
        var f = DS.$('#au-code');
        f.addEventListener('submit', function (ev) {
          ev.preventDefault(); fail(''); showErr({});
          var body = { phone: st.phone, code: DS.$('#a-code').value.trim() };
          if (st.isNew) body.profile = { name: DS.$('#a-name').value, gender: DS.$('#a-gender').value, birthDate: DS.$('#a-birthDate').value, nationalId: DS.$('#a-nationalId').value };
          var btn = f.querySelector('button[type=submit]'); btn.disabled = true;
          DS.api.post('/auth/verify', body, { timeout: 15000 }).then(function (r) {
            A.set(r.data.token, r.data.patient);
            DS.store.set('profile', { name: r.data.patient.name, phone: A.local(r.data.patient.phone) });
            DS.toast('تم تسجيل الدخول'); if (DS.files && DS.files.refresh) DS.files.refresh(); location.replace(next);
          }).catch(function (e) {
            btn.disabled = false;
            if (e && e.fields && Object.keys(e.fields).length) showErr(e.fields);
            fail(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر التحقق الآن.');
          });
        });
      }
      DS.acts['au-back'] = function () { location.reload(); return false; };
      DS.$('#au-phone').addEventListener('submit', function (ev) {
        ev.preventDefault(); fail(''); showErr({});
        var ph = DS.normPhone(DS.$('#a-phone').value.trim());
        if (!ph || ph.slice(0, 4) !== '9665') { showErr({ 'a-phone': 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)' }); return; }
        var btn = ev.target.querySelector('button[type=submit]'); btn.disabled = true;
        DS.api.post('/auth/otp', { phone: ph, deviceId: DS.deviceId() }, { timeout: 15000 }).then(function (r) {
          st.phone = ph; st.isNew = !!r.data.isNew; codeStep();
        }).catch(function (e) {
          btn.disabled = false;
          fail(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر إرسال الرمز الآن.');
        });
      });
    }, 0);
    return html;
  }, { tab: 'none', title: 'تسجيل الدخول', back: true });

  /* بطاقة الحساب في «طلباتي وبياناتي» */
  A.card = function () {
    if (!A.enabled()) return '';
    var p = A.patient();
    if (!p) return '<div class="card row" style="margin-bottom:10px"><span class="ico-box">' + ic('user') + '</span><div class="grow"><b>حسابي</b><p class="sm muted">سجّل لتتمكن من إرسال طلبات الحجز.</p></div><a class="btn pri sm" href="#/login?next=' + encodeURIComponent('#/profile') + '">دخول</a></div>';
    return '<div class="card" style="margin-bottom:10px"><b>حسابي</b><p class="sm" style="margin:6px 0"><span>' + esc(p.name) + '</span> · <span class="ltr">' + esc(A.local(p.phone)) + '</span></p>' +
      '<div class="grid2"><button class="btn out sm" data-act="au-logout">تسجيل الخروج</button>' +
      '<button class="btn out sm" style="color:var(--danger);border-color:var(--danger)" data-act="au-delete">حذف حسابي</button></div></div>';
  };
  DS.acts['au-logout'] = function () { A.clear(); DS.toast('تم تسجيل الخروج'); DS.render(); return false; };
  DS.acts['au-delete'] = function () {
    if (!root.confirm('سيُحذف حسابك وتُزال بياناتك من طلباتك لدى المجمع، ولا يمكن التراجع. متابعة؟')) return false;
    DS.api.post('/auth/delete', {}).then(function () { A.clear(); DS.store.del('profile'); DS.store.del('myBookings'); DS.toast('تم حذف حسابك'); DS.render(); })
      .catch(function () { DS.toast('تعذر الحذف الآن، جرّب عند توفر الاتصال.'); });
    return false;
  };
})(window);

/* ملفات المراجع (PDF يرفعها موظفو المجمع): كل مراجع يرى ملفاته فقط، والخادم يتحقق من الهوية عند كل فتح أو تحميل */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui, A = DS.auth, fld = A.fld;

  var F = DS.files = {
    enabled: function () { return A.enabled() && !!(D.ds && D.ds.meta && D.ds.meta.files && D.ds.meta.files.enabled); },
    kinds: function () { return (D.ds && D.ds.meta && D.ds.meta.files && D.ds.meta.files.kinds) || []; },
    label: function (k) { var m = F.kinds().filter(function (x) { return x.id === k; })[0]; return m ? m.label : 'ملفات'; }
  };
  function fmtSize(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function fmtDate(iso) { try { return new Date(iso).toLocaleDateString('ar-SA-u-nu-latn-ca-gregory', { timeZone: 'Asia/Riyadh', day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return ''; } }

  /* الملف الطبي المرتبط بحساب المراجع (رقم الملف + بياناته) */
  F.records = function () { return A.token() ? DS.store.get('records', []) : []; };
  F.refresh = function () {
    if (!F.enabled() || !A.token()) return Promise.resolve([]);
    return DS.api.get('/records/mine', { timeout: 10000 }).then(function (r) {
      var l = (r.data && r.data.records) || []; DS.store.set('records', l); return l;
    }).catch(function (e) { if (e && e.status === 401) A.clear(); return F.records(); });
  };
  function fmtBirth(s) { return s ? fmtDate(s + 'T12:00:00+03:00') : ''; }
  function recCard(r) {
    return '<div class="card" style="margin-bottom:10px"><div class="row"><span class="ico-box">' + ic('user') + '</span><div class="grow"><b>' + esc(r.name) + '</b>' +
      '<div class="xs muted">رقم الملف: <span class="ltr">' + esc(r.mrn) + '</span></div>' +
      '<div class="xs muted">' + (r.birthDate ? 'الميلاد: ' + esc(fmtBirth(r.birthDate)) + ' · ' : '') + (r.gender ? (r.gender === 'male' ? 'ذكر' : 'أنثى') + ' · ' : '') + '<span class="ltr">' + esc(A.local(r.phone)) + '</span></div></div></div></div>';
  }
  /* بطاقة «ملفي الطبي» في صفحة بياناتي: تُرسم من النسخة المحفوظة ثم تتحدّث من الخادم */
  F.card = function () {
    if (!F.enabled() || !A.token()) return '';
    setTimeout(function () { F.refresh().then(function (l) { var b = DS.$('#mf-card'); if (b) b.innerHTML = cardBody(l); }); }, 0);
    return '<div id="mf-card">' + cardBody(F.records()) + '</div>';
  };
  function cardBody(l) {
    if (!l.length) return '<div class="card row" style="margin-bottom:10px"><span class="ico-box">' + ic('file') + '</span><div class="grow"><b>ملفي الطبي</b><p class="sm muted">اربط حسابك بملفك في المجمع لتظهر لك نتائجك ووثائقك هنا.</p></div><a class="btn pri sm" href="#/link?next=' + encodeURIComponent('#/files') + '">ربط الملف</a></div>';
    return '<div style="margin-bottom:10px"><div class="row" style="margin-bottom:6px"><b class="grow">ملفي الطبي</b><a class="sm" href="#/link?next=' + encodeURIComponent('#/profile') + '">ربط ملف آخر</a></div>' + l.map(recCard).join('') +
      '<a class="btn pri blk" href="#/files">' + ic('file', 'sm') + 'ملفاتي ونتائجي</a></div>';
  }

  DS.route('/link', function (p, q) {
    if (!F.enabled()) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    var next = q.next && q.next.charAt(0) === '#' ? q.next : '#/files';
    setTimeout(function () {
      var f = DS.$('#lk-form'); if (!f) return;
      f.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var nid = DS.$('#lk-nid').value.replace(/\D/g, ''), bd = DS.$('#lk-bd').value, fail = DS.$('#lk-fail'), btn = f.querySelector('button[type=submit]');
        fail.innerHTML = '';
        if (!nid && !bd) { fail.innerHTML = '<div class="alert danger" style="margin-bottom:10px">' + ic('alert', 'sm') + '<div>اكتب رقم الهوية/الإقامة أو تاريخ الميلاد.</div></div>'; return; }
        btn.disabled = true;
        DS.api.post('/records/link', nid ? { nationalId: nid } : { birthDate: bd }, { timeout: 15000 }).then(function (r) {
          DS.store.set('records', r.data.records || []); DS.toast('تم ربط ملفك الطبي'); location.replace(next);
        }).catch(function (e) {
          btn.disabled = false;
          if (e && e.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); return; }
          fail.innerHTML = '<div class="alert danger" style="margin-bottom:10px">' + ic('alert', 'sm') + '<div>' + esc(e && e.code === 'network' ? 'تعذر الاتصال بالخادم، حاول مرة أخرى.' : (e && e.message) || 'تعذر الربط الآن.') + '</div></div>';
        });
      });
    }, 0);
    return '<div class="card"><h2 style="font-weight:800;font-size:1.1rem">ربط ملفي الطبي</h2>' +
      '<p class="sm muted" style="margin:4px 0 12px">لحماية خصوصيتك نتأكد أنك صاحب الملف: أدخل رقم الهوية/الإقامة <b>أو</b> تاريخ الميلاد المسجّل في المجمع. يجب أن يكون جوالك هو الرقم المسجّل في ملفك لدى المجمع.</p>' +
      '<form id="lk-form" class="form" novalidate>' +
      fld('lk-nid', 'رقم الهوية / الإقامة', '<input class="in ltr" id="lk-nid" inputmode="numeric" maxlength="10" autocomplete="off">') +
      '<div class="xs muted" style="text-align:center;margin:-4px 0 8px">أو</div>' +
      fld('lk-bd', 'تاريخ الميلاد', '<input class="in ltr" id="lk-bd" type="date" max="' + DS.riyadhToday(0) + '">', 'لملف أحد أبنائك (برقم جوالك) استخدم تاريخ ميلاده.') +
      '<div id="lk-fail"></div><button class="btn pri blk" type="submit">ربط الملف</button></form></div>';
  }, { tab: 'none', title: 'ربط الملف الطبي', back: true });

  function noRecords() {
    return '<div class="card" style="text-align:center">' + ic('file') + '<p class="sm" style="margin:8px 0">لم تربط ملفك الطبي بعد، فلا توجد ملفات لعرضها.</p><a class="btn pri" href="#/link?next=' + encodeURIComponent(location.hash || '#/files') + '">ربط الملف الطبي</a></div>';
  }
  function fileCard(x, multi) {
    return '<div class="card fl" style="margin-bottom:10px"><div class="row"><span class="ico-box">' + ic('file') + '</span><div class="grow"><b>' + esc(x.title) + '</b>' +
      '<div class="xs muted">' + esc(x.kindLabel) + ' · ' + esc(fmtDate(x.uploadedAt)) + ' · ' + fmtSize(x.size) + '</div>' + (multi && x.recordName ? '<div class="xs muted">للمراجع: ' + esc(x.recordName) + '</div>' : '') +
      (x.note ? '<div class="sm" style="margin-top:4px">' + esc(x.note) + '</div>' : '') + '</div></div>' +
      '<div class="grid2" style="margin-top:10px"><button class="btn pri sm" data-act="fl-view" data-id="' + esc(x.id) + '">عرض</button><button class="btn out sm" data-act="fl-dl" data-id="' + esc(x.id) + '" data-title="' + esc(x.title) + '">تحميل</button></div></div>';
  }
  function loadFiles(kind, onDone) {
    return DS.api.get('/files' + (kind ? '?kind=' + encodeURIComponent(kind) : ''), { timeout: 12000 }).then(function (r) { onDone((r.data && r.data.files) || []); });
  }
  function onErr(box) {
    return function (e) {
      if (e && e.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); return; }
      box.innerHTML = '<div class="alert danger">' + ic('alert', 'sm') + '<div>تعذر تحميل الملفات الآن. تحقق من الاتصال وحاول لاحقاً.</div></div>';
    };
  }

  /* نظرة عامة: كل أنواع الملفات مع العدد، وملف/ملفات المراجع المرتبطة */
  DS.route('/files', function () {
    if (!F.enabled()) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    setTimeout(function () {
      var box = DS.$('#fl-box'); if (!box) return;
      F.refresh().then(function (recs) {
        if (!recs.length) { box.innerHTML = noRecords(); return; }
        return loadFiles('', function (l) {
          var cnt = {}; l.forEach(function (x) { cnt[x.kind] = (cnt[x.kind] || 0) + 1; });
          box.innerHTML = recs.map(recCard).join('') + '<section class="sec">' + U.sec('أنواع الملفات') + F.kinds().map(function (k) {
            return '<a class="item" href="#/files/' + esc(k.id) + '">' + U.icoBox('file') + '<div class="grow"><h3>' + esc(k.label) + '</h3></div>' + (cnt[k.id] ? '<span class="tag">' + cnt[k.id] + '</span>' : '') + ic('chevron-left', 'chev') + '</a>'; }).join('') + '</section>' +
            (l.length ? '<section class="sec">' + U.sec('الأحدث') + l.slice(0, 3).map(function (x) { return fileCard(x, recs.length > 1); }).join('') + '</section>' : '');
        });
      }).catch(onErr(box));
    }, 0);
    return '<div class="alert info" style="margin-bottom:10px">' + ic('shield', 'sm') + '<div>هذه ملفاتك أنت فقط. لا تشاركها مع أحد.</div></div><div id="fl-box"><div class="skel" style="height:110px"></div></div>';
  }, { tab: 'none', title: 'ملفاتي', back: true });

  DS.route('/files/:kind', function (p) {
    if (!F.enabled()) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (A.gate(location.hash)) return '';
    var kind = p.kind, label = F.label(kind);
    setTimeout(function () {
      var box = DS.$('#fl-box'); if (!box) return;
      F.refresh().then(function (recs) {
        if (!recs.length) { box.innerHTML = noRecords(); return; }
        return loadFiles(kind, function (l) {
          box.innerHTML = l.length ? l.map(function (x) { return fileCard(x, recs.length > 1); }).join('')
            : U.empty('لا توجد ملفات في «' + label + '» حالياً. تظهر هنا فور رفعها من موظفي المجمع إلى ملفك.', 'file');
        });
      }).catch(onErr(box));
    }, 0);
    return '<div class="alert info" style="margin-bottom:10px">' + ic('shield', 'sm') + '<div>هذه ملفاتك أنت فقط. لا تشاركها مع أحد.</div></div><div id="fl-box"><div class="skel" style="height:110px"></div></div>';
  }, { tab: 'none', title: 'ملفاتي', back: true });

  function fetchPdf(id, dl) {
    return fetch(DS.api.url('/files/' + encodeURIComponent(id) + (dl ? '?dl=1' : '')), { headers: { 'Authorization': 'Bearer ' + A.token() }, cache: 'no-store' }).then(function (r) {
      if (r.status === 401) { A.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); throw new Error('login'); }
      if (!r.ok) throw new Error('تعذر فتح الملف الآن');
      return r.blob();
    });
  }
  DS.acts['fl-view'] = function (el) {
    var w = root.open('', '_blank');   // نفتح النافذة فوراً (قيد المتصفح على النوافذ بعد الطلب)
    fetchPdf(el.getAttribute('data-id'), false).then(function (b) {
      var u = URL.createObjectURL(b); if (w) w.location = u; else location.href = u;
      setTimeout(function () { URL.revokeObjectURL(u); }, 120000);
    }).catch(function (e) { if (w) w.close(); if (e.message !== 'login') DS.toast(e.message || 'تعذر فتح الملف'); });
    return false;
  };
  DS.acts['fl-dl'] = function (el) {
    fetchPdf(el.getAttribute('data-id'), true).then(function (b) {
      var u = URL.createObjectURL(b), a = document.createElement('a');
      a.href = u; a.download = (el.getAttribute('data-title') || 'document') + '.pdf'; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
    }).catch(function (e) { if (e.message !== 'login') DS.toast(e.message || 'تعذر تحميل الملف'); });
    return false;
  };
})(window);
