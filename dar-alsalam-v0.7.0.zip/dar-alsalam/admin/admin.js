/* لوحة إدارة دار السلام. النماذج تُبنى من مخطط الخادم (/api/admin/schema): أي حقل جديد يظهر هنا دون تعديل هذا الملف. */
(function () {
  'use strict';
  var API = '/api/admin';
  var STATUS = { 'new': 'جديد', contacted: 'تم التواصل', confirmed: 'مؤكد', cancelled: 'ملغي' };
  var PERIOD = { morning: 'صباحاً', evening: 'مساءً', any: 'أي وقت' };
  var KINDS = ['doctors', 'specialties', 'services', 'branches', 'faqs', 'banners'];
  var S = { token: '', schema: null, ds: null, stats: null, bk: { status: '', q: '', rows: [], stats: {} }, prefill: null, route: '' };
  try { S.token = sessionStorage.getItem('ds.admin.token') || ''; } catch (e) { /* تجاهل */ }

  /* ---------- أدوات ---------- */
  var $ = function (s, e) { return (e || document).querySelector(s); };
  var $$ = function (s, e) { return Array.prototype.slice.call((e || document).querySelectorAll(s)); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function nl(s) { return esc(s).replace(/\n/g, '<br>'); }
  var toastT;
  function toast(msg, bad) { var t = $('#toast'); t.textContent = msg; t.className = 'toast on' + (bad ? ' bad' : ''); clearTimeout(toastT); toastT = setTimeout(function () { t.className = 'toast'; }, 3200); }
  function fmtTime(iso) {
    try { return new Date(iso).toLocaleString('ar-SA-u-nu-latn-ca-gregory', { timeZone: 'Asia/Riyadh', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch (e) { return iso || ''; }
  }
  function nm(kind, id) { var l = (S.ds && S.ds[kind]) || [], x = l.filter(function (e) { return e.id === id; })[0]; return x ? (x.name || x.title || x.question || id) : (id || ''); }
  function getPath(o, p) { return p.split('.').reduce(function (c, k) { return c && typeof c === 'object' ? c[k] : undefined; }, o); }
  function setPath(o, p, v) { var a = p.split('.'), c = o; for (var i = 0; i < a.length - 1; i++) { c = c[a[i]] = c[a[i]] || {}; } c[a[a.length - 1]] = v; }
  function cut(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n) + '…' : s; }

  function api(method, path, body) {
    var h = { 'Accept': 'application/json' };
    if (body !== undefined) h['Content-Type'] = 'application/json';
    if (S.token) h['Authorization'] = 'Bearer ' + S.token;
    return fetch(API + path, { method: method, headers: h, body: body === undefined ? undefined : JSON.stringify(body), cache: 'no-store' }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401 && j.error === 'unauthorized') { logout('انتهت الجلسة، سجّل الدخول من جديد'); }
        if (!r.ok) { var e = new Error(j.message || j.error || ('HTTP ' + r.status)); e.status = r.status; e.fields = j.fields || {}; e.code = j.error; throw e; }
        return j;
      });
    });
  }
  function logout(msg) {
    S.token = ''; try { sessionStorage.removeItem('ds.admin.token'); } catch (e) { /* تجاهل */ }
    loginView(msg);
  }

  /* ---------- تسجيل الدخول ---------- */
  function loginView(msg) {
    $('#root').innerHTML = '<div class="login"><img src="../app/img/mark.svg" alt="" width="79" height="62"><h1>لوحة إدارة دار السلام</h1><p class="muted sm">للموظفين المخوّلين فقط</p>' +
      '<form data-submit="login"><div class="fld"><label for="pw">كلمة المرور</label><input class="in" id="pw" type="password" autocomplete="current-password" required></div>' +
      '<div class="err" id="login-err"' + (msg ? '' : ' hidden') + '>' + esc(msg || '') + '</div><button class="btn pri" type="submit">دخول</button></form></div>';
    var pw = $('#pw'); if (pw) pw.focus();
  }

  /* ---------- الهيكل ---------- */
  var NAV = [
    ['dash', 'نظرة عامة'], ['bookings', 'الحجوزات'],
    ['grp', 'المحتوى'], ['list/doctors', 'الأطباء'], ['list/specialties', 'التخصصات'], ['list/services', 'الخدمات'], ['list/branches', 'الفروع'], ['list/faqs', 'الأسئلة الشائعة'], ['list/banners', 'اللوحات الإعلانية'],
    ['grp', 'المراجعون'], ['files', 'المراجعون والملفات'],
    ['grp', 'المنظومة'], ['staff', 'الموظفون والصلاحيات'], ['audit', 'سجل التدقيق'],
    ['grp', 'الإعدادات'], ['settings', 'معلومات المجمع'], ['qamar', 'المساعد قمر'], ['notify', 'الإشعارات'], ['security', 'الأمان والنسخ']
  ];
  function shell() {
    $('#root').innerHTML = '<div class="shell"><aside class="side"><div class="brand"><img src="../app/img/mark-white.svg" alt="" width="41" height="32"><span>إدارة دار السلام</span></div><nav id="nav">' +
      NAV.map(function (n) {
        if (n[0] === 'grp') return '<div class="grp">' + n[1] + '</div>';
        return '<a href="#/' + n[0] + '" data-r="' + n[0] + '">' + n[1] + (n[0] === 'bookings' ? '<span class="pill" id="newpill" hidden></span>' : '') + '</a>';
      }).join('') + '</nav><button class="out" data-a="logout">تسجيل الخروج</button></aside><main class="main" id="main" tabindex="-1"></main></div>';
    badge();
  }
  function badge() {
    var n = S.stats && S.stats.bookings ? S.stats.bookings['new'] : 0, p = $('#newpill');
    if (p) { p.hidden = !n; p.textContent = n; }
    document.title = (n ? '(' + n + ') ' : '') + 'لوحة إدارة دار السلام';
  }
  function setNav(route) {
    $$('#nav a').forEach(function (a) { a.classList.toggle('on', route === a.getAttribute('data-r') || (route.indexOf('edit/') === 0 && a.getAttribute('data-r') === 'list/' + route.split('/')[1])); });
  }
  function main() { return $('#main'); }

  /* ---------- مكوّنات النماذج المبنية من المخطط ---------- */
  function fid(k) { return 'f_' + k.replace(/[^a-z0-9]/gi, '_'); }
  function phoneRow(p) {
    var types = (S.schema.phoneTypes || [['main', 'الرقم الموحد'], ['whatsapp', 'واتساب'], ['other', 'آخر']]);
    return '<div class="ph-row"><input class="in" data-ph="label" placeholder="الوصف" value="' + esc(p.label || '') + '"><input class="in ltr" data-ph="number" type="tel" placeholder="الرقم" value="' + esc(p.number || '') + '">' +
      '<select class="in" data-ph="type">' + types.map(function (t) { return '<option value="' + esc(t[0]) + '"' + (p.type === t[0] ? ' selected' : '') + '>' + esc(t[1]) + '</option>'; }).join('') + '</select>' +
      '<button type="button" class="btn dangero sm" data-a="ph-del">حذف</button><input type="hidden" data-ph="branchId" value="' + esc(p.branchId || '') + '"></div>';
  }
  function fieldHtml(f, val) {
    var id = fid(f.key), k = esc(f.key), req = f.required ? ' <span class="req">*</span>' : '';
    var help = f.help ? '<div class="help">' + esc(f.help) + '</div>' : '', err = '<div class="err" data-err="' + k + '" hidden></div>';
    var max = f.max ? ' maxlength="' + f.max + '"' : '', body = '';
    switch (f.type) {
      case 'bool': return '<div class="fld bool"><label class="chk"><input type="checkbox" id="' + id + '" data-k="' + k + '"' + (val ? ' checked' : '') + '><span>' + esc(f.label) + '</span></label>' + help + err + '</div>';
      case 'textarea': body = '<textarea class="in" id="' + id + '" data-k="' + k + '" rows="4"' + max + '>' + esc(val || '') + '</textarea>'; break;
      case 'list': body = '<textarea class="in" id="' + id + '" data-k="' + k + '" rows="5">' + esc((val || []).join('\n')) + '</textarea>'; break;
      case 'number': body = '<input class="in ltr" type="number" id="' + id + '" data-k="' + k + '" step="' + esc(f.step || 1) + '" value="' + (val == null ? '' : esc(val)) + '">'; break;
      case 'phone': body = '<input class="in ltr" type="tel" id="' + id + '" data-k="' + k + '" value="' + esc(val || '') + '"' + max + '>'; break;
      case 'url': body = '<input class="in ltr" type="url" id="' + id + '" data-k="' + k + '" placeholder="https://" value="' + esc(val || '') + '">' +
        (/(^|\.)(image|photo)$/.test(f.key) ? '<div class="up-row"><label class="btn ghost sm up-btn">رفع صورة من الجهاز<input type="file" accept="image/*" hidden data-up="' + id + '"></label><span class="muted sm" data-upmsg="' + id + '"></span></div>' : ''); break;
      case 'select': body = '<select class="in" id="' + id + '" data-k="' + k + '">' + (f.options || []).map(function (o) {
        return '<option value="' + esc(o) + '"' + ((val || f.default) === o ? ' selected' : '') + '>' + esc((f.labels && f.labels[o]) || o) + '</option>'; }).join('') + '</select>'; break;
      case 'multi': {
        var items = (S.ds && S.ds[f.ref]) || [], cur = val || [];
        body = '<div class="checks">' + (items.length ? items.map(function (e) {
          return '<label><input type="checkbox" data-k="' + k + '" value="' + esc(e.id) + '"' + (cur.indexOf(e.id) >= 0 ? ' checked' : '') + '>' + esc(e.name || e.id) + '</label>'; }).join('') : '<span class="muted sm">لا توجد عناصر</span>') + '</div>';
        break;
      }
      case 'phones': body = '<div data-phs="' + k + '">' + (val || []).map(phoneRow).join('') + '</div><button type="button" class="btn ghost sm" data-a="ph-add">+ إضافة رقم</button>'; break;
      default: body = '<input class="in" type="text" id="' + id + '" data-k="' + k + '" value="' + esc(val == null ? '' : val) + '"' + max + '>';
    }
    return '<div class="fld"><label' + (f.type === 'multi' || f.type === 'phones' ? '' : ' for="' + id + '"') + '>' + esc(f.label) + req + '</label>' + body + help + err + '</div>';
  }
  function collect(fields, root) {
    var out = {};
    fields.forEach(function (f) {
      var v;
      if (f.type === 'multi') v = $$('input[data-k="' + f.key + '"]:checked', root).map(function (c) { return c.value; });
      else if (f.type === 'phones') v = $$('.ph-row', root).map(function (r) {
        var g = function (n) { return ($('[data-ph="' + n + '"]', r).value || '').trim(); };
        var o = { label: g('label'), number: g('number'), type: g('type') }; if (g('branchId')) o.branchId = g('branchId'); return o;
      }).filter(function (p) { return p.number || p.label; });
      else {
        var el = $('[data-k="' + f.key + '"]', root); if (!el) return;
        if (f.type === 'bool') v = el.checked;
        else if (f.type === 'list') v = el.value.split(/\n+/).map(function (x) { return x.trim(); }).filter(Boolean);
        else if (f.type === 'number') v = el.value === '' ? null : Number(el.value);
        else v = el.value.trim();
      }
      setPath(out, f.key, v);
    });
    return out;
  }
  function showErrors(root, fields, general) {
    $$('.err[data-err]', root).forEach(function (e) { e.hidden = true; e.textContent = ''; });
    $$('.in.bad', root).forEach(function (e) { e.classList.remove('bad'); });
    var first = null;
    Object.keys(fields || {}).forEach(function (k) {
      var e = $('[data-err="' + k + '"]', root), i = $('[data-k="' + k + '"]', root);
      if (e) { e.textContent = fields[k]; e.hidden = false; first = first || e; } else if (general) { general += ' — ' + k + ': ' + fields[k]; }
      if (i) i.classList.add('bad');
    });
    var box = $('.form-err', root);
    if (box) { box.hidden = !general; box.textContent = general || ''; }
    if (first && first.scrollIntoView) first.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  /* ================= نظرة عامة ================= */
  function dashView() {
    var m = main(), ds = S.ds, st = S.stats || { bookings: {}, audit: [] }, s = ds.settings || {};
    var flagged = KINDS.reduce(function (a, k) { return a.concat((ds[k] || []).filter(function (e) { return e.needsReview; }).map(function (e) { return [k, e]; })); }, []);
    var html = '<div class="page-h"><h1>نظرة عامة</h1></div>';
    if (s.dataStatus !== 'verified') html += '<div class="alert warn"><b>بيانات التطبيق ما زالت «مسودة».</b> يظهر للمراجعين شريط «بيانات قيد المراجعة». بعد مراجعتك للأطباء والفروع والأرقام غيّر الحالة إلى «تمت مراجعتها» من <a href="#/settings">معلومات المجمع</a>.</div>';
    html += '<div class="grid g4"><a class="stat' + (st.bookings['new'] ? ' hot' : '') + '" href="#/bookings"><b>' + (st.bookings['new'] || 0) + '</b><span>طلبات جديدة</span></a>' +
      '<a class="stat" href="#/bookings"><b>' + (st.bookings.contacted || 0) + '</b><span>تم التواصل</span></a><a class="stat" href="#/bookings"><b>' + (st.bookings.confirmed || 0) + '</b><span>مؤكدة</span></a>' +
      '<a class="stat" href="#/qamar"><b>' + (st.qamarToday || 0) + '</b><span>رسائل قمر اليوم' + (ds.qamarStatus && ds.qamarStatus.llmConfigured ? ' · نموذج: ' + (st.llmToday || 0) : '') + '</span></a></div>';
    if (flagged.length) html += '<div class="card"><h2>عناصر تحتاج مراجعتك (' + flagged.length + ')</h2><p class="muted sm" style="margin-bottom:8px">أُدخلت من الموقع الرسمي وفيها معلومة غير مؤكدة. افتح العنصر وصحّحه ثم ألغِ علامة «يحتاج مراجعة».</p><ul class="list">' +
      flagged.slice(0, 12).map(function (x) { return '<li><a href="#/edit/' + x[0] + '/' + esc(x[1].id) + '">' + esc(x[1].name || x[1].title || x[1].question) + '</a> <span class="muted xs">(' + esc(S.schema.kinds[x[0]].label) + ')</span></li>'; }).join('') + (flagged.length > 12 ? '<li class="muted">…و' + (flagged.length - 12) + ' أخرى</li>' : '') + '</ul></div>';
    if ((s.reviewNotes || []).length) html += '<div class="card"><h2>ملاحظات المراجعة على بيانات الموقع</h2><ul class="list">' + s.reviewNotes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul></div>';
    html += '<div class="card"><h2>اختصارات</h2><div class="actions"><a class="btn pri" href="#/edit/doctors/new">+ طبيب</a><a class="btn out" href="#/edit/branches/new">+ فرع</a><a class="btn out" href="#/edit/services/new">+ خدمة</a><a class="btn out" href="#/edit/faqs/new">+ سؤال شائع</a><a class="btn out" href="#/notify">إرسال إشعار</a></div></div>';
    if ((st.audit || []).length) html += '<div class="card"><h2>آخر التعديلات</h2><ul class="list">' + st.audit.slice(0, 6).map(function (a) { return '<li class="sm">' + esc(fmtTime(a.ts)) + ' — ' + esc(a.action) + ' ' + esc(a.kind || '') + ' ' + esc(a.ref || '') + '</li>'; }).join('') + '</ul></div>';
    m.innerHTML = html;
  }

  /* ================= الحجوزات ================= */
  function bookingsView() {
    var m = main(), b = S.bk;
    m.innerHTML = '<div class="page-h"><h1>طلبات الحجز</h1><button class="btn ghost" data-a="bk-reload">تحديث</button></div>' +
      '<div class="alert info sm">الطلب «جديد» حتى يتواصل معه موظف. لا تضغط «مؤكد» إلا بعد الاتفاق على الموعد مع المراجع واكتب تفاصيله، فهو ما يراه المراجع في التطبيق.</div>' +
      '<div class="chips" id="bk-chips"></div><div class="tools"><input class="in" id="bk-q" type="search" placeholder="بحث بالاسم أو الجوال أو رقم الطلب" value="' + esc(b.q) + '"></div><div id="bk-box"><p class="muted">جارٍ التحميل…</p></div>';
    $('#bk-q').addEventListener('input', debounce(function () { S.bk.q = $('#bk-q').value.trim(); loadBookings(); }, 300));
    loadBookings();
  }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }
  function loadBookings() {
    var b = S.bk;
    return api('GET', '/bookings?status=' + encodeURIComponent(b.status) + '&q=' + encodeURIComponent(b.q)).then(function (r) {
      b.rows = r.bookings; b.stats = r.stats; S.stats = S.stats || { bookings: {} }; S.stats.bookings = r.stats; badge();
      var chips = $('#bk-chips'), box = $('#bk-box'); if (!chips || !box) return;
      chips.innerHTML = [['', 'الكل']].concat(Object.keys(STATUS).map(function (k) { return [k, STATUS[k] + ' (' + (r.stats[k] || 0) + ')']; })).map(function (c) {
        return '<button class="chipb' + (b.status === c[0] ? ' on' : '') + '" data-a="bk-filter" data-s="' + c[0] + '">' + esc(c[1]) + '</button>'; }).join('');
      box.innerHTML = r.bookings.length ? '<table class="tbl stack"><thead><tr><th>الوقت</th><th>الرقم</th><th>الاسم</th><th>الجوال</th><th>الطلب</th><th>الموعد المفضل</th><th>الحالة</th></tr></thead><tbody>' +
        r.bookings.map(function (x) {
          var what = [nm('specialties', x.specialty_id) || nm('services', x.service_id), x.doctor_id ? 'د. ' + nm('doctors', x.doctor_id) : '', x.branch_id ? nm('branches', x.branch_id) : ''].filter(Boolean).join(' · ');
          return '<tr class="click" data-a="bk-open" data-id="' + esc(x.id) + '"><td data-l="الوقت">' + esc(fmtTime(x.created_at)) + '</td><td data-l="الرقم" class="ltr">' + esc(x.id) + '</td><td data-l="الاسم">' + esc(x.name) + '</td>' +
            '<td data-l="الجوال" class="ltr">' + esc(x.phone) + '</td><td data-l="الطلب">' + esc(what) + '</td><td data-l="الموعد المفضل">' + esc((x.date || '—') + (x.period ? ' · ' + (PERIOD[x.period] || '') : '')) + '</td>' +
            '<td data-l="الحالة"><span class="tag ' + esc(x.status) + '">' + esc(STATUS[x.status] || x.status) + '</span></td></tr>'; }).join('') + '</tbody></table>' : '<div class="card muted">لا توجد طلبات مطابقة.</div>';
    }).catch(function (e) { toast(e.message, true); });
  }
  function openModal(title, html) {
    closeModal();
    var d = document.createElement('div'); d.className = 'modal-bg'; d.id = 'modal';
    d.innerHTML = '<div class="modal" role="dialog" aria-modal="true" aria-label="' + esc(title) + '"><div class="head"><h2>' + esc(title) + '</h2><button class="x" data-a="modal-close" aria-label="إغلاق">×</button></div>' + html + '</div>';
    document.body.appendChild(d);
    d.addEventListener('mousedown', function (e) { if (e.target === d) closeModal(); });
    return d;
  }
  function closeModal() { var d = $('#modal'); if (d) d.remove(); }
  function openBooking(id) {
    var x = S.bk.rows.filter(function (r) { return r.id === id; })[0]; if (!x) return;
    var digits = String(x.phone || '').replace(/\D/g, '');
    var d = openModal('طلب ' + x.id,
      '<dl class="kv"><dt>الاسم</dt><dd>' + esc(x.name) + '</dd><dt>الجوال</dt><dd><a class="ltr" href="tel:+' + esc(digits) + '">' + esc(x.phone) + '</a> · <a href="https://wa.me/' + esc(digits) + '" target="_blank" rel="noopener">واتساب</a></dd>' +
      '<dt>التخصص/الخدمة</dt><dd>' + esc(nm('specialties', x.specialty_id) || nm('services', x.service_id) || '—') + '</dd><dt>الطبيب</dt><dd>' + esc(x.doctor_id ? nm('doctors', x.doctor_id) : 'أي طبيب') + '</dd>' +
      '<dt>الفرع</dt><dd>' + esc(x.branch_id ? nm('branches', x.branch_id) : 'أي فرع') + '</dd><dt>الموعد المفضل</dt><dd>' + esc((x.date || 'غير محدد') + (x.period ? ' · ' + (PERIOD[x.period] || '') : '')) + '</dd>' +
      '<dt>ملاحظة المراجع</dt><dd>' + (x.note ? nl(x.note) : '—') + '</dd><dt>وصل في</dt><dd>' + esc(fmtTime(x.created_at)) + ' · ' + esc(x.source || 'app') + '</dd></dl><hr style="border:0;border-top:1px solid var(--line);margin:14px 0">' +
      '<form class="form" data-submit="bk-save" data-id="' + esc(x.id) + '"><div class="form-err alert danger" hidden></div>' +
      '<div class="fld"><label for="bk-status">الحالة</label><select class="in" id="bk-status" data-k="status">' + Object.keys(STATUS).map(function (k) { return '<option value="' + k + '"' + (x.status === k ? ' selected' : '') + '>' + STATUS[k] + '</option>'; }).join('') + '</select>' +
      '<div class="help">عند تغيير الحالة إلى «تم التواصل» أو «مؤكد» أو «ملغي» يصل المراجع إشعار داخل التطبيق تلقائياً.</div></div>' +
      '<div class="fld"><label for="bk-appt">تفاصيل الموعد المؤكد <span class="muted">(مطلوبة عند «مؤكد»)</span></label><input class="in" id="bk-appt" data-k="appointmentText" maxlength="200" placeholder="مثال: الأحد 5:30 مساءً — عيادة الباطنة — د. فلان" value="' + esc(x.appointment_text || '') + '"><div class="err" data-err="appointmentText" hidden></div></div>' +
      '<div class="fld"><label for="bk-note">ملاحظة داخلية <span class="muted">(لا تظهر للمراجع)</span></label><textarea class="in" id="bk-note" data-k="adminNote" maxlength="500" rows="3">' + esc(x.admin_note || '') + '</textarea></div>' +
      '<div class="actions"><button class="btn pri" type="submit">حفظ</button><button class="btn out" type="button" data-a="modal-close">إغلاق</button></div></form>');
    return d;
  }

  /* ================= قوائم الكيانات ================= */
  function lbl(kind, key, val) {
    var f = ((S.schema && S.schema.kinds[kind] && S.schema.kinds[kind].fields) || []).filter(function (x) { return x.key === key; })[0];
    return (f && f.labels && f.labels[val]) || val;
  }
  var COLS = {
    doctors: [['الاسم', function (e) { return 'د. ' + e.name; }], ['الدرجة', function (e) { return e.rank || ''; }],
      ['التخصصات', function (e) { return (e.specialtyIds || []).map(function (i) { return nm('specialties', i); }).concat((e.serviceIds || []).map(function (i) { return nm('services', i); })).join('، '); }],
      ['الفروع', function (e) { return (e.branchIds || []).map(function (i) { return nm('branches', i); }).join('، ') || 'غير محدد'; }]],
    specialties: [['الاسم', function (e) { return e.name; }], ['الوصف', function (e) { return cut(e.description, 60); }], ['الأطباء', function (e) { return S.ds.doctors.filter(function (d) { return (d.specialtyIds || []).indexOf(e.id) >= 0; }).length; }]],
    services: [['الاسم', function (e) { return e.name; }], ['الوصف', function (e) { return cut(e.description, 60); }], ['الساعات', function (e) { return e.hoursText || ''; }]],
    branches: [['الاسم', function (e) { return e.name; }], ['العنوان', function (e) { return e.address; }], ['الهاتف', function (e) { return e.phone || ''; }], ['إحداثيات الخريطة', function (e) { return e.lat != null ? 'نعم' : 'لا (روابط بحث)'; }]],
    faqs: [['السؤال', function (e) { return e.question; }], ['النوع', function (e) { return e.category === 'tips' ? 'نصيحة صحية' : 'سؤال عن المجمع/التطبيق'; }]],
    banners: [['العنوان', function (e) { return e.title; }], ['اللون', function (e) { return lbl('banners', 'theme', e.theme || 'blue'); }],
      ['الرابط', function (e) { var t = e.linkType || 'none'; return t === 'none' ? '—' : lbl('banners', 'linkType', t) + (e.linkRef ? ' · ' + cut(e.linkRef, 30) : ''); }]]
  };
  function listView(kind) {
    var m = main(), spec = S.schema.kinds[kind], rows = (S.ds[kind] || []).slice().sort(function (a, b) { return (a.sort || 0) - (b.sort || 0); });
    var cols = COLS[kind];
    m.innerHTML = '<div class="page-h"><h1>' + esc(spec.label) + ' <span class="muted sm">(' + rows.length + ')</span></h1><a class="btn pri" href="#/edit/' + kind + '/new">+ إضافة ' + esc(spec.single) + '</a></div>' +
      '<div class="tools"><input class="in" id="ls-q" type="search" placeholder="بحث"></div>' +
      '<table class="tbl stack"><thead><tr>' + cols.map(function (c) { return '<th>' + c[0] + '</th>'; }).join('') + '<th>الحالة</th><th></th></tr></thead><tbody id="ls-body"></tbody></table>';
    function draw() {
      var q = ($('#ls-q').value || '').trim();
      $('#ls-body').innerHTML = rows.filter(function (e) { return !q || JSON.stringify(e).indexOf(q) >= 0; }).map(function (e) {
        return '<tr class="click' + (e.active === false ? ' off' : '') + '" data-a="edit" data-kind="' + kind + '" data-id="' + esc(e.id) + '">' + cols.map(function (c) { return '<td data-l="' + c[0] + '">' + esc(c[1](e)) + '</td>'; }).join('') +
          '<td data-l="الحالة">' + (e.active === false ? '<span class="tag off">مخفي</span>' : '<span class="tag">ظاهر</span>') + (e.needsReview ? ' <span class="tag rev">يحتاج مراجعة</span>' : '') + '</td>' +
          '<td><button class="btn ghost sm" data-a="toggle" data-kind="' + kind + '" data-id="' + esc(e.id) + '">' + (e.active === false ? 'إظهار' : 'إخفاء') + '</button></td></tr>'; }).join('') ||
        '<tr><td colspan="' + (cols.length + 2) + '" class="muted">لا توجد نتائج</td></tr>';
    }
    $('#ls-q').addEventListener('input', draw); draw();
  }

  function editView(kind, id) {
    var m = main(), spec = S.schema.kinds[kind], isNew = id === 'new', cur = isNew ? {} : (S.ds[kind] || []).filter(function (e) { return e.id === id; })[0];
    if (!isNew && !cur) { m.innerHTML = '<div class="card">العنصر غير موجود. <a href="#/list/' + kind + '">رجوع</a></div>'; return; }
    if (isNew && S.prefill) { cur = S.prefill; S.prefill = null; }
    var fields = spec.fields;
    m.innerHTML = '<div class="page-h"><h1>' + (isNew ? 'إضافة ' : 'تعديل ') + esc(spec.single) + '</h1><a class="btn out" href="#/list/' + kind + '">رجوع للقائمة</a></div>' +
      '<form class="card form" data-submit="save-entity" data-kind="' + kind + '" data-id="' + esc(id) + '"><div class="form-err alert danger" hidden></div>' +
      (isNew ? '<div class="fld"><label for="new-id">المعرّف <span class="muted">(اختياري)</span></label><input class="in ltr" id="new-id" data-k="id" placeholder="يُولَّد تلقائياً، أو اكتب مثل: dr-ali"><div class="help">حروف إنجليزية صغيرة وأرقام وشرطات. لا يمكن تغييره لاحقاً.</div><div class="err" data-err="id" hidden></div></div>' : '') +
      fields.map(function (f) { var v = cur[f.key]; if (v === undefined) v = f.default !== undefined ? f.default : (f.type === 'bool' ? false : ''); return fieldHtml(f, v); }).join('') +
      '<div class="actions"><button class="btn pri" type="submit">حفظ</button><a class="btn out" href="#/list/' + kind + '">إلغاء</a>' +
      (!isNew ? '<button type="button" class="btn dangero" style="margin-inline-start:auto" data-a="hard-delete" data-kind="' + kind + '" data-id="' + esc(id) + '">حذف نهائي…</button>' : '') + '</div>' +
      (!isNew ? '<p class="help">للإخفاء المؤقت (الأفضل) أزل علامة «ظاهر في التطبيق». الحذف النهائي لا رجعة فيه.</p>' : '') + '</form>';
  }

  /* ================= الإعدادات / قمر ================= */
  var SETTINGS_HEADS = { name: 'الهوية', phones: 'التواصل', 'social.x': 'حسابات التواصل الاجتماعي', 'stats.patients': 'أرقام تظهر في الرئيسية (من الموقع الرسمي)', emergencyNumber: 'أرقام الطوارئ', 'booking.externalUrl': 'الحجز', notice: 'الرئيسية وحالة البيانات' };
  function settingsView() {
    var m = main(), s = S.ds.settings || {};
    m.innerHTML = '<div class="page-h"><h1>معلومات المجمع</h1></div><form class="card form" data-submit="save-settings"><div class="form-err alert danger" hidden></div>' +
      S.schema.settings.map(function (f) { return (SETTINGS_HEADS[f.key] ? '<div class="sec">' + SETTINGS_HEADS[f.key] + '</div>' : '') + fieldHtml(f, getPath(s, f.key)); }).join('') +
      '<div class="actions"><button class="btn pri" type="submit">حفظ</button></div></form>';
  }
  function qamarView() {
    var m = main(), q = S.ds.qamar || {}, stt = S.ds.qamarStatus || {};
    var status = stt.llmConfigured
      ? '<div class="alert ok"><b>النموذج الذكي مفعّل</b> (' + esc(stt.provider) + ' / ' + esc(stt.model) + '). الحد اليومي ' + esc(stt.dailyCap) + ' رد، المستخدم اليوم ' + esc(stt.usedToday) + '. يُستخدم حسب «الوضع» أدناه.</div>'
      : '<div class="alert info"><b>قمر يعمل الآن بقاعدة المعرفة فقط — بدون أي تكلفة.</b> يجيب من بيانات المجمع والأسئلة الشائعة. لتفعيل النموذج الذكي يضيف مدير الخادم مفتاحاً في ملف الإعدادات (<span class="ltr">QAMAR_PROVIDER</span> و<span class="ltr">QAMAR_API_KEY</span>) بعد موافقتك على التكلفة؛ لا يوجد مفتاح الآن.</div>';
    m.innerHTML = '<div class="page-h"><h1>المساعد قمر</h1></div>' + status +
      '<form class="card form" data-submit="save-qamar"><div class="form-err alert danger" hidden></div>' + S.schema.qamar.map(function (f) { return fieldHtml(f, q[f.key]); }).join('') + '<div class="actions"><button class="btn pri" type="submit">حفظ</button></div></form>' +
      '<div class="card"><h2>أسئلة لم يفهمها قمر</h2><p class="muted sm" style="margin-bottom:8px">تُحفظ مختصرة وبعد إخفاء الأرقام والبريد. أضف منها «سؤالاً شائعاً» ليجيب قمر عنها مباشرة في المرة القادمة.</p><div id="qlog"><p class="muted">جارٍ التحميل…</p></div></div>';
    api('GET', '/qamar/log?unconfident=1').then(function (r) {
      S.qlog = r.log || [];
      var box = $('#qlog'); if (!box) return;
      box.innerHTML = S.qlog.length ? '<table class="tbl stack"><thead><tr><th>الوقت</th><th>السؤال</th><th>الفهم</th><th></th></tr></thead><tbody>' + S.qlog.slice(0, 60).map(function (l, i) {
        return '<tr><td data-l="الوقت">' + esc(fmtTime(l.ts)) + '</td><td data-l="السؤال">' + esc(l.question) + '</td><td data-l="الفهم">' + esc(l.intent || '') + (l.used_llm ? ' · نموذج' : '') + '</td><td><button class="btn ghost sm" data-a="log-faq" data-i="' + i + '">إضافة كسؤال شائع</button></td></tr>'; }).join('') + '</tbody></table>' :
        '<p class="muted">لا توجد أسئلة غير مفهومة مسجّلة بعد.</p>';
    }).catch(function (e) { toast(e.message, true); });
  }

  /* ================= الإشعارات ================= */
  function notifyView() {
    var m = main(), fcm = S.ds.pushStatus && S.ds.pushStatus.fcm;
    m.innerHTML = '<div class="page-h"><h1>الإشعارات</h1></div>' +
      '<div class="alert ' + (fcm ? 'ok' : 'info') + ' sm">' + (fcm ? 'الإشعارات الفورية للجوال مفعّلة.' : 'الإشعارات الفورية للجوال غير مفعّلة (تحتاج إعداد Firebase). الإشعار العام يظهر لكل مستخدم داخل صفحة «الإشعارات» في التطبيق وبشارة على الجرس.') + '</div>' +
      '<form class="card form" data-submit="send-notify"><div class="form-err alert danger" hidden></div><h2>إشعار عام لكل المستخدمين</h2>' +
      '<div class="fld"><label for="n-title">العنوان</label><input class="in" id="n-title" data-k="title" maxlength="80" required></div>' +
      '<div class="fld"><label for="n-body">النص</label><textarea class="in" id="n-body" data-k="body" maxlength="300" rows="3" required></textarea></div>' +
      '<div class="actions"><button class="btn pri" type="submit">إرسال للجميع</button></div><p class="help">لا يمكن سحب الإشعار بعد إرساله. راجعه جيداً.</p></form>' +
      '<div class="card"><h2>آخر الإشعارات</h2><div id="nlist"><p class="muted">جارٍ التحميل…</p></div></div>';
    loadNotifs();
  }
  function loadNotifs() {
    api('GET', '/notifications').then(function (r) {
      var box = $('#nlist'); if (!box) return;
      box.innerHTML = r.notifications.length ? '<table class="tbl stack"><thead><tr><th>الوقت</th><th>العنوان</th><th>النص</th><th>الهدف</th></tr></thead><tbody>' + r.notifications.slice(0, 40).map(function (n) {
        return '<tr><td data-l="الوقت">' + esc(fmtTime(n.created_at)) + '</td><td data-l="العنوان">' + esc(n.title) + '</td><td data-l="النص">' + esc(cut(n.body, 90)) + '</td><td data-l="الهدف">' + (n.target === 'all' ? 'الجميع' : 'مراجع واحد (' + esc(n.kind) + ')') + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="muted">لا توجد إشعارات.</p>';
    }).catch(function (e) { toast(e.message, true); });
  }

  /* ================= الأمان والنسخ ================= */
  function securityView() {
    var m = main();
    m.innerHTML = '<div class="page-h"><h1>الأمان والنسخ الاحتياطي</h1></div>' +
      '<div class="card"><h2>نسخة احتياطية من كل البيانات</h2><p class="muted sm" style="margin-bottom:10px">ملف JSON فيه الإعدادات والأطباء والفروع والأسئلة والحجوزات. يحتوي أسماء وأرقام مراجعين، فاحفظه في مكان آمن. (النسخ الكامل لقاعدة البيانات: <span class="ltr">python3 server/manage.py backup</span>.)</p><button class="btn pri" data-a="export">تنزيل النسخة</button></div>' +
      '<form class="card form" data-submit="change-pw"><div class="form-err alert danger" hidden></div><h2>تغيير كلمة المرور</h2>' +
      '<div class="fld"><label for="pw-old">الحالية</label><input class="in" type="password" id="pw-old" autocomplete="current-password" required></div>' +
      '<div class="fld"><label for="pw-new">الجديدة (10 أحرف على الأقل)</label><input class="in" type="password" id="pw-new" autocomplete="new-password" minlength="10" required></div>' +
      '<div class="fld"><label for="pw-new2">تأكيد الجديدة</label><input class="in" type="password" id="pw-new2" autocomplete="new-password" required></div><div class="actions"><button class="btn pri" type="submit">تغيير</button></div></form>' +
      '<div class="card"><h2>سجل التعديلات</h2><div id="audit"><p class="muted">جارٍ التحميل…</p></div></div>';
    api('GET', '/stats').then(function (r) {
      S.stats = r; badge(); var box = $('#audit'); if (!box) return;
      box.innerHTML = r.audit.length ? '<table class="tbl stack"><thead><tr><th>الوقت</th><th>العملية</th><th>النوع</th><th>المعرّف</th></tr></thead><tbody>' + r.audit.map(function (a) {
        return '<tr><td data-l="الوقت">' + esc(fmtTime(a.ts)) + '</td><td data-l="العملية">' + esc(a.action) + '</td><td data-l="النوع">' + esc(a.kind || '') + '</td><td data-l="المعرّف" class="ltr">' + esc(a.ref || '') + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="muted">لا توجد تعديلات.</p>';
    }).catch(function () { /* تجاهل */ });
  }

  /* ================= الإجراءات ================= */
  var A = {};
  A.logout = function () { logout(''); };
  A['modal-close'] = closeModal;
  A['bk-reload'] = function () { loadBookings(); toast('تم التحديث'); };
  A['bk-filter'] = function (el) { S.bk.status = el.getAttribute('data-s'); loadBookings(); };
  A['bk-open'] = function (el) { openBooking(el.getAttribute('data-id')); };
  A.edit = function (el) { location.hash = '#/edit/' + el.getAttribute('data-kind') + '/' + el.getAttribute('data-id'); };
  /* رفع صورة: تُصغَّر في المتصفح (عرض أقصى 1400px، JPEG) ثم تُرسل للخادم فيعيد مساراً يوضع في الحقل */
  document.addEventListener('change', function (ev) {
    var inp = ev.target; if (!inp || !inp.getAttribute || !inp.getAttribute('data-up')) return;
    var file = inp.files && inp.files[0]; if (!file) return;
    var id = inp.getAttribute('data-up'), msg = $('[data-upmsg="' + id + '"]'), field = document.getElementById(id);
    var say = function (t, bad) { if (msg) { msg.textContent = t; msg.style.color = bad ? '#B3261E' : ''; } };
    say('جارٍ تجهيز الصورة…');
    var img = new Image(), rd = new FileReader();
    img.onerror = function () { say('تعذّر قراءة الصورة', true); inp.value = ''; };
    img.onload = function () {
      var maxW = 1400, sc = Math.min(1, maxW / img.naturalWidth), c = document.createElement('canvas');
      c.width = Math.round(img.naturalWidth * sc); c.height = Math.round(img.naturalHeight * sc);
      var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
      c.toBlob(function (blob) {
        if (!blob) { say('تعذّر تجهيز الصورة', true); return; }
        say('جارٍ الرفع…');
        fetch(API + '/upload', { method: 'POST', headers: { 'Authorization': 'Bearer ' + S.token, 'Content-Type': 'image/jpeg' }, body: blob, cache: 'no-store' })
          .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw new Error(j.message || ('HTTP ' + r.status)); return j; }); })
          .then(function (j) { field.value = location.origin + j.path; say('تم الرفع ✓ — لا تنس زر «حفظ» أسفل الصفحة'); })
          .catch(function (e) { say(e.message, true); });
      }, 'image/jpeg', 0.82);
    };
    rd.onerror = img.onerror; rd.onload = function () { img.src = rd.result; };
    rd.readAsDataURL(file); inp.value = '';
  });
  A['ph-add'] = function (el) { var box = $('[data-phs]', el.parentNode); box.insertAdjacentHTML('beforeend', phoneRow({ type: 'other' })); };
  A['ph-del'] = function (el) { el.closest('.ph-row').remove(); };
  A['log-faq'] = function (el) { var l = S.qlog[Number(el.getAttribute('data-i'))]; S.prefill = { question: l.question, category: 'app', active: true }; location.hash = '#/edit/faqs/new'; };
  A.toggle = function (el) {
    var kind = el.getAttribute('data-kind'), id = el.getAttribute('data-id'), e = S.ds[kind].filter(function (x) { return x.id === id; })[0];
    api('PUT', '/entities/' + kind + '/' + id, { active: e.active === false }).then(function () { return reloadDs(); }).then(function () { listView(kind); toast(e.active === false ? 'صار العنصر ظاهراً في التطبيق' : 'أُخفي العنصر من التطبيق'); }).catch(function (er) { toast(er.message, true); });
  };
  A['hard-delete'] = function (el) {
    var kind = el.getAttribute('data-kind'), id = el.getAttribute('data-id');
    var d = openModal('حذف نهائي', '<p>سيُحذف هذا العنصر نهائياً ولا يمكن استرجاعه. إن كنت تريد فقط إخفاءه فأزل علامة «ظاهر في التطبيق» بدلاً من ذلك.</p>' +
      '<p style="margin:10px 0">للتأكيد اكتب المعرّف: <b class="ltr" style="display:inline-block">' + esc(id) + '</b></p><input class="in ltr" id="del-confirm" autocomplete="off">' +
      '<div class="actions" style="margin-top:12px"><button class="btn danger" data-a="hard-delete-go" data-kind="' + kind + '" data-id="' + esc(id) + '">حذف نهائي</button><button class="btn out" data-a="modal-close">إلغاء</button></div>');
    $('#del-confirm', d).focus();
  };
  A['hard-delete-go'] = function (el) {
    var kind = el.getAttribute('data-kind'), id = el.getAttribute('data-id');
    if ($('#del-confirm').value.trim() !== id) { toast('المعرّف غير مطابق', true); return; }
    api('DELETE', '/entities/' + kind + '/' + encodeURIComponent(id) + '?hard=1&confirm=' + encodeURIComponent(id)).then(function () { closeModal(); return reloadDs(); })
      .then(function () { toast('تم الحذف النهائي'); location.hash = '#/list/' + kind; }).catch(function (e) { toast(e.message, true); });
  };
  A.export = function () {
    api('GET', '/export').then(function (j) {
      var blob = new Blob([JSON.stringify(j, null, 1)], { type: 'application/json' }), a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = 'dar-alsalam-export-' + new Date().toISOString().slice(0, 10) + '.json'; document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    }).catch(function (e) { toast(e.message, true); });
  };

  var SUB = {};
  SUB.login = function (f) {
    var pw = $('#pw').value, btn = $('button', f); btn.disabled = true;
    fetch(API + '/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: pw }) }).then(function (r) { return r.json().then(function (j) { return [r.ok, j]; }); })
      .then(function (x) {
        if (!x[0]) { btn.disabled = false; var e = $('#login-err'); e.textContent = x[1].message || 'تعذر الدخول'; e.hidden = false; return; }
        S.token = x[1].token; try { sessionStorage.setItem('ds.admin.token', S.token); } catch (e2) { /* تجاهل */ }
        boot();
      }).catch(function () { btn.disabled = false; var e = $('#login-err'); e.textContent = 'تعذر الاتصال بالخادم'; e.hidden = false; });
  };
  SUB['bk-save'] = function (f) {
    var id = f.getAttribute('data-id'), body = { status: $('#bk-status').value, appointmentText: $('#bk-appt').value.trim(), adminNote: $('#bk-note').value.trim() };
    if (body.status === 'confirmed' && !body.appointmentText) { showErrors(f, { appointmentText: 'اكتب تفاصيل الموعد قبل التأكيد' }); return; }
    api('PATCH', '/bookings/' + id, body).then(function () { closeModal(); toast('تم حفظ الطلب ' + id); return loadBookings(); }).catch(function (e) { showErrors(f, e.fields, e.message); });
  };
  SUB['save-entity'] = function (f) {
    var kind = f.getAttribute('data-kind'), id = f.getAttribute('data-id'), spec = S.schema.kinds[kind], isNew = id === 'new', body = collect(spec.fields, f);
    if (isNew) { var nid = ($('#new-id', f).value || '').trim(); if (nid) body.id = nid; }
    api(isNew ? 'POST' : 'PUT', '/entities/' + kind + (isNew ? '' : '/' + encodeURIComponent(id)), body).then(function () { return reloadDs(); })
      .then(function () { toast('تم الحفظ'); location.hash = '#/list/' + kind; }).catch(function (e) { showErrors(f, e.fields, e.message); });
  };
  SUB['save-settings'] = function (f) {
    api('PUT', '/settings', collect(S.schema.settings, f)).then(function () { return reloadDs(); }).then(function () { toast('تم حفظ معلومات المجمع'); settingsView(); }).catch(function (e) { showErrors(f, e.fields, e.message); });
  };
  SUB['save-qamar'] = function (f) {
    api('PUT', '/qamar', collect(S.schema.qamar, f)).then(function () { return reloadDs(); }).then(function () { toast('تم حفظ إعدادات قمر'); }).catch(function (e) { showErrors(f, e.fields, e.message); });
  };
  SUB['send-notify'] = function (f) {
    var b = collect([{ key: 'title', type: 'text' }, { key: 'body', type: 'textarea' }], f);
    if (!b.title || !b.body) { showErrors(f, {}, 'العنوان والنص مطلوبان'); return; }
    if (!window.confirm('سيُرسل هذا الإشعار لكل المستخدمين ولا يمكن سحبه. متابعة؟')) return;
    api('POST', '/notifications', b).then(function () { toast('أُرسل الإشعار'); f.reset(); loadNotifs(); }).catch(function (e) { showErrors(f, e.fields, e.message); });
  };
  SUB['change-pw'] = function (f) {
    var o = $('#pw-old').value, n = $('#pw-new').value, n2 = $('#pw-new2').value;
    if (n !== n2) { showErrors(f, {}, 'تأكيد كلمة المرور غير مطابق'); return; }
    api('POST', '/password', { old: o, 'new': n }).then(function (r) { S.token = r.token; try { sessionStorage.setItem('ds.admin.token', S.token); } catch (e) { /* تجاهل */ } toast('تم تغيير كلمة المرور'); f.reset(); showErrors(f, {}, ''); })
      .catch(function (e) { showErrors(f, e.fields, e.message); });
  };

  document.addEventListener('click', function (ev) {
    var t = ev.target.closest('[data-a]'); if (!t) return;
    var fn = A[t.getAttribute('data-a')]; if (fn) { ev.preventDefault(); fn(t, ev); }
  });
  document.addEventListener('submit', function (ev) {
    var f = ev.target.closest('form[data-submit]'); if (!f) return;
    ev.preventDefault(); var fn = SUB[f.getAttribute('data-submit')]; if (fn) fn(f);
  });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') closeModal(); });

  /* ================= المراجعون والملفات الطبية (رقم الملف الطبي + استيراد Excel + PDF) ================= */
  var FILE_KINDS = [['records', 'السجلات الطبية'], ['lab', 'نتائج المختبر'], ['radiology', 'نتائج الأشعة'], ['consents', 'الموافقات الطبية'], ['excuses', 'الأعذار الطبية'],
    ['invoices', 'الفواتير'], ['medications', 'الأدوية'], ['allergies', 'الحساسية'], ['refills', 'إعادة صرف الأدوية'], ['prescriptions', 'الوصفات الطبية'], ['activity', 'النشاط الصحي']];
  function staffBy() { try { return localStorage.getItem('ds.admin.by') || ''; } catch (e) { return ''; } }
  function fmtSize(n) { return n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function rawApi(method, path, blob, ctype) {
    return fetch(API + path, { method: method, headers: { 'Authorization': 'Bearer ' + S.token, 'Content-Type': ctype || 'application/pdf', 'Accept': 'application/json' }, body: blob, cache: 'no-store' }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401) logout('انتهت الجلسة، سجّل الدخول من جديد');
        if (!r.ok) { var e = new Error(j.message || ('HTTP ' + r.status)); e.fields = j.fields || {}; e.extra = j; throw e; }
        return j;
      });
    }, function () { throw new Error('تعذر الاتصال بالخادم'); });
  }
  function toLocalPhone(p) { return String(p || '').indexOf('966') === 0 ? '0' + String(p).slice(3) : String(p || ''); }
  function kopts(sel) { return FILE_KINDS.map(function (k) { return '<option value="' + k[0] + '"' + (k[0] === sel ? ' selected' : '') + '>' + esc(k[1]) + '</option>'; }).join(''); }
  function needBy() {
    var by = ($('#pf-by') && $('#pf-by').value.trim()) || ($('#im-by') && $('#im-by').value.trim()) || staffBy() || (window.prompt('اكتب اسمك (الموظف) ليُسجَّل مع هذه العملية') || '').trim();
    if (by.length < 2) { toast('اسم الموظف مطلوب', true); return ''; }
    try { localStorage.setItem('ds.admin.by', by); } catch (e) { /* تجاهل */ }
    return by;
  }

  function filesView(mrn) {
    if (mrn) return recordView(decodeURIComponent(mrn));
    var m = main();
    m.innerHTML = '<div class="page-h"><h1>المراجعون والملفات الطبية</h1></div>' +
      '<div class="alert info sm">كل مراجع له <b>رقم ملف طبي</b> من نظام المستوصف. استورد بياناتهم دفعة واحدة من Excel، ثم ارفع ملفات PDF لكل رقم ملف. حين يسجّل المراجع في التطبيق ويؤكّد هويته يرى ملفاته مباشرة مع إشعار.</div>' +
      '<div class="card" style="margin:10px 0"><h2 style="font-size:1.05rem;margin-bottom:6px">استيراد المراجعين من Excel</h2>' +
      '<div class="muted sm" style="margin-bottom:8px">حمّل <a href="records-template.xlsx" download>القالب</a> وعبّئه (أو استخدم ملفاً بنفس العناوين: رقم الملف، الاسم، الجوال، الهوية، تاريخ الميلاد، الجنس). يُقبل xlsx أو csv حتى 20,000 صف. تظهر لك معاينة قبل الحفظ، ولا يُحذف أي مراجع.</div>' +
      '<div class="row"><input class="in" id="im-by" maxlength="40" placeholder="اسمك (الموظف)" value="' + esc(staffBy()) + '" style="max-width:200px"> <input class="in" id="im-file" type="file" accept=".xlsx,.csv" style="max-width:300px"> <button class="btn pri" data-a="im-preview">معاينة</button></div>' +
      '<div id="im-out" style="margin-top:10px"></div></div>' +
      '<div class="card" style="margin:10px 0"><form data-submit="rec-open" class="row"><input class="in ltr" id="rec-mrn" placeholder="فتح رقم ملف مباشرة" style="max-width:220px"><button class="btn ghost" type="submit">فتح</button> <button type="button" class="btn ghost" data-a="rec-new">+ إضافة مراجع يدوياً</button></form></div>' +
      '<div class="tools"><input class="in" id="pt-q" type="search" placeholder="بحث برقم الملف أو الاسم أو الجوال أو الهوية"></div><div id="pt-box"></div>';
    var load = function () {
      api('GET', '/records?q=' + encodeURIComponent($('#pt-q').value.trim())).then(function (r) {
        var box = $('#pt-box'); if (!box) return;
        box.innerHTML = r.records.length ? '<div class="muted sm" style="margin:6px 0">إجمالي المراجعين: ' + r.total + '</div><table class="tbl stack"><thead><tr><th>رقم الملف</th><th>الاسم</th><th>الجوال</th><th>الملفات</th><th>مرتبط بحساب</th></tr></thead><tbody>' + r.records.map(function (x) {
          return '<tr class="click" data-a="rec-open" data-mrn="' + esc(x.mrn) + '"><td data-l="رقم الملف" class="ltr">' + esc(x.mrn) + '</td><td data-l="الاسم">' + esc(x.name) + '</td><td data-l="الجوال" class="ltr">' + esc(toLocalPhone(x.phone)) + '</td><td data-l="الملفات">' + x.files + '</td><td data-l="مرتبط">' + (x.linked ? 'نعم' : '—') + '</td></tr>'; }).join('') + '</tbody></table>'
          : '<div class="card muted">' + (r.total ? 'لا نتائج لهذا البحث.' : 'لا يوجد مراجعون بعد. استورد ملف Excel أو أضف مراجعاً يدوياً.') + '</div>';
      }).catch(function (e) { toast(e.message, true); });
    };
    $('#pt-q').addEventListener('input', debounce(load, 300));
    load();
  }
  A['rec-open'] = function (el) { location.hash = '#/files/' + encodeURIComponent(el.getAttribute('data-mrn')); };
  SUB['rec-open'] = function (f) { var v = $('#rec-mrn', f).value.trim(); if (v) location.hash = '#/files/' + encodeURIComponent(v); };

  function importResult(r, committed) {
    var rows = (r.errors || []).map(function (x) { return '<li>الصف ' + x.row + ': ' + esc(x.error) + '</li>'; }).join('');
    return '<div class="alert ' + (r.errorCount ? 'warn' : 'info') + ' sm"><b>' + (committed ? 'تم الحفظ' : 'معاينة (لم يُحفظ شيء بعد)') + '</b>: ' + r.new + ' جديد · ' + r.updated + ' تحديث · ' + r.same + ' بلا تغيير' + (r.errorCount ? ' · <b>' + r.errorCount + ' صف فيه خطأ</b>' : '') + '</div>' +
      (rows ? '<ul class="sm" style="margin:6px 0 0;padding-inline-start:20px">' + rows + '</ul>' + (r.errorCount > (r.errors || []).length ? '<div class="muted sm">يظهر أول ' + r.errors.length + ' خطأ فقط.</div>' : '') + '<div class="muted sm">صحّح الصفوف في ملفك ثم اختره من جديد (لا يُحفظ شيء قبل أن تصبح كلها سليمة).</div>' : '');
  }
  A['im-preview'] = function () {
    var file = $('#im-file').files[0], out = $('#im-out'), by = $('#im-by').value.trim();
    if (!file) { toast('اختر ملف Excel', true); return; }
    if (by.length < 2) { toast('اكتب اسمك (الموظف)', true); return; }
    if (file.size > 8 * 1024 * 1024) { toast('الملف أكبر من 8 ميغابايت', true); return; }
    try { localStorage.setItem('ds.admin.by', by); } catch (e) { /* تجاهل */ }
    out.innerHTML = '<span class="muted">جارٍ الفحص…</span>';
    rawApi('POST', '/records/import?commit=0&by=' + encodeURIComponent(by), file, 'application/octet-stream').then(function (r) {
      out.innerHTML = importResult(r, false) + (!r.errorCount && r.rows ? '<button class="btn pri" style="margin-top:8px" data-a="im-commit">حفظ ' + (r.new + r.updated) + ' مراجع' + (r.same ? ' (و' + r.same + ' بلا تغيير)' : '') + '</button>' : (!r.rows ? '<div class="muted sm">الملف لا يحتوي صفوفاً.</div>' : ''));
    }).catch(function (e) { out.innerHTML = '<div class="alert warn sm">' + esc(e.message) + '</div>'; });
  };
  A['im-commit'] = function (el) {
    var file = $('#im-file').files[0], by = $('#im-by').value.trim(), out = $('#im-out'); if (!file) return;
    el.disabled = true;
    rawApi('POST', '/records/import?commit=1&by=' + encodeURIComponent(by), file, 'application/octet-stream').then(function (r) {
      out.innerHTML = importResult(r, true); $('#im-file').value = ''; filesView('');
      setTimeout(function () { var o = $('#im-out'); if (o) o.innerHTML = importResult(r, true); }, 50);
    }).catch(function (e) { el.disabled = false; out.innerHTML = '<div class="alert warn sm">' + esc(e.message) + '</div>'; });
  };

  A['rec-new'] = function () { recForm(null); };
  A['rec-edit'] = function (el) { recForm(JSON.parse(el.getAttribute('data-rec'))); };
  function recForm(r) {
    r = r || {};
    openModal(r.mrn ? 'تعديل بيانات المراجع' : 'إضافة مراجع', '<form data-submit="rec-save" class="form">' +
      '<div class="fld"><label>رقم الملف الطبي</label><input class="in ltr" id="rf-mrn" maxlength="30" value="' + esc(r.mrn || '') + '"' + (r.mrn ? ' readonly' : '') + '></div>' +
      '<div class="fld"><label>الاسم</label><input class="in" id="rf-name" maxlength="80" value="' + esc(r.name || '') + '"></div>' +
      '<div class="fld"><label>الجوال</label><input class="in ltr" id="rf-phone" type="tel" placeholder="05xxxxxxxx" value="' + esc(r.phone ? toLocalPhone(r.phone) : '') + '"></div>' +
      '<div class="fld"><label>الهوية / الإقامة (اختياري)</label><input class="in ltr" id="rf-nid" maxlength="10" value="' + esc(r.nationalId || '') + '"></div>' +
      '<div class="fld"><label>تاريخ الميلاد (YYYY-MM-DD)</label><input class="in ltr" id="rf-bd" placeholder="1990-05-21" value="' + esc(r.birthDate || '') + '"></div>' +
      '<div class="fld"><label>الجنس</label><select class="in" id="rf-g"><option value="">—</option><option value="male"' + (r.gender === 'male' ? ' selected' : '') + '>ذكر</option><option value="female"' + (r.gender === 'female' ? ' selected' : '') + '>أنثى</option></select></div>' +
      '<div class="fld"><label>اسمك (الموظف)</label><input class="in" id="rf-by" maxlength="40" value="' + esc(staffBy()) + '"></div>' +
      '<div class="err" id="rf-err" hidden></div><button class="btn pri" type="submit">حفظ</button></form>');
  }
  SUB['rec-save'] = function () {
    var by = $('#rf-by').value.trim(), err = $('#rf-err'); err.hidden = true;
    try { localStorage.setItem('ds.admin.by', by); } catch (e) { /* تجاهل */ }
    var mrn = $('#rf-mrn').value.trim();
    api('POST', '/records?by=' + encodeURIComponent(by), { mrn: mrn, name: $('#rf-name').value, phone: $('#rf-phone').value, nationalId: $('#rf-nid').value, birthDate: $('#rf-bd').value, gender: $('#rf-g').value })
      .then(function () { closeModal(); toast('تم الحفظ'); if (location.hash === '#/files/' + encodeURIComponent(mrn)) recordView(mrn); else location.hash = '#/files/' + encodeURIComponent(mrn); })
      .catch(function (e) { err.textContent = (e.fields && Object.keys(e.fields).map(function (k) { return e.fields[k]; }).join(' · ')) || e.message; err.hidden = false; });
  };

  function recordView(mrn) {
    var m = main(), by = staffBy();
    m.innerHTML = '<div class="page-h"><h1>ملف المراجع</h1><a class="btn ghost" href="#/files">رجوع</a></div><div id="pf-head" class="card">جارٍ التحميل…</div>' +
      '<div class="card" style="margin-top:12px"><h2 style="font-size:1.05rem;margin-bottom:8px">رفع ملف جديد</h2><form data-submit="file-upload" class="form" id="pf-form" data-mrn="' + esc(mrn) + '">' +
      '<div class="fld"><label for="pf-kind">نوع الملف</label><select class="in" id="pf-kind">' + kopts('') + '</select></div>' +
      '<div class="fld"><label for="pf-title">اسم المستند</label><input class="in" id="pf-title" maxlength="80" placeholder="مثال: تحليل صورة دم كاملة"></div>' +
      '<div class="fld"><label for="pf-note">ملاحظة للمراجع (اختياري)</label><input class="in" id="pf-note" maxlength="300"></div>' +
      '<div class="fld"><label for="pf-by">اسمك (الموظف الذي يرفع الملف)</label><input class="in" id="pf-by" maxlength="40" value="' + esc(by) + '"><div class="help">يُسجَّل مع كل رفع أو استبدال أو حذف. إن كان المراجع مرتبطاً بحساب في التطبيق يصله إشعار تلقائياً.</div></div>' +
      '<div class="fld"><label for="pf-file">ملف PDF (حتى 12 ميغابايت)</label><input class="in" id="pf-file" type="file" accept="application/pdf,.pdf"></div>' +
      '<div class="err" id="pf-err" hidden></div><button class="btn pri" type="submit">رفع الملف</button></form></div>' +
      '<div id="pf-list" style="margin-top:12px"></div>';
    loadRecord(mrn);
  }
  function loadRecord(mrn) {
    api('GET', '/records/' + encodeURIComponent(mrn) + '?deleted=1').then(function (r) {
      var h = $('#pf-head'), l = $('#pf-list'); if (!h || !l) return;
      var c = r.record;
      h.innerHTML = '<div class="row" style="justify-content:space-between"><div><b>' + esc(c.name) + '</b> · <span class="ltr">' + esc(c.mrn) + '</span><div class="muted sm">جوال: <span class="ltr">' + esc(toLocalPhone(c.phone)) + '</span>' +
        (c.nationalId ? ' · هوية: <span class="ltr">' + esc(c.nationalId) + '</span>' : '') + (c.birthDate ? ' · ميلاد: ' + esc(c.birthDate) : '') + '</div>' +
        '<div class="muted sm">' + (c.linked ? 'مرتبط بحساب في التطبيق (' + c.linked + ')' : 'لم يربط أي حساب هذا الملف بعد — تظهر الملفات حين يسجّل المراجع ويؤكد هويته.') + '</div></div>' +
        '<button class="btn ghost sm" data-a="rec-edit" data-rec="' + esc(JSON.stringify(c)) + '">تعديل البيانات</button></div>';
      var live = r.files.filter(function (x) { return !x.deletedAt; }), gone = r.files.filter(function (x) { return x.deletedAt; });
      l.innerHTML = '<h2 style="font-size:1.05rem;margin-bottom:8px">الملفات (' + live.length + ')</h2>' + (live.length ? '<table class="tbl stack"><thead><tr><th>النوع</th><th>المستند</th><th>رُفع</th><th>آخر تعديل</th><th></th></tr></thead><tbody>' + live.map(function (x) {
        return '<tr><td data-l="النوع">' + esc(x.kindLabel) + '</td><td data-l="المستند"><b>' + esc(x.title) + '</b>' + (x.note ? '<div class="muted sm">' + esc(x.note) + '</div>' : '') + '<div class="muted sm">' + fmtSize(x.size) + '</div></td>' +
          '<td data-l="رُفع">' + esc(fmtTime(x.uploadedAt)) + '<div class="muted sm">' + esc(x.uploadedBy) + '</div></td><td data-l="آخر تعديل">' + (x.updatedAt ? esc(fmtTime(x.updatedAt)) + '<div class="muted sm">' + esc(x.updatedBy) + '</div>' : '—') + '</td>' +
          '<td class="acts"><button class="btn ghost sm" data-a="pf-view" data-id="' + x.id + '">عرض</button> <button class="btn ghost sm" data-a="pf-edit" data-id="' + x.id + '" data-kind="' + esc(x.kind) + '" data-title="' + esc(x.title) + '" data-note="' + esc(x.note) + '">تعديل</button> ' +
          '<label class="btn ghost sm" style="cursor:pointer">استبدال<input type="file" accept="application/pdf,.pdf" hidden data-replace="' + x.id + '"></label> <button class="btn dangero sm" data-a="pf-del" data-id="' + x.id + '" data-title="' + esc(x.title) + '">حذف</button></td></tr>'; }).join('') + '</tbody></table>' : '<div class="card muted">لا توجد ملفات بعد.</div>') +
        (gone.length ? '<details style="margin-top:12px"><summary class="muted">ملفات محذوفة (' + gone.length + ') — لا تظهر للمراجع</summary><ul class="sm muted">' + gone.map(function (x) { return '<li>' + esc(x.kindLabel) + ' — ' + esc(x.title) + ' · حذفه ' + esc(x.deletedBy) + ' ' + esc(fmtTime(x.deletedAt)) + '</li>'; }).join('') + '</ul></details>' : '');
    }).catch(function (e) { toast(e.message, true); var h = $('#pf-head'); if (h) h.textContent = e.message; });
  }
  SUB['file-upload'] = function (f) {
    var mrn = f.getAttribute('data-mrn'), file = $('#pf-file').files[0], err = $('#pf-err'), btn = $('button[type=submit]', f);
    err.hidden = true;
    var by = $('#pf-by').value.trim(), title = $('#pf-title').value.trim();
    if (!$('#pf-kind').value) { err.textContent = 'اختر نوع الملف'; err.hidden = false; return; }
    if (!file) { err.textContent = 'اختر ملف PDF'; err.hidden = false; return; }
    if (file.size > 12 * 1024 * 1024) { err.textContent = 'حجم الملف أكبر من 12 ميغابايت'; err.hidden = false; return; }
    if (by.length < 2) { err.textContent = 'اكتب اسمك (اسم الموظف)'; err.hidden = false; return; }
    if (title.length < 2) { err.textContent = 'اكتب اسم المستند'; err.hidden = false; return; }
    try { localStorage.setItem('ds.admin.by', by); } catch (e) { /* تجاهل */ }
    btn.disabled = true;
    var q = '?mrn=' + encodeURIComponent(mrn) + '&kind=' + encodeURIComponent($('#pf-kind').value) + '&title=' + encodeURIComponent(title) + '&note=' + encodeURIComponent($('#pf-note').value.trim()) + '&by=' + encodeURIComponent(by);
    rawApi('POST', '/files' + q, file).then(function () {
      toast('تم رفع الملف'); $('#pf-title').value = ''; $('#pf-note').value = ''; $('#pf-file').value = ''; btn.disabled = false; loadRecord(mrn);
    }).catch(function (e) {
      btn.disabled = false; err.textContent = (e.fields && Object.keys(e.fields).map(function (k) { return e.fields[k]; }).join(' · ')) || e.message; err.hidden = false;
    });
  };
  A['pf-view'] = function (el) {
    var w = window.open('', '_blank');
    fetch(API + '/files/' + el.getAttribute('data-id') + '/download', { headers: { 'Authorization': 'Bearer ' + S.token }, cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('تعذر فتح الملف'); return r.blob();
    }).then(function (b) { var u = URL.createObjectURL(b); if (w) w.location = u; else location.href = u; setTimeout(function () { URL.revokeObjectURL(u); }, 60000); })
      .catch(function (e) { if (w) w.close(); toast(e.message, true); });
  };
  A['pf-del'] = function (el) {
    if (!window.confirm('حذف «' + el.getAttribute('data-title') + '»؟ سيختفي من تطبيق المراجع فوراً، ويبقى أثر الحذف في السجل.')) return;
    var by = needBy(); if (!by) return;
    var mrn = $('#pf-form').getAttribute('data-mrn');
    api('DELETE', '/files/' + el.getAttribute('data-id') + '?by=' + encodeURIComponent(by)).then(function () { toast('تم حذف الملف'); loadRecord(mrn); }).catch(function (e) { toast(e.message, true); });
  };
  A['pf-edit'] = function (el) {
    var id = el.getAttribute('data-id'), mrn = $('#pf-form').getAttribute('data-mrn');
    openModal('تعديل بيانات الملف', '<form data-submit="file-edit" class="form" data-id="' + esc(id) + '" data-mrn="' + esc(mrn) + '">' +
      '<div class="fld"><label>النوع</label><select class="in" id="fe-kind">' + kopts(el.getAttribute('data-kind')) + '</select></div>' +
      '<div class="fld"><label>اسم المستند</label><input class="in" id="fe-title" maxlength="80" value="' + esc(el.getAttribute('data-title')) + '"></div>' +
      '<div class="fld"><label>ملاحظة</label><input class="in" id="fe-note" maxlength="300" value="' + esc(el.getAttribute('data-note')) + '"></div>' +
      '<button class="btn pri" type="submit">حفظ</button></form>');
  };
  SUB['file-edit'] = function (f) {
    var by = needBy(); if (!by) return;
    api('POST', '/files/' + f.getAttribute('data-id') + '/update?by=' + encodeURIComponent(by), { kind: $('#fe-kind').value, title: $('#fe-title').value, note: $('#fe-note').value })
      .then(function () { closeModal(); toast('تم الحفظ'); loadRecord(f.getAttribute('data-mrn')); }).catch(function (e) { toast(e.message, true); });
  };
  document.addEventListener('change', function (ev) {
    var inp = ev.target; if (!inp || !inp.getAttribute || !inp.getAttribute('data-replace')) return;
    var file = inp.files && inp.files[0]; if (!file) return;
    var by = needBy(); if (!by) { inp.value = ''; return; }
    if (!window.confirm('استبدال الملف الحالي بـ «' + file.name + '»؟ سيرى المراجع الملف الجديد فوراً.')) { inp.value = ''; return; }
    var mrn = $('#pf-form').getAttribute('data-mrn');
    rawApi('POST', '/files/' + inp.getAttribute('data-replace') + '/replace?by=' + encodeURIComponent(by), file).then(function () { toast('تم الاستبدال'); loadRecord(mrn); })
      .catch(function (e) { toast(e.message, true); inp.value = ''; });
  });

  /* ================= الموظفون والصلاحيات + سجل التدقيق (المنظومة) ================= */
  var ST = { roles: [], branches: [] };
  function genPw() { var a = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789', o = '', r = new Uint32Array(14); (window.crypto || window.msCrypto).getRandomValues(r); for (var i = 0; i < r.length; i++) o += a[r[i] % a.length]; return o; }
  function branchName(id) { var b = ST.branches.filter(function (x) { return x.id === id; })[0]; return id ? (b ? b.name : id) : 'كل الفروع'; }
  function staffView() {
    var m = main();
    m.innerHTML = '<div class="page-h"><h1>الموظفون والصلاحيات</h1><button class="btn pri" data-a="st-new">+ موظف جديد</button></div>' +
      '<div class="alert info sm">لكل موظف حساب خاص ودور تحدّد الصلاحيات الفعلية في الخادم. تطبيق الاستقبال على الرابط <a class="ltr" href="../staff/" target="_blank" rel="noopener">/staff/</a>. تُسجَّل كل عمليات الدخول والتعديل في «سجل التدقيق». الأدوار غير الجاهزة (الطبيب، التمريض، المختبر، الأشعة، الصيدلية) محجوزة للمراحل القادمة ولا يمكن إنشاء حسابات لها بعد.</div><div id="st-box"><p class="muted">جارٍ التحميل…</p></div>';
    Promise.all([api('GET', '/roles'), api('GET', '/staff')]).then(function (r) {
      ST.roles = r[0].roles; ST.branches = r[0].branches;
      var box = $('#st-box'); if (!box) return;
      box.innerHTML = r[1].staff.length ? '<table class="tbl stack"><thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>الدور</th><th>الفرع</th><th>الحالة</th><th>آخر دخول</th><th></th></tr></thead><tbody>' + r[1].staff.map(function (x) {
        return '<tr><td data-l="الاسم">' + esc(x.name) + '</td><td data-l="المستخدم" class="ltr">' + esc(x.username) + '</td><td data-l="الدور">' + esc(x.roleLabel) + '</td><td data-l="الفرع">' + esc(branchName(x.branchId)) + '</td>' +
          '<td data-l="الحالة">' + (!x.active ? 'موقوف' : x.locked ? 'مقفل مؤقتاً' : x.mustChange ? 'بانتظار تغيير الكلمة' : 'فعّال') + '</td><td data-l="آخر دخول">' + (x.lastLogin ? esc(fmtTime(x.lastLogin)) : '—') + '</td>' +
          '<td class="acts"><button class="btn ghost sm" data-a="st-edit" data-st="' + esc(JSON.stringify(x)) + '">تعديل</button> <button class="btn ghost sm" data-a="st-reset" data-id="' + x.id + '" data-name="' + esc(x.name) + '">كلمة جديدة</button> ' +
          '<button class="btn ' + (x.active ? 'dangero' : 'ghost') + ' sm" data-a="st-toggle" data-id="' + x.id + '" data-active="' + (x.active ? '1' : '0') + '" data-name="' + esc(x.name) + '">' + (x.active ? 'إيقاف' : 'تفعيل') + '</button></td></tr>'; }).join('') + '</tbody></table>' : '<div class="card muted">لا يوجد موظفون بعد. أضف أول حساب للاستقبال.</div>';
    }).catch(function (e) { toast(e.message, true); });
  }
  function roleOpts(sel) { return ST.roles.filter(function (r) { return r.ready || r.id === sel; }).map(function (r) { return '<option value="' + r.id + '"' + (r.id === sel ? ' selected' : '') + '>' + esc(r.label) + '</option>'; }).join(''); }
  function branchOpts(sel) { return '<option value="">كل الفروع</option>' + ST.branches.map(function (b) { return '<option value="' + esc(b.id) + '"' + (b.id === sel ? ' selected' : '') + '>' + esc(b.name) + '</option>'; }).join(''); }
  A['st-new'] = function () {
    var pw = genPw();
    openModal('موظف جديد', '<form data-submit="st-create" class="form">' +
      '<div class="fld"><label>الاسم الكامل</label><input class="in" id="sf-name" maxlength="60"></div>' +
      '<div class="fld"><label>اسم المستخدم (إنجليزي صغير)</label><input class="in ltr" id="sf-user" maxlength="30" autocapitalize="none" placeholder="reception1"></div>' +
      '<div class="fld"><label>الدور</label><select class="in" id="sf-role">' + roleOpts('reception') + '</select></div>' +
      '<div class="fld"><label>الفرع</label><select class="in" id="sf-branch">' + branchOpts('') + '</select><div class="help">موظف الاستقبال يُحدَّد له فرعه فلا يرى غيره. اتركه «كل الفروع» للمشرف فقط.</div></div>' +
      '<div class="fld"><label>كلمة المرور المؤقتة</label><input class="in ltr" id="sf-pw" value="' + pw + '"><div class="help">انسخها وسلّمها للموظف الآن؛ لن تظهر بعد الحفظ، ويُجبر على تغييرها عند أول دخول.</div></div>' +
      '<div class="err" id="sf-err" hidden></div><button class="btn pri" type="submit">إنشاء الحساب</button></form>');
  };
  SUB['st-create'] = function () {
    var err = $('#sf-err'); err.hidden = true;
    api('POST', '/staff', { name: $('#sf-name').value, username: $('#sf-user').value, role: $('#sf-role').value, branchId: $('#sf-branch').value, password: $('#sf-pw').value })
      .then(function () { var pw = $('#sf-pw').value, u = $('#sf-user').value; closeModal(); toast('تم إنشاء الحساب'); window.alert('تم إنشاء الحساب.\nاسم المستخدم: ' + u + '\nكلمة المرور المؤقتة: ' + pw + '\nسلّمها للموظف الآن.'); staffView(); })
      .catch(function (e) { err.textContent = (e.fields && Object.keys(e.fields).map(function (k) { return e.fields[k]; }).join(' · ')) || e.message; err.hidden = false; });
  };
  A['st-edit'] = function (el) {
    var x = JSON.parse(el.getAttribute('data-st'));
    openModal('تعديل ' + x.name, '<form data-submit="st-save" class="form" data-id="' + esc(x.id) + '">' +
      '<div class="fld"><label>الاسم الكامل</label><input class="in" id="se-name" maxlength="60" value="' + esc(x.name) + '"></div>' +
      '<div class="fld"><label>الدور</label><select class="in" id="se-role">' + roleOpts(x.role) + '</select></div>' +
      '<div class="fld"><label>الفرع</label><select class="in" id="se-branch">' + branchOpts(x.branchId) + '</select></div>' +
      '<div class="err" id="se-err" hidden></div><button class="btn pri" type="submit">حفظ</button></form>');
  };
  SUB['st-save'] = function (f) {
    var err = $('#se-err'); err.hidden = true;
    api('PATCH', '/staff/' + f.getAttribute('data-id'), { name: $('#se-name').value, role: $('#se-role').value, branchId: $('#se-branch').value })
      .then(function () { closeModal(); toast('تم الحفظ'); staffView(); })
      .catch(function (e) { err.textContent = (e.fields && Object.keys(e.fields).map(function (k) { return e.fields[k]; }).join(' · ')) || e.message; err.hidden = false; });
  };
  A['st-toggle'] = function (el) {
    var on = el.getAttribute('data-active') === '1';
    if (!window.confirm((on ? 'إيقاف حساب «' : 'تفعيل حساب «') + el.getAttribute('data-name') + '»؟' + (on ? ' سيخرج من جلسته فوراً.' : ''))) return;
    api('PATCH', '/staff/' + el.getAttribute('data-id'), { active: !on }).then(function () { toast(on ? 'تم الإيقاف' : 'تم التفعيل'); staffView(); }).catch(function (e) { toast(e.message, true); });
  };
  A['st-reset'] = function (el) {
    if (!window.confirm('إنشاء كلمة مرور مؤقتة جديدة لـ «' + el.getAttribute('data-name') + '»؟ ستنتهي جلسته الحالية ويُجبر على تغييرها عند الدخول.')) return;
    var pw = genPw();
    api('PATCH', '/staff/' + el.getAttribute('data-id'), { password: pw }).then(function () { window.alert('كلمة المرور المؤقتة الجديدة:\n' + pw + '\nسلّمها للموظف الآن؛ لن تظهر مرة أخرى.'); staffView(); }).catch(function (e) { toast(e.message, true); });
  };

  function auditView() {
    var m = main();
    m.innerHTML = '<div class="page-h"><h1>سجل التدقيق</h1></div><div class="alert info sm">كل عمليات الدخول (الناجحة والفاشلة) والتعديل والرفع وتسجيل الوصول وتغيير الحالات تظهر هنا باسم من نفّذها ووقتها. لا تُسجَّل كلمات المرور ولا أرقام الهوية.</div>' +
      '<form class="card row" data-submit="audit-filter"><input class="in" id="au-who" placeholder="المنفّذ (مثل staff:reception1)" style="max-width:240px"><input class="in" id="au-act" placeholder="العملية (مثل visit_ أو login)" style="max-width:220px"><button class="btn ghost" type="submit">تصفية</button></form><div id="au-box"></div>';
    loadAudit(null, true);
  }
  SUB['audit-filter'] = function () { loadAudit(null, true); };
  function loadAudit(before, reset) {
    var q = '?limit=100' + ($('#au-who') && $('#au-who').value.trim() ? '&who=' + encodeURIComponent($('#au-who').value.trim()) : '') + ($('#au-act') && $('#au-act').value.trim() ? '&action=' + encodeURIComponent($('#au-act').value.trim()) : '') + (before ? '&before=' + before : '');
    api('GET', '/audit' + q).then(function (r) {
      var box = $('#au-box'); if (!box) return;
      var rows = r.audit.map(function (a) { return '<tr><td data-l="الوقت">' + esc(fmtTime(a.ts)) + '</td><td data-l="المنفّذ" class="ltr">' + esc(a.who) + '</td><td data-l="العملية" class="ltr">' + esc(a.action) + '</td><td data-l="المرجع" class="ltr">' + esc(a.ref || '') + '</td><td data-l="تفاصيل" class="ltr sm">' + esc(cut(a.detail || '', 90)) + '</td></tr>'; }).join('');
      var more = r.audit.length >= 100 ? '<button class="btn ghost" data-a="au-more" data-before="' + r.audit[r.audit.length - 1].id + '">المزيد</button>' : '';
      if (reset || !$('#au-body')) box.innerHTML = '<table class="tbl stack"><thead><tr><th>الوقت</th><th>المنفّذ</th><th>العملية</th><th>المرجع</th><th>تفاصيل</th></tr></thead><tbody id="au-body">' + rows + '</tbody></table><div id="au-more" style="margin-top:10px">' + more + '</div>';
      else { $('#au-body').insertAdjacentHTML('beforeend', rows); $('#au-more').innerHTML = more; }
      if (!r.audit.length && reset) box.innerHTML = '<div class="card muted">لا سجلات مطابقة.</div>';
    }).catch(function (e) { toast(e.message, true); });
  }
  A['au-more'] = function (el) { loadAudit(el.getAttribute('data-before'), false); };

  /* ================= التوجيه والتشغيل ================= */
  function reloadDs() { return api('GET', '/dataset').then(function (d) { S.ds = d; }); }
  function route() {
    if (!S.token || !S.ds) return;
    closeModal();
    var r = (location.hash || '#/dash').slice(2) || 'dash', p = r.split('/');
    S.route = r; setNav(r);
    var m = main(); if (!m) return;
    if (p[0] === 'dash') dashView();
    else if (p[0] === 'bookings') bookingsView();
    else if (p[0] === 'list' && S.schema.kinds[p[1]]) listView(p[1]);
    else if (p[0] === 'edit' && S.schema.kinds[p[1]]) editView(p[1], p[2] || 'new');
    else if (p[0] === 'files') filesView(p[1] || '');
    else if (p[0] === 'staff') staffView();
    else if (p[0] === 'audit') auditView();
    else if (p[0] === 'settings') settingsView();
    else if (p[0] === 'qamar') qamarView();
    else if (p[0] === 'notify') notifyView();
    else if (p[0] === 'security') securityView();
    else dashView();
    window.scrollTo(0, 0);
  }
  window.addEventListener('hashchange', route);

  function boot() {
    if (!S.token) { loginView(); return; }
    Promise.all([api('GET', '/schema'), api('GET', '/dataset'), api('GET', '/stats')]).then(function (x) {
      S.schema = x[0]; S.ds = x[1]; S.stats = x[2];
      shell(); route();
    }).catch(function (e) { if (e.status !== 401) { $('#root').innerHTML = '<p class="boot">تعذر تحميل اللوحة: ' + esc(e.message) + ' <button class="btn out" data-a="logout">خروج</button></p>'; } });
  }
  setInterval(function () {   // تنبيه بالطلبات الجديدة دون إعادة تحميل
    if (!S.token || document.hidden) return;
    api('GET', '/stats').then(function (r) {
      var was = S.stats && S.stats.bookings ? S.stats.bookings['new'] : 0; S.stats = r; badge();
      if (r.bookings['new'] > was) { toast('وصل طلب حجز جديد'); if (S.route === 'bookings') loadBookings(); }
    }).catch(function () { /* تجاهل */ });
  }, 30000);
  boot();
})();
