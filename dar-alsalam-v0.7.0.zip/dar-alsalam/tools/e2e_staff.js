/* اختبار تطبيق الاستقبال (/staff/) ولوحة إدارة الموظفين بمتصفح حقيقي:
   NODE_PATH=<playwright> node tools/e2e_staff.js [BASE_URL] [ADMIN_PASSWORD]
   يحتاج خادماً بقاعدة جديدة (restart_dev.sh) لأن بعض التأكيدات تعتمد على أن اليوم فارغ. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BASE = process.argv[2] || 'http://127.0.0.1:8090';
const PW = process.argv[3] || 'devpass-12345';
const SHOTS = path.join(__dirname, '..', 'qa', 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
let fails = 0, passes = 0;
function ok(c, m) { if (c) { passes++; console.log('PASS', m); } else { fails++; console.log('FAIL', m); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function http(method, p, body, token) {
  const h = { Accept: 'application/json' };
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(() => ({})), headers: r.headers };
}
const futureDate = (d) => new Date(Date.now() + d * 86400000 + 3 * 3600000).toISOString().slice(0, 10);

(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const errors = [];
  const watch = (page, tag) => {
    page.on('pageerror', (e) => errors.push(tag + ' pageerror: ' + e.message));
    // أخطاء الشبكة المتوقعة (409/401 …) ليست أخطاء برمجية؛ نلتقط الباقي (CSP وغيرها)
    page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(tag + ' console: ' + m.text()); });
  };
  const newCtx = (vw, vh) => browser.newContext({ viewport: { width: vw || 1100, height: vh || 800 }, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const shot = async (page, n) => { await sleep(250); await page.screenshot({ path: path.join(SHOTS, n + '.png') }); };
  const go = async (page, h) => { await page.evaluate((x) => { location.hash = x; }, h); await sleep(350); };
  /* ننتظر نص الإشعار المتوقع (لا أي إشعار قديم ما زال ظاهراً) */
  const waitToast = async (page, re) => {
    await page.waitForFunction((src) => { const t = document.querySelector('#toast'); return !!t && t.classList.contains('on') && new RegExp(src).test(t.innerText); }, re.source);
    return page.locator('#toast').innerText();
  };
  const waitChip = (page, name, re) => page.waitForFunction(([n, src]) => {
    const row = [...document.querySelectorAll('.vrow')].find((x) => x.innerText.includes(n)); const c = row && row.querySelector('.chip');
    return !!c && new RegExp(src).test(c.innerText);
  }, [name, re.source]);

  /* مدير النظام: توكن للإعداد السريع عبر الـAPI */
  const alog = await http('POST', '/api/admin/login', { password: PW });
  ok(alog.status === 200 && alog.body.token, 'دخول المالك عبر API');
  const ADM = alog.body.token;
  const adm = (m, p, b) => http(m, '/api/admin' + p, b, ADM);
  const brs = (await adm('GET', '/entities/branches')).body.items.map((b) => b.id);
  const QUBA = brs.includes('quba') ? 'quba' : brs[0], TALAL = brs.find((b) => b !== QUBA);
  ok(QUBA && TALAL, 'يوجد فرعان للاختبار: ' + QUBA + ' / ' + TALAL);

  /* =============== 1) لوحة الإدارة: إنشاء موظف من الواجهة =============== */
  const actx = await newCtx(1280, 820);
  const ap = await actx.newPage(); watch(ap, 'admin');
  const dialogs = [];
  ap.on('dialog', async (d) => { dialogs.push(d.message()); await d.accept(); });
  await ap.goto(BASE + '/admin/', { waitUntil: 'networkidle' });
  await ap.fill('#pw', PW); await ap.click('button[type=submit]');
  await ap.waitForSelector('#nav', { timeout: 8000 });
  ok((await ap.locator('#nav').innerText()).includes('الموظفون'), 'قائمة الإدارة تحوي «الموظفون والصلاحيات»');
  ok((await ap.locator('#nav').innerText()).includes('سجل التدقيق'), 'قائمة الإدارة تحوي «سجل التدقيق»');
  await go(ap, '#/staff');
  await ap.waitForSelector('#st-box');
  await ap.waitForFunction(() => /لا يوجد موظفون/.test(document.querySelector('#st-box').innerText));
  ok(true, 'لا موظفين في البداية');
  await ap.click('[data-a="st-new"]');
  await ap.waitForSelector('#modal');
  const roleVals = await ap.$$eval('#sf-role option', (o) => o.map((x) => x.value));
  ok(roleVals.join() === 'reception,manager', 'الأدوار الجاهزة فقط في القائمة: ' + roleVals.join());
  await ap.fill('#sf-name', 'سارة الاستقبال');
  await ap.fill('#sf-user', 'Bad Name');
  await ap.selectOption('#sf-branch', QUBA);
  const tmpPw = await ap.inputValue('#sf-pw');
  ok(tmpPw.length >= 10, 'كلمة مؤقتة مولّدة عشوائياً (طولها ' + tmpPw.length + ')');
  await ap.click('form[data-submit="st-create"] button[type=submit]');
  await ap.waitForSelector('#sf-err:not([hidden])');
  ok(true, 'اسم مستخدم غير صالح يُرفض: ' + (await ap.locator('#sf-err').innerText()));
  await ap.fill('#sf-user', 'rec.quba');
  await ap.click('form[data-submit="st-create"] button[type=submit]');
  await ap.waitForSelector('#st-box td:has-text("rec.quba")');
  ok(dialogs.some((m) => m.includes('rec.quba') && m.includes(tmpPw)), 'يظهر تنبيه بكلمة المرور المؤقتة مرة واحدة');
  const rowTxt = await ap.locator('#st-box tr', { hasText: 'rec.quba' }).innerText();
  ok(rowTxt.includes('بانتظار تغيير الكلمة') && rowTxt.includes('فرع'), 'الحساب بحالة «بانتظار تغيير الكلمة» وله فرع: ' + rowTxt.replace(/\s+/g, ' ').slice(0, 90));
  await shot(ap, 's01-admin-staff');
  ok(!JSON.stringify(await adm('GET', '/staff')).includes(tmpPw), 'كلمة المرور لا تُعاد من الخادم');

  /* حسابات إضافية عبر API */
  const mk = async (username, name, role, branch) => (await adm('POST', '/staff', { username, name, role, branchId: branch, password: 'Temp-pass-2468-x' })).status;
  ok(await mk('rec.talal', 'نورة فرع التلال', 'reception', TALAL) === 201, 'حساب استقبال للفرع الثاني');
  ok(await mk('mgr.all', 'خالد المشرف', 'manager', '') === 201, 'حساب مشرف لكل الفروع');
  ok(await mk('doc.try', 'طبيب', 'doctor', '') === 422, 'دور الطبيب غير جاهز بعد (يُرفض إنشاؤه)');

  /* =============== 2) الدخول إلى تطبيق الاستقبال =============== */
  const sctx = await newCtx(1100, 800);
  const sp = await sctx.newPage(); watch(sp, 'staff');
  sp.on('dialog', async (d) => { dialogs.push(d.message()); await d.accept(); });
  await sp.goto(BASE + '/staff/', { waitUntil: 'networkidle' });
  ok(await sp.locator('#lg-user').isVisible(), 'شاشة دخول الاستقبال');
  ok(await sp.evaluate(() => { const i = document.querySelector('.login img'); return !!i && i.complete && i.naturalWidth > 0; }), 'الشعار يُحمَّل');
  ok(await sp.evaluate(() => getComputedStyle(document.querySelector('.login')).borderRadius !== '0px'), 'ملف التنسيق admin.css يُطبَّق');
  const hdr = await http('GET', '/staff/');
  ok(/frame-ancestors 'none'/.test(hdr.headers.get('content-security-policy') || '') && hdr.headers.get('x-frame-options') === 'DENY', 'ترويسات الأمان على /staff/');
  ok((await sp.content()).includes('noindex'), 'الصفحة غير قابلة للفهرسة');
  await shot(sp, 's02-login');
  await sp.fill('#lg-user', 'rec.quba'); await sp.fill('#lg-pw', 'wrong-wrong-123');
  await sp.click('form[data-f=login] button[type=submit]');
  await sp.waitForSelector('#lg-err:not([hidden])');
  ok(true, 'كلمة مرور خاطئة: ' + (await sp.locator('#lg-err').innerText()));
  await sp.fill('#lg-pw', tmpPw);
  await sp.click('form[data-f=login] button[type=submit]');
  await sp.waitForSelector('#pw-old');
  ok((await sp.locator('h1').innerText()).includes('المؤقتة'), 'تغيير كلمة المرور المؤقتة إجباري');
  ok(await sp.locator('#tabs').count() === 0, 'لا تظهر أدوات قبل تغيير الكلمة');
  await sp.fill('#pw-old', tmpPw); await sp.fill('#pw-new', 'short');
  await sp.click('form[data-f=pw] button[type=submit]');
  await sp.waitForSelector('#pw-err:not([hidden])');
  ok(true, 'كلمة جديدة ضعيفة تُرفض: ' + (await sp.locator('#pw-err').innerText()));
  const NEWPW = 'Quba-Reception-2026';
  await sp.fill('#pw-new', NEWPW);
  await sp.click('form[data-f=pw] button[type=submit]');
  await sp.waitForSelector('#tabs');
  const who = await sp.locator('.top .who').innerText();
  ok(who.includes('سارة الاستقبال') && who.includes('الاستقبال') && who.includes('قباء'), 'الترويسة: الاسم والدور والفرع — ' + who.replace(/\s+/g, ' '));
  const tabs = await sp.$$eval('#tabs a', (a) => a.map((x) => x.getAttribute('data-t')));
  ok(tabs.join() === 'board,checkin,bookings,patients', 'تبويبات الاستقبال بدون التدقيق: ' + tabs.join());
  const stor = await sp.evaluate(() => ({ s: !!sessionStorage.getItem('ds.staff.token'), l: Object.keys(localStorage).join() }));
  ok(stor.s && !/token/i.test(stor.l), 'التوكن في sessionStorage وليس localStorage');
  const TOK = await sp.evaluate(() => sessionStorage.getItem('ds.staff.token'));
  ok((await http('GET', '/api/admin/staff', undefined, TOK)).status === 401, 'توكن الموظف لا يفتح API الإدارة');
  ok((await http('GET', '/api/staff/me', undefined, ADM)).status === 401, 'توكن المالك لا يفتح API الموظفين');
  await shot(sp, 's03-board-empty');
  const lk = (await http('GET', '/api/staff/lookups', undefined, TOK)).body;
  ok(lk.branches.length === 1 && lk.branches[0].id === QUBA, 'القوائم محصورة بفرع الموظف');
  const dA = lk.doctors[1], dB = lk.doctors[2]; // طبيبان للاختبار

  /* =============== 3) تسجيل مراجع جديد + تسجيل وصول =============== */
  await go(sp, '#/checkin');
  await sp.fill('#ci-q', 'zzzzzz');
  await sp.waitForFunction(() => /لا نتائج/.test(document.querySelector('#ci-res').innerText));
  ok(true, 'بحث بلا نتائج يعرض خيار التسجيل');
  await sp.click('[data-a="ci-new"]');
  await sp.waitForSelector('#modal');
  await sp.fill('#rf-name', 'مريم عبدالله الاختبار'); await sp.fill('#rf-phone', '0565550111');
  await sp.click('form[data-f=recsave] button[type=submit]');
  await sp.waitForSelector('#rf-err:not([hidden])');
  ok(true, 'التسجيل بلا هوية ولا تاريخ ميلاد يُرفض: ' + (await sp.locator('#rf-err').innerText()));
  await sp.fill('#rf-bd', '1991-03-02'); await sp.selectOption('#rf-g', 'female');
  await sp.click('form[data-f=recsave] button[type=submit]');
  await sp.waitForSelector('form[data-f=checkin]');
  const t1 = await waitToast(sp, /رقم الملف DS-\d+/);
  const mrn1 = (t1.match(/DS-\d+/) || [])[0];
  ok(!!mrn1, 'تسجيل مراجع جديد برقم ملف تلقائي: ' + t1);
  ok((await sp.locator('#view').innerText()).includes('مريم عبدالله الاختبار'), 'تظهر بيانات المراجع في نموذج الوصول');
  ok(await sp.locator('#ci-br').count() === 0, 'موظف الفرع لا يختار الفرع (محدد من حسابه)');
  ok(await sp.$$eval('#ci-doc option', (o) => o.length > 5), 'قائمة الأطباء معبّأة');
  await sp.click('form[data-f=checkin] button[type=submit]');
  await sp.waitForSelector('#ci-err:not([hidden])');
  ok(true, 'تسجيل الوصول بلا طبيب يُرفض: ' + (await sp.locator('#ci-err').innerText()));
  await sp.selectOption('#ci-doc', dA.id); await sp.fill('#ci-reason', 'كشف عام');
  await sp.click('form[data-f=checkin] button[type=submit]');
  await sp.waitForSelector('.vrow:has-text("مريم")');
  ok(/#\/board/.test(await sp.evaluate(() => location.hash)), 'بعد التسجيل تنتقل إلى اللوحة');
  ok(/رقم الطابور 1/.test(await waitToast(sp, /رقم الطابور 1/)), 'رقم الطابور الأول عند الطبيب');
  const row1 = sp.locator('.vrow', { hasText: 'مريم' });
  ok((await row1.locator('.no').innerText()).trim() === '1' && (await row1.innerText()).includes('ينتظر') && (await row1.innerText()).includes('كشف عام'), 'الصف: رقم 1 · ينتظر · السبب');
  ok((await sp.locator('.dcard h3').first().innerText()).includes(dA.name), 'الزيارة تحت اسم الطبيب المختار');
  const sums = await sp.$$eval('#bd-sum b', (b) => b.map((x) => x.textContent));
  ok(sums.join() === '1,0,0,0', 'العدّادات: ينتظر 1 — ' + sums.join('/'));
  await shot(sp, 's04-board-one');

  /* مراجع مكرر + زيارة جارية */
  await go(sp, '#/checkin');
  await sp.click('[data-a="ci-new"]');
  await sp.fill('#rf-name', 'مريم عبدالله الاختبار'); await sp.fill('#rf-phone', '0565550111'); await sp.fill('#rf-bd', '1991-03-02');
  await sp.click('form[data-f=recsave] button[type=submit]');
  await sp.waitForSelector('#rf-dup .alert');
  ok((await sp.locator('#rf-dup').innerText()).includes(mrn1), 'تحذير التكرار يقترح الملف الموجود ' + mrn1);
  await sp.click('#rf-dup [data-a="rf-use"]');
  await sp.waitForSelector('form[data-f=checkin]');
  ok((await sp.locator('#view').innerText()).includes(mrn1), 'استخدام الملف الموجود بدل التكرار');
  await sp.selectOption('#ci-doc', dB.id);
  await sp.click('form[data-f=checkin] button[type=submit]');
  await sp.waitForSelector('#ci-err:not([hidden])');
  const dupMsg = await sp.locator('#ci-err').innerText();
  ok(dupMsg.includes('زيارة جارية') && dupMsg.includes(dA.name) && !dupMsg.includes('dr-'), 'زيارة ثانية في اليوم لنفس الملف تُرفض باسم الطبيب لا معرّفه: ' + dupMsg);
  await sp.click('[data-a="ci-reset"]');
  await sp.click('[data-a="ci-new"]');
  await sp.fill('#rf-name', 'مريم عبدالله الاختبار'); await sp.fill('#rf-phone', '0565550111'); await sp.fill('#rf-bd', '1991-03-02');
  await sp.click('form[data-f=recsave] button[type=submit]');
  await sp.waitForSelector('#rf-dup [data-a="rf-force"]');
  await sp.click('#rf-dup [data-a="rf-force"]');
  await sp.waitForSelector('form[data-f=checkin]');
  const mrnDup = ((await sp.locator('#view').innerText()).match(/DS-\d+/) || [])[0];
  ok(mrnDup && mrnDup !== mrn1, 'التسجيل رغم التكرار ينشئ ملفاً جديداً: ' + mrnDup);

  /* =============== 4) الطابور: تغيير الحالات والتحويل والإلغاء =============== */
  const sapi = (m, p, b) => http(m, '/api/staff' + p, b, TOK);
  const mkVisit = async (name, phone, doctorId) => {
    const r = await sapi('POST', '/records', { name, phone, birthDate: '1985-05-05' });
    const v = await sapi('POST', '/visits', { mrn: r.body.record.mrn, doctorId, reason: '' });
    return { mrn: r.body.record.mrn, status: v.status, visit: v.body.visit };
  };
  const p2 = await mkVisit('عبدالعزيز التحويل', '0565550222', dA.id);
  const p3 = await mkVisit('هند الإلغاء', '0565550333', dA.id);
  ok(p2.status === 201 && p2.visit.queueNo === 2 && p3.visit.queueNo === 3, 'ترقيم الطابور متسلسل لكل طبيب: ' + p2.visit.queueNo + ',' + p3.visit.queueNo);
  await go(sp, '#/board'); await sp.click('[data-a="bd-refresh"]');
  await sp.waitForSelector('.vrow:has-text("هند")');
  const vrow = (name) => sp.locator('.vrow', { hasText: name });
  const stat = async (name) => (await vrow(name).locator('.chip').innerText()).trim();
  await vrow('مريم').locator('[data-st="ready"]').click();
  await waitChip(sp, 'مريم', /جاهز للطبيب/);
  ok(await stat('مريم') === 'جاهز للطبيب', 'الحالة: جاهز للطبيب');
  await vrow('مريم').locator('[data-st="with_doctor"]').click();
  await waitChip(sp, 'مريم', /عند الطبيب/);
  ok(await stat('مريم') === 'عند الطبيب', 'الحالة: عند الطبيب');
  ok(await vrow('مريم').locator('[data-a="vt"]').count() === 0 && await vrow('مريم').locator('[data-st="cancelled"]').count() === 0, 'لا تحويل ولا إلغاء بعد دخول الطبيب');
  await vrow('مريم').locator('[data-st="done"]').click();
  await waitChip(sp, 'مريم', /انتهت/);
  ok(await vrow('مريم').locator('[data-a="vs"]').count() === 0, 'الزيارة المنتهية بلا أزرار');
  ok((await sp.getAttribute('.vrow:has-text("مريم")', 'class')).includes('done'), 'الصف المنتهي يُخفَّف بصرياً');
  /* تحويل */
  await vrow('عبدالعزيز').locator('[data-a="vt"]').click();
  await sp.waitForSelector('#tr-doc');
  const trOpts = await sp.$$eval('#tr-doc option', (o) => o.map((x) => x.value));
  ok(!trOpts.includes(dA.id) && trOpts.includes(dB.id), 'قائمة التحويل تستثني الطبيب الحالي');
  await shot(sp, 's05-transfer');
  await sp.selectOption('#tr-doc', dB.id);
  await sp.click('form[data-f=transfer] button[type=submit]');
  await sp.waitForFunction((n) => { const s = [...document.querySelectorAll('.dcard')].find((c) => c.innerText.includes(n)); return !!s && /عبدالعزيز/.test(s.innerText); }, dB.name);
  const dcB = sp.locator('.dcard', { hasText: dB.name });
  ok((await dcB.locator('.vrow', { hasText: 'عبدالعزيز' }).locator('.no').innerText()).trim() === '1', 'بعد التحويل يأخذ رقم 1 في طابور الطبيب الجديد');
  ok(!(await sp.locator('.dcard', { hasText: dA.name }).innerText()).includes('عبدالعزيز'), 'اختفى من طابور الطبيب القديم');
  /* إلغاء بتأكيد */
  const nDial = dialogs.length;
  await vrow('هند').locator('[data-st="cancelled"]').click();
  await waitChip(sp, 'هند', /ملغاة/);
  ok(dialogs.length === nDial + 1 && dialogs[dialogs.length - 1].includes('إلغاء'), 'الإلغاء يطلب تأكيداً أولاً');
  const sums2 = await sp.$$eval('#bd-sum b', (b) => b.map((x) => x.textContent));
  ok(sums2.join() === '0,0,0,1' || sums2.join() === '1,0,0,1', 'العدّادات بعد الحالات: ' + sums2.join('/'));
  await shot(sp, 's06-board-mixed');

  /* =============== 5) الحجوزات =============== */
  const dev = 'dev_staff_e2e_000000000001';
  const mkBk = (name, phone, branchId) => http('POST', '/api/v1/bookings', { deviceId: dev, name, phone, specialtyId: 'dental', branchId, date: futureDate(3), period: 'evening', note: 'اختبار الاستقبال', consent: true });
  const bq = await mkBk('حجز فرع قباء', '0565550444', QUBA);
  const bt = await mkBk('حجز فرع التلال', '0565550555', TALAL);
  ok(bq.status === 201 && bt.status === 201, 'طلبان من التطبيق (قباء والتلال): ' + bq.status + '/' + bt.status);
  const bqId = bq.body.booking.id, btId = bt.body.booking.id;
  await go(sp, '#/bookings');
  await sp.waitForSelector('.bk:has-text("حجز فرع قباء")');
  ok((await sp.locator('#bk-box').innerText()).includes(bqId), 'طلب فرعي يظهر للاستقبال');
  ok(!(await sp.locator('#bk-box').innerText()).includes(btId), 'طلب فرع آخر لا يظهر (عزل الفروع)');
  await shot(sp, 's07-bookings');
  await sp.locator('.bk', { hasText: bqId }).locator('[data-a="bk-confirm"]').click();
  await sp.waitForSelector('#bc-t');
  await sp.click('form[data-f=bkconfirm] button[type=submit]');
  await sp.waitForSelector('#bc-err:not([hidden])');
  ok(true, 'التأكيد بلا تفاصيل موعد يُرفض: ' + (await sp.locator('#bc-err').innerText()));
  await sp.fill('#bc-t', 'الأحد 4:30 مساءً مع د. اختبار');
  await sp.click('form[data-f=bkconfirm] button[type=submit]');
  await sp.waitForFunction((id) => { const b = [...document.querySelectorAll('.bk')].find((x) => x.innerText.includes(id)); return !!b && /الموعد المؤكد/.test(b.innerText); }, bqId);
  ok(true, 'الموعد المؤكد يظهر على البطاقة');
  const chk = (await adm('GET', '/bookings')).body;
  const bkRow = (chk.items || chk.bookings || []).find((b) => b.id === bqId);
  ok(bkRow && bkRow.status === 'confirmed' && (bkRow.appointment_text || '').includes('الأحد'), 'الحالة والنص محفوظان في الخادم');
  /* من الحجز إلى تسجيل الوصول */
  await sp.locator('.bk', { hasText: bqId }).locator('[data-a="bk-arrive"]').click();
  await sp.waitForSelector('.alert.info:has-text("' + bqId + '")');
  ok((await sp.inputValue('#ci-q')).includes('0565550444'), 'البحث مُعبّأ برقم جوال الحجز');
  await sp.waitForFunction(() => /لا نتائج/.test(document.querySelector('#ci-res').innerText));
  await sp.click('[data-a="ci-new"]');
  ok((await sp.inputValue('#rf-name')) === 'حجز فرع قباء' && (await sp.inputValue('#rf-phone')).endsWith('0565550444'), 'نموذج المراجع الجديد مُعبّأ من الحجز');
  await sp.fill('#rf-bd', '1992-02-02');
  await sp.click('form[data-f=recsave] button[type=submit]');
  await sp.waitForSelector('form[data-f=checkin]');
  await sp.selectOption('#ci-doc', dB.id);
  await sp.click('form[data-f=checkin] button[type=submit]');
  await sp.waitForSelector('.vrow:has-text("حجز فرع قباء")');
  await go(sp, '#/bookings');
  await sp.waitForSelector('.bk:has(.chip.ready)');
  ok((await sp.locator('.bk', { hasText: bqId }).innerText()).includes('وصل'), 'الحجز يُعلَّم «وصل» بعد تسجيل الوصول');
  const aud = (await adm('GET', '/audit?limit=200')).body.audit;
  ok(aud.some((a) => a.who === 'staff:rec.quba' && a.action === 'visit_create') && aud.some((a) => a.who === 'staff:rec.quba' && a.action.startsWith('booking')), 'سجل التدقيق يحوي عمليات الموظف (وصول + حجز)');

  /* =============== 6) المراجعون =============== */
  await go(sp, '#/patients');
  await sp.fill('#pt-q', 'التحويل');
  await sp.waitForSelector('#pt-res button:has-text("عبدالعزيز")');
  await sp.click('#pt-res [data-a="pt-open"]');
  await sp.waitForSelector('#modal');
  const mt = await sp.locator('#modal').innerText();
  ok(mt.includes('DS-') && mt.includes('آخر الزيارات') && mt.includes('ينتظر'), 'بطاقة المراجع: الملف وآخر زيارة');
  ok(!/\d{10}/.test(mt.replace(/DS-\d+/g, '').replace(/05\d{8}/g, '')), 'لا يظهر رقم هوية كامل في البطاقة');
  await sp.click('#modal [data-a="pt-edit"]');
  await sp.fill('#rf-name', 'عبدالعزيز بعد التعديل');
  await sp.click('form[data-f=recsave] button[type=submit]');
  ok(/حفظ التعديل/.test(await waitToast(sp, /حفظ التعديل/)), 'تعديل بيانات مراجع');
  const rs = (await sapi('GET', '/records?q=' + encodeURIComponent('بعد التعديل'))).body.records;
  ok(rs.length === 1 && rs[0].mrn === p2.mrn, 'التعديل حافظ على رقم الملف نفسه (' + p2.mrn + ')');

  /* =============== 7) عزل الفروع (API) =============== */
  const ft = await http('POST', '/api/staff/login', { username: 'rec.talal', password: 'Temp-pass-2468-x' });
  ok(ft.status === 200 && ft.body.user.mustChange === true, 'موظف التلال: دخول بكلمة مؤقتة');
  const fp = await http('POST', '/api/staff/password', { old: 'Temp-pass-2468-x', new: 'Talal-Reception-2026' }, ft.body.token);
  const TT = fp.body.token;
  const tv = await http('GET', '/api/staff/visits', undefined, TT);
  ok(tv.status === 200 && tv.body.visits.length === 0, 'موظف التلال لا يرى زيارات قباء');
  ok((await http('POST', '/api/staff/visits/' + p2.visit.id + '/status', { status: 'ready' }, TT)).status === 404, 'ولا يستطيع تغيير زيارة فرع آخر');
  ok((await http('POST', '/api/staff/visits', { mrn: p2.mrn, doctorId: dA.id, branchId: QUBA }, TT)).status === 403, 'ولا يسجّل وصولاً في فرع آخر');
  ok((await http('PATCH', '/api/staff/bookings/' + bqId, { status: 'cancelled' }, TT)).status === 404, 'ولا يعدّل حجز فرع آخر');
  const tb = (await http('GET', '/api/staff/bookings', undefined, TT)).body.bookings;
  ok(tb.some((b) => b.id === btId) && !tb.some((b) => b.id === bqId), 'يرى حجز فرعه فقط');

  /* =============== 8) المشرف (كل الفروع + التدقيق) =============== */
  const mctx = await newCtx(1100, 800);
  const mp = await mctx.newPage(); watch(mp, 'manager');
  await mp.goto(BASE + '/staff/', { waitUntil: 'networkidle' });
  const ml = await http('POST', '/api/staff/login', { username: 'mgr.all', password: 'Temp-pass-2468-x' });
  await http('POST', '/api/staff/password', { old: 'Temp-pass-2468-x', new: 'Manager-All-2026' }, ml.body.token);
  await mp.fill('#lg-user', 'mgr.all'); await mp.fill('#lg-pw', 'Manager-All-2026');
  await mp.click('form[data-f=login] button[type=submit]');
  await mp.waitForSelector('#tabs');
  const mtabs = await mp.$$eval('#tabs a', (a) => a.map((x) => x.getAttribute('data-t')));
  ok(mtabs.join() === 'board,checkin,bookings,patients,audit', 'المشرف يرى تبويب التدقيق: ' + mtabs.join());
  ok((await mp.locator('.top .who').innerText()).includes('كل الفروع'), 'الترويسة: كل الفروع');
  await mp.waitForSelector('.vrow');
  ok((await mp.locator('#bd-branch option').count()) === 3, 'قائمة تصفية الفروع للمشرف');
  ok((await mp.locator('#bd-box').innerText()).includes('قباء'), 'يرى اسم الفرع في كل زيارة');
  await mp.selectOption('#bd-branch', TALAL);
  await mp.waitForFunction(() => /لا زيارات/.test(document.querySelector('#bd-box').innerText));
  ok(true, 'تصفية فرع التلال: لا زيارات');
  await mp.selectOption('#bd-branch', '');
  await mp.waitForSelector('.vrow');
  await go(mp, '#/audit');
  await mp.waitForSelector('#au-box table');
  const auTxt = await mp.locator('#au-box').innerText();
  ok(auTxt.includes('staff:rec.quba') && auTxt.includes('visit_create'), 'تبويب التدقيق يعرض عمليات الموظفين');
  ok(!auTxt.includes(tmpPw) && !auTxt.includes(NEWPW), 'لا كلمات مرور في سجل التدقيق');
  await shot(mp, 's08-manager-audit');
  ok((await http('GET', '/api/staff/audit', undefined, TOK)).status === 403, 'موظف الاستقبال لا يقرأ التدقيق (403)');

  /* =============== 9) الإيقاف الفوري من لوحة الإدارة =============== */
  await go(ap, '#/staff');
  await ap.waitForSelector('#st-box tr:has-text("rec.quba")');
  await ap.locator('#st-box tr', { hasText: 'rec.quba' }).locator('[data-a="st-toggle"]').click();
  await ap.waitForFunction(() => { const r = [...document.querySelectorAll('#st-box tr')].find((x) => /rec\.quba/.test(x.innerText)); return !!r && /موقوف/.test(r.innerText); });
  ok(true, 'إيقاف الحساب من لوحة الإدارة');
  await go(sp, '#/board');
  await sp.waitForSelector('#lg-user');
  ok((await sp.locator('#lg-err').innerText()).includes('انتهت الجلسة'), 'الجلسة الجارية تنتهي فوراً بعد الإيقاف');
  ok((await http('POST', '/api/staff/login', { username: 'rec.quba', password: NEWPW })).status === 401, 'ولا يمكنه الدخول من جديد');
  ok((await sp.evaluate(() => sessionStorage.getItem('ds.staff.token') || '')) === '', 'التوكن حُذف من المتصفح');

  /* =============== 10) الجوال (390px) =============== */
  const mob = await newCtx(390, 800);
  const mo = await mob.newPage(); watch(mo, 'mobile');
  await mo.goto(BASE + '/staff/', { waitUntil: 'networkidle' });
  await mo.fill('#lg-user', 'mgr.all'); await mo.fill('#lg-pw', 'Manager-All-2026');
  await mo.click('form[data-f=login] button[type=submit]');
  await mo.waitForSelector('.vrow');
  ok(await mo.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'لا تمرير أفقي على الجوال (اللوحة)');
  await shot(mo, 's09-mobile-board');
  await go(mo, '#/checkin');
  ok(await mo.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'لا تمرير أفقي على الجوال (تسجيل وصول)');
  await go(mo, '#/bookings');
  await mo.waitForSelector('.bk');
  ok(await mo.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'لا تمرير أفقي على الجوال (الحجوزات)');
  await shot(mo, 's10-mobile-bookings');
  await go(mo, '#/audit');
  await mo.waitForSelector('#au-box table');
  ok(await mo.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'لا تمرير أفقي على الجوال (التدقيق)');

  ok(errors.length === 0, 'لا أخطاء جافاسكربت/CSP في أي صفحة' + (errors.length ? ': ' + errors.slice(0, 5).join(' | ') : ''));
  await browser.close();
  console.log('\n' + passes + ' passed, ' + fails + ' failed');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
