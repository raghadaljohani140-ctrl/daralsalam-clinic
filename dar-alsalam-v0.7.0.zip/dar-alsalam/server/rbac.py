"""الأدوار والصلاحيات (RBAC) لمنظومة المستوصف.

الصلاحية = اسم نصي. لكل دور قائمة صلاحيات ثابتة في الكود (لا تُعدَّل من قاعدة البيانات)،
والخادم يتحقق منها عند كل طلب، لا الواجهة. صاحب كلمة مرور الإدارة (المالك) يملك كل شيء.

`ready` = هل واجهة هذا الدور مبنية فعلاً؟ الأدوار غير الجاهزة مُعرَّفة هنا لتكون الصلاحيات
محجوزة ومتّسقة عند بناء مراحلها (الطبيب، المختبر، الأشعة، الصيدلية، التمريض)، ولا يمكن إنشاء حسابات لها بعد.
"""

PERMS = {
    "records.read": "عرض بيانات المراجعين",
    "records.write": "تسجيل وتعديل المراجعين",
    "bookings.read": "عرض طلبات الحجز",
    "bookings.manage": "تأكيد/إلغاء طلبات الحجز",
    "visits.read": "عرض الزيارات وقوائم الانتظار",
    "visits.create": "تسجيل وصول مراجع",
    "visits.transfer": "تحويل مراجع إلى طبيب آخر",
    "visits.advance": "تغيير حالة الزيارة (تجهيز، عند الطبيب، انتهت)",
    "visits.cancel": "إلغاء زيارة",
    "audit.read": "عرض سجل التدقيق",
    "staff.manage": "إدارة الموظفين والصلاحيات",
    # محجوزة للمراحل القادمة (غير مستعملة بعد)
    "clinical.read": "فتح الملف الطبي السريري",
    "clinical.write": "تسجيل تشخيص وملاحظات طبية",
    "orders.lab": "طلب/معالجة التحاليل",
    "orders.radiology": "طلب/معالجة الأشعة",
    "rx.write": "إصدار وصفة",
    "rx.dispense": "صرف وصفة",
    "vitals.write": "تسجيل العلامات الحيوية",
    "files.read": "عرض ملفات المراجع",
    "files.upload": "رفع ملفات المراجع",
}

_VISITS_VIEW = ["records.read", "visits.read"]
_RECEPTION = ["records.read", "records.write", "bookings.read", "bookings.manage", "visits.read", "visits.create", "visits.transfer", "visits.advance", "visits.cancel"]

ROLES = {
    "reception": {"label": "الاستقبال", "ready": True, "perms": _RECEPTION},
    "manager": {"label": "مدير فرع / مشرف", "ready": True, "perms": _RECEPTION + ["audit.read", "files.read"]},
    "nurse": {"label": "التمريض", "ready": False, "perms": _VISITS_VIEW + ["visits.advance", "vitals.write"]},
    "doctor": {"label": "الطبيب", "ready": False, "perms": _VISITS_VIEW + ["visits.advance", "clinical.read", "clinical.write", "orders.lab", "orders.radiology", "rx.write", "files.read"]},
    "lab": {"label": "المختبر", "ready": False, "perms": _VISITS_VIEW + ["orders.lab", "files.upload"]},
    "radiology": {"label": "الأشعة", "ready": False, "perms": _VISITS_VIEW + ["orders.radiology", "files.upload"]},
    "pharmacy": {"label": "الصيدلية", "ready": False, "perms": _VISITS_VIEW + ["rx.dispense"]},
}


def perms_of(role):
    return list(ROLES.get(role, {}).get("perms", []))


def can(role, perm):
    return perm in ROLES.get(role, {}).get("perms", ())


def public_roles(ready_only=True):
    return [{"id": k, "label": v["label"], "ready": v["ready"], "perms": [PERMS[p] for p in v["perms"]]}
            for k, v in ROLES.items() if v["ready"] or not ready_only]
