#!/usr/bin/env python3
"""خادم تطبيق دار السلام: واجهة API عامة + لوحة إدارة + ملفات التطبيق. بدون أي مكتبات خارجية (Python 3.9+)."""
import argparse
import base64
import datetime as dt
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sys
import threading
import time
import urllib.parse
from collections import defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as cfgmod  # noqa: E402
import importer as impmod  # noqa: E402
import db as dbmod  # noqa: E402
import kb as kbmod  # noqa: E402
import push as pushmod  # noqa: E402
import qamar as qmod  # noqa: E402
import records_source as recsrc  # noqa: E402
import schema as sch  # noqa: E402
from util import AR_DIGITS, b64url, b64url_dec, check_password, hash_password, norm_phone, riyadh_today  # noqa: E402,F401
import sms as smsmod  # noqa: E402
from staffapi import StaffMixin  # noqa: E402

DEVICE_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")
BOOKING_ID_RE = re.compile(r"^DS-[A-Z0-9]{6}$")
STATUSES = ("new", "contacted", "confirmed", "cancelled")
PERIODS = ("morning", "evening", "any")
MAX_BODY = 64 * 1024
MAX_UPLOAD = 1536 * 1024  # صورة واحدة بعد ضغطها من المتصفح (عادةً أقل من 300KB)
IMG_MAGIC = ((b'\xff\xd8\xff', 'jpg', 'image/jpeg'), (b'\x89PNG\r\n\x1a\n', 'png', 'image/png'))
MAX_PDF = 12 * 1024 * 1024
MAX_XLSX = 8 * 1024 * 1024
FILE_ID_RE = re.compile(r'f-[0-9a-f]{32}')
UPLOAD_RE = re.compile(r'[0-9a-f]{24}\.(jpg|png)')


class RateLimiter:
    def __init__(self):
        self.h = defaultdict(deque)
        self.lock = threading.Lock()

    def peek(self, key, limit, window):
        """هل ما زال المفتاح تحت الحد؟ (دون تسجيل محاولة)"""
        now = time.monotonic()
        with self.lock:
            q = self.h[key]
            while q and now - q[0] > window:
                q.popleft()
            return len(q) < limit

    def allow(self, key, limit, window):
        now = time.monotonic()
        with self.lock:
            q = self.h[key]
            while q and now - q[0] > window:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            if len(self.h) > 20000:
                for k in [k for k, v in self.h.items() if not v or now - v[-1] > 3600][:5000]:
                    self.h.pop(k, None)
            return True


class App:
    def __init__(self, cfg=None):
        self.cfg = cfg or cfgmod.Config()
        self.db = dbmod.DB(self.cfg.db_path)
        self.lexicon = kbmod.Lexicon.load(self.cfg.lexicon_path)
        if not self.db.is_seeded():
            self.db.seed(json.loads(self.cfg.seed_path.read_text(encoding="utf-8")))
        self.secret = self._load_secret()
        self.rl = RateLimiter()
        self.push = pushmod.Push(self.cfg)
        self._kb = None
        self._kb_ver = None
        self._ds = None
        self._lock = threading.Lock()
        self.qamar = qmod.Qamar(self.cfg, self.db, self.get_kb)

    def _load_secret(self):
        p = self.cfg.secret_path
        if p.exists():
            return p.read_bytes()
        p.parent.mkdir(parents=True, exist_ok=True)
        s = secrets.token_bytes(32)
        p.write_bytes(s)
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
        return s

    # ---------------------------------------------------------------- بيانات
    def _data_version(self):
        return int(self.db.get_kv("dataVersion", 1) or 1)

    def public_dataset(self):
        ver = self._data_version()
        if self._ds and self._ds[0] == ver:
            return self._ds
        with self._lock:
            ds = self.db.dataset(public=True)
            sp = {e["id"] for e in ds["specialties"]}
            sv = {e["id"] for e in ds["services"]}
            br = {e["id"] for e in ds["branches"]}
            for d in ds["doctors"]:
                d["specialtyIds"] = [i for i in d.get("specialtyIds", []) if i in sp]
                d["serviceIds"] = [i for i in d.get("serviceIds", []) if i in sv]
                d["branchIds"] = [i for i in d.get("branchIds", []) if i in br]
            # إفصاح علني (ليس سراً): هل يُستعان بمزوّد ذكاء اصطناعي خارجي؟ يقرؤه التطبيق ليعرض نص خصوصية مطابقاً لما يحدث فعلاً
            ds["qamar"]["externalAi"] = bool(self.cfg.llm_enabled)
            # هل التسجيل برمز التحقق مفعّل؟ (يُفعَّل فقط بضبط مزوّد رسائل على الخادم؛ وإلا يبقى الحجز بلا تسجيل كما هو)
            ds["meta"]["auth"] = {"enabled": smsmod.enabled(self.cfg)}
            # الملفات الطبية تُعرض فقط لمن تحقّق من جواله (لذلك لا تعمل إلا مع تفعيل التسجيل)
            ds["meta"]["files"] = {"enabled": smsmod.enabled(self.cfg), "kinds": [{"id": k, "label": l} for k, l in sch.FILE_KINDS]}
            body = json.dumps(ds, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            self._ds = (ver, ds, '"' + hashlib.sha256(body).hexdigest()[:24] + '"', body)
        return self._ds

    def get_kb(self):
        ver = self._data_version()
        if self._kb is None or self._kb_ver != ver:
            with self._lock:
                ds = self.db.dataset(public=True)
                self._kb = kbmod.KB(ds, self.lexicon)
                self._kb_ver = ver
        return self._kb

    # ---------------------------------------------------------------- مصادقة الإدارة
    def admin_record(self):
        return self.db.get_kv("admin")

    def set_admin_password(self, pw):
        self.db.set_kv("admin", hash_password(pw))

    def make_token(self):
        rec = self.admin_record()
        payload = b64url(json.dumps({"exp": int(time.time() + self.cfg.admin_token_hours * 3600), "ph": rec["hash"][:10]}).encode())
        sig = hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()
        return payload + "." + sig

    # ---------------------------------------------------------------- حساب المريض
    PATIENT_DAYS = 90

    def make_patient_token(self, pid):
        payload = b64url(json.dumps({"k": "pt", "pid": pid, "exp": int(time.time() + self.PATIENT_DAYS * 86400)}).encode())
        return payload + "." + hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()

    def patient_from_token(self, tok):
        try:
            payload, sig = tok.split(".", 1)
            if not hmac.compare_digest(sig, hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()):
                return None
            d = json.loads(b64url_dec(payload))
            if d.get("k") != "pt" or d["exp"] <= time.time():
                return None
            return self.db.patient_by_id(d["pid"])
        except Exception:  # noqa: BLE001
            return None

    def otp_hash(self, phone, code):
        return hmac.new(self.secret, ("otp|%s|%s" % (phone, code)).encode(), hashlib.sha256).hexdigest()

    def verify_token(self, tok):
        try:
            payload, sig = tok.split(".", 1)
            good = hmac.new(self.secret, payload.encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(sig, good):
                return False
            d = json.loads(b64url_dec(payload))
            rec = self.admin_record()
            return bool(rec) and d.get("k") is None and d["exp"] > time.time() and d["ph"] == rec["hash"][:10]
        except Exception:  # noqa: BLE001
            return False


MIME = {".js": "application/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".html": "text/html; charset=utf-8",
        ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml", ".webmanifest": "application/manifest+json", ".png": "image/png",
        ".ico": "image/x-icon", ".woff2": "font/woff2", ".txt": "text/plain; charset=utf-8"}


def privacy_html(settings, llm, auth=False):
    name = settings.get("name", "")
    phone = next((p["number"] for p in settings.get("phones", []) if p.get("type") == "main"), "")
    auth_li = "<li>%s</li>" % "عند إنشاء حساب: الاسم ورقم الجوال والجنس وتاريخ الميلاد، ورقم الهوية/الإقامة إن أدخلته (اختياري). ويُرسَل إليك رمز تحقق في رسالة نصية عبر مزوّد خدمة رسائل. يمكنك حذف حسابك من صفحة «طلباتي وبياناتي». ولربط حسابك بملفك الطبي نطابق رقم هويتك أو تاريخ ميلادك مع ما هو مسجّل لدى المجمع برقم جوالك، ولا نعرض أي بيانات من الملف قبل نجاح المطابقة. ملفاتك الطبية (PDF) التي يرفعها موظفو المجمع إلى ملفك (كنتائج المختبر والأشعة): تُحفظ على خادم المجمع بصورة خاصة ولا يراها إلا أنت وموظفو المجمع المخوَّلون، وتبقى لدى المجمع وفق أنظمة حفظ السجلات الطبية حتى لو حذفت حسابك." if auth else ""
    log_note = " (وكذلك ما أُرسل منها للمزوّد الخارجي)" if llm else ""
    ai = ("<li>المساعد «قمر» مفعَّل حالياً بخدمة ذكاء اصطناعي خارجية للأسئلة التي لا يجيب عنها من بيانات المجمع: يُرسَل إلى المزوّد نص سؤالك "
          "وآخر رسائل المحادثة فقط، بعد استبدال الأرقام الطويلة والبريد الإلكتروني برموز، ولا يُرسَل إليه الاسم ولا الجوال المسجّلان في طلبات الحجز. "
          "قد تُعالَج هذه النصوص خارج المملكة بحسب مزوّد الخدمة، فننصحك بعدم كتابة معلومات شخصية أو تفاصيل طبية في المحادثة.</li>") if llm else ""
    return f"""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>سياسة الخصوصية — {name}</title><style>body{{font-family:system-ui,'Segoe UI',Tahoma,sans-serif;line-height:1.9;margin:0;background:#f3f6fa;color:#1b2b36}}
main{{max-width:760px;margin:auto;padding:24px 18px}}h1{{color:#064a85;font-size:1.5rem}}h2{{font-size:1.1rem;margin-top:1.6em}}</style></head><body><main>
<h1>سياسة الخصوصية — تطبيق {name}</h1>
<h2>ما الذي نجمعه؟</h2><ul>{auth_li}<li>عند إرسال طلب حجز: الاسم ورقم الجوال والتخصص/الطبيب/الفرع المطلوب والتاريخ المفضل وملاحظتك الاختيارية.</li>
<li>معرّف عشوائي للجهاز لربط طلباتك وإشعاراتك بجهازك، دون أي معلومات هوية.</li>
<li>أسئلة المساعد «قمر» التي لم يفهمها بشكل كافٍ{log_note} تُحفظ مختصرة بعد إخفاء الأرقام والبريد، لتحسين الإجابات، ويُحذف الأقدم تلقائياً.</li>{ai}</ul>
<h2>لماذا؟</h2><p>لمعالجة طلبك والتواصل معك لتأكيد الموعد، وإرسال إشعارات تخص طلباتك، وتحسين خدمة المساعد.</p>
<h2>مع من نشارك بياناتك؟</h2><p>لا نبيع بياناتك ولا نشاركها لأغراض إعلانية. تصل بيانات الطلب إلى موظفي {name} المسؤولين عن المواعيد فقط.</p>
<h2>حقوقك</h2><p>تستطيع من صفحة «حسابي» في التطبيق إلغاء طلباتك وحذف بياناتك من الخادم، أو الاتصال بنا على {phone}.</p>
<h2>تنبيه طبي</h2><p>المساعد «قمر» لا يقدّم تشخيصاً ولا وصفات علاجية. في الحالات الطارئة اتصل بالإسعاف {settings.get('emergencyNumber', '997')}.</p>
</main></body></html>"""


class Handler(StaffMixin, BaseHTTPRequestHandler):
    server_version = "DarAlsalam/1.0"
    protocol_version = "HTTP/1.1"

    # ---------------------------------------------------------------- أدوات
    @property
    def app(self):
        return self.server.app

    def log_message(self, fmt, *args):
        if os.environ.get("DS_QUIET") == "1":
            return
        sys.stderr.write("%s %s\n" % (self.address_string(), (fmt % args).split("?")[0]))

    @property
    def ip(self):
        if self.app.cfg.trust_proxy:
            xff = self.headers.get("X-Forwarded-For", "")
            if xff:
                return xff.split(",")[0].strip()
        return self.client_address[0]

    def _send(self, status, body, ctype, headers=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        if self.path.startswith("/api/v1/"):
            self.send_header("Access-Control-Allow-Origin", self.app.cfg.cors_origin)
            self.send_header("Access-Control-Expose-Headers", "ETag")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def json(self, status, obj, headers=None):
        h = {"Cache-Control": "no-store"}
        h.update(headers or {})
        self._send(status, json.dumps(obj, ensure_ascii=False), "application/json; charset=utf-8", h)

    def err(self, status, code, msg="", fields=None):
        d = {"error": code, "message": msg}
        if fields:
            d["fields"] = fields
        self.json(status, d)

    def body_json(self):
        raw = getattr(self, "_raw", b"")
        if not raw:
            return {}
        try:
            d = json.loads(raw.decode("utf-8"))
            return d if isinstance(d, dict) else (self.err(400, "bad_json", "صيغة غير صحيحة") or None)
        except (ValueError, UnicodeDecodeError):
            self.err(400, "bad_json", "صيغة غير صحيحة")
            return None

    def admin_ok(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Bearer ") and self.app.verify_token(h[7:]):
            return True
        self.err(401, "unauthorized", "غير مصرّح")
        return False

    # ---------------------------------------------------------------- توزيع الطلبات
    def do_OPTIONS(self):
        if self.path.startswith("/api/v1/"):
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", self.app.cfg.cors_origin)
            self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, If-None-Match, Authorization")
            self.send_header("Access-Control-Max-Age", "86400")
            self.send_header("Content-Length", "0")
            self.end_headers()
        else:
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.dispatch("PUT")

    def do_PATCH(self):
        self.dispatch("PATCH")

    def do_DELETE(self):
        self.dispatch("DELETE")

    def dispatch(self, method):
        try:
            u = urllib.parse.urlsplit(self.path)
            path, qs = u.path, urllib.parse.parse_qs(u.query)
            self.qs = {k: v[0] for k, v in qs.items()}
            self._raw = b""
            if method in ("POST", "PUT", "PATCH", "DELETE"):
                try:
                    n = int(self.headers.get("Content-Length", "0") or 0)
                except ValueError:
                    n = -1
                if path == "/api/admin/upload":
                    if not self.admin_ok():
                        self.close_connection = True
                        return
                    limit = MAX_UPLOAD
                elif method == "POST" and (path == "/api/admin/files" or re.fullmatch(r"/api/admin/files/f-[0-9a-f]{32}/replace", path)):
                    if not self.admin_ok():
                        self.close_connection = True
                        return
                    limit = MAX_PDF
                elif method == "POST" and path == "/api/admin/records/import":
                    if not self.admin_ok():
                        self.close_connection = True
                        return
                    limit = MAX_XLSX
                else:
                    limit = MAX_BODY
                if n < 0 or n > limit:
                    self.close_connection = True
                    return self.err(413, "too_large", "الطلب كبير")
                self._raw = self.rfile.read(n) if n else b""
            if path.startswith("/api/v1/"):
                return self.public_api(method, path[len("/api/v1"):])
            if method == "GET" and path.startswith("/uploads/"):
                return self.serve_upload(path[len("/uploads/"):])
            if path.startswith("/api/staff/"):
                return self.staff_api(method, path[len("/api/staff"):])
            if path.startswith("/api/admin/"):
                return self.admin_api(method, path[len("/api/admin"):])
            if method in ("GET", "HEAD"):
                return self.static(path)
            self.err(405, "method_not_allowed")
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:  # noqa: BLE001
            sys.stderr.write("ERROR %s: %r\n" % (self.path.split("?")[0], e))
            try:
                self.err(500, "server_error", "حدث خطأ في الخادم")
            except Exception:  # noqa: BLE001
                pass

    # ---------------------------------------------------------------- API العامة
    def public_api(self, method, p):
        app = self.app
        if method == "GET" and p == "/health":
            return self.json(200, {"ok": True, "dataVersion": app._data_version()})
        if method == "GET" and p == "/clinic":
            _, _, etag, body = app.public_dataset()
            if self.headers.get("If-None-Match") == etag:
                return self._send(304, b"", "application/json", {"ETag": etag, "Cache-Control": "no-cache"})
            return self._send(200, body, "application/json; charset=utf-8", {"ETag": etag, "Cache-Control": "no-cache"})
        if method == "GET" and p == "/lexicon":
            body = app.cfg.lexicon_path.read_bytes()
            etag = '"' + hashlib.sha256(body).hexdigest()[:24] + '"'
            if self.headers.get("If-None-Match") == etag:
                return self._send(304, b"", "application/json", {"ETag": etag})
            return self._send(200, body, "application/json; charset=utf-8", {"ETag": etag, "Cache-Control": "no-cache"})
        if method == "POST" and p == "/devices":
            return self.api_device_register()
        m = re.fullmatch(r"/devices/([A-Za-z0-9_-]{16,64})(/delete)?", p)
        if m and ((method == "DELETE" and not m.group(2)) or (method == "POST" and m.group(2))):
            if not app.rl.allow("deldev:" + self.ip, 10, 3600):
                return self.err(429, "rate_limited", "محاولات كثيرة")
            app.db.delete_device_data(m.group(1))
            return self.json(200, {"ok": True})
        if p == "/files" or p.startswith("/files/"):
            return self.patient_files_api(method, p[len("/files"):])
        if p.startswith("/records/"):
            return self.patient_records_api(method, p[len("/records"):])
        if p.startswith("/auth/"):
            return self.auth_api(method, p[len("/auth"):])
        if method == "POST" and p == "/bookings":
            return self.api_booking_create()
        if method == "GET" and p == "/bookings":
            did = self.qs.get("deviceId", "")
            if not DEVICE_RE.fullmatch(did):
                return self.err(400, "bad_device", "معرّف الجهاز غير صحيح")
            if not app.rl.allow("bk-list:" + self.ip, 120, 60):
                return self.err(429, "rate_limited")
            return self.json(200, {"bookings": [self.public_booking(b) for b in app.db.list_bookings(device_id=did, limit=50)]})
        m = re.fullmatch(r"/bookings/(DS-[A-Z0-9]{6})/cancel", p)
        if method == "POST" and m:
            body = self.body_json()
            if body is None:
                return
            b = app.db.get_booking(m.group(1))
            if not b or b["device_id"] != str(body.get("deviceId", "")):
                return self.err(404, "not_found", "الطلب غير موجود")
            if b["status"] not in ("new", "contacted"):
                return self.err(409, "not_cancellable", "لا يمكن إلغاء هذا الطلب من التطبيق، تواصل مع المجمع")
            b = app.db.update_booking(b["id"], status="cancelled")
            app.push.staff_alert("إلغاء طلب حجز %s من المراجع" % b["id"])
            return self.json(200, {"booking": self.public_booking(b)})
        if method == "GET" and p == "/notifications":
            did = self.qs.get("deviceId", "")
            if not DEVICE_RE.fullmatch(did):
                return self.err(400, "bad_device")
            if not app.rl.allow("notif:" + self.ip, 120, 60):
                return self.err(429, "rate_limited")
            try:
                since = int(self.qs.get("since", "0"))
            except ValueError:
                since = 0
            pt = self.current_patient()
            return self.json(200, {"notifications": app.db.list_notifications(did, since, patient_id=pt["id"] if pt else None)})
        if method == "GET" and p == "/qamar/config":
            return self.api_qamar_config()
        if method == "POST" and p == "/qamar":
            return self.api_qamar()
        self.err(404, "not_found")

    def api_qamar_config(self):
        """إعدادات خفيفة لويدجت الموقع (أقل من 1KB) حتى لا يحمّل الويدجت كل بيانات المجمع."""
        _, ds, _, _ = self.app.public_dataset()
        q, s = ds.get("qamar") or {}, ds.get("settings") or {}
        phone = next((x.get("number", "") for x in s.get("phones", []) if x.get("type") == "main"), "")
        out = {"enabled": q.get("enabled", True) is not False, "name": q.get("name") or "قمر", "greeting": q.get("greeting") or "",
               "quickReplies": [str(x)[:60] for x in (q.get("quickReplies") or [])[:6]],
               "clinicName": s.get("name") or "", "shortName": s.get("shortName") or "",
               "emergencyNumber": s.get("emergencyNumber") or "997", "mainPhone": phone}
        return self.json(200, out, {"Cache-Control": "public, max-age=120"})

    def api_device_register(self):
        body = self.body_json()
        if body is None:
            return
        did = str(body.get("deviceId", ""))
        if not DEVICE_RE.fullmatch(did):
            return self.err(400, "bad_device", "معرّف الجهاز غير صحيح")
        if not self.app.rl.allow("dev:" + self.ip, 60, 3600):
            return self.err(429, "rate_limited")
        platform = str(body.get("platform", ""))[:20]
        token = str(body.get("pushToken", ""))[:400]
        self.app.db.upsert_device(did, platform, token)
        return self.json(200, {"ok": True})

    @staticmethod
    def public_booking(b):
        keys = ("id", "status", "created_at", "updated_at", "specialty_id", "doctor_id", "branch_id", "service_id", "date", "period", "note", "appointment_text")
        d = {k: b.get(k) for k in keys}
        d["createdAt"], d["updatedAt"] = d.pop("created_at"), d.pop("updated_at")
        d["specialtyId"], d["doctorId"], d["branchId"], d["serviceId"] = d.pop("specialty_id"), d.pop("doctor_id"), d.pop("branch_id"), d.pop("service_id")
        d["appointmentText"] = d.pop("appointment_text") or ""
        return d

    # ---------------------------------------------------------------- تسجيل المرضى
    def current_patient(self):
        h = self.headers.get("Authorization", "")
        return self.app.patient_from_token(h[7:]) if h.startswith("Bearer ") else None

    @staticmethod
    def public_patient(p):
        return {"id": p["id"], "name": p["name"], "phone": p["phone"], "gender": p["gender"] or "", "birthDate": p["birth_date"] or "",
                "hasNationalId": bool(p["national_id"])}

    @staticmethod
    def clean_profile(body, f):
        name = re.sub(r"\s+", " ", str(body.get("name", ""))).strip()
        if not (2 <= len(name) <= 60) or len(re.findall(r"[A-Za-zء-ي]", name)) < 2:
            f["name"] = "اكتب الاسم (حرفان على الأقل)"
        gender = str(body.get("gender", ""))
        if gender not in ("male", "female"):
            f["gender"] = "اختر الجنس"
        bd = str(body.get("birthDate", ""))
        try:
            d0 = dt.date.fromisoformat(bd)
            if d0 < dt.date(1900, 1, 1) or d0 > riyadh_today():
                raise ValueError
        except ValueError:
            f["birthDate"] = "تاريخ الميلاد غير صحيح"
        nid = re.sub(r"\D", "", str(body.get("nationalId", "") or "").translate(AR_DIGITS))
        if nid and not re.fullmatch(r"[12]\d{9}", nid):
            f["nationalId"] = "رقم الهوية/الإقامة 10 أرقام يبدأ بـ 1 أو 2 (أو اتركه فارغاً)"
        return name, gender, bd, nid or None

    def auth_api(self, method, p):
        app = self.app
        if not smsmod.enabled(app.cfg):
            return self.err(503, "auth_disabled", "التسجيل غير مفعّل بعد")
        if method == "POST" and p == "/otp":
            body = self.body_json()
            if body is None:
                return
            phone = norm_phone(body.get("phone"))
            if not phone or not phone.startswith("9665"):
                return self.err(422, "validation", "رقم الجوال غير صحيح (مثال: 05xxxxxxxx)", {"phone": "رقم الجوال غير صحيح (مثال: 05xxxxxxxx)"})
            if not app.rl.allow("otp-ip:" + self.ip, 12, 3600) or not app.rl.allow("otp-ph:" + phone, 3, 600):
                return self.err(429, "rate_limited", "طلبات كثيرة، انتظر بضع دقائق ثم جرّب")
            old = app.db.otp_get(phone)
            if old and int(time.time()) - old["created"] < 45:
                return self.err(429, "too_soon", "انتظر قليلاً قبل طلب رمز جديد")
            code = "".join(secrets.choice("0123456789") for _ in range(6))
            app.db.otp_put(phone, app.otp_hash(phone, code), 300)
            try:
                smsmod.send(app.cfg, phone, "رمز التحقق لتطبيق مجمعات دار السلام الطبية: %s\nصالح 5 دقائق. لا تشاركه مع أحد." % code)
            except smsmod.SmsError as e:
                app.db.otp_clear(phone)
                sys.stderr.write("SMS ERROR: %s\n" % e)
                return self.err(502, "sms_failed", "تعذّر إرسال الرمز الآن، جرّب لاحقاً أو اتصل بالمجمع")
            return self.json(200, {"ok": True, "isNew": app.db.patient_by_phone(phone) is None})
        if method == "POST" and p == "/verify":
            body = self.body_json()
            if body is None:
                return
            phone = norm_phone(body.get("phone"))
            code = re.sub(r"\D", "", str(body.get("code", "")).translate(AR_DIGITS))
            if not phone or not code:
                return self.err(422, "validation", "أدخل الرمز")
            if not app.rl.allow("verify-ip:" + self.ip, 40, 3600):
                return self.err(429, "rate_limited", "محاولات كثيرة")
            rec = app.db.otp_get(phone)
            if not rec or rec["expires"] < time.time() or rec["attempts"] >= 5:
                return self.err(400, "otp_expired", "انتهت صلاحية الرمز، اطلب رمزاً جديداً")
            if not hmac.compare_digest(rec["code_hash"], app.otp_hash(phone, code)):
                app.db.otp_fail(phone)
                return self.err(400, "otp_bad", "الرمز غير صحيح")
            pt = app.db.patient_by_phone(phone)
            if not pt:
                f = {}
                name, gender, bd, nid = self.clean_profile(body.get("profile") if isinstance(body.get("profile"), dict) else {}, f)
                if f:
                    return self.err(422, "profile_needed", "أكمل بياناتك لإنشاء الحساب", f)
                pt = app.db.patient_create(phone, name, gender, bd, nid)
            else:
                app.db.patient_touch(pt["id"])
            app.db.otp_clear(phone)
            return self.json(200, {"token": app.make_patient_token(pt["id"]), "patient": self.public_patient(pt)})
        pt = self.current_patient()
        if not pt:
            return self.err(401, "unauthorized", "سجّل الدخول")
        if method == "GET" and p == "/me":
            return self.json(200, {"patient": self.public_patient(pt)})
        if method == "POST" and p == "/me":
            body = self.body_json()
            if body is None:
                return
            f = {}
            name, gender, bd, nid = self.clean_profile(body, f)
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            return self.json(200, {"patient": self.public_patient(app.db.patient_update(pt["id"], name, gender, bd, nid or pt["national_id"]))})
        if method == "POST" and p == "/delete":
            app.db.patient_delete(pt["id"])
            return self.json(200, {"ok": True})
        self.err(404, "not_found")

    def api_booking_create(self):
        app = self.app
        body = self.body_json()
        if body is None:
            return
        pt = None
        if smsmod.enabled(app.cfg):
            pt = self.current_patient()
            if not pt:
                return self.err(401, "login_required", "سجّل الدخول لإرسال طلب الحجز")
            body = dict(body, name=pt["name"], phone=pt["phone"])
        if not app.rl.allow("bk:" + self.ip, 15, 3600):
            return self.err(429, "rate_limited", "محاولات كثيرة، جرّب لاحقاً")
        f = {}
        did = str(body.get("deviceId", ""))
        if not DEVICE_RE.fullmatch(did):
            f["deviceId"] = "معرّف الجهاز غير صحيح"
        name = re.sub(r"\s+", " ", str(body.get("name", ""))).strip()
        if not (2 <= len(name) <= 60) or len(re.findall(r"[A-Za-zء-ي]", name)) < 2:
            f["name"] = "اكتب الاسم (حرفان على الأقل)"
        phone = norm_phone(body.get("phone"))
        if not phone:
            f["phone"] = "رقم الجوال غير صحيح (مثال: 05xxxxxxxx)"
        if body.get("consent") is not True:
            f["consent"] = "يجب الموافقة على سياسة الخصوصية"
        ds = app.public_dataset()[1]
        ids = {k: {e["id"] for e in ds[k]} for k in ("specialties", "doctors", "branches", "services")}

        def ref(field, kind):
            v = str(body.get(field) or "")
            if v and v not in ids[kind]:
                f[field] = "غير موجود"
                return None
            return v or None

        sp, dr, br, sv = ref("specialtyId", "specialties"), ref("doctorId", "doctors"), ref("branchId", "branches"), ref("serviceId", "services")
        if not (sp or dr or sv) and not f:
            f["specialtyId"] = "اختر التخصص أو الطبيب"
        if dr and not sp:
            d = next(e for e in ds["doctors"] if e["id"] == dr)
            sp = (d.get("specialtyIds") or [None])[0]
        date = str(body.get("date") or "")
        if date:
            try:
                d0 = dt.date.fromisoformat(date)
                t = riyadh_today()
                if d0 < t or d0 > t + dt.timedelta(days=120):
                    f["date"] = "اختر تاريخاً من اليوم حتى 120 يوماً"
            except ValueError:
                f["date"] = "تاريخ غير صحيح"
        period = str(body.get("period") or "any")
        if period not in PERIODS:
            f["period"] = "فترة غير صحيحة"
        note = re.sub(r"[\x00-\x08\x0b-\x1f]", "", str(body.get("note") or "")).strip()[:300]
        if f:
            return self.err(422, "validation", "تحقق من الحقول", f)
        if app.db.count_recent_bookings(did, 24) >= 8:
            return self.err(429, "too_many", "وصلت للحد اليومي من الطلبات، تواصل مع المجمع هاتفياً")
        for b in app.db.list_bookings(device_id=did, limit=5):
            same = (b["specialty_id"], b["doctor_id"], b["branch_id"], b["service_id"], b["date"], b["period"]) == (sp, dr, br, sv, date or None, period)
            if same and b["status"] in ("new", "contacted") and b["created_at"][:13] == dbmod.now()[:13]:
                return self.json(200, {"booking": self.public_booking(b), "duplicate": True})
        app.db.upsert_device(did, str(body.get("platform", ""))[:20], "")
        rec = app.db.create_booking({"name": name, "phone": phone, "device_id": did, "specialty_id": sp, "doctor_id": dr, "branch_id": br,
                                     "service_id": sv, "date": date or None, "period": period, "note": note, "source": str(body.get("source", "app"))[:20]})
        label = next((e["name"] for e in ds["specialties"] if e["id"] == sp), "") or next((e["name"] for e in ds["services"] if e["id"] == sv), "")
        threading.Thread(target=app.push.staff_alert, args=("طلب حجز جديد %s — %s" % (rec["id"], label or "غير محدد"),), daemon=True).start()
        return self.json(201, {"booking": self.public_booking(rec)})

    def api_qamar(self):
        app = self.app
        body = self.body_json()
        if body is None:
            return
        qcfg = app.db.get_kv("qamar", {}) or {}
        if not qcfg.get("enabled", True):
            return self.err(503, "qamar_disabled", "المساعد غير متاح حالياً")
        msg = str(body.get("message", "")).strip()
        did = str(body.get("deviceId", ""))
        if not msg:
            return self.err(400, "empty", "اكتب رسالتك")
        if len(msg) > 600:
            return self.err(400, "too_long", "الرسالة طويلة")
        if not app.rl.allow("qamar-ip:" + self.ip, 60, 60) or not app.rl.allow("qamar-dev:" + did, 20, 60):
            return self.err(429, "rate_limited", "أرسلت رسائل كثيرة، انتظر قليلاً")
        hist = body.get("history") if isinstance(body.get("history"), list) else []
        hist = [{"role": str(h.get("role", "")), "content": str(h.get("content", ""))[:500]} for h in hist[-8:] if isinstance(h, dict)]
        out = app.qamar.reply(msg, hist, did)
        return self.json(200, {"reply": out})

    # ---------------------------------------------------------------- API الإدارة
    def admin_api(self, method, p):
        app = self.app
        if method == "POST" and p == "/login":
            if not app.rl.allow("login:" + self.ip, 8, 600):
                return self.err(429, "rate_limited", "محاولات كثيرة، انتظر 10 دقائق")
            body = self.body_json()
            if body is None:
                return
            rec = app.admin_record()
            if not rec:
                return self.err(503, "admin_not_configured", "لم تُضبط كلمة مرور الإدارة بعد (python3 server/manage.py init)")
            if not check_password(str(body.get("password", "")), rec):
                return self.err(401, "bad_password", "كلمة المرور غير صحيحة")
            return self.json(200, {"token": app.make_token(), "hours": app.cfg.admin_token_hours})
        if not self.admin_ok():
            return
        db = app.db
        if method == "POST" and p == "/upload":
            return self.api_upload()
        if p == "/patients" or p == "/files" or p.startswith("/files/") or p == "/records" or p.startswith("/records/"):
            return self.admin_files_api(method, p)
        if p in ("/roles", "/audit", "/staff") or p.startswith("/staff/"):
            return self.admin_staff_api(method, p)
        if method == "GET" and p == "/schema":
            return self.json(200, sch.public_schema())
        if method == "GET" and p == "/dataset":
            ds = db.dataset(public=False)
            ds["meta"]["dataVersion"] = app._data_version()
            ds["qamarStatus"] = {"llmConfigured": app.cfg.llm_enabled, "provider": app.cfg.qamar_provider, "model": app.cfg.qamar_model,
                                 "dailyCap": app.cfg.qamar_daily_cap, "usedToday": db.usage_get("llm")}
            ds["pushStatus"] = {"fcm": app.push.fcm_enabled, "telegram": bool(app.cfg.telegram_token and app.cfg.telegram_chat)}
            return self.json(200, ds)
        if method == "PUT" and p == "/settings":
            body = self.body_json()
            if body is None:
                return
            out, errs = sch.validate_settings(body, db.get_kv("settings", {}))
            if errs:
                return self.err(422, "validation", "تحقق من الحقول", errs)
            db.set_kv("settings", out)
            db._bump()
            db.conn().execute("INSERT INTO audit(ts,who,action,kind,ref,detail) VALUES(?,?,?,?,?,?)", (dbmod.now(), "admin", "update", "settings", "", ""))
            return self.json(200, {"settings": out})
        if method == "PUT" and p == "/qamar":
            body = self.body_json()
            if body is None:
                return
            out, errs = sch.validate_qamar(body, db.get_kv("qamar", {}))
            if errs:
                return self.err(422, "validation", "تحقق من الحقول", errs)
            db.set_kv("qamar", out)
            db._bump()
            return self.json(200, {"qamar": out})
        m = re.fullmatch(r"/entities/(\w+)(?:/([a-z0-9-]+))?", p)
        if m and m.group(1) in sch.KINDS:
            return self.admin_entity(method, m.group(1), m.group(2))
        if method == "GET" and p == "/bookings":
            rows = db.list_bookings(status=self.qs.get("status") or None, q=self.qs.get("q") or None, limit=300)
            return self.json(200, {"bookings": rows, "stats": db.booking_stats()})
        m = re.fullmatch(r"/bookings/(DS-[A-Z0-9]{6})", p)
        if method == "PATCH" and m:
            return self.admin_booking_update(m.group(1))
        if method == "GET" and p == "/notifications":
            return self.json(200, {"notifications": db.list_all_notifications()})
        if method == "POST" and p == "/notifications":
            body = self.body_json()
            if body is None:
                return
            title, text = str(body.get("title", "")).strip()[:80], str(body.get("body", "")).strip()[:300]
            target = str(body.get("target") or "all")
            if not title or not text:
                return self.err(422, "validation", "العنوان والنص مطلوبان")
            if target != "all" and not DEVICE_RE.fullmatch(target):
                return self.err(422, "validation", "هدف غير صحيح")
            nid = db.add_notification(title, text, target, "info")
            sent = app.push.send(db.push_tokens(target), title, text, {"id": nid})
            return self.json(201, {"id": nid, "push": {"sent": sent[0], "failed": sent[1], "enabled": app.push.fcm_enabled}})
        if method == "GET" and p == "/qamar/log":
            return self.json(200, {"log": db.recent_qamar_log(150, self.qs.get("unconfident") == "1")})
        if method == "GET" and p == "/stats":
            return self.json(200, {"bookings": db.booking_stats(), "qamarToday": db.usage_get("qamar:msgs"), "llmToday": db.usage_get("llm"),
                                   "audit": db.recent_audit(30)})
        if method == "POST" and p == "/password":
            body = self.body_json()
            if body is None:
                return
            new = str(body.get("new", ""))
            if not check_password(str(body.get("old", "")), app.admin_record()):
                return self.err(401, "bad_password", "كلمة المرور الحالية غير صحيحة")
            if len(new) < 10:
                return self.err(422, "weak", "كلمة المرور الجديدة قصيرة (10 أحرف على الأقل)")
            app.set_admin_password(new)
            return self.json(200, {"ok": True, "token": app.make_token()})
        if method == "GET" and p == "/export":
            return self.json(200, db.export_all())
        self.err(404, "not_found")

    def admin_entity(self, method, kind, eid):
        db = self.app.db
        if method == "GET" and not eid:
            return self.json(200, {"items": db.list_entities(kind, include_inactive=True)})
        if method in ("POST", "PUT"):
            body = self.body_json()
            if body is None:
                return
            existing = db.get_entity(kind, eid) if eid else None
            if method == "POST" and not eid:
                if body.get("id") and db.get_entity(kind, str(body["id"])):
                    return self.err(409, "exists", "المعرّف مستخدم")
            elif method == "PUT" and not existing:
                return self.err(404, "not_found")
            if eid:
                body["id"] = eid
            refs = {k: db.ids(k) for k in ("specialties", "services", "branches", "doctors")}
            out, errs = sch.validate_entity(kind, body, existing, refs)
            if errs:
                return self.err(422, "validation", "تحقق من الحقول", errs)
            return self.json(200 if existing else 201, {"item": db.upsert_entity(kind, out, "admin")})
        if method == "DELETE" and eid:
            hard = self.qs.get("hard") == "1"
            if hard and self.qs.get("confirm") != eid:
                return self.err(422, "confirm_required", "الحذف النهائي يتطلب تأكيد المعرّف")
            ok = db.delete_entity(kind, eid, hard=hard, who="admin")
            return self.json(200 if ok else 404, {"ok": ok, "hard": hard})
        self.err(405, "method_not_allowed")

    def admin_booking_update(self, bid, who="admin"):
        app = self.app
        db = app.db
        b = db.get_booking(bid)
        if not b:
            return self.err(404, "not_found")
        body = self.body_json()
        if body is None:
            return
        fields = {}
        if "adminNote" in body:
            fields["admin_note"] = str(body["adminNote"])[:500]
        if "appointmentText" in body:
            fields["appointment_text"] = str(body["appointmentText"]).strip()[:200]
        new_status = body.get("status")
        if new_status is not None:
            if new_status not in STATUSES:
                return self.err(422, "validation", "حالة غير صحيحة")
            fields["status"] = new_status
            if new_status == "confirmed" and not (fields.get("appointment_text") or b.get("appointment_text")):
                return self.err(422, "validation", "اكتب تفاصيل الموعد المؤكد (اليوم والوقت والطبيب) قبل التأكيد")
        nb = db.update_booking(bid, **fields)
        db.audit(who, "booking_update", "booking", bid, json.dumps({"status": new_status or "", "fields": sorted(fields)}, ensure_ascii=False))
        if new_status and new_status != b["status"] and b["device_id"] and not b["device_id"].startswith("deleted-"):
            msgs = {"contacted": ("تواصل معك المجمع", "تواصل المجمع بخصوص طلبك رقم %s." % bid),
                    "confirmed": ("تم تأكيد موعدك", "طلبك رقم %s: %s" % (bid, nb.get("appointment_text") or "")),
                    "cancelled": ("تم إلغاء طلبك", "تم إلغاء طلب الحجز رقم %s. للاستفسار اتصل بالمجمع." % bid)}
            if new_status in msgs:
                t, x = msgs[new_status]
                nid = db.add_notification(t, x, b["device_id"], "booking", bid)
                app.push.send(db.push_tokens(b["device_id"]), t, x, {"id": nid, "booking": bid})
        return self.json(200, {"booking": nb})

    # ---------------------------------------------------------------- ملفات ثابتة
    def static(self, path):
        cfg = self.app.cfg
        if path in ("", "/"):
            return self._send(302, b"", "text/plain", {"Location": "/app/"})
        if path == "/privacy":
            s = self.app.db.get_kv("settings", {})
            return self._send(200, privacy_html(s, cfg.llm_enabled, smsmod.enabled(cfg)), "text/html; charset=utf-8", {"Cache-Control": "no-cache"})
        roots = {"/app": cfg.web_dir, "/admin": cfg.admin_dir, "/staff": cfg.admin_dir / "staff", "/widget": cfg.widget_dir}
        for prefix, root in roots.items():
            if path == prefix:
                return self._send(302, b"", "text/plain", {"Location": prefix + "/"})
            if path.startswith(prefix + "/"):
                return self.serve_file(root, path[len(prefix) + 1:], prefix)
        self.err(404, "not_found")

    # ---------------------------------------------------------------- الملفات الطبية (PDF)
    @staticmethod
    def file_dict(f, admin=False):
        kinds = dict(sch.FILE_KINDS)
        d = {"id": f["id"], "kind": f["kind"], "kindLabel": kinds.get(f["kind"], f["kind"]), "title": f["title"], "note": f["note"] or "",
             "size": f["size"], "uploadedAt": f["uploaded_at"]}
        if admin:
            d.update({"mrn": f["mrn"] or "", "phone": f["phone"], "uploadedBy": f["uploaded_by"], "updatedBy": f["updated_by"] or "", "updatedAt": f["updated_at"] or "",
                      "deletedBy": f["deleted_by"] or "", "deletedAt": f["deleted_at"] or ""})
        return d

    def pdf_path(self, fid):
        return self.app.cfg.files_dir / (fid + ".pdf")

    def send_pdf(self, f, inline, who):
        path = self.pdf_path(f["id"])
        if not path.is_file():
            return self.err(404, "not_found", "الملف غير موجود")
        title = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", " ", f["title"]).strip()[:80] or "document"
        cd = "%s; filename=\"document.pdf\"; filename*=UTF-8''%s" % ("inline" if inline else "attachment", urllib.parse.quote(title + ".pdf"))
        self.app.db.audit(who, "file_view" if inline else "file_download", "patient_file", f["id"], "")
        return self._send(200, path.read_bytes(), "application/pdf",
                          {"Content-Disposition": cd, "Cache-Control": "private, no-store", "Content-Security-Policy": "sandbox; default-src 'none'"})

    def read_pdf(self):
        raw = self._raw
        if len(raw) < 100 or not raw.startswith(b"%PDF-") or b"%%EOF" not in raw[-2048:]:
            self.err(415, "bad_type", "الملف ليس PDF صالحاً")
            return None
        return raw

    def save_pdf(self, fid, raw):
        d = self.app.cfg.files_dir
        d.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(d, 0o700)
        except OSError:
            pass
        tmp = d / (fid + ".tmp")
        tmp.write_bytes(raw)
        os.chmod(tmp, 0o600)
        os.replace(tmp, self.pdf_path(fid))

    def staff_name(self, f):
        by = re.sub(r"\s+", " ", str(self.qs.get("by", ""))).strip()
        if not (2 <= len(by) <= 40):
            f["by"] = "اكتب اسمك (اسم الموظف الذي يرفع الملف)"
        return by

    def clean_file_meta(self, f, src, need_kind=True):
        kind = str(src.get("kind", ""))
        if need_kind and kind not in sch.FILE_KIND_IDS:
            f["kind"] = "اختر نوع الملف"
        title = re.sub(r"\s+", " ", str(src.get("title", ""))).strip()
        if not (2 <= len(title) <= 80):
            f["title"] = "اسم المستند من حرفين إلى 80 حرفاً"
        note = re.sub(r"[\x00-\x08\x0b-\x1f]", "", str(src.get("note", "") or "")).strip()[:300]
        return kind, title, note

    @staticmethod
    def record_dict(r):
        return {"mrn": r["mrn"], "name": r["name"], "phone": r["phone"], "nationalId": r["national_id"] or "", "birthDate": r["birth_date"] or "",
                "gender": r["gender"] or "", "source": r["source"], "updatedAt": r["updated_at"],
                "files": r.get("files", 0), "linked": r.get("linked", 0)}

    def clean_record(self, src, f):
        """يتحقق من سجل مراجع واحد (إضافة/تعديل يدوي) بنفس قواعد الاستيراد."""
        rows, errs = impmod.parse_rows([src], norm_phone)
        if errs or not rows:
            f.update({"record": (errs[0]["error"] if errs else "بيانات غير صحيحة")})
            return None
        return rows[0]

    def notify_file(self, rec, rcd):
        kinds = dict(sch.FILE_KINDS)
        for pid in self.app.db.patients_of_mrn(rcd["mrn"]):
            self.app.db.add_notification("ملف جديد في ملفك الطبي", "%s: %s" % (kinds.get(rec["kind"], ""), rec["title"]), "pt:" + pid, "file", "#/files/" + rec["kind"])

    def admin_files_api(self, method, p):
        app = self.app
        if method == "GET" and p == "/records":
            rows = app.db.records_search(self.qs.get("q", ""))
            return self.json(200, {"records": [self.record_dict(r) for r in rows], "total": app.db.records_count()})
        if method == "POST" and p == "/records/import":
            by = re.sub(r"\s+", " ", str(self.qs.get("by", ""))).strip()
            if not (2 <= len(by) <= 40):
                return self.err(422, "validation", "اكتب اسمك (اسم الموظف الذي يستورد الملف)", {"by": "مطلوب"})
            try:
                rows, errors = impmod.parse(self._raw, norm_phone)
            except impmod.ImportError_ as e:
                return self.err(422, "bad_file", str(e))
            except Exception:  # ملف تالف
                return self.err(422, "bad_file", "تعذّرت قراءة الملف، تأكد أنه Excel (xlsx) أو CSV سليم")
            errors = [{"row": r, "error": m} for r, m in errors]
            counts = {"new": 0, "updated": 0, "same": 0}
            for r in rows:
                old = app.db.record_get(r["mrn"])
                if not old:
                    counts["new"] += 1
                elif any((r.get(k) or old.get(k)) != old.get(k) for k in ("name", "phone", "national_id", "birth_date", "gender")):
                    counts["updated"] += 1
                else:
                    counts["same"] += 1
            commit = self.qs.get("commit") == "1"
            if commit:
                if errors:
                    return self.err(409, "has_errors", "صحّح الصفوف الخاطئة أو احذفها ثم أعد الرفع", {"errors": errors[:50]})
                for r in rows:
                    app.db.record_upsert(r, "excel")
                app.db.audit("admin", "records_import", "records", "", json.dumps({"by": by, "sha256": hashlib.sha256(self._raw).hexdigest(), **counts}, ensure_ascii=False))
            return self.json(200, {"committed": commit, "rows": len(rows), **counts, "errorCount": len(errors), "errors": errors[:50]})
        if method == "POST" and p == "/records":
            body = self.body_json()
            if body is None:
                return
            f = {}
            by = self.staff_name(f)
            r = self.clean_record(body, f)
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            state = app.db.record_upsert(r, "manual")
            app.db.audit("admin", "record_" + state, "record", r["mrn"], json.dumps({"by": by}, ensure_ascii=False))
            return self.json(200, {"state": state, "record": self.record_dict(app.db.record_get(r["mrn"]))})
        m = re.fullmatch(r"/records/([A-Za-z0-9][A-Za-z0-9\-_/.]{0,29})", urllib.parse.unquote(p))
        if method == "GET" and m:
            r = app.db.record_get(m.group(1))
            if not r:
                return self.err(404, "not_found", "رقم الملف غير موجود")
            r["linked"] = len(app.db.patients_of_mrn(r["mrn"]))
            return self.json(200, {"record": self.record_dict(r),
                                   "files": [self.file_dict(x, True) for x in app.db.file_list(r["mrn"], include_deleted=self.qs.get("deleted") == "1")]})
        if method == "GET" and p == "/files":
            return self.err(400, "bad_request", "استخدم /records/<رقم الملف>")
        if method == "POST" and p == "/files":
            f = {}
            rcd = app.db.record_get(str(self.qs.get("mrn", "")))
            if not rcd:
                f["mrn"] = "رقم الملف الطبي غير موجود، أضفه أولاً أو استورده من Excel"
            by = self.staff_name(f)
            kind, title, note = self.clean_file_meta(f, self.qs)
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            raw = self.read_pdf()
            if raw is None:
                return
            rec = app.db.file_create({"phone": rcd["phone"], "mrn": rcd["mrn"], "kind": kind, "title": title, "note": note, "size": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "by": by})
            self.save_pdf(rec["id"], raw)
            app.db.audit("admin", "file_upload", "patient_file", rec["id"], json.dumps({"by": by, "mrn": rcd["mrn"], "kind": kind, "size": len(raw), "sha256": rec["sha256"]}, ensure_ascii=False))
            self.notify_file(rec, rcd)
            return self.json(201, {"file": self.file_dict(rec, True)})
        m = re.fullmatch(r"/files/(f-[0-9a-f]{32})(/replace|/update|/download)?", p)
        if not m:
            return self.err(404, "not_found")
        rec = app.db.file_get(m.group(1))
        if not rec:
            return self.err(404, "not_found", "الملف غير موجود")
        sub = m.group(2)
        if method == "GET" and sub == "/download":
            return self.send_pdf(rec, self.qs.get("dl") != "1", "admin")
        f = {}
        by = self.staff_name(f)
        if method == "POST" and sub == "/replace":
            if rec["deleted_at"]:
                return self.err(409, "deleted", "الملف محذوف")
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            raw = self.read_pdf()
            if raw is None:
                return
            old = rec["sha256"]
            self.save_pdf(rec["id"], raw)
            rec = app.db.file_update(rec["id"], by, size=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            app.db.audit("admin", "file_replace", "patient_file", rec["id"], json.dumps({"by": by, "oldSha256": old, "sha256": rec["sha256"], "size": len(raw)}, ensure_ascii=False))
            return self.json(200, {"file": self.file_dict(rec, True)})
        if method == "POST" and sub == "/update":
            body = self.body_json()
            if body is None:
                return
            kind, title, note = self.clean_file_meta(f, body)
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            rec2 = app.db.file_update(rec["id"], by, kind=kind, title=title, note=note)
            app.db.audit("admin", "file_update", "patient_file", rec["id"], json.dumps({"by": by, "kind": kind, "title": title}, ensure_ascii=False))
            return self.json(200, {"file": self.file_dict(rec2, True)})
        if method == "DELETE" and not sub:
            if f:
                return self.err(422, "validation", "تحقق من الحقول", f)
            app.db.file_soft_delete(rec["id"], by)
            app.db.audit("admin", "file_delete", "patient_file", rec["id"], json.dumps({"by": by, "mrn": rec["mrn"], "title": rec["title"]}, ensure_ascii=False))
            return self.json(200, {"ok": True})
        self.err(405, "method_not_allowed")

    def patient_files_api(self, method, p):
        app = self.app
        if not smsmod.enabled(app.cfg):
            return self.err(503, "auth_disabled", "الخدمة غير مفعّلة بعد")
        pt = self.current_patient()
        if not pt:
            return self.err(401, "unauthorized", "سجّل الدخول")
        if method != "GET":
            return self.err(405, "method_not_allowed")
        if not app.rl.allow("pfiles:" + pt["id"], 90, 60):
            return self.err(429, "rate_limited", "طلبات كثيرة")
        recs = {r["mrn"]: r for r in app.db.linked_records(pt["id"])}
        if p in ("", "/"):
            kind = self.qs.get("kind", "")
            items = []
            for x in app.db.file_list(list(recs), kind=kind or None):
                d = self.file_dict(x)
                d["mrn"], d["recordName"] = x["mrn"], recs[x["mrn"]]["name"]
                items.append(d)
            return self.json(200, {"files": items}, {"Cache-Control": "private, no-store"})
        m = re.fullmatch(r"/(f-[0-9a-f]{32})", p)
        rec = app.db.file_get(m.group(1)) if m else None
        # ملف غير موجود أو غير مرتبط بحساب هذا المراجع أو محذوف: الاستجابة واحدة (404) حتى لا يُعرف وجوده
        if not rec or rec["mrn"] not in recs or rec["deleted_at"]:
            return self.err(404, "not_found", "الملف غير موجود")
        return self.send_pdf(rec, self.qs.get("dl") != "1", "patient:" + pt["id"])

    def patient_records_api(self, method, p):
        """ربط حساب المراجع بملفه الطبي: الجوال موثّق برمز SMS + عامل ثانٍ (الهوية أو تاريخ الميلاد) يطابق ما في سجل العيادة."""
        app = self.app
        if not smsmod.enabled(app.cfg):
            return self.err(503, "auth_disabled", "الخدمة غير مفعّلة بعد")
        pt = self.current_patient()
        if not pt:
            return self.err(401, "unauthorized", "سجّل الدخول")
        if method == "GET" and p == "/mine":
            return self.json(200, {"records": [self.public_record(r) for r in app.db.linked_records(pt["id"])]}, {"Cache-Control": "private, no-store"})
        if method != "POST":
            return self.err(405, "method_not_allowed")
        body = self.body_json()
        if body is None:
            return
        if p == "/unlink":
            app.db.link_remove(pt["id"], str(body.get("mrn", "")))
            app.db.audit("patient:" + pt["id"], "record_unlink", "record", str(body.get("mrn", ""))[:30], "")
            return self.json(200, {"ok": True})
        if p != "/link":
            return self.err(404, "not_found")
        key = "rlink:" + pt["id"]
        if not app.rl.peek(key, 5, 3600):
            return self.err(429, "rate_limited", "محاولات كثيرة، حاول بعد ساعة أو تواصل مع المجمع")
        nid = re.sub(r"\D", "", str(body.get("nationalId", "") or "").translate(AR_DIGITS))
        bd = str(body.get("birthDate", "") or "")
        found = []
        for r in recsrc.get(app.cfg).candidates(app.db, pt["phone"], norm_phone):
            if (nid and r["national_id"] and nid == r["national_id"]) or (bd and r["birth_date"] and bd == r["birth_date"] and not (nid and r["national_id"])):
                found.append(r)
        if not found:
            app.rl.allow(key, 5, 3600)  # يُحسب فشلاً
            app.db.audit("patient:" + pt["id"], "record_link_fail", "patient", pt["id"], "")
            return self.err(404, "no_match", "لم نجد ملفاً مطابقاً. تأكد من البيانات أو تواصل مع المجمع")
        for r in found:
            app.db.link_add(pt["id"], r["mrn"])
            app.db.audit("patient:" + pt["id"], "record_link", "record", r["mrn"], "")
        return self.json(200, {"records": [self.public_record(r) for r in app.db.linked_records(pt["id"])]})

    @staticmethod
    def public_record(r):
        return {"mrn": r["mrn"], "name": r["name"], "phone": r["phone"], "birthDate": r["birth_date"] or "", "gender": r["gender"] or ""}

    def api_upload(self):
        """رفع صورة من لوحة الإدارة: يُقبل JPEG/PNG فقط (يُتحقق من البايتات لا من الاسم) وتُحفظ باسم عشوائي من بصمتها."""
        app = self.app
        if not app.rl.allow("upload:" + self.ip, 40, 3600):
            return self.err(429, "rate_limited", "رفع صور كثير، انتظر قليلاً")
        raw = self._raw
        if not raw:
            return self.err(400, "empty", "لم تصل صورة")
        kind = next((m for m in IMG_MAGIC if raw.startswith(m[0])), None)
        if not kind:
            return self.err(415, "bad_type", "الملف ليس صورة JPEG أو PNG")
        name = hashlib.sha256(raw).hexdigest()[:24] + "." + kind[1]
        d = app.cfg.uploads_dir
        d.mkdir(parents=True, exist_ok=True)
        f = d / name
        if not f.exists():
            tmp = d / (name + ".tmp")
            tmp.write_bytes(raw)
            os.replace(tmp, f)
        return self.json(200, {"path": "/uploads/" + name, "bytes": len(raw)})

    def serve_upload(self, name):
        m = UPLOAD_RE.fullmatch(name)
        f = self.app.cfg.uploads_dir / name if m else None
        if not f or not f.is_file():
            return self.err(404, "not_found")
        ctype = "image/png" if name.endswith(".png") else "image/jpeg"
        return self._send(200, f.read_bytes(), ctype, {"Cache-Control": "public, max-age=31536000, immutable", "Content-Security-Policy": "default-src 'none'"})

    def serve_file(self, root, rel, prefix):
        rel = urllib.parse.unquote(rel) or "index.html"
        if rel.endswith("/"):
            rel += "index.html"
        root = Path(root).resolve()
        f = (root / rel).resolve()
        if root not in f.parents and f != root:
            return self.err(404, "not_found")
        if f.is_dir():
            f = f / "index.html"
        if not f.is_file():
            return self.err(404, "not_found")
        st = f.stat()
        etag = '"%x-%x"' % (st.st_mtime_ns, st.st_size)
        if self.headers.get("If-None-Match") == etag:
            return self._send(304, b"", "text/plain", {"ETag": etag})
        ctype = MIME.get(f.suffix.lower()) or mimetypes.guess_type(str(f))[0] or "application/octet-stream"
        headers = {"ETag": etag, "Cache-Control": "no-cache"}
        if prefix in ("/admin", "/staff"):
            headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'"
            headers["X-Frame-Options"] = "DENY"
        if prefix == "/widget":
            headers["Access-Control-Allow-Origin"] = "*"
            headers["Cache-Control"] = "public, max-age=300"
        return self._send(200, f.read_bytes(), ctype, headers)


class DSServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64

    def __init__(self, addr, app):
        super().__init__(addr, Handler)
        self.app = app


def make_server(cfg=None, host=None, port=None):
    app = App(cfg)
    srv = DSServer((host or app.cfg.host, app.cfg.port if port is None else port), app)
    return srv


def main():
    ap = argparse.ArgumentParser(description="خادم تطبيق دار السلام")
    ap.add_argument("--host")
    ap.add_argument("--port", type=int)
    a = ap.parse_args()
    srv = make_server(host=a.host, port=a.port)
    h, p = srv.server_address[:2]
    print("خادم دار السلام يعمل على http://%s:%s  (التطبيق: /app/  الإدارة: /admin/)" % (h, p))
    if not srv.app.admin_record():
        print("تنبيه: لم تُضبط كلمة مرور الإدارة. نفّذ: python3 server/manage.py init")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nتم الإيقاف")


if __name__ == "__main__":
    main()
