/* طلب الحجز (بصياغة صادقة) + حسابي + زياراتي (ملخص الزيارة) + الإشعارات + سياسة الخصوصية */
(function (root) {
  'use strict';
  var DS = root.DS, D = DS.data, esc = DS.esc, ic = DS.icon, U = DS.ui;

  /* ---------- أدوات ---------- */
  var AR = '٠١٢٣٤٥٦٧٨٩', FA = '۰۱۲۳۴۵۶۷۸۹';
  function asciiDigits(s) {
    return String(s == null ? '' : s).replace(/[٠-٩۰-۹]/g, function (c) { var i = AR.indexOf(c); return String(i < 0 ? FA.indexOf(c) : i); });
  }
  /* نفس منطق الخادم (norm_phone) */
  DS.normPhone = function (v) {
    var s = asciiDigits(v).replace(/[\s\-().]/g, '');
    var intl = s.charAt(0) === '+' || s.slice(0, 2) === '00';
    var d = s.replace(/\D/g, '');
    if (d.slice(0, 2) === '00') d = d.slice(2);
    if (d.slice(0, 3) === '966') { var rest = d.slice(3); if (rest.charAt(0) === '0') rest = rest.slice(1); return /^5\d{8}$/.test(rest) ? '966' + rest : null; }
    if (/^05\d{8}$/.test(d)) return '966' + d.slice(1);
    if (/^5\d{8}$/.test(d)) return '966' + d;
    if (intl && d.length >= 8 && d.length <= 15) return '+' + d;
    return null;
  };
  DS.platform = function () { try { var C = root.Capacitor; return C && C.getPlatform ? C.getPlatform() : 'web'; } catch (e) { return 'web'; } };
  function isEmergency(x) { return x.id === 'emergency' || x.type === 'emergency'; }
  function periodsList() {
    var p = D.bookingMode().periods;
    return p && p.length ? p : [{ id: 'morning', label: 'صباحاً' }, { id: 'evening', label: 'مساءً' }, { id: 'any', label: 'أي وقت' }];
  }
  function periodLabel(id) { var m = periodsList().filter(function (x) { return x.id === id; })[0]; return m ? m.label : ''; }
  function profile() { return DS.store.get('profile', { name: '', phone: '' }) || { name: '', phone: '' }; }

  /* ================= المواعيد: الطبيب الذي أدخلت الإدارة ساعات عمله يُحجز عنده بموعد محدد ================= */
  DS.sched = {
    has: function (id) { var m = D.ds && D.ds.meta; return !!(m && m.scheduled && m.scheduled.indexOf(id) >= 0); },
    any: function () { var m = D.ds && D.ds.meta; return !!(m && m.scheduled && m.scheduled.length); },
    /* ساعات الطبيب الأسبوعية المعتادة: [[الفرع، اليوم 0=الأحد، من بالدقائق، إلى بالدقائق]] (من الخادم؛ فارغة في نسخة التجربة) */
    hours: function (id) { var m = D.ds && D.ds.meta; return (m && m.hours && m.hours[id]) || []; },
    branchesOf: function (id) { var seen = {}, out = []; this.hours(id).forEach(function (r) { if (!seen[r[0]]) { seen[r[0]] = 1; out.push(r[0]); } }); return out; }
  };
  var lastPol = null;                       // سياسة المواعيد من آخر استجابة «المواعيد المتاحة» (للنصوص فقط؛ الخادم هو من يفرض القواعد)
  function timeAr(hhmm) { var p = String(hhmm || '').split(':'), h = +p[0] || 0; return (h % 12 || 12) + ':' + (p[1] || '00') + ' ' + (h < 12 ? 'ص' : 'م'); }
  function dayWords(iso) {
    var d = new Date(iso + 'T12:00:00'), o = { w: '', d: String(+iso.slice(8, 10)), m: '' };
    try { o.w = d.toLocaleDateString('ar-SA-u-nu-latn-ca-gregory', { weekday: 'long' }); o.m = d.toLocaleDateString('ar-SA-u-nu-latn-ca-gregory', { month: 'long' }); } catch (e) { /* نكتفي برقم اليوم */ }
    if (iso === DS.riyadhToday(0)) o.w = 'اليوم'; else if (iso === DS.riyadhToday(1)) o.w = 'غداً';
    return o;
  }
  function hoursAr(n) { return n === 1 ? 'ساعة' : n === 2 ? 'ساعتين' : n >= 3 && n <= 10 ? n + ' ساعات' : n + ' ساعة'; }
  function apptLine(b) { return b.slot && b.date ? DS.fmtDate(b.date) + ' · ' + (b.slot.label || timeAr(b.slot.start)) : (b.appointmentText || ''); }

  /* فقرة خصوصية حسابات كلمة المرور (الملف الصحي): نسخة حرفية من PRIVACY_PASSWORD_LI في server/app.py؛ يفحص الاختبار تطابقهما */
  var PRIVACY_PW = 'عند إنشاء حساب: الاسم ورقم الجوال والجنس وتاريخ الميلاد وكلمة المرور (تُحفظ مشفّرة ولا يستطيع أحد قراءتها)، ورقم الهوية/الإقامة والجنسية والبريد الإلكتروني والمدينة إن أدخلتها (اختياري). وبياناتك الصحية التي تدخلها بموافقتك الصريحة (فصيلة الدم، الحساسية، الأمراض المزمنة، الأدوية الحالية، العمليات السابقة، الحمل أو الرضاعة) وجهة اتصال الطوارئ وبيانات التأمين (اختيارية): تُحفظ على خادم المجمع لتجهيز زيارتك وسلامتك الطبية، ولا يطّلع عليها إلا موظفو المجمع المخوَّلون، ولا تُرسَل إلى المساعد «قمر» ولا إلى مزوّد الذكاء الاصطناعي ولا تُشارك مع أي جهة أخرى. تستطيع تعديلها أو حذف حسابك من «حسابي»، وقد تبقى نسخة منها في النسخ الاحتياطية للخادم إلى أن تُحذف.';
  DS.privacyPw = PRIVACY_PW;

  /* مسودة الحجز: تُحفظ عند الضغط على «تأكيد الحجز» قبل تسجيل الدخول، وتُستعاد بعد العودة فلا تضيع الخدمة ولا الطبيب ولا الموعد.
     تنتهي صلاحيتها بعد ساعتين، وتُمسح فور إتمام الحجز. لا تُحفظ فيها بيانات الاسم والجوال (تأتي من الحساب). */
  var DRAFT_TTL = 2 * 3600 * 1000;
  DS.bkDraft = {
    get: function () {
      var d = DS.store.get('bkDraft', null);
      if (!d || typeof d !== 'object' || !d.t || Date.now() - d.t > DRAFT_TTL) { if (d) DS.store.del('bkDraft'); return null; }
      return d;
    },
    set: function (d) { d.t = Date.now(); DS.store.set('bkDraft', d); },
    clear: function () { DS.store.del('bkDraft'); },
    /* ملخص الحجز المحفوظ لشاشة الدخول، مثل: «د. فلان · الاثنين، 23 نوفمبر 2026 · 9:30 ص» */
    line: function () {
      var d = DS.bkDraft.get(); if (!d) return '';
      var dr = d.dr && D.doctor(d.dr), kind = d.sel && d.sel.slice(0, 2), ent = d.sel && (kind === 'sp' ? D.specialty(d.sel.slice(3)) : D.service(d.sel.slice(3)));
      var parts = [dr ? D.docTitle(dr) : (ent ? ent.name : '')];
      if (d.slot && d.slot.day) parts.push(DS.fmtDate(d.slot.day), timeAr(d.slot.start));
      return parts.filter(Boolean).join(' · ');
    }
  };
  var syncHook = null;                      // يحدّث حقول الهوية في صفحة الحجز المفتوحة عند وصول إعدادات الخادم متأخرة
  D.onChange(function () { if (syncHook) syncHook(); });


  var STATUS = {
    'new': { t: 'تم الاستلام', c: 's-new', n: 'استلمنا الطلب وسيراجعه فريق المجمع. هذا ليس موعداً مؤكداً بعد.' },
    contacted: { t: 'تم التواصل معك', c: 's-contacted', n: 'يُعدّ الموعد مؤكداً فقط عندما تصبح حالته «مؤكد» هنا أو يخبرك المجمع بذلك.' },
    confirmed: { t: 'مؤكد', c: 's-confirmed', n: '' },
    cancelled: { t: 'ملغي', c: 's-cancelled', n: '' }
  };
  /* حالة العرض: الموعد المؤكد تلقائياً والموعد المحجوز مؤقتاً بانتظار الدفع لهما صياغتهما، وما عداهما كما كان */
  function statusOf(b) {
    if (b.pay && b.pay.status === 'pending' && (b.status === 'new' || b.status === 'contacted'))
      return { t: 'بانتظار الدفع', c: 's-new', n: 'الموعد محجوز لك مؤقتاً ويتأكد بعد إتمام الدفع، وإن انتهت المهلة يُفرَج عنه لغيرك.' };
    if (b.slot && b.status === 'confirmed') return { t: 'موعد مؤكد', c: 's-confirmed', n: '' };
    return STATUS[b.status] || STATUS['new'];
  }

  /* مرحلة الزيارة اليوم (يسجّلها الاستقبال ثم الطبيب). لا نعرض مرحلة «جارية» من يوم سابق حتى لا تُضلّل */
  function stageText(v) {
    if (!v) return '';
    var live = v.status === 'waiting' || v.status === 'ready' || v.status === 'with_doctor';
    if (live && v.day && v.day !== DS.riyadhToday()) return '';
    if (v.status === 'waiting' || v.status === 'ready') return 'سُجّل وصولك · رقمك ' + v.queueNo + (v.doctorName ? ' عند ' + v.doctorName : '');
    if (v.status === 'with_doctor') return 'أنت الآن عند ' + (v.doctorName || 'الطبيب');
    if (v.status === 'done') return 'انتهت زيارتك';
    if (v.status === 'left') return 'شكراً لزيارتك';
    return '';
  }

  /* ================= بطاقة «طلباتي» في الرئيسية: آخر حالة وصلتنا من الخادم، بلا ادّعاء أكثر مما أكّده المجمع ================= */
  var bkSeen = 0;
  /* جلب حالة الطلبات من الخادم وحفظها محلياً */
  function pullBookings() {
    return DS.api.get('/bookings?deviceId=' + encodeURIComponent(DS.deviceId()), { timeout: 8000 }).then(function (r) {
      var l = (r.data && r.data.bookings) || [];
      if (l.length) DS.store.set('myBookings', l); else DS.store.del('myBookings');
      return l;
    });
  }
  /* أثناء زيارة جارية (ينتظر / عند الطبيب) نحدّث الشاشة المفتوحة كل 20 ثانية وعند العودة للتطبيق، فيرى المراجع «حان دورك»
     وهو جالس في الانتظار دون أن يُعيد فتح الصفحة. لا يعمل خارج زيارة جارية اليوم، ويتوقف بمجرد مغادرة الصفحة. */
  var watcher = null, watchT = 0;
  function liveNow() {
    return DS.bk.list().some(function (b) { var v = b.visit; return !!v && !!stageText(v) && v.status !== 'done' && v.status !== 'left'; });
  }
  function tick() {
    clearTimeout(watchT);
    if (!watcher || !watcher.el.isConnected) { watcher = null; return; }
    if (!liveNow()) return;
    watchT = setTimeout(function () {
      if (!watcher || !watcher.el.isConnected) { watcher = null; return; }
      if (document.hidden) { tick(); return; }
      pullBookings().then(function (l) { if (watcher && watcher.el.isConnected) watcher.draw(l); }).catch(function () { /* نُبقي ما على الشاشة */ }).then(tick);
    }, DS.cfg.liveMs || 20000);   // liveMs للاختبارات فقط
  }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden || !watcher || !watcher.el.isConnected || !liveNow()) return;
    pullBookings().then(function (l) { if (watcher && watcher.el.isConnected) { watcher.draw(l); tick(); } }).catch(function () { /* نُبقي ما على الشاشة */ });
  });
  function moreText(n) { return n === 1 ? 'وطلب آخر' : n === 2 ? 'وطلبان آخران' : n <= 10 ? 'و' + n + ' طلبات أخرى' : 'و' + n + ' طلباً آخر'; }
  DS.bk = {
    list: function () { var l = DS.store.get('myBookings', []); return Array.isArray(l) ? l : []; },
    card: function (stale) {
      var l = DS.bk.list(); if (!l.length) return '';
      var b = l[0], s = statusOf(b);
      var sp = b.specialtyId && D.specialty(b.specialtyId), sv = b.serviceId && D.service(b.serviceId), dr = b.doctorId && D.doctor(b.doctorId);
      var what = sp || sv ? (sp || sv).name : (dr ? D.docTitle(dr) : (b.slot ? 'موعد' : 'طلب حجز'));
      var ln = stageText(b.visit) ? '<span style="color:var(--pri-d);font-weight:800">' + esc(stageText(b.visit)) + '</span>' :
        (b.status === 'confirmed' && (b.slot || b.appointmentText) ? '<span style="color:var(--ok);font-weight:700">موعدك: ' + esc(apptLine(b)) + '</span>' : esc(what));
      return '<a class="bkc" href="#/profile"><span class="ico-box">' + ic('calendar') + '</span><div class="grow" style="min-width:0"><div class="bk-l"><b>طلباتي</b> <span class="status ' + s.c + '">' + esc(s.t) + '</span></div>' +
        '<div class="bk-s">' + ln + (l.length > 1 ? ' · ' + esc(moreText(l.length - 1)) : '') + (stale ? ' · تعذر تحديث الحالة الآن؛ هذه آخر حالة وصلتنا.' : '') + '</div></div>' + ic('chevron-left', 'chev') + '</a>';
    },
    refresh: function () {
      if (DS.cfg.demo || !DS.$('#home-bk') || !DS.bk.list().length || Date.now() - bkSeen < 20000) return;
      bkSeen = Date.now();
      pullBookings().then(function () {
        var box = DS.$('#home-bk'); if (!box) return;
        box.innerHTML = DS.bk.card();
        watcher = { el: box, draw: function () { box.innerHTML = DS.bk.card(); } }; tick();
      }).catch(function () { var box = DS.$('#home-bk'); if (box) box.innerHTML = DS.bk.card(true); });
    }
  };

  /* ================= صفحة طلب الحجز ================= */
  function summaryRows(b) {
    var rows = [], sp = b.specialtyId && D.specialty(b.specialtyId), sv = b.serviceId && D.service(b.serviceId), dr = b.doctorId && D.doctor(b.doctorId), br = b.branchId && D.branch(b.branchId);
    if (sp || sv) rows.push(['stethoscope', (sp || sv).name]);
    if (dr) rows.push(['user', D.docTitle(dr)]);
    rows.push(['map-pin', br ? br.name : 'أي فرع']);
    if (b.slot && b.date) rows.push(['calendar', 'الموعد: ' + apptLine(b)]);
    else if (b.date || b.period) rows.push(['calendar', (b.date ? 'التاريخ المفضل: ' + DS.fmtDate(b.date) : 'بدون تاريخ محدد') + (b.period ? ' · ' + periodLabel(b.period) : '')]);
    return '<div class="kv">' + rows.map(function (r) { return '<div class="r">' + ic(r[0], 'sm') + '<div>' + esc(r[1]) + '</div></div>'; }).join('') + '</div>';
  }

  function fallbackButtons(branchId) {
    var ph = D.mainPhone(), br = branchId && D.branch(branchId), wa = br && br.whatsapp ? br.whatsapp : (D.settings().whatsapp || '');
    return '<div class="grid2" style="margin-top:10px">' + (ph ? U.call(ph, 'اتصال بالمجمع', 'pri') : '') + (wa ? U.wa(DS.kbmod.e164(wa), 'واتساب') : '') + '</div>';
  }

  /* مربع الدفع المقدّم (يظهر فقط إن فعّلته الإدارة وكان مزوّد الدفع مربوطاً؛ حالياً المزوّد «تجريبي» لا يحصّل أي مبلغ) */
  function payBox(b) {
    var p = b.pay || {};
    return '<div class="card" style="margin-top:12px"><div class="row"><span class="ico-box">' + ic('clock') + '</span><div class="grow"><b>مطلوب دفع مقدّم: ' + esc(String(p.amount || 0)) + ' ر.س</b>' +
      '<p class="sm muted">الموعد محجوز لك' + (p.holdUntil ? ' حتى ' + esc(DS.fmtDateTime(p.holdUntil)) : ' مؤقتاً') + '، وبعدها يُفرَج عنه لغيرك.</p></div></div>' +
      (p.test ? '<div class="alert warn" style="margin-top:10px">' + ic('info', 'sm') + '<div><b>دفع تجريبي.</b> نسخة اختبار: لا يُحصَّل أي مبلغ ولا توجد بوابة دفع حقيقية مربوطة بعد.</div></div>' : '') +
      '<button type="button" class="btn pri blk" style="margin-top:10px" data-act="bk-pay" data-id="' + esc(b.id) + '">' + (p.test ? 'ادفع الآن (تجريبي)' : 'ادفع الآن') + '</button></div>';
  }
  /* رسالة التأكيد بعد حجز موعد: واضحة، وتقول ما الخطوة التالية بلا ادّعاء أكثر مما يفعله النظام */
  function apptDoneHtml(b, pol) {
    var held = !!(b.pay && b.pay.status === 'pending' && b.status !== 'cancelled'), cb = pol && pol.cancelBeforeH;
    return '<div class="card" style="text-align:center"><div class="okmark"' + (held ? ' style="background:var(--warn-l);color:var(--warn)"' : '') + '>' + ic(held ? 'clock' : 'check') + '</div>' +
      '<h2 style="font-size:1.25rem;font-weight:800">' + (held ? 'تم حجز الموعد مؤقتاً' : 'تم تأكيد موعدك') + '</h2>' +
      '<p class="muted" style="margin-top:4px">رقم الحجز</p><div class="bk-id ltr" style="font-size:1.5rem;font-weight:800;letter-spacing:1px;color:var(--pri-d);text-align:center">' + esc(b.id) + '</div></div>' +
      '<div class="card" style="margin-top:12px">' + summaryRows(b) + '</div>' +
      (held ? payBox(b) :
        '<div class="alert ok" style="margin-top:12px">' + ic('check', 'sm') + '<div><b>موعدك مؤكد.</b> ' +
        (pol && pol.checkin ? 'عند وصولك سجّل وصولك في الاستقبال ثم توجّه إلى عيادة الطبيب.'
          : 'يظهر موعدك لدى الطبيب تلقائياً، فتوجّه إلى عيادته عند حلول موعدك. لا حاجة للمرور على الاستقبال إلا إذا طلب منك المجمع ذلك.') + '</div></div>' +
        (cb ? '<p class="xs muted" style="margin-top:8px">يمكنك إلغاء الموعد من «حسابي» حتى ' + esc(hoursAr(cb)) + ' قبل وقته.</p>' : '')) +
      '<div class="grid2" style="margin-top:12px"><a class="btn pri" href="#/profile">موعدي</a><a class="btn out" href="#/">الرئيسية</a></div>' + fallbackButtons(b.branchId);
  }

  DS.route('/book', function (p, q) {
    /* لا بوابة دخول عند فتح الصفحة: يتصفح المراجع ويختار الخدمة والطبيب والموعد بحرية؛ ويُفحص الدخول عند «تأكيد الحجز» فقط */
    var bm = D.bookingMode(), pf = profile(), today = DS.riyadhToday(0), maxd = DS.riyadhToday(120);
    var ap = DS.auth.enabled() && DS.auth.patient();
    if (ap) pf = { name: ap.name, phone: DS.auth.local(ap.phone) };
    var st = { sel: '', dr: '', br: '', date: '', period: 'any', name: pf.name || '', phone: pf.phone || '', note: '', consent: false, busy: false,
      mode: 'slot', slot: null, day: '', sl: null, slState: 'idle', slNote: '', seq: 0, resumed: false };
    if (q.sp && D.specialty(q.sp)) st.sel = 'sp:' + q.sp;
    else if (q.sv && D.service(q.sv) && !isEmergency(D.service(q.sv))) st.sel = 'sv:' + q.sv;
    if (q.dr && D.doctor(q.dr)) {
      var d0 = D.doctor(q.dr);
      if (!st.sel) st.sel = (d0.specialtyIds || [])[0] ? 'sp:' + d0.specialtyIds[0] : ((d0.serviceIds || [])[0] ? 'sv:' + d0.serviceIds[0] : '');
      st.dr = q.dr;
    }
    if (q.br && D.branch(q.br)) st.br = q.br;
    /* موعد رتّبه قمر: اليوم والوقت من الرابط. لا يُطبَّق إلا بعد جلب المواعيد من الخادم وإن كان ما زال متاحاً، والمراجع هو من يؤكد الحجز */
    st.want = q.dr && D.doctor(q.dr) && /^\d{4}-\d{2}-\d{2}$/.test(q.day || '') && /^\d{2}:\d{2}$/.test(q.t || '') ? { day: q.day, start: q.t, br: st.br } : null;
    /* العودة بعد تسجيل الدخول: نستعيد اختياره كما تركه (الخدمة والطبيب والفرع والموعد والملاحظة) */
    var dft = q.resume === '1' ? DS.bkDraft.get() : null;
    if (dft) {
      var dk = String(dft.sel || '');
      st.sel = dk && (dk.slice(0, 2) === 'sp' ? D.specialty(dk.slice(3)) : D.service(dk.slice(3))) ? dk : st.sel;
      st.dr = dft.dr && D.doctor(dft.dr) ? dft.dr : st.dr;
      st.br = dft.br && D.branch(dft.br) ? dft.br : st.br;
      st.mode = dft.mode === 'request' ? 'request' : 'slot';
      st.slot = dft.slot && dft.slot.day && dft.slot.start && dft.slot.branchId ? { day: dft.slot.day, start: dft.slot.start, branchId: dft.slot.branchId } : null;
      st.day = st.slot ? st.slot.day : '';
      st.date = dft.date && dft.date >= today ? dft.date : ''; st.period = dft.period || 'any'; st.note = String(dft.note || '').slice(0, 300); st.consent = !!dft.consent;
      st.resumed = true;
    }

    /* فروع الطبيب: من جدول ساعاته إن وُجد، وإلا من فروعه المسجّلة، وإلا غير معروفة (null) فيظهر في كل فرع */
    function docBranches(d) {
      var sb = d ? DS.sched.branchesOf(d.id) : [];
      if (sb.length) return sb;
      return d && d.branchIds && d.branchIds.length ? d.branchIds : null;
    }
    function doctorsFor() {
      var l = D.ds.doctors;
      if (st.sel) { var id = st.sel.slice(3); l = st.sel.slice(0, 2) === 'sp' ? D.doctorsOfSpecialty(id) : D.doctorsOfService(id); }
      if (!st.br) return l;
      return l.filter(function (d) { var b = docBranches(d); return !b || b.indexOf(st.br) >= 0; });        // اختيار الفرع يُظهر أطباءه فقط
    }
    function branchesFor() {
      var d = st.dr && D.doctor(st.dr), ids = d ? docBranches(d) : null;
      return D.ds.branches.filter(function (b) { return !ids || ids.indexOf(b.id) >= 0; });
    }
    function optSel() {
      var h = '<option value="">اختر التخصص أو الخدمة…</option><optgroup label="التخصصات">' + D.ds.specialties.map(function (s) {
        return '<option value="sp:' + esc(s.id) + '"' + (st.sel === 'sp:' + s.id ? ' selected' : '') + '>' + esc(s.name) + '</option>';
      }).join('') + '</optgroup>';
      var svs = D.ds.services.filter(function (x) { return !isEmergency(x); });
      if (svs.length) h += '<optgroup label="الخدمات">' + svs.map(function (s) {
        return '<option value="sv:' + esc(s.id) + '"' + (st.sel === 'sv:' + s.id ? ' selected' : '') + '>' + esc(s.name) + '</option>';
      }).join('') + '</optgroup>';
      return h;
    }
    function optDr() {
      var l = doctorsFor();
      if (st.dr && !l.some(function (d) { return d.id === st.dr; })) st.dr = '';
      return '<option value="">أي طبيب متاح</option>' + l.map(function (d) {
        return '<option value="' + esc(d.id) + '"' + (st.dr === d.id ? ' selected' : '') + '>' + esc(D.docTitle(d)) + (DS.sched.has(d.id) ? ' — حجز بموعد' : '') + '</option>';
      }).join('');
    }
    function optBr() {
      var l = branchesFor();
      if (st.br && !l.some(function (b) { return b.id === st.br; })) st.br = '';
      return '<option value="">أي فرع</option>' + l.map(function (b) { return '<option value="' + esc(b.id) + '"' + (st.br === b.id ? ' selected' : '') + '>' + esc(b.name) + '</option>'; }).join('');
    }
    function fld(key, label, inner, hint) {
      return '<div class="fld"><label for="f-' + key + '">' + label + '</label>' + inner + (hint ? '<div class="hint">' + hint + '</div>' : '') + '<div class="err" data-err="' + key + '" hidden></div></div>';
    }

    var portal = '';
    if (bm.url && /^https:\/\//.test(bm.url)) {
      portal = '<div class="card" style="margin-bottom:12px"><div class="row"><span class="ico-box">' + ic('external') + '</span><div class="grow"><b>' + esc(bm.label) + '</b><p class="sm muted">لديك حساب في بوابة المريض؟ احجز مباشرة من موقع المجمع.</p></div></div>' +
        '<a class="btn pri blk" style="margin-top:10px" href="' + esc(bm.url) + '" data-act="ext" data-url="' + esc(bm.url) + '">' + ic('external', 'sm') + 'فتح بوابة المريض</a></div>' +
        '<p class="sm muted" style="text-align:center;margin:4px 0 12px">أو اترك طلب حجز ليتواصل معك المجمع:</p>';
    }

    var html = '<div id="bkroot">' +
      (DS.cfg.demo ? '<div class="alert warn" style="margin-bottom:12px">' + ic('info', 'sm') + '<div><b>نسخة تجريبية.</b> يمكنك تجربة الشاشات، لكن لن يُرسَل أي طلب إلى أي جهة.</div></div>' : '') +
      (st.resumed ? '<div class="alert ok" id="bk-resume" style="margin-bottom:12px">' + ic('check', 'sm') + '<div><b>' + (ap ? 'تم تسجيل دخولك.' : 'استعدنا اختيارك.') + '</b> حجزك محفوظ كما اخترته. راجعه ثم اضغط «تأكيد الحجز».</div></div>' : '') +
      '<div class="alert info" style="margin-bottom:12px">' + ic('info', 'sm') + '<div id="bk-lead"></div></div>' +
      '<div class="card row" style="margin-bottom:12px"><span class="ico-box">' + ic('chat') + '</span><div class="grow sm">لست متأكداً من التخصص؟ اوصف حاجتك لقمر وسيقترح عليك العيادة المناسبة.</div><button type="button" class="btn ghost sm" data-act="qamar-open">اسأل قمر</button></div>' + portal +
      '<form id="bk-form" class="form card" novalidate autocomplete="on">' +
      fld('sel', 'التخصص أو الخدمة <span class="muted">*</span>', '<select class="in" id="f-sel">' + optSel() + '</select>') +
      fld('br', 'الفرع <span class="muted">(اختياري)</span>', '<select class="in" id="f-br">' + optBr() + '</select>') +
      fld('dr', 'الطبيب <span class="muted">(اختياري)</span>', '<select class="in" id="f-dr">' + optDr() + '</select>', '<span id="dr-hint"></span>') +
      '<div id="dr-info"></div>' +
      '<div id="bk-when"></div>' +
      '<div id="bk-id">' + fld('name', 'الاسم <span class="muted">*</span>', '<input class="in" id="f-name" autocomplete="name" maxlength="60" value="' + esc(st.name) + '">') +
      fld('phone', 'رقم الجوال <span class="muted">*</span>', '<input class="in ltr" id="f-phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="05xxxxxxxx" value="' + esc(st.phone) + '">', DS.auth.pw() ? 'الحجز باسم صاحب الحساب وجواله. لحجز شخص آخر اكتب اسمه في الملاحظة.' : 'للتواصل معك بخصوص الطلب فقط.') + '</div>' +
      '<div class="alert info" id="bk-login-note" hidden style="margin-bottom:12px">' + ic('shield', 'sm') + '<div>' + (DS.auth.pw() ? 'عند «تأكيد الحجز» تسجّل دخولك بجوالك وكلمة المرور، أو تنشئ حساباً وتعبّئ بياناتك الطبية لمرة واحدة. اختيارك محفوظ ولن يضيع.' : 'نتحقق من رقم جوالك برمز SMS عند «تأكيد الحجز» (دخول سريع، وننشئ لك حساباً إن لم يكن لديك). اختيارك محفوظ ولن يضيع.') + '</div></div>' +
      fld('note', 'ملاحظة <span class="muted">(اختياري)</span>', '<textarea class="in" id="f-note" maxlength="300" rows="3" placeholder="مثال: أول زيارة، أو أفضّل طبيبة">' + esc(st.note) + '</textarea>', 'لا تكتب تفاصيل مرضية أو معلومات حساسة هنا.') +
      '<div class="fld"><label class="check" for="f-consent"><input type="checkbox" id="f-consent"' + (st.consent ? ' checked' : '') + '><span>أوافق على إرسال اسمي ورقم جوالي إلى ' + esc(D.settings().name || 'المجمع') + ' للتواصل معي بخصوص هذا الحجز، وقد اطّلعت على <a href="#/privacy">سياسة الخصوصية</a>.</span></label><div class="err" data-err="consent" hidden></div></div>' +
      '<div id="bk-fail"></div>' +
      '<button class="btn pri blk" id="f-submit" type="submit">' + ic('send', 'sm') + '<span id="f-sl">إرسال طلب الحجز</span></button></form></div>';

    setTimeout(function () {
      var form = DS.$('#bk-form'); if (!form) return;
      var sel = DS.$('#f-sel'), dr = DS.$('#f-dr'), br = DS.$('#f-br');
      function needLogin() { return DS.auth.enabled() && !DS.auth.token(); }
      function schedDoc() { return !!st.dr && DS.sched.has(st.dr); }
      function slotMode() { return schedDoc() && st.mode === 'slot'; }
      function clearErr() { DS.$$('[data-err]', form).forEach(function (e) { e.hidden = true; e.textContent = ''; }); DS.$$('.in.bad', form).forEach(function (e) { e.classList.remove('bad'); }); }
      function showErr(fields) {
        var first = null, map = { specialtyId: 'sel', serviceId: 'sel', doctorId: 'dr', branchId: 'br' };
        Object.keys(fields).forEach(function (k) {
          var key = map[k] || k, e = DS.$('[data-err="' + key + '"]', form), inp = DS.$('#f-' + key, form);
          if (e) { e.textContent = fields[k]; e.hidden = false; if (!first) first = e; }
          if (inp) inp.classList.add('bad');
        });
        if (first && first.scrollIntoView) first.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
      /* الهوية: مع تفعيل تسجيل المرضى لا نطلب الاسم والجوال قبل الدخول (يأتيان من الحساب)؛ وبدونه نطلبهما كما كان */
      function syncIdentity() {
        if (!DS.$('#bk-form')) { syncHook = null; return; }
        var nl = needLogin(), a = DS.auth.enabled() && DS.auth.patient(), fn = DS.$('#f-name'), fp = DS.$('#f-phone');
        DS.$('#bk-id').hidden = nl; DS.$('#bk-login-note').hidden = !nl;
        if (a) { fn.value = a.name; fp.value = DS.auth.local(a.phone); fn.readOnly = true; fp.readOnly = true; }
        else { fn.readOnly = false; fp.readOnly = false; }
      }
      /* وصول بيانات الخادم بعد رسم الصفحة (تشغيل أول مرة أو تغيير الإدارة لساعات الأطباء): نحدّث الهوية وتسميات الأطباء،
         وإن صار الطبيب المختار يُحجز عنده بموعد (أو لم يعد) نبدّل واجهة الموعد دون مسّ ما كتبه المراجع */
      function onData() {
        if (!DS.$('#bk-form')) { syncHook = null; return; }
        syncIdentity();
        dr.innerHTML = optDr(); br.innerHTML = optBr(); paintInfo();
        if (st.pSched !== schedDoc()) { st.slState = 'idle'; st.mode = 'slot'; loadSlots(); }
      }
      syncHook = onData; syncIdentity();

      function paintLead() {
        var el = DS.$('#bk-lead'); if (!el) return;
        var pre = lastPol && lastPol.prepay && lastPol.prepay.enabled;
        el.innerHTML = slotMode()
          ? '<b>احجز موعدك بنفسك.</b> اختر يوماً ووقتاً من المواعيد المتاحة للطبيب ' + (pre ? 'ويُحجز لك مؤقتاً حتى تُتمّ الدفع' : 'ويتأكد حجزك فور الضغط على «تأكيد الحجز»') + '. للحالات العاجلة اتصل بالمجمع مباشرة.'
          : '<b>هذا طلب حجز وليس موعداً مؤكداً.</b> يراجعه فريق المجمع ويتواصل معك لتحديد الموعد وتأكيده. للحالات العاجلة اتصل بالمجمع مباشرة.';
      }
      function freeDays() { return ((st.sl && st.sl.days) || []).filter(function (d) { return d.slots.length; }); }
      function brName(id) { var b = D.branch(id); return b ? (b.shortName || b.name) : ''; }
      /* تنبيه الدوام: فرع الطبيب وأيام وساعات عمله (من جدوله الفعلي)، أو بيان ما يظهر في القائمة بعد اختيار الفرع */
      var DAYN = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      function minAr(m) { return m >= 1440 ? 'منتصف الليل' : timeAr(('0' + Math.floor(m / 60)).slice(-2) + ':' + ('0' + (m % 60)).slice(-2)); }
      function spanAr(w) {
        if (w.some(function (x) { return x[0] === 0 && x[1] >= 1440; })) return 'على مدار 24 ساعة';
        return w.map(function (x) { return minAr(x[0]) + ' – ' + minAr(x[1]); }).join(' و');
      }
      function hoursLines(id) {
        var by = {}, order = [];
        DS.sched.hours(id).forEach(function (r) {
          if (!by[r[0]]) { by[r[0]] = [[], [], [], [], [], [], []]; order.push(r[0]); }
          if (r[1] >= 0 && r[1] <= 6) by[r[0]][r[1]].push([r[2], r[3]]);
        });
        return order.map(function (b) {
          var wd = by[b], key = wd.map(function (w) { return w.length ? JSON.stringify(w) : ''; }), runs = [], i = 0;
          while (i < 7) {
            if (!key[i]) { i++; continue; }
            var j = i; while (j + 1 < 7 && key[j + 1] === key[i]) j++;
            runs.push({ a: i, b: j, t: spanAr(wd[i]) }); i = j + 1;
          }
          var parts = runs.map(function (r) {
            var days = runs.length === 1 && r.a === 0 && r.b === 6 ? 'كل الأيام' : r.a === r.b ? DAYN[r.a] : r.b === r.a + 1 ? DAYN[r.a] + ' و' + DAYN[r.b] : DAYN[r.a] + ' – ' + DAYN[r.b];
            return days + ': ' + r.t;
          });
          return '<b>' + esc(brName(b)) + '</b> — ' + esc(parts.join(' · '));
        });
      }
      function paintInfo() {
        var el = DS.$('#dr-info'); if (!el) return;
        var h = '', d = st.dr && D.doctor(st.dr);
        if (d) {
          var lines = DS.sched.has(d.id) ? hoursLines(d.id) : [];
          if (lines.length) h = '<b>' + esc(D.docTitle(d)) + '</b> يداوم في:<div class="dr-hrs">' + lines.join('<br>') + '</div>';
          else {
            var names = (d.branchIds || []).map(brName).filter(Boolean);
            if (names.length) h = '<b>' + esc(D.docTitle(d)) + '</b> في ' + esc(names.join(' و')) + '. يؤكّد لك المجمع الدوام والموعد.';
          }
        } else if (st.br) {
          var n = doctorsFor().length;
          h = n ? 'تظهر في القائمة أطباء <b>' + esc(brName(st.br)) + '</b> فقط (' + n + ').'
            : 'لا يوجد في <b>' + esc(brName(st.br)) + '</b> أطباء لهذا الاختيار حالياً. اختر فرعاً آخر أو «أي فرع».';
        }
        el.innerHTML = h ? '<div class="alert info" style="margin-bottom:12px">' + ic('info', 'sm') + '<div>' + h + '</div></div>' : '';
      }
      function timesHtml(day) {
        var by = {}, order = [];
        day.slots.forEach(function (s) { if (!by[s.branchId]) { by[s.branchId] = []; order.push(s.branchId); } by[s.branchId].push(s); });
        function chips(l) {
          return '<div class="sl-times">' + l.map(function (s) {
            var on = !!st.slot && st.slot.day === day.day && st.slot.start === s.start && st.slot.branchId === s.branchId;
            return '<button type="button" class="sl-t' + (on ? ' on' : '') + '" role="radio" aria-checked="' + on + '" data-act="sl-pick" data-day="' + esc(day.day) + '" data-start="' + esc(s.start) + '" data-br="' + esc(s.branchId) + '">' + esc(timeAr(s.start)) + '</button>';
          }).join('') + '</div>';
        }
        return order.map(function (bid) {
          var l = by[bid], am = l.filter(function (s) { return s.start < '12:00'; }), pm = l.filter(function (s) { return s.start >= '12:00'; });
          return '<div class="sl-grp">' + (order.length > 1 ? '<h4>' + ic('map-pin', 'sm') + esc(brName(bid)) + '</h4>' : '') +
            (am.length ? '<h5>صباحاً</h5>' + chips(am) : '') + (pm.length ? '<h5>مساءً</h5>' + chips(pm) : '') + '</div>';
        }).join('');
      }
      function slotsHtml() {
        var h = '<div class="fld" id="bk-slots"><label>الموعد <span class="muted">*</span></label>';
        if (st.slState === 'loading' || st.slState === 'idle') h += '<div class="skel" style="height:112px"></div>';
        else if (st.slState === 'error') h += '<div class="alert danger">' + ic('alert', 'sm') + '<div>تعذر تحميل المواعيد المتاحة الآن.</div></div><button type="button" class="btn ghost sm" data-act="sl-retry">إعادة المحاولة</button>';
        else {
          var days = freeDays();
          if (!days.length) h += '<div class="alert info">' + ic('info', 'sm') + '<div>لا توجد مواعيد متاحة لهذا الطبيب في الأيام القادمة' + (st.br ? ' في هذا الفرع' : '') + '. يمكنك إرسال طلب حجز ليتواصل معك المجمع.</div></div>';
          else {
            var cur = days.filter(function (d) { return d.day === st.day; })[0] || days[0];
            h += '<div class="sl-days" role="radiogroup" aria-label="اختر اليوم">' + days.map(function (d) {
              var w = dayWords(d.day), on = d.day === cur.day;
              return '<button type="button" class="sl-day' + (on ? ' on' : '') + '" role="radio" aria-checked="' + on + '" data-act="sl-day" data-day="' + esc(d.day) + '"><span>' + esc(w.w) + '</span><b>' + esc(w.d) + '</b><span class="mo">' + esc(w.m) + '</span></button>';
            }).join('') + '</div>' + timesHtml(cur);
            if (st.slot) h += '<div class="sl-pick" aria-live="polite">' + ic('check', 'sm') + '<div>موعدك المختار: ' + esc(DS.fmtDate(st.slot.day)) + ' · ' + esc(timeAr(st.slot.start)) + (brName(st.slot.branchId) ? ' — ' + esc(brName(st.slot.branchId)) : '') +
              (st.viaQamar ? '<div class="sm muted">رتّبه لك قمر. راجعه واكتب بياناتك ثم اضغط «تأكيد الحجز».</div>' : '') + '</div></div>';
          }
        }
        if (st.slNote) h += '<div class="alert warn" style="margin-top:10px">' + ic('info', 'sm') + '<div>' + esc(st.slNote) + '</div></div>';
        return h + '<button type="button" class="lnk" data-act="bk-mode" data-mode="request">لا يناسبني موعد؟ أرسل طلب حجز ليتواصل معك المجمع</button><div class="err" data-err="slot" hidden></div></div>';
      }
      function requestHtml() {
        return (schedDoc() ? '<button type="button" class="lnk" data-act="bk-mode" data-mode="slot">' + ic('calendar', 'sm') + 'اختر من المواعيد المتاحة لهذا الطبيب</button>' : '') +
          fld('date', 'التاريخ المفضل <span class="muted">(اختياري)</span>', '<input class="in" id="f-date" type="date" min="' + today + '" max="' + maxd + '" value="' + esc(st.date) + '">') +
          '<div class="fld"><label>الفترة المفضلة</label><div class="seg" role="radiogroup" aria-label="الفترة المفضلة">' + periodsList().map(function (pr) {
            return '<input type="radio" name="period" id="per-' + esc(pr.id) + '" value="' + esc(pr.id) + '"' + (pr.id === st.period ? ' checked' : '') + '><label for="per-' + esc(pr.id) + '">' + esc(pr.label) + '</label>';
          }).join('') + '</div><div class="err" data-err="period" hidden></div></div>';
      }
      function paintWhen() {
        var box = DS.$('#bk-when'); if (!box) return;
        var strip = box.querySelector('.sl-days'), sx = strip ? strip.scrollLeft : 0, sm = slotMode();
        st.pSched = schedDoc();
        box.innerHTML = sm ? slotsHtml() : requestHtml();
        var s2 = box.querySelector('.sl-days'); if (s2 && sx) s2.scrollLeft = sx;
        var on = s2 && s2.querySelector('.sl-day.on');
        if (on && !st.centered) {      // مرة واحدة بعد وصول المواعيد: نُظهر اليوم المختار (مثلاً عند العودة بعد الدخول) دون تحريك الصفحة نفسها
          st.centered = true;
          var a = on.getBoundingClientRect(), c = s2.getBoundingClientRect(); s2.scrollLeft += (a.left + a.width / 2) - (c.left + c.width / 2);
        }
        var hint = DS.$('#dr-hint'); if (hint) hint.textContent = schedDoc() ? (sm ? 'اختر الموعد من المواعيد المتاحة أدناه.' : 'سيراجع المجمع طلبك ويتواصل معك.') : 'الاختيار لا يضمن توفر الطبيب؛ يؤكد المجمع ذلك معك.';
        var lb = DS.$('#f-sl'); if (lb) lb.textContent = sm ? 'تأكيد الحجز' : 'إرسال طلب الحجز';
        paintLead();
      }
      /* جلب المواعيد المتاحة للطبيب (والفرع إن اختير). نتجاهل الردود المتأخرة إن تغيّر الاختيار */
      function loadSlots(after) {
        if (!schedDoc()) { st.sl = null; st.slState = 'idle'; st.slot = null; paintWhen(); return; }
        var my = ++st.seq; st.slState = 'loading'; paintWhen();
        DS.api.get('/slots?doctorId=' + encodeURIComponent(st.dr) + (st.br ? '&branchId=' + encodeURIComponent(st.br) : ''), { timeout: 10000 }).then(function (r) {
          if (my !== st.seq) return;
          st.sl = r.data; lastPol = r.data.policy || null; st.slState = 'ok';
          var days = freeDays();
          if (st.want) {
            var w = st.want, wd = days.filter(function (d) { return d.day === w.day; })[0];
            var hit = wd && wd.slots.filter(function (s) { return s.start === w.start && (!w.br || s.branchId === w.br); })[0];
            st.want = null;
            if (hit) { st.slot = { day: w.day, start: w.start, branchId: hit.branchId }; st.br = hit.branchId; br.innerHTML = optBr(); st.slNote = ''; st.viaQamar = true; }
            else { st.slNote = 'الموعد الذي رتّبه لك قمر لم يعد متاحاً. اختر موعداً آخر من المتاح.'; if (wd) st.day = w.day; }
          }
          if (st.slot) {
            var dd = days.filter(function (d) { return d.day === st.slot.day; })[0];
            var still = !!dd && dd.slots.some(function (s) { return s.start === st.slot.start && s.branchId === st.slot.branchId; });
            if (!still) { st.slot = null; st.slNote = 'الموعد الذي اخترته لم يعد متاحاً. اختر موعداً آخر.'; }
          }
          if (!st.day || !days.some(function (d) { return d.day === st.day; })) st.day = st.slot ? st.slot.day : (days[0] ? days[0].day : '');
          paintWhen();
          if (after) after();
        }).catch(function () { if (my !== st.seq) return; st.slState = 'error'; paintWhen(); });
      }

      DS.acts['sl-day'] = function (el) { st.day = el.getAttribute('data-day'); paintWhen(); return false; };
      DS.acts['sl-pick'] = function (el) {
        st.slot = { day: el.getAttribute('data-day'), start: el.getAttribute('data-start'), branchId: el.getAttribute('data-br') };
        st.day = st.slot.day; st.slNote = ''; st.viaQamar = false; st.br = st.slot.branchId; br.innerHTML = optBr();
        paintWhen(); return false;
      };
      DS.acts['sl-retry'] = function () { loadSlots(); return false; };
      DS.acts['bk-mode'] = function (el) {
        st.mode = el.getAttribute('data-mode') === 'request' ? 'request' : 'slot';
        if (st.mode === 'slot' && st.slState !== 'ok') loadSlots(); else paintWhen();
        return false;
      };

      sel.addEventListener('change', function () { st.sel = sel.value; var was = st.dr; dr.innerHTML = optDr(); br.innerHTML = optBr(); if (was !== st.dr) { st.slot = null; st.slNote = ''; st.mode = 'slot'; st.slState = 'idle'; loadSlots(); } paintInfo(); });
      dr.addEventListener('change', function () { st.dr = dr.value; st.slot = null; st.slNote = ''; st.mode = 'slot'; st.slState = 'idle'; br.innerHTML = optBr(); loadSlots(); paintInfo(); });
      br.addEventListener('change', function () {
        st.br = br.value; var was = st.dr; dr.innerHTML = optDr();          // الأطباء يُرشَّحون بالفرع؛ وإن لم يعد الطبيب المختار فيه يُفرَّغ اختياره
        if (was !== st.dr) { st.slot = null; st.slNote = ''; st.mode = 'slot'; st.slState = 'idle'; loadSlots(); } else if (slotMode()) loadSlots();
        paintInfo();
      });
      form.addEventListener('change', function (ev) {
        var t = ev.target;
        if (t.id === 'f-date') st.date = t.value;
        else if (t.name === 'period') st.period = t.value;
        else if (t.id === 'f-consent') st.consent = t.checked;
      });
      DS.$('#f-note').addEventListener('input', function (ev) { st.note = ev.target.value; });
      paintInfo();
      loadSlots(st.want ? function () { var el = DS.$('.sl-pick') || DS.$('#bk-slots'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
        : st.resumed && st.slot ? function () { var sb = DS.$('#f-submit'); if (sb && sb.scrollIntoView) sb.scrollIntoView({ block: 'center', behavior: 'smooth' }); } : null);

      /* بعد الدخول ينتهي الحجز بالكامل في هذه الصفحة: الرسالة الواضحة تحلّ محل النموذج */
      function finish(b, dup) {
        var list = DS.store.get('myBookings', []).filter(function (x) { return x.id !== b.id; });
        list.unshift(b); DS.store.set('myBookings', list.slice(0, 50));
        DS.bkDraft.clear(); syncHook = null;
        var rootEl = DS.$('#bkroot'); rootEl.setAttribute('data-done', b.id);
        if (b.slot) rootEl.innerHTML = apptDoneHtml(b, lastPol);
        else rootEl.innerHTML = '<div class="card" style="text-align:center"><div class="okmark">' + ic('check') + '</div>' +
          '<h2 style="font-size:1.25rem;font-weight:800">' + (dup ? 'لديك طلب مماثل قيد المعالجة' : 'تم استلام طلبك') + '</h2>' +
          '<p class="muted" style="margin-top:4px">رقم الطلب</p><div class="bk-id ltr" style="font-size:1.5rem;font-weight:800;letter-spacing:1px;color:var(--pri-d);text-align:center">' + esc(b.id) + '</div></div>' +
          '<div class="alert warn" style="margin-top:12px">' + ic('info', 'sm') + '<div><b>هذا ليس موعداً مؤكداً.</b> سيراجع فريق المجمع طلبك ويتواصل معك على الرقم الذي كتبته لتحديد الموعد. تابع حالة الطلب من صفحة «حسابي».</div></div>' +
          '<div class="card" style="margin-top:12px">' + summaryRows(b) + '</div>' +
          '<div class="grid2" style="margin-top:12px"><a class="btn pri" href="#/profile">متابعة الطلب</a><a class="btn out" href="#/">الرئيسية</a></div>' + fallbackButtons(b.branchId);
        root.scrollTo(0, 0);
        if (DS.notif && DS.notif.refreshBadge) DS.notif.refreshBadge();
      }
      /* الدخول مطلوب: نحفظ الاختيار ثم نذهب لشاشة الدخول/التسجيل، وبعدها يعود المراجع لهذه الصفحة نفسها باختياره */
      function saveDraft() {
        DS.bkDraft.set({ sel: st.sel, dr: st.dr, br: st.br, mode: st.mode, slot: st.slot, date: st.date, period: st.period, note: DS.$('#f-note').value, consent: DS.$('#f-consent').checked });
      }
      function toLogin() { saveDraft(); location.replace('#/login?next=' + encodeURIComponent('#/book?resume=1')); }
      /* كلمة مرور مؤقتة أصدرها المجمع: تُغيَّر أولاً ثم يعود المراجع لحجزه كما تركه */
      function toPassword() { saveDraft(); DS.toast('غيّر كلمة المرور المؤقتة أولاً'); location.replace('#/password?next=' + encodeURIComponent('#/book?resume=1')); }

      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        if (st.busy) return;
        clearErr();
        var sm = slotMode(), nl = needLogin(), fails = {}, name = '', phoneRaw = '', phone = null;
        if (!st.sel && !st.dr) fails.sel = 'اختر التخصص أو الخدمة';
        if (!nl) {
          name = DS.$('#f-name').value.replace(/\s+/g, ' ').trim(); phoneRaw = DS.$('#f-phone').value; phone = DS.normPhone(phoneRaw);
          if (name.length < 2 || (name.match(/[A-Za-zء-ي]/g) || []).length < 2) fails.name = 'اكتب الاسم (حرفان على الأقل)';
          if (!phone) fails.phone = 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)';
        }
        if (!DS.$('#f-consent').checked) fails.consent = 'يلزم الموافقة لإرسال الطلب';
        var date = sm ? '' : (DS.$('#f-date') || {}).value || '';
        if (sm && !st.slot) fails.slot = 'اختر موعداً من المواعيد المتاحة';
        if (date && (date < today || date > maxd)) fails.date = 'اختر تاريخاً من اليوم حتى 120 يوماً';
        if (Object.keys(fails).length) { showErr(fails); return; }
        if (!DS.cfg.demo && nl) { toLogin(); return; }
        if (!DS.cfg.demo && DS.auth.pw() && DS.auth.mustChange()) { toPassword(); return; }

        var per = sm ? 'any' : ((DS.$('input[name="period"]:checked', form) || {}).value || 'any');
        var body = {
          deviceId: DS.deviceId(), name: name, phone: phoneRaw, consent: true, period: per, date: date, note: DS.$('#f-note').value.trim(),
          specialtyId: st.sel.slice(0, 2) === 'sp' ? st.sel.slice(3) : '', serviceId: st.sel.slice(0, 2) === 'sv' ? st.sel.slice(3) : '',
          doctorId: st.dr, branchId: sm ? st.slot.branchId : st.br, platform: DS.platform(), source: 'app'
        };
        if (sm) body.slot = { day: st.slot.day, start: st.slot.start };
        if (name) DS.store.set('profile', { name: name, phone: phoneRaw });
        var btn = DS.$('#f-submit'); st.busy = true; btn.disabled = true; btn.setAttribute('aria-busy', 'true');
        DS.$('#bk-fail').innerHTML = '';

        if (DS.cfg.demo) {   // وضع التجربة: لا شيء يُرسل
          st.busy = false;
          DS.$('#bkroot').innerHTML = '<div class="card" style="text-align:center"><div class="okmark" style="background:var(--warn-l);color:var(--warn)">' + ic('info') + '</div>' +
            '<h2 style="font-size:1.2rem;font-weight:800">نسخة تجريبية</h2><p class="muted" style="margin-top:6px">لم يُرسَل أي طلب إلى أي جهة. في النسخة الحقيقية يصلك هنا رقم الطلب ويتابع فريق المجمع طلبك.</p></div>' +
            '<div class="card" style="margin-top:12px"><b style="display:block;margin-bottom:8px">ما كان سيُرسَل</b>' + summaryRows({ specialtyId: body.specialtyId, serviceId: body.serviceId, doctorId: body.doctorId, branchId: body.branchId, date: body.date, period: body.period }) + '</div>' +
            '<a class="btn out blk" style="margin-top:12px" href="#/">العودة للرئيسية</a>';
          root.scrollTo(0, 0);
          return;
        }

        DS.api.post('/bookings', body, { timeout: 15000 }).then(function (r) {
          finish(r.data.booking, !!r.data.duplicate);
        }).catch(function (e) {
          st.busy = false; btn.disabled = false; btn.removeAttribute('aria-busy');
          if (e && e.status === 401 && DS.auth.enabled()) { DS.auth.clear(); DS.toast('انتهت جلستك، سجّل الدخول من جديد'); toLogin(); return; }
          if (e && e.status === 403 && e.code === 'password_change_required') { DS.store.set('mustChange', true); toPassword(); return; }
          if (e && e.status === 422 && e.fields && Object.keys(e.fields).length) { showErr(e.fields); return; }
          /* موعد فاته أو سبقك إليه غيرك: نُبقي كل ما اخترته ونحدّث المواعيد ليختار موعداً آخر */
          if (e && (e.code === 'slot_taken' || e.code === 'slot_invalid')) { st.slot = null; st.slNote = e.message; loadSlots(function () { var sl = DS.$('#bk-slots'); if (sl && sl.scrollIntoView) sl.scrollIntoView({ block: 'center', behavior: 'smooth' }); }); return; }
          if (e && e.code === 'not_scheduled') { st.mode = 'request'; st.slot = null; paintWhen(); }
          var msg = e && e.code === 'network' ? 'تعذر الاتصال بالخادم. لم يُرسَل طلبك — تحقق من الإنترنت وحاول مرة أخرى، أو تواصل مع المجمع مباشرة.'
            : (e && e.message) || 'تعذر إرسال الطلب. لم يُرسَل شيء — حاول لاحقاً أو تواصل مع المجمع.';
          DS.$('#bk-fail').innerHTML = '<div class="alert danger">' + ic('alert', 'sm') + '<div>' + esc(msg) + '</div></div>' + fallbackButtons(st.br);
        });
      });
    }, 0);
    return html;
  }, { tab: 'none', title: 'طلب حجز', back: true });

  /* ================= حسابي ================= */
  /* هل يظهر زر الإلغاء؟ الطلب العادي (جديد/تم التواصل) وموعد بانتظار الدفع دائماً؛ والموعد المؤكد حتى مهلة الإلغاء ما لم تبدأ زيارته (والخادم يفرض ذلك فعلاً) */
  function canCancel(b) {
    if (b.status === 'new' || b.status === 'contacted') return true;
    if (b.slot && b.status === 'confirmed') { var t = Date.parse((b.slot && b.slot.cancelUntil) || ''); return !b.visit && t > Date.now(); }
    return false;
  }
  function bkCard(b) {
    var s = statusOf(b), held = !!(b.pay && b.pay.status === 'pending' && b.status !== 'cancelled');
    var h = '<div class="card bk" data-bk="' + esc(b.id) + '"><div class="top"><span class="id">' + esc(b.id) + '</span><span class="status ' + s.c + '">' + esc(s.t) + '</span></div>' + summaryRows(b);
    if (b.status === 'confirmed' && b.slot) h += '<div class="alert ok" style="margin-top:10px">' + ic('check', 'sm') + '<div><b>موعدك مؤكد.</b> ' + esc(apptLine(b)) + '</div></div>';
    else if (b.status === 'confirmed' && b.appointmentText) h += '<div class="alert ok" style="margin-top:10px">' + ic('check', 'sm') + '<div><b>موعدك:</b> ' + esc(b.appointmentText) + '</div></div>';
    else if (s.n) h += '<p class="xs muted" style="margin-top:8px">' + esc(s.n) + '</p>';
    if (held) h += payBox(b);
    if (stageText(b.visit)) h += '<div class="alert info" style="margin-top:10px">' + ic('stethoscope', 'sm') + '<div><b>' + esc(stageText(b.visit)) + '</b>' +
      (b.visit.summary ? '<div><a href="#/visits/' + esc(b.visit.id) + '">عرض ملخص الزيارة</a></div>' : '') + '</div></div>';
    if (canCancel(b)) { var lbl = b.slot ? 'إلغاء الموعد' : 'إلغاء الطلب'; h += '<button class="btn out sm" style="margin-top:10px" data-act="bk-cancel" data-id="' + esc(b.id) + '" data-lbl="' + lbl + '">' + lbl + '</button>'; }
    return h + '</div>';
  }

  DS.route('/profile', function () {
    var pf = profile(), s = D.settings(), fc = DS.files && DS.files.card ? DS.files.card() : '';
    var html = DS.auth.card() +
      /* الأهم لمن في المجمع: حالة طلبه وزيارته أولاً، ثم ملفه، ثم بياناته */
      '<section class="sec">' + U.sec('طلبات الحجز') + '<div id="bk-list">' + '<div class="skel" style="height:110px"></div>' + '</div></section>' +
      '<section class="sec" id="vs-sec" hidden>' + U.sec('زياراتي', '#/visits', 'الكل') + '<div id="vs-mini"></div></section>' +
      (fc ? '<div style="margin-top:20px">' + fc + '</div>' : '') + (DS.auth.pw() && DS.auth.token() ? '' : '<div class="card" style="margin-top:20px"><h2 style="font-weight:800;font-size:1.05rem;margin-bottom:10px">بياناتي</h2><form id="pf-form" class="form" novalidate>' +
      '<div class="fld"><label for="p-name">الاسم</label><input class="in" id="p-name" autocomplete="name" maxlength="60" value="' + esc(pf.name) + '"></div>' +
      '<div class="fld"><label for="p-phone">رقم الجوال</label><input class="in ltr" id="p-phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="05xxxxxxxx" value="' + esc(pf.phone) + '"><div class="err" data-err="p-phone" hidden></div></div>' +
      '<button class="btn ghost blk" type="submit">' + ic('check', 'sm') + 'حفظ</button></form>' +
      '<p class="xs muted" style="margin-top:8px">تُحفظ هذه البيانات على جوالك فقط لتعبئة الطلبات تلقائياً، ولا تُرسل إلا عند إرسال طلب حجز.</p></div>') +
      '<section class="sec">' + U.sec('الإشعارات') + '<a class="item" href="#/notifications">' + U.icoBox('bell') + '<div class="grow"><h3>إشعارات المجمع</h3><p class="sm muted">تحديثات طلباتك وتنبيهات المجمع.</p></div>' + ic('chevron-left', 'chev') + '</a>' +
      (DS.push && DS.push.supported() ? '<div class="card row" style="margin-top:10px"><span class="ico-box">' + ic('bell') + '</span><div class="grow"><b>تنبيهات الجوال</b><p class="sm muted" id="push-state">' + (DS.store.get('pushOptIn') ? 'مفعّلة' : 'غير مفعّلة') + '</p></div><button class="btn ghost sm" data-act="push-toggle">' + (DS.store.get('pushOptIn') ? 'تحديث' : 'تفعيل') + '</button></div>' : '') + '</section>' +
      '<section class="sec">' + U.sec('الخصوصية') + '<a class="item" href="#/privacy">' + U.icoBox('shield') + '<div class="grow"><h3>سياسة الخصوصية</h3></div>' + ic('chevron-left', 'chev') + '</a>' +
      (DS.auth.pw() && DS.auth.token() ? '' : '<div class="card" style="margin-top:10px"><b>حذف بياناتي</b><p class="sm muted" style="margin:4px 0 10px">يحذف بياناتك المحفوظة على جوالك ويزيل اسمك ورقمك من طلباتك على الخادم ويحذف إشعاراتك. لا يمكن التراجع.</p>' +
      '<button class="btn out sm" style="color:var(--danger);border-color:var(--danger)" data-act="del-data">' + ic('trash', 'sm') + 'حذف بياناتي</button></div>') + '</section>' +
      '<footer class="foot"><a href="#/about">عن ' + esc(s.shortName || 'المجمعات') + '</a><div class="xs">الإصدار ' + esc(DS.cfg.version) + (DS.cfg.demo ? ' · نسخة تجريبية' : '') + '</div></footer>';

    setTimeout(function () {
      var f = DS.$('#pf-form') || document.createElement('form');   // بلا نموذج محلي حين يكون المراجع مسجّلاً بحساب
      f.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var name = DS.$('#p-name').value.replace(/\s+/g, ' ').trim(), raw = DS.$('#p-phone').value.trim(), err = DS.$('[data-err="p-phone"]');
        if (raw && !DS.normPhone(raw)) { err.textContent = 'رقم الجوال غير صحيح (مثال: 05xxxxxxxx)'; err.hidden = false; return; }
        err.hidden = true; DS.store.set('profile', { name: name, phone: raw }); DS.toast('تم الحفظ على جوالك');
      });
      var box = DS.$('#bk-list');
      function draw(list, note) {
        if (!list.length) { box.innerHTML = U.empty(DS.cfg.demo ? 'لا توجد طلبات (نسخة تجريبية).' : 'لا توجد طلبات حجز بعد.', 'calendar') + '<a class="btn pri blk" href="#/book">' + ic('calendar-plus', 'sm') + 'اطلب حجزاً</a>'; return; }
        box.innerHTML = (note ? '<div class="alert warn" style="margin-bottom:10px">' + ic('info', 'sm') + '<div>' + esc(note) + '</div></div>' : '') + list.map(bkCard).join('');
      }
      if (DS.cfg.demo) { draw([]); return; }
      function loadVisits() {
        if (DS.auth.enabled() && !DS.auth.token()) return;
        V.list().then(function (l) {
          var sec = DS.$('#vs-sec'); if (!sec || !l.length) return;
          DS.$('#vs-mini').innerHTML = l.slice(0, 2).map(visitItem).join(''); sec.hidden = false;
        }).catch(function () { /* لا نزعج المراجع: القسم يبقى مخفياً */ });
      }
      loadVisits();
      pullBookings().then(function (l) {
        draw(l);
        watcher = { el: box, draw: function (l2) { draw(l2); loadVisits(); } }; tick();
      }).catch(function () { draw(DS.store.get('myBookings', []), 'تعذر تحديث الحالة الآن. هذه آخر بيانات وصلتنا، وقد تكون تغيّرت.'); });
    }, 0);
    return html;
  }, { tab: 'records', title: 'حسابي' });

  DS.acts['bk-cancel'] = function (el) {
    if (el.getAttribute('data-armed') !== '1') {
      el.setAttribute('data-armed', '1'); el.textContent = 'اضغط مرة أخرى لتأكيد الإلغاء'; el.style.color = 'var(--danger)'; el.style.borderColor = 'var(--danger)';
      setTimeout(function () { if (el.isConnected) { el.removeAttribute('data-armed'); el.textContent = el.getAttribute('data-lbl') || 'إلغاء الطلب'; el.style.color = ''; el.style.borderColor = ''; } }, 4000);
      return false;
    }
    el.disabled = true;
    DS.api.post('/bookings/' + encodeURIComponent(el.getAttribute('data-id')) + '/cancel', { deviceId: DS.deviceId() }).then(function (r) {
      var b = r.data.booking, card = el.closest('.bk');
      var l = DS.store.get('myBookings', []).map(function (x) { return x.id === b.id ? b : x; }); DS.store.set('myBookings', l);
      if (card) card.outerHTML = bkCard(b);
      DS.toast(b.slot ? 'أُلغي الموعد' : 'أُلغي الطلب');
    }).catch(function (e) { el.disabled = false; DS.toast(e && e.message ? e.message : 'تعذر الإلغاء الآن، تواصل مع المجمع'); });
    return false;
  };

  /* دفع مقدّم بمزوّد «تجريبي»: لا يُحصَّل أي مبلغ (الخادم يرفض الطلب أصلاً إن لم يكن المزوّد التجريبي مفعّلاً) */
  DS.acts['bk-pay'] = function (el) {
    if (el.disabled) return false;
    el.disabled = true;
    DS.api.post('/bookings/' + encodeURIComponent(el.getAttribute('data-id')) + '/pay', { deviceId: DS.deviceId() }, { timeout: 15000 }).then(function (r) {
      var b = r.data.booking, rootEl = DS.$('#bkroot'), card = el.closest('.bk');
      DS.store.set('myBookings', DS.store.get('myBookings', []).map(function (x) { return x.id === b.id ? b : x; }));
      if (rootEl && rootEl.getAttribute('data-done') === b.id) rootEl.innerHTML = apptDoneHtml(b, lastPol);
      else if (card) card.outerHTML = bkCard(b);
      DS.toast('تم تأكيد موعدك');
    }).catch(function (e) {
      el.disabled = false;
      DS.toast(e && e.message ? e.message : 'تعذر إتمام الدفع الآن، حاول مرة أخرى');
      if (e && e.code === 'expired') pullBookings().then(function () { DS.render(); }).catch(function () { /* نُبقي ما على الشاشة */ });
    });
    return false;
  };

  DS.acts['del-data'] = function (el) {
    if (el.getAttribute('data-armed') !== '1') {
      el.setAttribute('data-armed', '1'); el.lastChild.textContent = 'اضغط مرة أخرى لتأكيد الحذف';
      setTimeout(function () { if (el.isConnected) { el.removeAttribute('data-armed'); el.lastChild.textContent = 'حذف بياناتي'; } }, 4000);
      return false;
    }
    function clearLocal() {
      ['profile', 'myBookings', 'notifCache', 'notifSeen', 'pushOptIn', 'qamarHistory', 'deviceId'].forEach(function (k) { DS.store.del(k); });
      if (DS.notif) DS.notif.setBadge(0);
      DS.toast('تم حذف بياناتك'); DS.render();
    }
    if (DS.cfg.demo) { clearLocal(); return false; }
    DS.api.post('/devices/' + encodeURIComponent(DS.deviceId()) + '/delete').then(clearLocal).catch(function () {
      DS.toast('تعذر الحذف الآن. بياناتك على الجوال كما هي — جرّب عند توفر الاتصال.');
    });
    return false;
  };

  /* ================= زياراتي: ملخص ما سجّله الطبيب بعد انتهاء الزيارة (بلا ملاحظاته الداخلية) ================= */
  var V = DS.visits = {
    q: function () { return DS.auth.enabled() ? '' : '?deviceId=' + encodeURIComponent(DS.deviceId()); },   // مع الحساب يكفي التوكن؛ بدونه (وضع التجربة) يُعرَف الجهاز
    list: function () { return DS.api.get('/visits' + V.q(), { timeout: 10000 }).then(function (r) { return (r.data && r.data.visits) || []; }); },
    get: function (id) { return DS.api.get('/visits/' + encodeURIComponent(id) + V.q(), { timeout: 10000 }).then(function (r) { return r.data && r.data.visit; }); }
  };
  function visitItem(v) {
    return '<a class="item" href="#/visits/' + esc(v.id) + '">' + U.icoBox('stethoscope') + '<div class="grow"><h3>' + esc(v.diagnosis || 'زيارة') + '</h3><p class="sm muted">' + esc(DS.fmtDate(v.day)) + ' · ' + esc(v.doctorName) +
      (v.branchName ? ' · ' + esc(v.branchName) : '') + '</p></div>' + (v.rxCount ? '<span class="tag">وصفة ' + v.rxCount + '</span>' : '') + ic('chevron-left', 'chev') + '</a>';
  }
  function visitErr(box) {
    return function (e) {
      if (e && e.status === 401) { DS.auth.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); return; }
      box.innerHTML = e && e.status === 404 ? U.empty('لم نجد هذه الزيارة. قد لا يكون الطبيب أظهر ملخصها بعد.', 'stethoscope')
        : '<div class="alert danger">' + ic('alert', 'sm') + '<div>تعذر تحميل الزيارات الآن. تحقق من الاتصال وحاول لاحقاً.</div></div>';
    };
  }
  DS.route('/visits', function () {
    if (DS.cfg.demo) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (DS.auth.gate(location.hash)) return '';
    setTimeout(function () {
      var box = DS.$('#vs-box'); if (!box) return;
      V.list().then(function (l) {
        box.innerHTML = l.length ? l.map(visitItem).join('') : U.empty('لا توجد زيارات منتهية بعد. يظهر ملخص كل زيارة هنا بعد أن ينهيها الطبيب.', 'stethoscope');
      }).catch(visitErr(box));
    }, 0);
    return '<div class="alert info" style="margin-bottom:10px">' + ic('shield', 'sm') + '<div>هذه زياراتك أنت فقط. لا تشاركها مع أحد.</div></div><div id="vs-box"><div class="skel" style="height:110px"></div></div>';
  }, { tab: 'visits', title: 'زياراتي', back: true });

  /* قيم النتائج كما أدخلها القسم وبعد أن راجعها الطبيب ونشرها: صف لكل فحص (الاسم، النتيجة والوحدة، المعدل الطبيعي والتقييم) وتقرير نصي */
  var STTAG = { sent: 'gray', in_progress: 'info', resulted: 'gold', reviewed: 'ok', cancelled: 'danger' };
  var FLAGW = { normal: 'طبيعي', high: 'مرتفع', low: 'منخفض', critical: 'حرج' };
  function resRows(o) {
    var rows = (o.rows || []).map(function (r) {
      var f = FLAGW[r.flag] ? r.flag : '';
      return '<div class="rr ' + f + '"><span class="rn">' + esc(r.name) + '</span><span class="rv"><bdi class="num">' + esc(r.value) + '</bdi>' + (r.unit ? ' <bdi class="num xs muted">' + esc(r.unit) + '</bdi>' : '') + '</span>' +
        (r.ref || f ? '<span class="rf">' + (r.ref ? 'المعدل الطبيعي: <bdi class="num">' + esc(r.ref) + '</bdi>' : '') + (f ? ' <span class="tag ' + (f === 'normal' ? 'ok' : f === 'critical' ? 'danger' : 'gold') + '">' + FLAGW[f] + '</span>' : '') + '</span>' : '') + '</div>';
    }).join('');
    return (rows ? '<div class="rres">' + rows + '</div>' : '') + (o.text ? '<div class="rtext">' + DS.nl(o.text) + '</div>' : '');
  }
  function visitDetail(v) {
    var rx = (v.rx || []).map(function (r) {
      var meta = [r.dose, r.freq, r.duration].filter(Boolean).map(esc).join(' · ');
      return '<div class="vrx"><span class="ico-box">' + ic('pill') + '</span><div class="grow"><b>' + esc(r.drug) + '</b>' + (meta ? '<div class="sm">' + meta + '</div>' : '') + (r.note ? '<div class="xs muted">' + esc(r.note) + '</div>' : '') + '</div></div>';
    }).join('');
    var live = (v.orders || []).some(function (o) { return !!o.statusLabel; });   // طلبات ما قبل 0.9.0 بلا حالة
    var od = (v.orders || []).map(function (o) {
      var tag = o.statusLabel ? ' <span class="tag ' + (STTAG[o.status] || 'gray') + '">' + esc(o.statusLabel) + '</span>' : '';
      return '<div class="vrx"><span class="ico-box">' + ic(o.type === 'lab' ? 'flask' : 'scan') + '</span><div class="grow"><b>' + esc(o.name) + '</b>' + tag + '<div class="xs muted">' + (o.type === 'lab' ? 'تحليل' : 'أشعة') + (o.note ? ' · ' + esc(o.note) : '') + '</div>' +
        (o.released ? resRows(o) : o.status === 'reviewed' ? '<div class="xs muted" style="margin-top:6px">راجع الطبيب هذه النتيجة ولم يُظهرها في تطبيقك بعد؛ اسأل طبيبك عنها.</div>' : '') + '</div></div>';
    }).join('');
    return '<div class="card"><div class="row"><span class="ico-box">' + ic('stethoscope') + '</span><div class="grow"><b>' + esc(v.doctorName) + '</b><div class="xs muted">' + esc(DS.fmtDate(v.day)) + (v.branchName ? ' · ' + esc(v.branchName) : '') + '</div></div></div></div>' +
      (v.diagnosis ? '<section class="sec">' + U.sec('التشخيص') + '<div class="card">' + esc(v.diagnosis) + '</div></section>' : '') +
      '<section class="sec">' + U.sec('الوصفة') + (rx || '<div class="card muted sm">لا أدوية في هذه الزيارة.</div>') + '</section>' +
      '<section class="sec">' + U.sec('تحاليل وأشعة مطلوبة') + (od || '<div class="card muted sm">لا طلبات.</div>') +
      (od ? '<p class="xs muted" style="margin-top:6px">' + (live ? 'تظهر نتيجة كل طلب هنا وفي «نتائجي» بعد أن يراجعها الطبيب ويقرر إظهارها لك.' : 'نتائجها تظهر في «ملفاتي» عندما يرفعها المجمع إلى ملفك.') + '</p>' : '') + '</section>' +
      (v.advice ? '<section class="sec">' + U.sec('تعليمات الطبيب') + '<div class="card">' + DS.nl(v.advice) + '</div></section>' : '') +
      (v.followUp ? '<section class="sec">' + U.sec('موعد المراجعة') + '<div class="card">' + esc(v.followUp) + '</div></section>' : '') +
      '<div class="alert warn" style="margin-top:14px">' + ic('info', 'sm') + '<div>هذا ملخص للاطلاع كما سجّله الطبيب. الوصفة المعتمدة هي التي يسلّمها لك المجمع. التزم بتعليمات طبيبك ولا تغيّر جرعة دواء دون استشارته.</div></div>';
  }
  DS.route('/visits/:id', function (p) {
    if (DS.cfg.demo) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (DS.auth.gate(location.hash)) return '';
    setTimeout(function () {
      var box = DS.$('#vs-box'); if (!box) return;
      V.get(p.id).then(function (v) { box.innerHTML = v ? visitDetail(v) : ''; }).catch(visitErr(box));
    }, 0);
    return '<div id="vs-box"><div class="skel" style="height:160px"></div></div>';
  }, { tab: 'visits', title: 'ملخص الزيارة', back: true });

  /* ================= نتائجي: نتائج المختبر والأشعة التي راجعها الطبيب وقرر إظهارها (حساب موثّق، أو جهاز الحجز في وضع التجربة) ================= */
  DS.results = { list: function () { return DS.api.get('/results' + V.q(), { timeout: 10000 }).then(function (r) { return (r.data && r.data.results) || []; }); } };
  function resultCard(o) {
    return '<div class="card rcard"><div class="row"><span class="ico-box">' + ic(o.kind === 'lab' ? 'flask' : 'scan') + '</span><div class="grow"><b>' + esc(o.name) + '</b><div class="xs muted">' + esc(o.kindLabel) + ' · ' + esc(DS.fmtDate(o.day)) +
      (o.doctorName ? ' · ' + esc(o.doctorName) : '') + (o.branchName ? ' · ' + esc(o.branchName) : '') + '</div></div></div>' + resRows(o) + '</div>';
  }
  function resultsPage(p) {
    var kind = (p && p.kind) || '', TABS = [['', 'الكل'], ['lab', 'المختبر'], ['radiology', 'الأشعة']];
    if (DS.cfg.demo) { setTimeout(function () { location.replace('#/'); }, 0); return ''; }
    if (kind && kind !== 'lab' && kind !== 'radiology') { setTimeout(function () { location.replace('#/results'); }, 0); return ''; }
    if (DS.auth.gate(location.hash)) return '';
    setTimeout(function () {
      var box = DS.$('#rs-box'); if (!box) return;
      DS.results.list().then(function (l) {
        var list = kind ? l.filter(function (o) { return o.kind === kind; }) : l;
        box.innerHTML = (list.length ? list.map(resultCard).join('') : U.empty('لا توجد نتائج منشورة بعد. تظهر هنا نتائج التحاليل والأشعة بعد أن يراجعها طبيبك ويقرر إظهارها لك.', kind === 'radiology' ? 'scan' : 'flask')) +
          (kind && DS.files && DS.files.enabled() ? '<a class="btn out blk" style="margin-top:12px" href="#/files/' + kind + '">' + ic('file', 'sm') + 'ملفات PDF ' + (kind === 'lab' ? 'للمختبر' : 'للأشعة') + '</a>' : '') +
          '<div class="alert warn" style="margin-top:14px">' + ic('info', 'sm') + '<div>النتائج للاطلاع كما أدخلها القسم وراجعها طبيبك. تفسيرها وقرار العلاج عند طبيبك؛ لا تغيّر علاجك بناءً عليها دون استشارته.</div></div>';
      }).catch(function (e) {
        if (e && e.status === 401) { DS.auth.clear(); location.replace('#/login?next=' + encodeURIComponent(location.hash)); return; }
        box.innerHTML = '<div class="alert danger">' + ic('alert', 'sm') + '<div>تعذر تحميل النتائج الآن. تحقق من الاتصال وحاول لاحقاً.</div></div>';
      });
    }, 0);
    return '<div class="alert info" style="margin-bottom:10px">' + ic('shield', 'sm') + '<div>هذه نتائجك أنت فقط. لا تشاركها مع أحد.</div></div>' +
      '<nav class="rtabs" aria-label="نوع النتائج">' + TABS.map(function (t) { return '<a href="#/results' + (t[0] ? '/' + t[0] : '') + '"' + (t[0] === kind ? ' class="on" aria-current="page"' : '') + '>' + t[1] + '</a>'; }).join('') + '</nav>' +
      '<div id="rs-box"><div class="skel" style="height:110px"></div></div>';
  }
  DS.route('/results', resultsPage, { tab: 'records', title: 'نتائجي', back: true });
  DS.route('/results/:kind', resultsPage, { tab: 'records', title: 'نتائجي', back: true });

  /* ================= الإشعارات ================= */
  var N = DS.notif = {
    unread: 0,
    cached: function () { return DS.store.get('notifCache', []); },
    seen: function () { return DS.store.get('notifSeen', null); },
    setBadge: function (n) { N.unread = n; var b = DS.$('#nbadge'); if (b) { b.textContent = n > 9 ? '9+' : String(n); b.hidden = !n; } },
    fetch: function (since) {
      return DS.api.get('/notifications?deviceId=' + encodeURIComponent(DS.deviceId()) + '&since=' + (since || 0), { timeout: 8000 }).then(function (r) { return (r.data && r.data.notifications) || []; });
    },
    maxId: function (l, base) { return l.reduce(function (a, x) { return Math.max(a, x.id); }, base || 0); },
    refreshBadge: function () {
      if (DS.cfg.demo) return Promise.resolve();
      var seen = N.seen();
      if (seen == null) {   // أول تشغيل: لا نُظهر إشعارات قديمة كأنها جديدة
        return N.fetch(0).then(function (l) { DS.store.set('notifSeen', N.maxId(l)); N.setBadge(0); }).catch(function () {});
      }
      return N.fetch(seen).then(function (l) { N.setBadge(l.length); }).catch(function () {});
    },
    markSeen: function (l) { DS.store.set('notifSeen', N.maxId(l, N.seen() || 0)); N.setBadge(0); }
  };

  function ntItem(n, isNew, sample) {
    var icon = n.kind === 'booking' ? 'calendar' : n.kind === 'file' ? 'file' : n.kind === 'visit' ? 'stethoscope' : n.kind === 'result' ? 'flask' : 'bell';
    return '<div class="nt' + (isNew ? ' new' : '') + '"><span class="ico">' + ic(icon, 'sm') + '</span><div class="grow"><b>' + esc(n.title) + '</b>' + (sample ? ' <span class="tag gray">مثال</span>' : '') +
      (n.body ? '<p class="sm" style="margin-top:2px">' + DS.nl(n.body) + '</p>' : '') + '<p class="xs muted" style="margin-top:4px">' + esc(DS.fmtDateTime(n.created_at)) + '</p>' +
      (n.kind === 'booking' ? '<a class="sm" href="#/profile">عرض الطلب</a>' : '') +
      (n.kind === 'visit' ? (/^#\/visits\/v-[0-9a-f]{12}$/.test(n.ref || '') ? '<a class="sm" href="' + esc(n.ref) + '">عرض ملخص الزيارة</a>' : '<a class="sm" href="#/profile">عرض طلبي</a>') : '') + (n.kind === 'file' && /^#\/files\/[a-z]+$/.test(n.ref || '') ? '<a class="sm" href="' + esc(n.ref) + '">عرض الملف</a>' : '') + (n.kind === 'result' ? '<a class="sm" href="#/results">عرض النتائج</a>' : '') + '</div></div>';
  }

  DS.route('/notifications', function () {
    setTimeout(function () {
      var box = DS.$('#nlist'); if (!box) return;
      var seen = N.seen() || 0;
      function draw(list, stale) {
        box.innerHTML = (stale ? '<div class="alert warn" style="margin-bottom:10px">' + ic('info', 'sm') + '<div>تعذر التحديث الآن. هذه آخر إشعارات وصلتنا.</div></div>' : '') +
          (list.length ? list.map(function (n) { return ntItem(n, n.id > seen); }).join('') : U.empty('لا توجد إشعارات حالياً.', 'bell'));
      }
      if (DS.cfg.demo) {
        box.innerHTML = '<div class="alert warn" style="margin-bottom:10px">' + ic('info', 'sm') + '<div>نسخة تجريبية: هذه أمثلة لشكل الإشعارات، وليست رسائل حقيقية.</div></div>' +
          ntItem({ title: 'تحديث على طلب حجزك', body: 'سيظهر هنا عندما يغيّر فريق المجمع حالة طلبك.', kind: 'booking', created_at: new Date().toISOString() }, true, true) +
          ntItem({ title: 'إعلان من المجمع', body: 'يرسل المجمع تنبيهاته العامة من لوحة الإدارة.', kind: 'info', created_at: new Date().toISOString() }, false, true);
        return;
      }
      N.fetch(0).then(function (l) { DS.store.set('notifCache', l); draw(l); N.markSeen(l); }).catch(function () { draw(N.cached(), true); });
    }, 0);
    return '<div id="nlist"><div class="skel" style="height:78px"></div></div>';
  }, { tab: 'more', title: 'الإشعارات', back: true });

  /* ================= تنبيهات الجوال (تعمل داخل التطبيق الأصلي فقط — لم تُختبر هنا) ================= */
  DS.push = {
    plugin: function () { return DS.cap ? DS.cap('PushNotifications') : null; },
    supported: function () { return DS.isNative() && DS.cfg.push === true && !!DS.push.plugin(); },   // لا يظهر الزر إلا إذا بُني التطبيق بالتنبيهات (--push) فعلاً
    enable: function () {
      var PN = DS.push.plugin();
      if (!PN) return Promise.reject(new Error('unsupported'));
      return PN.requestPermissions().then(function (r) {
        if (!r || r.receive !== 'granted') throw new Error('denied');
        PN.addListener('registration', function (t) {
          DS.api.post('/devices', { deviceId: DS.deviceId(), platform: DS.platform(), pushToken: t.value }).catch(function () { /* تجاهل */ });
        });
        PN.addListener('registrationError', function () { DS.toast('تعذر تفعيل التنبيهات'); });
        PN.addListener('pushNotificationReceived', function () { N.refreshBadge(); });
        return PN.register();
      }).then(function () { DS.store.set('pushOptIn', true); });
    }
  };
  DS.acts['push-toggle'] = function (el) {
    DS.push.enable().then(function () { DS.toast('تم تفعيل التنبيهات'); var s = DS.$('#push-state'); if (s) s.textContent = 'مفعّلة'; })
      .catch(function (e) { DS.toast(e && e.message === 'denied' ? 'لم تُمنح صلاحية التنبيهات من إعدادات الجهاز' : 'تعذر تفعيل التنبيهات'); });
    return false;
  };

  /* ================= سياسة الخصوصية (نسخة من نص صفحة الخادم /privacy؛ اختبار test_privacy_text_matches_app_copy يمنع اختلافهما) ================= */
  DS.route('/privacy', function () {
    var s = D.settings(), name = esc(s.name || 'المجمع'), ph = D.mainPhone(), ai = !!(D.ds && D.ds.qamar && D.ds.qamar.externalAi);
    return '<article class="card prose"><h2>ما الذي نجمعه؟</h2><ul>' +
      (DS.auth.pw() ? '<li>' + PRIVACY_PW + '</li>' : DS.auth.enabled() ? '<li>عند إنشاء حساب: الاسم ورقم الجوال والجنس وتاريخ الميلاد، ورقم الهوية/الإقامة إن أدخلته (اختياري). ويُرسَل إليك رمز تحقق في رسالة نصية عبر مزوّد خدمة رسائل. يمكنك حذف حسابك من صفحة «طلباتي وبياناتي». ملفاتك الطبية (PDF) التي يرفعها موظفو المجمع إلى حسابك (كنتائج المختبر والأشعة): تُحفظ على خادم المجمع بصورة خاصة ولا يراها إلا أنت وموظفو المجمع المخوَّلون، وتبقى لدى المجمع وفق أنظمة حفظ السجلات الطبية حتى لو حذفت حسابك.</li>' : '') +
      '<li>عند إرسال طلب حجز: الاسم ورقم الجوال والتخصص/الطبيب/الفرع المطلوب والتاريخ المفضل وملاحظتك الاختيارية.</li>' +
      '<li>معرّف عشوائي للجهاز لربط طلباتك وإشعاراتك بجهازك، دون أي معلومات هوية.</li>' +
      '<li>عند زيارتك للمجمع: يسجّل الاستقبال وصولك، ويسجّل الطبيب التشخيص والتعليمات والوصفة وما يطلبه من تحاليل وأشعة، ويدخل موظفو المختبر والأشعة نتائجها ثم يراجعها الطبيب. بعد انتهاء الزيارة يظهر لك في التطبيق ملخصها إن اعتمد الطبيب إظهاره، وتظهر لك النتائج بعد أن يراجعها الطبيب ويقرر إظهارها، دون ملاحظاته الداخلية، ولا يطّلع عليه إلا أنت وموظفو المجمع المخوَّلون. وتبقى سجلات الزيارة لدى المجمع وفق أنظمة حفظ السجلات الطبية حتى لو حذفت بياناتك من التطبيق.</li>' +
      '<li>أسئلة المساعد «قمر» التي لم يفهمها بشكل كافٍ' + (ai ? ' (وكذلك ما أُرسل منها للمزوّد الخارجي)' : '') + ' تُحفظ مختصرة بعد إخفاء الأرقام والبريد، لتحسين الإجابات، ويُحذف الأقدم تلقائياً.</li>' +
      (ai ? '<li>المساعد «قمر» مفعَّل حالياً بخدمة ذكاء اصطناعي خارجية للأسئلة التي لا يجيب عنها من بيانات المجمع: يُرسَل إلى المزوّد نص سؤالك وآخر رسائل المحادثة فقط، بعد استبدال الأرقام الطويلة والبريد الإلكتروني برموز، ولا يُرسَل إليه الاسم ولا الجوال المسجّلان في طلبات الحجز. قد تُعالَج هذه النصوص خارج المملكة بحسب مزوّد الخدمة، فننصحك بعدم كتابة معلومات شخصية أو تفاصيل طبية في المحادثة.</li>' : '') + '</ul>' +
      '<h2>لماذا؟</h2><p>لمعالجة طلبك والتواصل معك لتأكيد الموعد، وتنظيم زيارتك وتسجيلها طبياً، وإرسال إشعارات تخص طلباتك وزياراتك، وتحسين خدمة المساعد.</p>' +
      '<h2>مع من نشارك بياناتك؟</h2><p>لا نبيع بياناتك ولا نشاركها لأغراض إعلانية. تصل بيانات الطلب إلى موظفي ' + name + ' المسؤولين عن المواعيد، وتصل بيانات الزيارة إلى الطبيب المعالج وموظفي الاستقبال فقط، ويرى موظفو المختبر والأشعة الطلبات الموجّهة لقسمهم فقط (اسمك وعمرك ورقم ملفك واسم الفحص وملاحظة الطبيب عليه) دون التشخيص والوصفة.</p>' +
      '<h2>حقوقك</h2><p>تستطيع من صفحة «حسابي» في التطبيق إلغاء طلباتك وحذف بياناتك من الخادم' + (ph ? '، أو الاتصال بنا على <span class="ltr" style="display:inline-block">' + esc(ph) + '</span>' : '') + '.</p>' +
      '<h2>تنبيه طبي</h2><p>المساعد «قمر» لا يقدّم تشخيصاً ولا وصفات علاجية. في الحالات الطارئة اتصل بالإسعاف ' + esc(s.emergencyNumber || '997') + '.</p></article>';
  }, { tab: 'more', title: 'سياسة الخصوصية', back: true });
})(window);
