/* اختبار «الغراء» بين التطبيق وغلاف Capacitor بدون جهاز: يبني www بالسكربت الفعلي ويشغّله بأصل منفصل عن الخادم
   (كما في التطبيق الأصلي) ويحاكي كائن Capacitor والإضافات (Browser, App, PushNotifications).
   مهم: هذا لا يثبت عمل البناء الأصلي على iOS/Android — يثبت فقط أن كود الواجهة يستدعي الإضافات صحيحاً ويتصل بالخادم عبر الأصول.
   NODE_PATH=<playwright> node tools/e2e_native_glue.js [BASE_URL]      (يتطلب خادماً يعمل على BASE_URL)                       */
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const BASE = process.argv[2] || 'http://127.0.0.1:8090';
const PORT = 8092;
const ROOT = path.join(__dirname, '..');
const WWW = fs.mkdtempSync(path.join(os.tmpdir(), 'ds-www-'));
const SHOTS = path.join(ROOT, 'qa', 'shots');
let fails = 0, passes = 0;
function ok(c, m) { if (c) { passes++; console.log('PASS', m); } else { fails++; console.log('FAIL', m); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const prep = (...a) => spawnSync('node', [path.join(ROOT, 'mobile', 'scripts', 'prepare-www.js'), ...a], { encoding: 'utf8', cwd: os.tmpdir() });
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };

(async () => {
  /* ---------- سكربت التجهيز: يرفض العناوين الخطرة ---------- */
  for (const [args, why] of [[[], 'بلا --api'], [['--api', 'http://example.com'], 'http غير محلي'], [['--api', 'http://127.0.0.1:8090'], 'http محلي بلا --dev'],
    [['--api', 'https://x.example.com/'], '/ في الآخر'], [['--api', 'https://x.example.com/api'], 'مسار إضافي'], [['--api', 'https://u:p@x.example.com'], 'بيانات دخول داخل العنوان'],
    [['--api', 'not a url'], 'عنوان غير صالح']]) {
    const r = prep(...args, '--out', path.join(WWW, 'bad'));
    ok(r.status === 1 && !fs.existsSync(path.join(WWW, 'bad')), 'prepare-www يرفض: ' + why);
  }
  const good = prep('--api', BASE, '--dev', '--push', '--out', WWW + '/site', '--build', 't1');
  ok(good.status === 0, 'prepare-www ينجح مع عنوان تطوير محلي: ' + (good.stdout || good.stderr).trim());
  const site = WWW + '/site';
  ok(!fs.existsSync(site + '/sw.js') && !fs.existsSync(site + '/manifest.webmanifest'), 'لا sw.js ولا manifest داخل التطبيق الأصلي');
  ok(!/rel="manifest"/.test(fs.readFileSync(site + '/index.html', 'utf8')), 'وسم manifest محذوف من index.html');
  ok(/"apiBase":"http:\/\/127\.0\.0\.1:8090"/.test(fs.readFileSync(site + '/config.js', 'utf8')) && /"demo":false/.test(fs.readFileSync(site + '/config.js', 'utf8')), 'config.js يحمل عنوان الخادم ويعطّل الوضع التجريبي');
  const https = prep('--api', 'https://dar.example.com', '--out', WWW + '/prod');
  ok(https.status === 0 && /"apiBase":"https:\/\/dar\.example\.com"/.test(fs.readFileSync(WWW + '/prod/config.js', 'utf8')), 'عنوان https عادي مقبول');
  ok(/"push":false/.test(fs.readFileSync(WWW + '/prod/config.js', 'utf8')) && /"push":true/.test(fs.readFileSync(site + '/config.js', 'utf8')), 'التنبيهات مخفية افتراضياً ولا تُفعَّل إلا بـ --push');

  /* ---------- نخدم www على localhost:8092 (أصل مختلف عن الخادم) ---------- */
  const srv = http.createServer((req, res) => {
    let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html';
    const f = path.join(site, p);
    if (!f.startsWith(site) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.statusCode = 404; return res.end('nf'); }
    res.setHeader('Content-Type', MIME[path.extname(f)] || 'application/octet-stream'); res.end(fs.readFileSync(f));
  });
  await new Promise((r) => srv.listen(PORT, '127.0.0.1', r));

  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'ar-SA', timezoneId: 'Asia/Riyadh' });
  const page = await ctx.newPage();
  const errors = [], posts = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('request', (r) => { if (r.method() === 'POST') posts.push({ url: r.url(), body: r.postData() }); });
  await page.addInitScript(() => {
    window.__calls = { browser: [], exit: 0, reg: 0, listeners: {}, opened: [], shared: [], shareFail: false };
    window.open = function () { window.__calls.opened.push([].slice.call(arguments)); return null; };
    window.Capacitor = {
      isNativePlatform: () => true, getPlatform: () => 'ios',
      Plugins: {
        Browser: { open: (o) => { window.__calls.browser.push(o.url); return Promise.resolve(); } },
        Share: { share: (o) => { window.__calls.shared.push(o); return window.__calls.shareFail ? Promise.reject(new Error('boom')) : Promise.resolve({ activityType: 'x' }); } },
        App: { addListener: (n, cb) => { window.__calls.listeners['App:' + n] = cb; return Promise.resolve({ remove() {} }); }, exitApp: () => { window.__calls.exit++; } },
        PushNotifications: {
          requestPermissions: () => Promise.resolve({ receive: 'granted' }),
          addListener: (n, cb) => { window.__calls.listeners['PN:' + n] = cb; return Promise.resolve({ remove() {} }); },
          register: () => { window.__calls.reg++; return Promise.resolve(); }
        }
      }
    };
  });
  const go = async (h) => { await page.evaluate((x) => { location.hash = x; }, h); await sleep(300); };

  const t0 = Date.now();
  await page.goto('http://localhost:' + PORT + '/', { waitUntil: 'load' });
  ok(await page.locator('#app .splash .sp-mark').count() === 1, 'شاشة البداية المتحركة تظهر عند فتح التطبيق الأصلي');
  await page.waitForSelector('.tabs', { timeout: 8000 });
  const heldMs = Date.now() - t0;
  ok(heldMs >= 1700 && heldMs < 5000, 'التطبيق الأصلي يُبقي شاشة البداية ~1.8 ثانية على الأقل ثم يدخل (' + heldMs + 'ms)');
  await page.waitForFunction(() => window.DS && DS.data && DS.data.source === 'network', null, { timeout: 8000 });
  ok(await page.evaluate(() => DS.cfg.apiBase === 'http://127.0.0.1:8090' && DS.cfg.build === 't1' && DS.isNative() && DS.platform() === 'ios'), 'التطبيق يعمل كتطبيق أصلي (iOS محاكى) ويقرأ إعدادات الخادم');
  ok(true, 'البيانات تُحدَّث من الخادم عبر أصل مختلف (CORS): ' + await page.evaluate(() => DS.data.source));
  ok((await page.evaluate(() => navigator.serviceWorker ? navigator.serviceWorker.getRegistrations().then((r) => r.length) : 0)) === 0, 'لا يُسجَّل Service Worker داخل التطبيق الأصلي');

  /* ---------- الروابط الخارجية عبر Browser ---------- */
  await go('#/contact');
  const wa = page.locator('a.btn.wa').first();
  const waUrl = await wa.getAttribute('data-url');
  await wa.click(); await sleep(200);
  const c1 = await page.evaluate(() => window.__calls);
  ok(c1.browser.length === 1 && c1.browser[0] === waUrl && /^https:\/\/wa\.me\/\d+/.test(waUrl) && c1.opened.length === 0, 'واتساب يفتح عبر إضافة Browser لا window.open: ' + waUrl);

  /* ---------- زر الرجوع في أندرويد ---------- */
  ok(await page.evaluate(() => typeof window.__calls.listeners['App:backButton'] === 'function'), 'تسجيل مستمع زر الرجوع');
  await go('#/doctors'); await go('#/specialties');
  await page.evaluate(() => window.__calls.listeners['App:backButton']()); await sleep(300);
  ok(await page.evaluate(() => DS.current().path) === '/doctors', 'الرجوع من التخصصات يعود إلى الأطباء');
  await page.evaluate(() => window.__calls.listeners['App:backButton']()); await sleep(300);
  await page.evaluate(() => window.__calls.listeners['App:backButton']()); await sleep(300);
  ok((await page.evaluate(() => DS.current().path)) === '/' && (await page.evaluate(() => window.__calls.exit)) >= 0, 'الرجوع المتتالي يصل للرئيسية');
  const exitBefore = await page.evaluate(() => window.__calls.exit);
  await page.evaluate(() => window.__calls.listeners['App:backButton']()); await sleep(200);
  ok(await page.evaluate(() => window.__calls.exit) === exitBefore + 1, 'الرجوع من الرئيسية يخرج من التطبيق');
  await page.locator('.qm-in').click(); await page.waitForSelector('.sheet');
  await page.evaluate(() => window.__calls.listeners['App:backButton']()); await sleep(300);
  ok((await page.locator('.sheet').count()) === 0 && (await page.evaluate(() => window.__calls.exit)) === exitBefore + 1, 'الرجوع أثناء فتح قمر يغلق النافذة ولا يخرج');

  /* ---------- الحجز يرسل المنصة ---------- */
  await go('#/book?sp=dental');
  await page.fill('#f-name', 'اختبار غلاف');
  await page.fill('#f-phone', '0501234567');
  await page.locator('#f-consent').check();
  await page.locator('#f-submit').click();
  await page.waitForSelector('.okmark', { timeout: 8000 });
  const bk = posts.find((p) => /\/api\/v1\/bookings$/.test(p.url));
  ok(bk && JSON.parse(bk.body).platform === 'ios' && JSON.parse(bk.body).source === 'app', 'طلب الحجز يحمل platform=ios و source=app إلى ' + (bk && new URL(bk.url).origin));
  ok(/^DS-[A-Z0-9]{6}$/.test((await page.locator('.bk-id').innerText()).trim()), 'رقم الطلب الحقيقي من الخادم');

  /* ---------- التنبيهات ---------- */
  await go('#/profile');
  const pt = page.locator('[data-act="push-toggle"]');
  ok(await pt.count() === 1, 'زر تفعيل التنبيهات يظهر لأن الإضافة متاحة والبناء بـ --push');
  ok(await page.evaluate(() => { DS.cfg.push = false; const r = DS.push.supported(); DS.cfg.push = true; return r === false; }), 'بدون --push لا يُعرض الزر حتى لو كانت الإضافة موجودة');
  await pt.click();
  await page.waitForFunction(() => window.__calls.listeners['PN:registration'] && window.__calls.reg === 1, null, { timeout: 4000 });
  await page.evaluate(() => window.__calls.listeners['PN:registration']({ value: 'TEST_TOKEN_123' }));
  await sleep(500);
  const dv = posts.find((p) => /\/api\/v1\/devices$/.test(p.url) && /TEST_TOKEN_123/.test(p.body || ''));
  ok(!!dv && JSON.parse(dv.body).platform === 'ios' && /^dev_/.test(JSON.parse(dv.body).deviceId), 'رمز التنبيه يُسجَّل في الخادم مع المنصة ومعرّف الجهاز');
  ok((await page.locator('#toast').innerText()).includes('تم تفعيل'), 'رسالة تأكيد تفعيل التنبيهات');

  /* ---------- مشاركة التطبيق عبر إضافة Share الأصلية ---------- */
  await go('#/more');
  await page.locator('[data-act="share"]').click(); await sleep(300);
  const sh = await page.evaluate(() => window.__calls.shared);
  ok(sh.length === 1 && /^https:\/\//.test(sh[0].url) && sh[0].title && sh[0].dialogTitle, 'مشاركة التطبيق تستدعي Share.share بعنوان ورابط https: ' + JSON.stringify(sh[0] && sh[0].url));
  ok((await page.evaluate(() => window.__calls.opened.length)) === 0, 'المشاركة لا تفتح نوافذ جديدة');
  await page.evaluate(() => { window.__calls.shareFail = true; window.__copied = null; navigator.clipboard.writeText = (t) => { window.__copied = t; return Promise.resolve(); }; });
  await page.locator('[data-act="share"]').click(); await sleep(500);
  ok(/^https:\/\//.test(await page.evaluate(() => window.__copied || '')), 'فشل Share الأصلي → ينسخ الرابط بدل ترك المستخدم بلا نتيجة');
  await page.evaluate(() => { window.__calls.shareFail = false; });

  /* ---------- الزر المركزي مع زر الرجوع الأصلي ---------- */
  await go('#/');
  await page.locator('.tab.cta').click(); await page.waitForSelector('#qaroot .sheet');
  const exitNow = await page.evaluate(() => window.__calls.exit);
  await page.evaluate(() => window.__calls.listeners['App:backButton']()); await sleep(300);
  ok((await page.locator('#qaroot').count()) === 0 && (await page.evaluate(() => window.__calls.exit)) === exitNow, 'زر الرجوع الأصلي يغلق الإجراءات السريعة ولا يخرج من التطبيق');

  /* ---------- هوامش الأمان (Capacitor 8 يحقن --safe-area-inset-*) ---------- */
  await go('#/');
  await page.evaluate(() => { document.documentElement.style.setProperty('--safe-area-inset-top', '30px'); document.documentElement.style.setProperty('--safe-area-inset-bottom', '20px'); });
  await sleep(200);
  const pads = await page.evaluate(() => ({ top: getComputedStyle(document.querySelector('.bar')).paddingTop, bottom: getComputedStyle(document.querySelector('.tabs')).paddingBottom }));
  ok(pads.top === '30px' && pads.bottom === '20px', 'الشريط العلوي والسفلي يحترمان هوامش أندرويد المحقونة: ' + JSON.stringify(pads));
  const gt = await page.evaluate(() => { const rib = document.querySelector('.ribbon'), b = document.querySelector('.bar').getBoundingClientRect(); return { hbn: Math.round(document.querySelector('.hbn').getBoundingClientRect().top), under: Math.round((rib && !rib.hidden ? rib.getBoundingClientRect().bottom : b.bottom)) }; });
  ok(gt.hbn === gt.under, 'بانر الرئيسية يبدأ مباشرة تحت الشريط العلوي مع هوامش أندرويد (' + gt.hbn + ' = ' + gt.under + ')');
  await page.screenshot({ path: path.join(SHOTS, 'n01-native-safe-area.png') });

  ok(errors.length === 0, 'لا أخطاء جافاسكربت/CSP ' + (errors.length ? JSON.stringify(errors.slice(0, 3)) : ''));
  await browser.close(); srv.close();
  fs.rmSync(WWW, { recursive: true, force: true });
  console.log('\nالنتيجة: ' + passes + ' ناجح، ' + fails + ' فاشل');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('خطأ في الاختبار:', e); process.exit(2); });
